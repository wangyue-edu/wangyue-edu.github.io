#include <iostream>  
#include <queue>  
#include <vector>  
#include <algorithm>  
using namespace std;  
  
// 定义挂号记录结构体  
struct Record {  
    string name;       // 患者姓名  
    int time;          // 挂号时间  
    int priority;      // 优先级  
    bool online;       // 是否网上挂号  
    bool need_check;   // 是否需要去检查  
      
    // 构造函数，初始化need_check为false  
    Record(string n, int t, bool o) : name(n), time(t), online(o), need_check(false) {  
        if (online) {  
            priority = time - 60; // 网上挂号优先级提前60分钟  
        } else {  
            priority = time; // 现场挂号优先级与挂号时间相同  
        }  
    }  
};  
  
// 比较函数，用于计算优先级  
bool cmp(const Record& a, const Record& b) {  
    if (a.priority != b.priority) {  
        return a.priority > b.priority;  
    } else {  
        return a.time < b.time;  
    }  
}  
  
int main() {  
    int n; // 挂号记录数量  
    cin >> n;  
      
    // 读入挂号记录并进行初步处理  
    vector<Record> records(n);  
    for (int i = 0; i < n; i++) {  
        string name;  
        int time, online;  
        cin >> name >> time >> online >> records[i].need_check;  
        records[i] = Record(name, time, online);  
    }  
      
    // 将挂号记录按优先级排序  
    sort(records.begin(), records.end(), cmp);  
      
    // 将排序后的挂号记录加入优先队列中  
    priority_queue<Record> q;  
    for (const auto& r : records) {  
        q.push(r);  
    }  
      
    // 等待检查结果的队列  
    deque<Record> wait_check; // 使用deque代替queue以优化性能  
      
    // 按照打卡顺序输出看病顺序  
    cout << "看病顺序：" << endl;  
    while (!q.empty()) {  
        Record r = q.top();  
        q.pop();  
        cout << r.name << endl;  
        if (r.need_check) {  
            // 患者需要去检查，将其加入等待检查结果的队列中，并从优先队列中移除  
            wait_check.push_back(r); // 使用push_back代替push以优化性能  
        }  
    }  
      
    // 处理等待检查结果的患者  
    while (!wait_check.empty()) {  
        Record r = wait_check.front();  
        wait_check.pop_front(); // 使用pop_front代替pop以优化性能  
        cout << r.name << "检查结果已出，等待叫号..." << endl;  
        // 将患者重新加入优先队列中，按照原来的优先级进行排序  
        q.push(r);  
    }  
      
    cout << "程序运行完毕。" << endl;   
}
