#pragma once

#include <QString>
#include <QStringList>
#include <QRegularExpression>

namespace redim {

/**
 * @brief AntiPhishing: 反钓鱼与恶意链接检测引擎
 * 对应脚本: https://github.com/tsurumi-yizhou/anti-fishing
 */
class AntiPhishing {
public:
    struct CheckResult {
        bool isDangerous{false};
        QString matchedPattern;
        QString warningMessage;
    };

    static CheckResult inspectUrl(const QString& url);
    static QString sanitizeTextWithWarnings(const QString& text);

private:
    static const QStringList s_suspiciousTlds;
    static const QStringList s_phishingKeywords;
};

} // namespace redim
