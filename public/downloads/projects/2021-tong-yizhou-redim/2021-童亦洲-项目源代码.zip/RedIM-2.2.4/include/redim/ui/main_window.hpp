#pragma once

#include <QMainWindow>
#include <QListWidget>
#include <QTextBrowser>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QSplitter>
#include <QVBoxLayout>
#include "redim/models/chat_session.hpp"

namespace redim {

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override = default;

private slots:
    void onSendMessageClicked();
    void onSelectImageClicked();
    void onSessionSelected(int index);
    void refreshSessionList();
    void handleIncomingTextMessage(qint64 senderId, qint64 targetId, const QString& name, const QString& text, const QDateTime& time);
    void handleIncomingImageMessage(qint64 senderId, qint64 targetId, const QString& name, const QString& url, const QDateTime& time);

private:
    void setupUi();
    void applyCustomStyles();
    void appendChatMessageHtml(const ChatMessage& msg);

    QListWidget* m_sessionList{nullptr};
    QTextBrowser* m_chatHistoryView{nullptr};
    QTextEdit* m_inputEdit{nullptr};
    QPushButton* m_sendBtn{nullptr};
    QPushButton* m_imageBtn{nullptr};
    QLabel* m_chatTitleLabel{nullptr};
    QLabel* m_statusBadge{nullptr};

    qint64 m_currentActiveTarget{0};
};

} // namespace redim
