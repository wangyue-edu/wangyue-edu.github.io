#pragma once

#include <QObject>
#include <QString>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QWebSocket>
#include <QTimer>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <memory>

namespace redim {

class MiraiClient : public QObject {
    Q_OBJECT

public:
    explicit MiraiClient(const QString& host, quint16 port, const QString& verifyKey, qint64 qqNumber, QObject* parent = nullptr);
    ~MiraiClient() override;

    void startConnection();
    void stopConnection();

    // 消息发送 API
    void sendFriendTextMessage(qint64 friendQq, const QString& message);
    void sendGroupTextMessage(qint64 groupNumber, const QString& message);

    bool isConnected() const { return m_connected; }
    QString sessionKey() const { return m_sessionKey; }

signals:
    void authenticated(const QString& sessionKey);
    void connectionLost(const QString& reason);
    void messageDispatched();

private slots:
    void onWebSocketConnected();
    void onWebSocketDisconnected();
    void onTextMessageReceived(const QString& message);
    void sendHeartbeat();

private:
    void verifyAuth();
    void bindSession();
    void parseIncomingEvent(const QJsonObject& root);
    void parseMessageChain(const QJsonObject& data, qint64 senderId, const QString& senderName, qint64 targetId);

    QString m_host;
    quint16 m_port;
    QString m_verifyKey;
    qint64 m_qqNumber;
    QString m_sessionKey;
    bool m_connected{false};

    QNetworkAccessManager* m_httpManager{nullptr};
    QWebSocket* m_webSocket{nullptr};
    QTimer* m_heartbeatTimer{nullptr};
};

} // namespace redim
