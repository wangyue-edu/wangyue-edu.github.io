#pragma once

#include <QObject>
#include <QString>
#include <QJsonObject>
#include <QDateTime>
#include <functional>
#include <memory>

namespace redim {

enum class EventType {
    Connected,
    Disconnected,
    AuthSuccess,
    AuthFailed,
    TextMessageReceived,
    ImageMessageReceived,
    MessageSentSuccess,
    MessageSentFailed,
    SessionUpdated,
    PhishingUrlDetected
};

struct EventPacket {
    EventType type;
    qint64 senderId{0};
    qint64 targetId{0};
    QString senderName;
    QString content;
    QString imageUrl;
    QDateTime timestamp;
    QJsonObject rawPayload;
};

/**
 * @brief MessageBus: 全局事件总线与数据中心
 * 利用 Qt 信号槽机制与 C++17 Lambda 表达式实现模块间完全解耦
 */
class MessageBus : public QObject {
    Q_OBJECT

public:
    static MessageBus& instance();

    // 发布通用事件
    void publish(const EventPacket& packet);

    // 辅助快捷事件投递
    void emitTextMessage(qint64 senderId, qint64 targetId, const QString& senderName, 
                         const QString& text, const QDateTime& time);
    void emitImageMessage(qint64 senderId, qint64 targetId, const QString& senderName, 
                          const QString& imageUrl, const QDateTime& time);
    void emitSessionUpdate(qint64 targetId);
    void emitPhishingAlert(const QString& url, const QString& threatType);

signals:
    void eventDispatched(const EventPacket& packet);
    void textMessageArrived(qint64 senderId, qint64 targetId, const QString& name, const QString& text, const QDateTime& time);
    void imageMessageArrived(qint64 senderId, qint64 targetId, const QString& name, const QString& url, const QDateTime& time);
    void connectionStateChanged(bool isConnected);
    void phishingWarningTriggered(const QString& url, const QString& reason);

private:
    explicit MessageBus(QObject* parent = nullptr);
    ~MessageBus() override = default;

    MessageBus(const MessageBus&) = delete;
    MessageBus& operator=(const MessageBus&) = delete;
};

} // namespace redim
