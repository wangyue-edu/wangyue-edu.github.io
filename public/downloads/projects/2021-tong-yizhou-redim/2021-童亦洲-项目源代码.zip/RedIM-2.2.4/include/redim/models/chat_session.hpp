#pragma once

#include <QString>
#include <QDateTime>
#include <QList>
#include <QMap>
#include <algorithm>

namespace redim {

enum class MessageType {
    Text,
    Image,
    Notice,
    System
};

struct ChatMessage {
    qint64 msgId{0};
    qint64 senderId{0};
    QString senderName;
    QString content;
    QString imageUrl;
    MessageType type{MessageType::Text};
    QDateTime timestamp;
    bool isOutgoing{false};
};

struct SessionItem {
    qint64 targetId{0};
    QString title;
    QString lastMessagePreview;
    QDateTime lastMessageTime;
    int unreadCount{0};
    bool isPinned{false};
    bool isGroup{false};
};

/**
 * @brief CustomListSort: 重写 List 的会话多级排序算法
 * 克服的困难：高频刷新下保持置顶会话优先、未读权重计算与精确时间戳倒序
 */
class CustomListSort {
public:
    static void sortSessions(QList<SessionItem>& list) {
        std::sort(list.begin(), list.end(), [](const SessionItem& a, const SessionItem& b) {
            // 1. 置顶会话优先级最高
            if (a.isPinned != b.isPinned) {
                return a.isPinned > b.isPinned;
            }
            // 2. 具备未读消息的会话优先上浮
            bool aHasUnread = (a.unreadCount > 0);
            bool bHasUnread = (b.unreadCount > 0);
            if (aHasUnread != bHasUnread) {
                return aHasUnread > bHasUnread;
            }
            // 3. 按照最后一条消息的最新毫秒时间戳倒序排列
            return a.lastMessageTime > b.lastMessageTime;
        });
    }
};

/**
 * @brief ChatSessionManager: 数据中心会话缓存与消息历史管理
 */
class ChatSessionManager {
public:
    static ChatSessionManager& instance();

    void addMessage(qint64 targetId, const ChatMessage& msg, bool isGroup = false);
    QList<ChatMessage> getMessages(qint64 targetId) const;
    QList<SessionItem> getSortedSessions();
    void markRead(qint64 targetId);
    void setPinned(qint64 targetId, bool pinned);

private:
    ChatSessionManager() = default;
    QMap<qint64, QList<ChatMessage>> m_historyStore;
    QMap<qint64, SessionItem> m_sessionMap;
};

} // namespace redim
