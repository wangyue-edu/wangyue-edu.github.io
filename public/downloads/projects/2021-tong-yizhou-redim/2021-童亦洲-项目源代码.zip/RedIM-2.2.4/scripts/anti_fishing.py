#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Anti-Fishing Security Inspector
Repository: https://github.com/tsurumi-yizhou/anti-fishing
Author: 童亦洲 (Tong Yizhou) - 2021
"""

import sys
import re
import urllib.parse

SUSPICIOUS_TLDS = {
    ".xyz", ".top", ".club", ".vip", ".work", ".cf", ".gq", ".ml", ".cc", ".tk"
}

PHISHING_KEYWORDS = [
    "qq-login", "tencent-security", "verify-token", "claim-gift",
    "q-zone", "pass-reset", "free-vip", "redbag-claim"
]

HOMOGRAPH_MAP = {
    'а': 'a', 'с': 'c', 'е': 'e', 'о': 'o', 'р': 'p', 'ѕ': 's', 'х': 'x'
}

def detect_homograph_spoof(domain: str) -> bool:
    """检测混合西里尔字符或同形异义词的域名伪装"""
    has_cyrillic = any(char in HOMOGRAPH_MAP for char in domain)
    has_latin = any('a' <= char <= 'z' for char in domain)
    return has_cyrillic and has_latin

def inspect_url(raw_url: str):
    parsed = urllib.parse.urlparse(raw_url)
    hostname = (parsed.hostname or "").lower()
    path = (parsed.path or "").lower()

    reasons = []

    # 1. 检查纯 IP 主机直连
    if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", hostname):
        reasons.append("使用纯数字 IP 直连，隐藏真实域名身份")

    # 2. 检查多级虚假官方域名欺诈
    if "qq.com." in hostname or "tencent.com." in hostname:
        reasons.append("采用子域名伪造腾讯官方网址 (Subdomain Phishing)")

    # 3. 检查高危顶级域名 + 敏感关键词
    for tld in SUSPICIOUS_TLDS:
        if hostname.endswith(tld):
            for kw in PHISHING_KEYWORDS:
                if kw in hostname or kw in path:
                    reasons.append(f"高危黑产 TLD ({tld}) 结合诱导性敏感词 ({kw})")

    # 4. 同形异义词攻击
    if detect_homograph_spoof(hostname):
        reasons.append("发现 Unicode 混合字符视觉欺骗 (IDN Homograph Attack)")

    return {
        "url": raw_url,
        "is_phishing": len(reasons) > 0,
        "reasons": reasons
    }

if __name__ == "__main__":
    test_urls = [
        "https://im.qq.com/download",
        "http://192.168.1.100/qq-login",
        "https://tencent.com.account-verify.xyz/login",
        "https://claim-gift-qq.top/vip"
    ]
    print("=== Anti-Fishing URL Security Analysis ===")
    for u in test_urls:
        res = inspect_url(u)
        status = "🚨 [BLOCKED]" if res["is_phishing"] else "✅ [SAFE]"
        print(f"{status} {u}")
        for r in res["reasons"]:
            print(f"     └─ {r}")
