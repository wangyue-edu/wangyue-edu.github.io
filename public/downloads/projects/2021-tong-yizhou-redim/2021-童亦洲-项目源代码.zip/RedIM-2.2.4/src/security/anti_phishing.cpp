#include "redim/security/anti_phishing.hpp"

namespace redim {

const QStringList AntiPhishing::s_suspiciousTlds = {
    ".xyz", ".top", ".club", ".vip", ".work", ".cf", ".gq", ".ml"
};

const QStringList AntiPhishing::s_phishingKeywords = {
    "login", "verify", "secure-qq", "q-zone-auth", "prize", "gift-claim", "freeloot", "tencent-security"
};

AntiPhishing::CheckResult AntiPhishing::inspectUrl(const QString& rawUrl) {
    CheckResult res;
    QString lower = rawUrl.toLower();

    // 1. 检测常见 IP 伪装 URL (如 http://192.168.1.1/qq)
    static QRegularExpression ipRegex(R"(https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})");
    if (ipRegex.match(lower).hasMatch()) {
        res.isDangerous = true;
        res.matchedPattern = "Direct-IP-Host";
        res.warningMessage = "⚠️ 警告：检测到纯 IP 直连链接，疑似虚假中继！";
        return res;
    }

    // 2. 检测高危 TLD
    for (const QString& tld : s_suspiciousTlds) {
        if (lower.contains(tld + "/") || lower.endsWith(tld)) {
            for (const QString& kw : s_phishingKeywords) {
                if (lower.contains(kw)) {
                    res.isDangerous = true;
                    res.matchedPattern = tld + " & " + kw;
                    res.warningMessage = "🚨 危险：该链接特征匹配已知钓鱼网站黑名单！";
                    return res;
                }
            }
        }
    }

    // 3. 仿冒官方域名的同形异义词混淆 (如 qq.com.evil.com)
    if (lower.contains("qq.com.") || lower.contains("tencent.com.")) {
        res.isDangerous = true;
        res.matchedPattern = "Subdomain-Spoofing";
        res.warningMessage = "🚨 拦截：伪造腾讯官方域名的多级子域名欺诈！";
        return res;
    }

    return res;
}

QString AntiPhishing::sanitizeTextWithWarnings(const QString& text) {
    static QRegularExpression urlRegex(R"((https?://[^\s]+))");
    auto matchIterator = urlRegex.globalMatch(text);

    QString result = text;
    while (matchIterator.hasNext()) {
        auto match = matchIterator.next();
        QString url = match.captured(1);
        auto check = inspectUrl(url);
        if (check.isDangerous) {
            result.replace(url, QString("<span style='color:red;font-weight:bold;'>[%1] %2</span>")
                                    .arg(check.warningMessage, url));
        }
    }
    return result;
}

} // namespace redim
