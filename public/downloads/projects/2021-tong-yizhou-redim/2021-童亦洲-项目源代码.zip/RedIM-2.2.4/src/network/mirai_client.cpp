#include "redim/network/mirai_client.hpp"
#include "redim/core/message_bus.hpp"
#include <QNetworkRequest>
#include <QUrl>
#include <QDebug>

namespace redim {

MiraiClient::MiraiClient(const QString& host, quint16 port, const QString& verifyKey, qint64 qqNumber, QObject* parent)
    : QObject(parent), m_host(host), m_port(port), m_verifyKey(verifyKey), m_qqNumber(qqNumber) {
    m_httpManager = new QNetworkAccessManager(this);
    m_webSocket = new QWebSocket(QString(), QWebSocketProtocol::VersionLatest, this);
    m_heartbeatTimer = new QTimer(this);

    connect(m_webSocket, &QWebSocket::connected, this, &MiraiClient::onWebSocketConnected);
    connect(m_webSocket, &QWebSocket::disconnected, this, &MiraiClient::onWebSocketDisconnected);
    connect(m_webSocket, &QWebSocket::textMessageReceived, this, &MiraiClient::onTextMessageReceived);
    connect(m_heartbeatTimer, &QTimer::timeout, this, &MiraiClient::sendHeartbeat);
}

MiraiClient::~MiraiClient() {
    stopConnection();
}

void MiraiClient::startConnection() {
    qInfo() << "[MiraiClient] Initiating connection to mirai-api-http at" << m_host << ":" << m_port;
    verifyAuth();
}

void MiraiClient::stopConnection() {
    m_heartbeatTimer->stop();
    if (m_webSocket->isValid()) {
        m_webSocket->close();
    }
    m_connected = false;
    MessageBus::instance().publish({EventType::Disconnected, 0, 0, "", "Connection terminated", "", QDateTime::currentDateTime(), {}});
}

void MiraiClient::verifyAuth() {
    QUrl url(QString("http://%1:%2/verify").arg(m_host).arg(m_port));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject body;
    body["verifyKey"] = m_verifyKey;

    QNetworkReply* reply = m_httpManager->post(request, QJsonDocument(body).toJson());
    connect(reply, &QNetworkReply::finished, [this, reply]() {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            qWarning() << "[MiraiClient] Auth verify failed:" << reply->errorString();
            emit connectionLost(reply->errorString());
            return;
        }

        QJsonObject res = QJsonDocument::fromJson(reply->readAll()).object();
        if (res.value("code").toInt() == 0) {
            m_sessionKey = res.value("session").toString();
            qInfo() << "[MiraiClient] Acquired Session Key:" << m_sessionKey;
            bindSession();
        } else {
            qWarning() << "[MiraiClient] Auth rejected by server, code:" << res.value("code").toInt();
        }
    });
}

void MiraiClient::bindSession() {
    QUrl url(QString("http://%1:%2/bind").arg(m_host).arg(m_port));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject body;
    body["sessionKey"] = m_sessionKey;
    body["qq"] = m_qqNumber;

    QNetworkReply* reply = m_httpManager->post(request, QJsonDocument(body).toJson());
    connect(reply, &QNetworkReply::finished, [this, reply]() {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            qWarning() << "[MiraiClient] Bind session failed:" << reply->errorString();
            return;
        }

        QJsonObject res = QJsonDocument::fromJson(reply->readAll()).object();
        if (res.value("code").toInt() == 0) {
            qInfo() << "[MiraiClient] Session bound successfully for QQ:" << m_qqNumber;
            // 打开 WebSocket 实时消息推送信道
            QUrl wsUrl(QString("ws://%1:%2/message?sessionKey=%3").arg(m_host).arg(m_port).arg(m_sessionKey));
            m_webSocket->open(wsUrl);
            m_heartbeatTimer->start(15000); // 15秒心跳
        }
    });
}

void MiraiClient::onWebSocketConnected() {
    m_connected = true;
    qInfo() << "[MiraiClient] WebSocket message push channel connected!";
    MessageBus::instance().publish({EventType::Connected, m_qqNumber, 0, "Self", "Online", "", QDateTime::currentDateTime(), {}});
    emit authenticated(m_sessionKey);
}

void MiraiClient::onWebSocketDisconnected() {
    m_connected = false;
    qWarning() << "[MiraiClient] WebSocket disconnected, scheduled reconnect in 5s";
    m_heartbeatTimer->stop();
    MessageBus::instance().publish({EventType::Disconnected, 0, 0, "", "WebSocket link broken", "", QDateTime::currentDateTime(), {}});
    QTimer::singleShot(5000, this, &MiraiClient::startConnection);
}

void MiraiClient::onTextMessageReceived(const QString& message) {
    QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8());
    if (!doc.isObject()) return;
    parseIncomingEvent(doc.object());
}

void MiraiClient::parseIncomingEvent(const QJsonObject& root) {
    QString type = root.value("type").toString();
    QJsonObject data = root.value("data").toObject();

    if (type == "FriendMessage") {
        QJsonObject sender = data.value("sender").toObject();
        qint64 senderId = sender.value("id").toVariant().toLongLong();
        QString senderName = sender.value("nickname").toString();
        parseMessageChain(data, senderId, senderName, senderId);
    } else if (type == "GroupMessage") {
        QJsonObject sender = data.value("sender").toObject();
        QJsonObject group = sender.value("group").toObject();
        qint64 senderId = sender.value("id").toVariant().toLongLong();
        qint64 groupId = group.value("id").toVariant().toLongLong();
        QString senderName = sender.value("memberName").toString();
        parseMessageChain(data, senderId, senderName, groupId);
    }
}

void MiraiClient::parseMessageChain(const QJsonObject& data, qint64 senderId, const QString& senderName, qint64 targetId) {
    QJsonArray chain = data.value("messageChain").toArray();
    QDateTime timestamp = QDateTime::fromSecsSinceEpoch(data.value("time").toVariant().toLongLong());

    for (const auto& elemVal : chain) {
        QJsonObject elem = elemVal.toObject();
        QString elemType = elem.value("type").toString();

        if (elemType == "Plain") {
            QString text = elem.value("text").toString();
            MessageBus::instance().emitTextMessage(senderId, targetId, senderName, text, timestamp);
        } else if (elemType == "Image") {
            QString imageUrl = elem.value("url").toString();
            MessageBus::instance().emitImageMessage(senderId, targetId, senderName, imageUrl, timestamp);
        }
    }
}

void MiraiClient::sendHeartbeat() {
    if (!m_connected || m_sessionKey.isEmpty()) return;
    QUrl url(QString("http://%1:%2/about").arg(m_host).arg(m_port));
    QNetworkRequest req(url);
    QNetworkReply* reply = m_httpManager->get(req);
    connect(reply, &QNetworkReply::finished, [reply]() {
        reply->deleteLater();
    });
}

void MiraiClient::sendFriendTextMessage(qint64 friendQq, const QString& message) {
    QUrl url(QString("http://%1:%2/sendFriendMessage").arg(m_host).arg(m_port));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject body;
    body["sessionKey"] = m_sessionKey;
    body["target"] = friendQq;

    QJsonArray chain;
    QJsonObject plainElem;
    plainElem["type"] = "Plain";
    plainElem["text"] = message;
    chain.append(plainElem);
    body["messageChain"] = chain;

    QNetworkReply* reply = m_httpManager->post(request, QJsonDocument(body).toJson());
    connect(reply, &QNetworkReply::finished, [this, reply, friendQq, message]() {
        reply->deleteLater();
        if (reply->error() == QNetworkReply::NoError) {
            MessageBus::instance().emitTextMessage(m_qqNumber, friendQq, "我", message, QDateTime::currentDateTime());
        }
    });
}

void MiraiClient::sendGroupTextMessage(qint64 groupNumber, const QString& message) {
    QUrl url(QString("http://%1:%2/sendGroupMessage").arg(m_host).arg(m_port));
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject body;
    body["sessionKey"] = m_sessionKey;
    body["target"] = groupNumber;

    QJsonArray chain;
    QJsonObject plainElem;
    plainElem["type"] = "Plain";
    plainElem["text"] = message;
    chain.append(plainElem);
    body["messageChain"] = chain;

    QNetworkReply* reply = m_httpManager->post(request, QJsonDocument(body).toJson());
    connect(reply, &QNetworkReply::finished, [this, reply, groupNumber, message]() {
        reply->deleteLater();
        if (reply->error() == QNetworkReply::NoError) {
            MessageBus::instance().emitTextMessage(m_qqNumber, groupNumber, "我", message, QDateTime::currentDateTime());
        }
    });
}

} // namespace redim
