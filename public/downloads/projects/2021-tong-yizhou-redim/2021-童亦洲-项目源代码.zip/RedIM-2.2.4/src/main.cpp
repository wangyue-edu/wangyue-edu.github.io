#include <QApplication>
#include <QStyleFactory>
#include "redim/ui/main_window.hpp"
#include "redim/network/mirai_client.hpp"
#include "redim/models/chat_session.hpp"

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    app.setApplicationName("RedIM");
    app.setApplicationVersion("2.2.4");
    app.setOrganizationName("TsurumiStudio");

    // 初始化演示会话数据 (南通中学望岳奖学金申报现场答辩用例)
    using namespace redim;
    ChatMessage welcomeMsg;
    welcomeMsg.senderId = 123456789;
    welcomeMsg.senderName = "陶缪涵";
    welcomeMsg.content = "亦洲，客户端 UI 资源与图标已经整理好了，跨平台编译测试顺利吗？";
    welcomeMsg.type = MessageType::Text;
    welcomeMsg.timestamp = QDateTime::currentDateTime().addSecs(-300);
    welcomeMsg.isOutgoing = false;
    ChatSessionManager::instance().addMessage(123456789, welcomeMsg);

    ChatMessage replyMsg;
    replyMsg.senderId = 10001;
    replyMsg.senderName = "我";
    replyMsg.content = "收到！Linux 环境测试通过，Qt 信号槽消息总线与 List 多级排序重写已调通。";
    replyMsg.type = MessageType::Text;
    replyMsg.timestamp = QDateTime::currentDateTime().addSecs(-120);
    replyMsg.isOutgoing = true;
    ChatSessionManager::instance().addMessage(123456789, replyMsg);

    // 启动 Mirai 协议后端客户端
    MiraiClient client("127.0.0.1", 8080, "INIT_VERIFY_KEY_2021", 10001);
    // client.startConnection();

    MainWindow w;
    w.show();

    return app.exec();
}
