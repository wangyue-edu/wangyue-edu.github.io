#include "redim/core/message_bus.hpp"
#include <QDebug>

namespace redim {

MessageBus& MessageBus::instance() {
    static MessageBus s_bus;
    return s_bus;
}

MessageBus::MessageBus(QObject* parent) : QObject(parent) {
    qInfo() << "[MessageBus] Initialized Global Event Bus & Data Center";
}

void MessageBus::publish(const EventPacket& packet) {
    emit eventDispatched(packet);

    switch (packet.type) {
    case EventType::Connected:
        emit connectionStateChanged(true);
        break;
    case EventType::Disconnected:
        emit connectionStateChanged(false);
        break;
    case EventType::TextMessageReceived:
        emit textMessageArrived(packet.senderId, packet.targetId, packet.senderName, packet.content, packet.timestamp);
        break;
    case EventType::ImageMessageReceived:
        emit imageMessageArrived(packet.senderId, packet.targetId, packet.senderName, packet.imageUrl, packet.timestamp);
        break;
    default:
        break;
    }
}

void MessageBus::emitTextMessage(qint64 senderId, qint64 targetId, const QString& senderName,
                                const QString& text, const QDateTime& time) {
    EventPacket packet;
    packet.type = EventType::TextMessageReceived;
    packet.senderId = senderId;
    packet.targetId = targetId;
    packet.senderName = senderName;
    packet.content = text;
    packet.timestamp = time.isValid() ? time : QDateTime::currentDateTime();
    publish(packet);
}

void MessageBus::emitImageMessage(qint64 senderId, qint64 targetId, const QString& senderName,
                                 const QString& imageUrl, const QDateTime& time) {
    EventPacket packet;
    packet.type = EventType::ImageMessageReceived;
    packet.senderId = senderId;
    packet.targetId = targetId;
    packet.senderName = senderName;
    packet.imageUrl = imageUrl;
    packet.timestamp = time.isValid() ? time : QDateTime::currentDateTime();
    publish(packet);
}

void MessageBus::emitSessionUpdate(qint64 targetId) {
    EventPacket packet;
    packet.type = EventType::SessionUpdated;
    packet.targetId = targetId;
    packet.timestamp = QDateTime::currentDateTime();
    publish(packet);
}

void MessageBus::emitPhishingAlert(const QString& url, const QString& threatType) {
    emit phishingWarningTriggered(url, threatType);
}

} // namespace redim
