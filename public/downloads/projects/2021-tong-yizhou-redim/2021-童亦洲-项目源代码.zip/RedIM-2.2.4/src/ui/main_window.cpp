#include "redim/ui/main_window.hpp"
#include "redim/core/message_bus.hpp"
#include "redim/security/anti_phishing.hpp"
#include <QHBoxLayout>
#include <QFileDialog>
#include <QMessageBox>
#include <QDateTime>

namespace redim {

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setupUi();
    applyCustomStyles();

    // 绑定全局消息总线信号（利用 Qt 信号槽与 C++ Lambda）
    connect(&MessageBus::instance(), &MessageBus::textMessageArrived,
            this, &MainWindow::handleIncomingTextMessage);
    connect(&MessageBus::instance(), &MessageBus::imageMessageArrived,
            this, &MainWindow::handleIncomingImageMessage);
    connect(&MessageBus::instance(), &MessageBus::connectionStateChanged,
            this, [this](bool connected) {
                m_statusBadge->setText(connected ? "● 在线 (Project-Mirai 已连接)" : "○ 离线 / 重连中");
                m_statusBadge->setStyleSheet(connected ? "color: #10B981; font-weight: bold;" : "color: #EF4444; font-weight: bold;");
            });

    connect(&MessageBus::instance(), &MessageBus::phishingWarningTriggered,
            this, [](const QString& url, const QString& reason) {
                QMessageBox::warning(nullptr, "安全中心拦截提醒", QString("检测到危险钓鱼链接：
%1

原因：%2").arg(url, reason));
            });
}

void MainWindow::setupUi() {
    setWindowTitle("RedIM v2.2.4 - 跨平台即时通信客户端 (童亦洲)");
    resize(960, 680);

    auto* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    auto* rootLayout = new QHBoxLayout(centralWidget);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(0);

    auto* splitter = new QSplitter(Qt::Horizontal, this);
    rootLayout->addWidget(splitter);

    // 左侧：会话列表栏
    auto* leftPanel = new QWidget(this);
    leftPanel->setFixedWidth(280);
    auto* leftLayout = new QVBoxLayout(leftPanel);
    leftLayout->setContentsMargins(12, 16, 12, 12);
    leftLayout->setSpacing(10);

    auto* appHeader = new QLabel("💬 RedIM 2.2.4", leftPanel);
    appHeader->setStyleSheet("font-size: 16px; font-weight: bold; color: #E2E8F0;");
    m_statusBadge = new QLabel("● 在线 (Project-Mirai 已连接)", leftPanel);
    m_statusBadge->setStyleSheet("color: #10B981; font-size: 12px;");

    m_sessionList = new QListWidget(leftPanel);
    connect(m_sessionList, &QListWidget::currentRowChanged, this, &MainWindow::onSessionSelected);

    leftLayout->addWidget(appHeader);
    leftLayout->addWidget(m_statusBadge);
    leftLayout->addWidget(m_sessionList);

    // 右侧：主聊天窗口
    auto* rightPanel = new QWidget(this);
    auto* rightLayout = new QVBoxLayout(rightPanel);
    rightLayout->setContentsMargins(16, 16, 16, 16);
    rightLayout->setSpacing(10);

    m_chatTitleLabel = new QLabel("未选定会话", rightPanel);
    m_chatTitleLabel->setStyleSheet("font-size: 15px; font-weight: bold; color: #F1F5F9; border-bottom: 1px solid #334155; padding-bottom: 8px;");

    m_chatHistoryView = new QTextBrowser(rightPanel);
    m_chatHistoryView->setOpenExternalLinks(false);
    connect(m_chatHistoryView, &QTextBrowser::anchorClicked, [this](const QUrl& url) {
        auto check = AntiPhishing::inspectUrl(url.toString());
        if (check.isDangerous) {
            MessageBus::instance().emitPhishingAlert(url.toString(), check.warningMessage);
        }
    });

    // 工具栏与输入区
    auto* toolBar = new QHBoxLayout();
    m_imageBtn = new QPushButton("📷 发送图片", rightPanel);
    connect(m_imageBtn, &QPushButton::clicked, this, &MainWindow::onSelectImageClicked);
    toolBar->addWidget(m_imageBtn);
    toolBar->addStretch();

    m_inputEdit = new QTextEdit(rightPanel);
    m_inputEdit->setMaximumHeight(100);
    m_inputEdit->setPlaceholderText("输入消息内容... (Enter 发送)");

    auto* bottomBar = new QHBoxLayout();
    m_sendBtn = new QPushButton("发送 (Enter)", rightPanel);
    m_sendBtn->setStyleSheet("background-color: #2563EB; color: white; border-radius: 6px; padding: 6px 18px; font-weight: bold;");
    connect(m_sendBtn, &QPushButton::clicked, this, &MainWindow::onSendMessageClicked);
    bottomBar->addStretch();
    bottomBar->addWidget(m_sendBtn);

    rightLayout->addWidget(m_chatTitleLabel);
    rightLayout->addWidget(m_chatHistoryView, 1);
    rightLayout->addLayout(toolBar);
    rightLayout->addWidget(m_inputEdit);
    rightLayout->addLayout(bottomBar);

    splitter->addWidget(leftPanel);
    splitter->addWidget(rightPanel);
    splitter->setStretchFactor(1, 1);

    // 初始化演示会话数据
    refreshSessionList();
}

void MainWindow::applyCustomStyles() {
    setStyleSheet(R"(
        QWidget {
            background-color: #0F172A;
            color: #CBD5E1;
            font-family: 'Inter', -apple-system, 'Segoe UI', 'PingFang SC', sans-serif;
        }
        QListWidget {
            background-color: #1E293B;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 4px;
        }
        QListWidget::item {
            padding: 10px;
            border-bottom: 1px solid #334155;
            border-radius: 6px;
        }
        QListWidget::item:selected {
            background-color: #3B82F6;
            color: #FFFFFF;
        }
        QTextBrowser {
            background-color: #1E293B;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 12px;
        }
        QTextEdit {
            background-color: #1E293B;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #F8FAFC;
            padding: 8px;
        }
        QPushButton {
            background-color: #334155;
            border: none;
            border-radius: 6px;
            padding: 6px 12px;
            color: #E2E8F0;
        }
        QPushButton:hover {
            background-color: #475569;
        }
    )");
}

void MainWindow::refreshSessionList() {
    m_sessionList->clear();
    auto sessions = ChatSessionManager::instance().getSortedSessions();
    for (const auto& item : sessions) {
        QString text = QString("%1
%2")
                           .arg(item.title)
                           .arg(item.lastMessagePreview.isEmpty() ? "暂无消息" : item.lastMessagePreview);
        if (item.unreadCount > 0) {
            text += QString("  [%1 未读]").arg(item.unreadCount);
        }
        m_sessionList->addItem(text);
    }
}

void MainWindow::onSessionSelected(int index) {
    auto sessions = ChatSessionManager::instance().getSortedSessions();
    if (index < 0 || index >= sessions.size()) return;

    m_currentActiveTarget = sessions[index].targetId;
    m_chatTitleLabel->setText(sessions[index].title);
    ChatSessionManager::instance().markRead(m_currentActiveTarget);

    m_chatHistoryView->clear();
    auto msgs = ChatSessionManager::instance().getMessages(m_currentActiveTarget);
    for (const auto& m : msgs) {
        appendChatMessageHtml(m);
    }
}

void MainWindow::onSendMessageClicked() {
    QString text = m_inputEdit->toPlainText().trimmed();
    if (text.isEmpty() || m_currentActiveTarget == 0) return;

    ChatMessage msg;
    msg.senderId = 10001;
    msg.senderName = "我";
    msg.content = text;
    msg.type = MessageType::Text;
    msg.timestamp = QDateTime::currentDateTime();
    msg.isOutgoing = true;

    ChatSessionManager::instance().addMessage(m_currentActiveTarget, msg);
    appendChatMessageHtml(msg);
    m_inputEdit->clear();
    refreshSessionList();
}

void MainWindow::onSelectImageClicked() {
    QString path = QFileDialog::getOpenFileName(this, "选择要发送的图片", "", "Images (*.png *.jpg *.jpeg *.gif)");
    if (path.isEmpty() || m_currentActiveTarget == 0) return;

    ChatMessage msg;
    msg.senderId = 10001;
    msg.senderName = "我";
    msg.imageUrl = path;
    msg.type = MessageType::Image;
    msg.timestamp = QDateTime::currentDateTime();
    msg.isOutgoing = true;

    ChatSessionManager::instance().addMessage(m_currentActiveTarget, msg);
    appendChatMessageHtml(msg);
    refreshSessionList();
}

void MainWindow::appendChatMessageHtml(const ChatMessage& msg) {
    QString timeStr = msg.timestamp.toString("HH:mm:ss");
    QString align = msg.isOutgoing ? "right" : "left";
    QString bgColor = msg.isOutgoing ? "#2563EB" : "#334155";
    QString name = msg.senderName;

    QString contentHtml;
    if (msg.type == MessageType::Image) {
        contentHtml = QString("<img src='%1' width='240' style='border-radius:6px;'/>").arg(msg.imageUrl);
    } else {
        contentHtml = AntiPhishing::sanitizeTextWithWarnings(msg.content.toHtmlEscaped());
    }

    QString html = QString(
        "<div style='text-align:%1; margin: 8px 0;'>"
        "  <span style='font-size:11px; color:#94A3B8;'>%2 (%3)</span><br/>"
        "  <div style='display:inline-block; background-color:%4; color:#FFFFFF; padding:8px 12px; border-radius:10px; margin-top:3px; max-width:70%;'>"
        "    %5"
        "  </div>"
        "</div>"
    ).arg(align, name, timeStr, bgColor, contentHtml);

    m_chatHistoryView->append(html);
}

void MainWindow::handleIncomingTextMessage(qint64 senderId, qint64 targetId, const QString& name, const QString& text, const QDateTime& time) {
    ChatMessage msg;
    msg.senderId = senderId;
    msg.senderName = name;
    msg.content = text;
    msg.type = MessageType::Text;
    msg.timestamp = time;
    msg.isOutgoing = false;

    ChatSessionManager::instance().addMessage(targetId, msg);
    if (targetId == m_currentActiveTarget) {
        appendChatMessageHtml(msg);
    }
    refreshSessionList();
}

void MainWindow::handleIncomingImageMessage(qint64 senderId, qint64 targetId, const QString& name, const QString& url, const QDateTime& time) {
    ChatMessage msg;
    msg.senderId = senderId;
    msg.senderName = name;
    msg.imageUrl = url;
    msg.type = MessageType::Image;
    msg.timestamp = time;
    msg.isOutgoing = false;

    ChatSessionManager::instance().addMessage(targetId, msg);
    if (targetId == m_currentActiveTarget) {
        appendChatMessageHtml(msg);
    }
    refreshSessionList();
}

} // namespace redim
