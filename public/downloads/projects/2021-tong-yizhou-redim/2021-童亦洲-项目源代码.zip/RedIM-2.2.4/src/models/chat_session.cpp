#include "redim/models/chat_session.hpp"

namespace redim {

ChatSessionManager& ChatSessionManager::instance() {
    static ChatSessionManager s_mgr;
    return s_mgr;
}

void ChatSessionManager::addMessage(qint64 targetId, const ChatMessage& msg, bool isGroup) {
    m_historyStore[targetId].append(msg);

    // 更新或新增会话元信息
    SessionItem& item = m_sessionMap[targetId];
    item.targetId = targetId;
    item.isGroup = isGroup;
    if (item.title.isEmpty()) {
        item.title = isGroup ? QString("群聊 (%1)").arg(targetId) : msg.senderName;
    }

    if (msg.type == MessageType::Image) {
        item.lastMessagePreview = "[图片]";
    } else {
        item.lastMessagePreview = msg.content;
    }
    item.lastMessageTime = msg.timestamp;

    if (!msg.isOutgoing) {
        item.unreadCount++;
    }
}

QList<ChatMessage> ChatSessionManager::getMessages(qint64 targetId) const {
    return m_historyStore.value(targetId);
}

QList<SessionItem> ChatSessionManager::getSortedSessions() {
    QList<SessionItem> list = m_sessionMap.values();
    // 调用重写的 List 排序算法
    CustomListSort::sortSessions(list);
    return list;
}

void ChatSessionManager::markRead(qint64 targetId) {
    if (m_sessionMap.contains(targetId)) {
        m_sessionMap[targetId].unreadCount = 0;
    }
}

void ChatSessionManager::setPinned(qint64 targetId, bool pinned) {
    if (m_sessionMap.contains(targetId)) {
        m_sessionMap[targetId].isPinned = pinned;
    }
}

} // namespace redim
