#include <bits/stdc++.h>
#define MAXN 100010
using namespace std;

int n, an, bn, aa[MAXN], bb[MAXN];
set<pair<int, int> > a, b;//国内区与国际区的远机位集合
pair<int, int> tmp;
set<pair<int, int> >::iterator id;

int ma()
{
    int t = 0, now = 0;
    while (true)
    {
        id = a.lower_bound(make_pair(now, now));//选中当前远机位中到达时间最早
        if (id == a.end())
            break;//若集合内飞机处理完，结束循环
        t++;//统计新增停入廊桥的飞机数
        now = id->second;
        a.erase(id);//从远机位集合中删去刚才处理的飞机
    }
    return t;
}
int mb()
{
    int t = 0, now = 0;
    while (true)
    {
        id = b.lower_bound(make_pair(now, now));
        if (id == b.end())
            break;
        t++;
        now = id->second;
        b.erase(id);
    }
    return t;
}//与国内区同理
int main()
{
    scanf("%d%d%d", &n, &an, &bn);
    for (int i = 1; i <= an; i++)
    {
        scanf("%d%d", &tmp.first, &tmp.second);
        a.insert(tmp);
    }//读入国内区航班信息
    for (int i = 1; i <= bn; i++)
    {
        scanf("%d%d", &tmp.first, &tmp.second);
        b.insert(tmp);
    }//读入国际区航班信息
    aa[0] = 0;//边界值为0
    for (int i = 1; i <= n; i++)
        aa[i] = aa[i - 1] + ma();//处理国内区子问题
    bb[0] = 0;
    for (int i = 1; i <= n; i++)
        bb[i] = bb[i - 1] + mb();//处理国际区子问题
    int ans = 0;
    for (int i = 0; i <= n; i++)
        ans=max(ans, aa[i] + bb[n - i]);//计算最终答案，从边界0开始
    printf("%d\n", ans);
    return 0;
}
