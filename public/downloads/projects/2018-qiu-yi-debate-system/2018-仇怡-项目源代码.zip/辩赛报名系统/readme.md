########### 环境依赖
node v0.10.28+

########### 目录结构描述
├── Readme.md                   // help
├── app.js                      // 应用
├── model                       // 配置
│   ├── db.js                   //数据库增、删、改、查
|   |-- config.js               //数据库名称
│   
|—— static                      // web静态资源加载
|      |--public                //前后端公用静态资源
|           |--css
|           |   |--ie10.css   
|           |--js
|               |--ie10.js
|      |--admin                 //后端静态资源
|      |--index                 //前端静态资源
|
|--routes                      // 配置路由
|    |--admin.js               // 后台路由
|    |--index.js               //前台路由
|    |--admin                  //后台渲染js文件
|         |--index.js
|         |--login.js          //管理员登陆
|         |--list.js
|
|--views                       //模板
|     |--admin                 //后台模板
|          |--list.html        //根据验证码查询
|          |--login.html       //管理员登陆
|          |--index.html       //显示全部信息
|          |--error.html       //错误显示页
|          |--search.html      //显示查找到的信息页
|     |--index                 //前台模板
|          |--index.html



## 数据库mongodb 数据库名:ntzx  集合名:ntzx  npm install mongodb --save

## 使用步骤：
###  1、npm init
###  2、npm install
###  3、开启mongodb数据库
###  4、node app.js
### 浏览器打开http://localhost:3000
###  http://localhost:3000/admin登陆时
####    管理员姓名:张三    密码：123456
