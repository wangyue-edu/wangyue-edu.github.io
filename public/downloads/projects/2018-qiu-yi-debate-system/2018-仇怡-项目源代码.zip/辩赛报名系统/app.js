
const koa = require('koa');
const app = new koa();
const path = require('path');
var Router = require('koa-router');
var router = new Router();
const render = require('koa-art-template'); //模板引擎
const serve = require('koa-static');  //引入静态文件中间件
const session = require('koa-session'); //引入session中间件
var bodyParser = require('koa-bodyparser');  //解析post提交数据为json格式的中间件


//配置bodyParser
app.use(bodyParser());  //一定要在所有的最上层配置

//配置session中间件，一定要在所有的最上层配置
app.keys = [process.env.SESSION_SECRET || 'your_secret_session_key'];

const CONFIG = {
    key: 'koa:sess',
    maxAge: 86400000,
    autoCommit: true,
    overwrite: true,
    httpOnly: true,
    signed: true,
    rolling: true,
    renew: false,
};
app.use(session(CONFIG, app));

//引入routes中的路由模块
var admin = require('./routes/admin.js');
var index = require('./routes/index.js');


//配置层级路由

router.use('/admin', admin); //http://localhost:3000/admin
router.use(index);  //最好放在最下面，因为index里面也有子路由/admin的话，就会先配置放在前面的/admin路由http://localhost:3000

//配置模板引擎,所有的文件的父级为views文件夹
render(app, {
    root: path.join(__dirname, 'views'),
    extname: '.html',
    debug: process.env.NODE_ENV !== 'production'
    
});
//配置静态资源中间件
app.use(serve(__dirname + '/static'));

app
    .use(router.routes())   //启动路由
    .use(router.allowedMethods());

app.listen(3000);
console.log('正在运行于3000端口');