var Router = require('koa-router');
var router = new Router();
var url = require('url');   //过滤url里？后面的内容

var login = require('./admin/login.js');
var list = require('./admin/list.js');
var index = require('./admin/index.js');


//配置中间件，获取url地址router.use([path], middleware) ⇒ Router， middleware为中间件，和koa的用法相同
router.use(async (ctx, next) => {
    
    //模板引擎配置全局变量__HOST__
    ctx.state.__HOST__ = 'http://' + ctx.request.header.host;
    var path = url.parse(ctx.request.url).pathname.substring(1);
    var splitUrl = path.split('/');

    //用于退出登陆
    ctx.state.G = {
        url: splitUrl,
        userinfo: ctx.session.userinfo,
        prevPage:ctx.request.headers['referer'] //得到前一个页面
    }


    //console.log(ctx.url)    //  /admin
    //权限判断，如果有权限，则可以访问，没有跳转到登陆页面
    if (ctx.session.userinfo) {
        await next();  //有了这个，才可向下运行
    } else {

        //如果当前页面不是登陆页面的话跳转到登陆页面，否则继续向下匹配
        if (path == 'admin/login' || path == 'admin/login/doLogin' ) {
            await next();

        } else {
            ctx.redirect('/admin/login');
        }

    }
   
})
//默认加载后台首页
router.use(list);

//配置层级路由
router.use('/login', login);
router.use('/index', index);


module.exports = router.routes();