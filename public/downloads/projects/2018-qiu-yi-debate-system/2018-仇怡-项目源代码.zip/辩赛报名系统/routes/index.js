var Router = require('koa-router');
var router = new Router();
var DB = require('../model/db.js');





router.get('/', async (ctx) => {
    await ctx.render('index/index')

})

router.post('/search', async (ctx) => {
    ctx.body = ctx.request.body;   //{"school":"南通中学","username":"王五","password":"12345678"}

    //验证姓名不超过4个汉字
    var pattern = /^[\u4e00-\u9fa5]{1,4}$/g;
    var string = ctx.body.username;
    var arr = pattern.exec(string);  //超过4个汉字为null


    //设置一个随机验证码：3位数字+数据条数
    var count = await DB.count('ntzx', {}); //没有数据时为0
    var randomNum = Math.ceil(Math.random() * 900 + 100).toString();
    // console.log('randomNum', randomNum)
    ctx.body.id = randomNum.toString() + count;

    //添加数据到数据库
    if (arr) {
        //如果是不同的password,则添加进数据库，否则提示错误
        var searchPassword = await DB.find('ntzx', { "password": ctx.body.password.toString(), "school": ctx.body.school.toString() });
        //console.log(searchPassword)
        if (searchPassword.length > 0) {
            var error = "已经注册过了！"
            await ctx.render('index/index', {
                error: error
            })
        } else {
            var result = await DB.insert('ntzx', ctx.body);
            var findId = await DB.find('ntzx', { "id": ctx.body.id.toString() });
            if (result && result.result.ok == 1) {

                await ctx.render('index/index', {
                    list: findId[0].id

                })
            }
        }
    } else {
        await ctx.render('index/index', {
            list: "请输入正确的姓名格式"

        })
    }


})

module.exports = router.routes(); 
