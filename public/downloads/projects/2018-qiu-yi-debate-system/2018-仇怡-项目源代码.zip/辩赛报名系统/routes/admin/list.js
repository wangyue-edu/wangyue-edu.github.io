var Router = require('koa-router');
var router = new Router();
var DB = require('../../model/db.js');

router.get('/', async (ctx) => {

    //渲染模板
    await ctx.render('admin/list');
})

router.post('/search', async (ctx) => {
    //获取验证码
    ctx.body = ctx.request.body;  //{"username":"张三","password":"123456"}
    //console.log(ctx.body)
    
    //根据提供的验证码查询数据库
    var list = await DB.find('ntzx', { "id": ctx.body.id});
    //console.log(ctx.state.G.prevPage);  //http://localhost:3000/admin
    //在页面渲染
    if(list.length > 0){
        await ctx.render('admin/search',{
            list:list,
            prevPage: ctx.state.G.prevPage,
            show:true

        });
    } else {
        //ctx.redirect(ctx.state.__HOST__ + '/admin');
        await ctx.render('admin/search',{
            value:true,
            prevPage: ctx.state.G.prevPage
        });
    }

})
module.exports = router.routes(); 