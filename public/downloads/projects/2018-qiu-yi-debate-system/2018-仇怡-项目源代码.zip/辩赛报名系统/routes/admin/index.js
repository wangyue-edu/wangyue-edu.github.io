var Router = require('koa-router');
var router = new Router();
var DB = require('../../model/db.js');

router.get('/', async (ctx) => {

    var page = ctx.query.page || 1;  //得到显示第几页
    var pageSize = 12;           //设置每页12条数据

    var result = await DB.find('ntzx', {}, {}, {
        page: page,
        pageSize: pageSize,
        sortJson: {
            "school": -1
        }
    });
    var count = await DB.count('ntzx', {});
    //渲染模板
    await ctx.render('admin/index', {
        list: result,
        page: page,
        totalPages: Math.ceil(count / pageSize)

    });

})
module.exports = router.routes(); 