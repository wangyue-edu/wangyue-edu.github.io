var Router = require('koa-router');
var router = new Router();

router.get('/', async (ctx) => {
    
    //渲染模板
    await ctx.render('admin/login');
})

router.post('/doLogin', async (ctx) => {
    
     ctx.body = ctx.request.body;  //{"username":"admin","password":"placeholder_password"}
    //成功后信息写入session 
    ctx.session.userinfo = ctx.body;

    if (ctx.body.username === (process.env.ADMIN_USER || "admin") && ctx.body.password === (process.env.ADMIN_PASSWORD || "placeholder_password")){
       // console.log('登陆成功');
        ctx.redirect(ctx.state.__HOST__ + '/admin'); //禁止跳转，还在当前页面
    } else {
        await ctx.render('admin/error', {
            message: "验证码错误",
            redirect: ctx.state.__HOST__ + '/admin/login'
        }); 
    }
})

//退出登陆
router.get('/loginOut', async (ctx) => {
    //清除session数据
    ctx.session.userinfo = null;
    //跳转到登陆页面
    ctx.redirect(ctx.state.__HOST__ + '/admin/login');
})
module.exports = router.routes(); 