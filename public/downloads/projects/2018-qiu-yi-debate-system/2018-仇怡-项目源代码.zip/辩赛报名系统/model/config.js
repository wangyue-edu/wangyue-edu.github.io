var app = {

    dbUrl: 'mongodb://localhost:27017/',

    dbName: 'ntzx'

}

module.exports = app;