/**

 * http://mongodb.github.io/node-mongodb-native

 * http://mongodb.github.io/node-mongodb-native/3.0/api/
 */

//DB??
var MongoDB = require('mongodb');
var MongoClient = MongoDB.MongoClient;
const ObjectID = MongoDB.ObjectID;

var Config = require('./config.js');

class Db {

    static getInstance() {

        if (!Db.instance) {
            Db.instance = new Db();
        }
        return Db.instance;
    }

    constructor() {

        this.dbClient = '';
        this.connect();

    }

    connect() {
        let _that = this;
        return new Promise((resolve, reject) => {
            if (!_that.dbClient) {
                MongoClient.connect(Config.dbUrl, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {

                    if (err) {
                        reject(err)

                    } else {

                        _that.dbClient = client.db(Config.dbName);
                        resolve(_that.dbClient)
                    }
                })

            } else {
                resolve(_that.dbClient);

            }


        })

    }

    find(collectionName, json1, json2, json3) {

        if (arguments.length == 2) { //当传入2个参数时，查询指定参数这一条数据
            var attr = {};
            var skipNum = 0;
            var pageSize = 0;
            // db.user.find().skip(0).limit(0) //查询出所有数据
        } else if (arguments.length == 3) {  //查询一列或多列
            var attr = json2;
            var skipNum = 0;
            var pageSize = 0;
            // db.user.find({},json2).skip(0).limit(0) //查询出json2指定的一列
        } else if (arguments.length == 4) {  //实现数据库分页显示
            var attr = json2;
            var page = json3.page || 1;             //当前页或默认第一页
            var pageSize = json3.pageSize || 20;     //每一页的条数或默认每页20条
            var skipNum = (page - 1) * pageSize;
            //判断是否排序
            if (json3.sortJson) {
                var sortJson = json3.sortJson;
            } else {
                var sortJson = {};
            }
        } else {
            console.log("参数错误")
        }

        return new Promise((resolve, reject) => {

            this.connect().then((db) => {

                //var result = db.collection(collectionName).find(json);
                var result = db.collection(collectionName).find(json1, { filters: attr }).skip(skipNum).limit(pageSize).sort(sortJson);

                result.toArray(function (err, docs) {

                    if (err) {
                        reject(err);
                        return;
                    }
                    resolve(docs);
                })

            })
        })
    }

    insert(collectionName, json) {
        return new Promise((resolve, reject) => {
            this.connect().then((db) => {

                db.collection(collectionName).insertOne(json, function (err, result) {
                    if (err) {
                        reject(err);
                    } else {

                        resolve(result);
                    }
                })


            })
        })
    }


    getObjectId(id) {   //�õ����ݿ�"_id"

        return new ObjectID(id);
    }

    count(collectionName, json) {
        return new Promise((resolve, reject) => {
            this.connect().then((db) => {

                db.collection(collectionName).find(json).count(function (err, result) {
                    if (err) {
                        reject(err);
                    } else {

                        resolve(result);
                    }
                })


            })
        })
    }

    insert(collectionName, json) {
        return new Promise((resolve, reject) => {
            this.connect().then((db) => {

                db.collection(collectionName).insertOne(json, function (err, result) {
                    if (err) {
                        reject(err);
                    } else {

                        resolve(result);
                    }
                })


            })
        })
    }
}


module.exports = Db.getInstance();
