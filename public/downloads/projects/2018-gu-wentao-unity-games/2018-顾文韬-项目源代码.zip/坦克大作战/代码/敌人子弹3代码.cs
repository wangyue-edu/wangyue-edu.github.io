﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class 敌人子弹3代码 : MonoBehaviour
{
    public float speed1 = 8;
    private Vector3 pos;
    private Vector3 hatPosition;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        pos = this.transform.position;
        hatPosition = new Vector3((float)(pos.x), (float)(pos.y-0.2), 0);
        GetComponent<Rigidbody2D>().MovePosition(hatPosition);
    }
    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.name == "主角上")
        {
            Destroy(coll.gameObject);
            Destroy(this.gameObject);
        }
        else if (coll.gameObject.name == "主角左")
        {
            Destroy(coll.gameObject);
            Destroy(this.gameObject);
        }
       else  if (coll.gameObject.name == "主角右")
        {
            Destroy(coll.gameObject);
            Destroy(this.gameObject);
        }
        else if (coll.gameObject.name == "主角下")
        {
            Destroy(coll.gameObject);
            Destroy(this.gameObject);
        }
        else
            Destroy(this.gameObject);
    }
}