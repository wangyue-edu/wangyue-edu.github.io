﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class 敌人坦克代码啊 : MonoBehaviour
{
    public GameObject enemytank;
    public GameObject enemytank1;
    public GameObject enemytank2;
    public GameObject enemytank3;
    public GameObject enemyzidan;
    public GameObject enemyzidan1;
    public GameObject enemyzidan2;
    public GameObject enemyzidan3;
    public GameObject tank;
    public GameObject tank1;
    public GameObject tank2;
    public GameObject tank3;
    private GameObject enemygwt;
    private GameObject enemyljn;
    private GameObject enemyqdp;
    private GameObject enemyjq;
    private Vector3 por1;
    private Vector3 por12;
    private Vector3 por13;
    private Vector3 por14;
    private Vector3 por15;
    private Vector3 hatPosition3;
    private int a = 0;
    private int b = 0;
    private int c = 0;
    private int e = 0;
    private int d = 0;
    public float speed = 4;
    public int system = 2;
    // Use this for initialization
    void Start()
    {
 
    }

    // Update is called once per frame
    void Update()
    {
        por12 = tank.transform.position;
        por13 = tank1.transform.position;
        por14 = tank2.transform.position;
        por15 = tank3.transform.position;
        if (por12.x < 20)
        {
            if (system == 0)
                por1 = enemytank.transform.position;
            if (system == 1)
                por1 = enemytank1.transform.position;
            if (system == 2)
                por1 = enemytank2.transform.position;
            if (system == 3)
                por1 = enemytank3.transform.position;

            if (por1.x < por12.x)
                a = 1;
            if (por1.x > por12.x)
                a = 2;
            if (a == 0 && system == 0)
            {
                por1 = enemytank.transform.position;
                hatPosition3 = new Vector3(por1.x, (float)(por1.y - 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 0 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            if (a == 1 && system == 1)
            {
                por1 = enemytank1.transform.position;
                hatPosition3 = new Vector3((float)(por1.x + 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 1 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }


            if (a == 2 && system == 2)
            {
                por1 = this.transform.position;
                hatPosition3 = new Vector3((float)(por1.x - 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 2 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            if (a == 3 && system == 3)
            {
                por1 = enemytank3.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y - 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 3 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
        }
        if (por13.x < 20)
        {
            if (system == 0)
                por1 = enemytank.transform.position;
            if (system == 1)
                por1 = enemytank1.transform.position;
            if (system == 2)
                por1 = enemytank2.transform.position;
            if (system == 3)
                por1 = enemytank3.transform.position;
            if (por1.x < por13.x)
                a = 1;
            if (por1.x > por13.x)
                a = 2;
            if (a == 0 && system == 0)
            {
                por1 = enemytank.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y + 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 0 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            if (a == 1 && system == 1)
            {
                por1 = enemytank1.transform.position;
                hatPosition3 = new Vector3((float)(por1.x + 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 1 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }


            if (a == 2 && system == 2)
            {
                por1 = enemytank2.transform.position;
                hatPosition3 = new Vector3((float)(por1.x - 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 2 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            if (a == 3 && system == 3)
            {
                por1 = enemytank3.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y - 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 3 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
        }
        if (por14.x < 20)
        {
            if (system == 0)
                por1 = enemytank.transform.position;
            if (system == 1)
                por1 = enemytank1.transform.position;
            if (system == 2)
                por1 = enemytank2.transform.position;
            if (system == 3)
                por1 = enemytank3.transform.position;
            if (por1.x < por14.x)
                a = 1;
            if (por1.x > por14.x)
                a = 2;
            if (a == 0 && system == 0)
            {
                por1 = enemytank.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y + 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 0 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            if (a == 1 && system == 1)
            {
                por1 = enemytank1.transform.position;
                hatPosition3 = new Vector3((float)(por1.x + 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 1 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }


            if (a == 2 && system == 2)
            {
                por1 = enemytank2.transform.position;
                hatPosition3 = new Vector3((float)(por1.x - 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 2 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            if (a == 3 && system == 3)
            {
                por1 = enemytank3.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y - 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 3 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }

        }
        if (por15.x < 20)
        {
            if (system == 0)
                por1 = enemytank.transform.position;
            if (system == 1)
                por1 = enemytank1.transform.position;
            if (system == 2)
                por1 = enemytank2.transform.position;
            if (system == 3)
                por1 = enemytank3.transform.position;
            if (por1.x < por15.x)
                a = 1;
            if (por1.x > por15.x)
                a = 2;
            if (a == 0 && system == 0)
            {
                por1 = enemytank.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y + 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 0 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            else if (a == 0 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank.transform.position;
                enemytank.transform.position = por1;
                system = 0;
            }
            if (a == 1 && system == 1)
            {
                por1 = enemytank1.transform.position;
                hatPosition3 = new Vector3((float)(por1.x + 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 1 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }
            else if (a == 1 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank1.transform.position;
                enemytank1.transform.position = por1;
                system = 1;
            }


            if (a == 2 && system == 2)
            {
                por1 = enemytank2.transform.position;
                hatPosition3 = new Vector3((float)(por1.x - 0.05), (float)(por1.y), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 2 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            else if (a == 2 && system == 3)
            {
                por1 = enemytank3.transform.position;
                enemytank3.transform.position = enemytank2.transform.position;
                enemytank2.transform.position = por1;
                system = 2;
            }
            if (a == 3 && system == 3)
            {
                por1 = enemytank3.transform.position;
                hatPosition3 = new Vector3((float)(por1.x), (float)(por1.y - 0.05), 0);
                GetComponent<Rigidbody2D>().MovePosition(hatPosition3);
            }
            else if (a == 3 && system == 0)
            {
                por1 = enemytank.transform.position;
                enemytank.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 1)
            {
                por1 = enemytank1.transform.position;
                enemytank1.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
            else if (a == 3 && system == 2)
            {
                por1 = enemytank2.transform.position;
                enemytank2.transform.position = enemytank3.transform.position;
                enemytank3.transform.position = por1;
                system = 3;
            }
        }

    }
}