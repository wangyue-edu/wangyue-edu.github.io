#include <iostream>
#include <vector>
#include <string>

// 图书信息数据模型结构体
struct Book {
    int id;              // 图书唯一识别编号
    std::string title;   // 图书题名
    std::string author;  // 作者信息
    bool isBorrowed;     // 借阅在馆状态标识
};

// 智慧图书管理系统核心业务类
class Library {
private:
    std::vector<Book> books;

public:
    // 1. 添加新图书记录
    void addBook(int id, const std::string& title, const std::string& author) {
        Book newBook = { id, title, author, false };
        books.push_back(newBook);
        std::cout << "==> 图书 [" << title << "] 成功入库！" << std::endl;
    }

    // 2. 遍历打印在馆图书总览
    void viewBooks() const {
        if (books.empty()) {
            std::cout << "==> 当前馆藏暂无图书记录。" << std::endl;
            return;
        }
        std::cout << "\n============= 馆藏图书总览 =============" << std::endl;
        for (const auto& book : books) {
            std::cout << "ID: " << book.id
                      << " | 书名: " << book.title
                      << " | 作者: " << book.author
                      << " | 状态: " << (book.isBorrowed ? "已借出 [不可借]" : "在馆 [可借阅]")
                      << std::endl;
        }
        std::cout << "========================================" << std::endl;
    }

    // 3. 办理图书借阅
    void borrowBook(int id) {
        for (auto& book : books) {
            if (book.id == id && !book.isBorrowed) {
                book.isBorrowed = true;
                std::cout << "==> 借阅办理成功！请妥善保管图书。" << std::endl;
                return;
            }
        }
        std::cout << "==> 借阅失败：未查询到该图书或已被借出。" << std::endl;
    }

    // 4. 办理图书归还
    void returnBook(int id) {
        for (auto& book : books) {
            if (book.id == id && book.isBorrowed) {
                book.isBorrowed = false;
                std::cout << "==> 归还登记成功！图书已恢复在馆状态。" << std::endl;
                return;
            }
        }
        std::cout << "==> 归还失败：未查询到该借出记录。" << std::endl;
    }
};

int main() {
    Library library;

    int choice;
    while (true) {
        std::cout << "\n========================================\n";
        std::cout << "     南通中学 · 智慧图书借阅管理系统      \n";
        std::cout << "========================================\n";
        std::cout << "  1. 添加图书\n";
        std::cout << "  2. 查看全部图书\n";
        std::cout << "  3. 办理图书借阅\n";
        std::cout << "  4. 办理图书归还\n";
        std::cout << "  5. 退出系统\n";
        std::cout << "----------------------------------------\n";
        std::cout << "请选择操作菜单 [1-5]: ";
        if (!(std::cin >> choice)) break;

        switch (choice) {
        case 1: {
            int id;
            std::string title, author;
            std::cout << "请输入图书 ID: ";
            std::cin >> id;
            std::cout << "请输入图书名称: ";
            std::cin.ignore();
            std::getline(std::cin, title);
            std::cout << "请输入作者姓名: ";
            std::getline(std::cin, author);
            library.addBook(id, title, author);
            break;
        }
        case 2:
            library.viewBooks();
            break;
        case 3: {
            int id;
            std::cout << "请输入借阅图书 ID: ";
            std::cin >> id;
            library.borrowBook(id);
            break;
        }
        case 4: {
            int id;
            std::cout << "请输入归还图书 ID: ";
            std::cin >> id;
            library.returnBook(id);
            break;
        }
        case 5:
            std::cout << "感谢使用，系统安全退出。" << std::endl;
            return 0;
        default:
            std::cout << "无效指令，请重新输入！" << std::endl;
        }
    }
    return 0;
}
