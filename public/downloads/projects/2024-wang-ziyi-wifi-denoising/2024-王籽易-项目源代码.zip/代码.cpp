#include <bits/stdc++.h>
std::vector<double> data ;
int n;
const double o = 3.0; // ��ֵ
const double k=3; // ���崰�ڴ�С
double max(int x,double y) {
    return (x>y)?x:y;
}
double min(int x,double y) {
    return (x<y)?x:y;
}
std::vector<double> Filter(const std::vector<double>& data, double o, double k) {
    std::vector<double> outData = data;
    std::vector<double> median(n);
    std::vector<double> mad(n);
    for (int i = 0; i < n; ++i) {
        std::vector<double> window;
        for (int j = max(0, i - k); j <= min(n - 1, i + k); ++j) {
            window.push_back(data[j]);
        }
        sort(window.begin(), window.end());
        median[i] = window[window.size() / 2];
        mad[i] = 0;
        for (int j = 0; j < window.size(); ++j) {
            mad[i] += std::abs(window[j] - median[i]);
        }
        mad[i] /= window.size();
    }

    double O = o * median[0];
    for (int i = 0; i < n; ++i) {
        if (std::abs(data[i] - median[i]) > O) outData[i] = median[i];
    }
    return outData;
}

int main() {
    std::cin>>n;//12
    for(double i=0;i<n;i++){//1 2 2 2 3 4 10 6 2 3 4 5
        double t;
        std::cin>>t;
        data.push_back(t);
    }
    std::vector<double> Fdata = Filter(data, o, k);
    for (double num : Fdata) {
        std::cout << num << " ";
    }
    return 0;
}
