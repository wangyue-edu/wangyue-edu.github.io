#include <iostream>
using namespace std;

// 智能灶台核心逻辑控制微程序
// 根据电容式物位传感器采样反馈判断锅内受热沸腾高度与溢出风险
// 从而实现灶台电磁阀/功率等级的自动闭环调节

int main() {
    int liquid_level;
    cout << "==> 智能防溢灶台监控微程序启动..." << endl;
    cout << "请输入物位传感器实时检测高度值 a (10-20 为安全防溢区间): ";
    
    if (cin >> liquid_level) {
        if ((liquid_level >= 10) && (liquid_level <= 20)) {
            // 物位处于微沸稳定区间，执行小火稳压微调
            cout << "small" << endl;
        } else {
            // 超出安全阈值或剧烈沸腾，触发自适应主控逻辑
            cout << "according to the brain" << endl;
        }
    }
    return 0;
}
