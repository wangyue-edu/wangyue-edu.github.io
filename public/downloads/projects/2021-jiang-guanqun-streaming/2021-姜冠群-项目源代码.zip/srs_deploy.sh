#!/bin/bash
# CentOS 8.4 下 SRS 流媒体服务器编译部署脚本 (支持 GB28181 国标协议与 WebRTC)
set -e

# 1. 克隆官方 SRS 源码并安装基础编译依赖
echo "==> Cloning SRS repository..."
git clone -b 4.0release https://gitee.com/ossrs/srs.git
cd srs/trunk

# 2. 编译基础 SRS 4.0 版本
echo "==> Compiling SRS 4.0 core..."
./configure
make

# 3. 切换至 feature/gb28181 分支，重新配置编译
echo "==> Switching to GB28181 branch..."
git checkout feature/gb28181
./configure --with-gb28181
make clean
make

# 4. 配置服务器端参数 (根据云服务器公网 IP 替换 Hosts 与 CANDIDATE 地址)
# conf/push.gb28181.conf:
# candidate: 服务器公网候选地址（客户端连接的目标 ip:port）
echo "==> Starting SRS server with GB28181 config..."
./objs/srs -c conf/push.gb28181.conf

echo "==> SRS Server running! Now login to Dahua camera and configure GB28181 push parameters."
