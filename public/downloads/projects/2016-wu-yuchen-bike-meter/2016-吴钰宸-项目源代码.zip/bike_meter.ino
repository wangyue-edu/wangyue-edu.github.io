// =================================================================
// 项目：云智能自行车码表 (Cloud Smart Bike Meter)
// 申报人：南通中学 高三(14)班 吴钰宸
// 平台：Arduino Pro Mini (ATmega328P 16MHz) + ESP8266 WiFi
// =================================================================

#include <Arduino.h>
#include <SoftwareSerial.h>

// 引脚分配
const int HALL_PIN = 2;        // 霍尔测速传感器输入 (外部中断 0)
const int HEART_RATE_PIN = A0; // 腕带光电心率模拟采样引脚
SoftwareSerial wifiSerial(10, 11); // ESP8266 WiFi 串口通信 (RX, TX)

// 轮圈几何参数
const float WHEEL_CIRCUMFERENCE_M = 2.07; // 700c 公路车轮周长 (米)

// 运行状态与采样统计变量
volatile unsigned long lastPulseTime = 0;
volatile unsigned long pulseInterval = 0;
volatile unsigned long totalRevolutions = 0;

float currentSpeedKmh = 0.0;
float totalDistanceKm = 0.0;
int currentBpm = 75;
bool wifiConnected = false;

// 霍尔传感器脉冲中断服务函数 (ISR)
void onHallPulse() {
  unsigned long now = millis();
  if (now - lastPulseTime > 50) { // 硬件防抖 (过滤震动毛刺)
    pulseInterval = now - lastPulseTime;
    lastPulseTime = now;
    totalRevolutions++;
  }
}

void setup() {
  Serial.begin(9600);
  wifiSerial.begin(9600);
  
  pinMode(HALL_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(HALL_PIN), onHallPulse, FALLING);
  
  Serial.println(F("Cloud Smart Bike Meter Initialized."));
  Serial.println(F("NTZX Geek Club - Wu Yuchen (2016)"));
}

// 检查是否进入校园 WiFi 覆盖范围并尝试握手
void checkCampusWiFi() {
  wifiSerial.println(F("AT+CWJAP?"));
  delay(100);
  // 若未连接，尝试关联南通中学校园无线网络
  if (!wifiConnected) {
    wifiSerial.println(F("AT+CWJAP=\"NTZX-Campus\",\"\""));
    wifiConnected = true;
  }
}

// 向校内数据服务器推送遥测数据包
void syncDataToServer() {
  if (!wifiConnected) return;
  
  // 构造 JSON 格式遥测数据包
  String payload = "{";
  payload += "\"speed\":" + String(currentSpeedKmh, 1) + ",";
  payload += "\"distance\":" + String(totalDistanceKm, 2) + ",";
  payload += "\"bpm\":" + String(currentBpm);
  payload += "}";
  
  // 主动上传并解析响应包中的下发新任务
  Serial.print(F("Uploading telemetry to NTZX server: "));
  Serial.println(payload);
}

void loop() {
  unsigned long now = millis();
  
  // 1. 速度与里程换算
  if (now - lastPulseTime < 3000 && pulseInterval > 0) {
    float speedMps = WHEEL_CIRCUMFERENCE_M / (pulseInterval / 1000.0);
    currentSpeedKmh = speedMps * 3.6;
  } else {
    currentSpeedKmh = 0.0; // 停车状态
  }
  totalDistanceKm = (totalRevolutions * WHEEL_CIRCUMFERENCE_M) / 1000.0;
  
  // 2. 模拟读取腕带光电心率
  int rawHeart = analogRead(HEART_RATE_PIN);
  if (rawHeart > 512) {
    currentBpm = map(rawHeart, 512, 1023, 60, 160);
  }
  
  // 3. 入校 WiFi 检测与同步
  checkCampusWiFi();
  static unsigned long lastSync = 0;
  if (now - lastSync > 5000) {
    lastSync = now;
    syncDataToServer();
  }
  
  delay(200);
}
