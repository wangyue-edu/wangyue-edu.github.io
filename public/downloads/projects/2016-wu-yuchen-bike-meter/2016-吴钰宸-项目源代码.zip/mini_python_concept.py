#!/usr/bin/env python3
# =================================================================
# 项目：便携微型编程机构想 (Portable Python Mini-Computer)
# 申报人：南通中学 高三(14)班 吴钰宸
# 运行环境设想：ARM SoC + BusyBox + Python 运行时 + 4x4 矩阵键盘
# =================================================================

import sys
import time

# 4x4 矩阵物理按键与关键字/函数映射表 (存放在外置 SD 卡中，可随时插拔修改)
KEYMAP_KEYWORDS = {
    (0, 0): "print(",
    (0, 1): "for i in range(",
    (0, 2): "while ",
    (0, 3): "if ",
    (1, 0): "def ",
    (1, 1): "return ",
    (1, 2): "import ",
    (1, 3): "class ",
    (2, 0): "sys.argv",
    (2, 1): "open(",
    (2, 2): "requests.get(",
    (2, 3): "len(",
    (3, 0): "True",
    (3, 1): "False",
    (3, 2): "None",
    (3, 3): "\n",  # 回车换行执行
}

# 模式二：自定义变量与常用函数映射表
KEYMAP_CUSTOM = {
    (0, 0): "url",
    (0, 1): "data",
    (0, 2): "headers",
    (0, 3): "result",
    (1, 0): "fetch_data()",
    (1, 1): "parse_html()",
    (1, 2): "save_to_sd()",
    (1, 3): "run_spider()",
}

class MiniPythonTerminal:
    def __init__(self):
        self.current_mode = "KEYWORDS" # KEYWORDS 或 CUSTOM
        self.code_buffer = ""
        print("==> 便携微型编程机 (NTZX Geek Edition) 启动中...")
        print("==> BusyBox 核心加载完成，Python 交互运行环境就绪。")
        print("==> 按键表已从 /mnt/sdcard/keymap.cfg 挂载成功。")

    def switch_keymap_mode(self):
        self.current_mode = "CUSTOM" if self.current_mode == "KEYWORDS" else "KEYWORDS"
        print(f"[*] 切换按键表映射模式: {self.current_mode}")

    def on_matrix_key_pressed(self, row: int, col: int):
        active_map = KEYMAP_KEYWORDS if self.current_mode == "KEYWORDS" else KEYMAP_CUSTOM
        token = active_map.get((row, col), "")
        self.code_buffer += token
        print(f"[INPUT] 写入: {token} | 当前代码缓冲区: {self.code_buffer}")

    def execute_script(self):
        print(f"[*] 开始在后台微型进程执行代码: {self.code_buffer}")
        # 在受控上下文中运行自定义爬虫/计算代码
        try:
            exec(self.code_buffer)
        except Exception as e:
            print(f"[!] 执行异常: {e}")
        self.code_buffer = ""

if __name__ == "__main__":
    device = MiniPythonTerminal()
    # 模拟矩阵键盘输入代码示例
    device.on_matrix_key_pressed(0, 0) # print(
    device.switch_keymap_mode()
    device.on_matrix_key_pressed(0, 3) # result
    device.switch_keymap_mode()
    device.on_matrix_key_pressed(3, 3) # 

