#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>

using namespace std;

int main() {
    int N;
    cin >> N;
    int a[N];
    for (int j = 0; j < N; ++j) {
        cin >> a[j];
    }
    int m;
    cin >> m;
    int sum = 0;
    for (int i = 0; i < N; ++i) {
        do {
            if (a[i] % 10 == m) sum++;
            a[i] = a[i] / 10;
        } while (a[i] > 0);
    }
    cout << sum;
    return 0;
}