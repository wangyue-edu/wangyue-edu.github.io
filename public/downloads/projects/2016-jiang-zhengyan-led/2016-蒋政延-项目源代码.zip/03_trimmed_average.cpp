#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>

using namespace std;

int main() {
    float a, i, sum, min, max;
    cin >> a;
    min = a;
    max = a;
    sum = a;
    for (i = 1; i <= 9; i++) {
        cin >> a;
        sum = sum + a;
        if (min > a) min = a;
        if (max < a) max = a;
    }
    printf("%8.3f", (sum - min - max) / 8);
    return 0;
}