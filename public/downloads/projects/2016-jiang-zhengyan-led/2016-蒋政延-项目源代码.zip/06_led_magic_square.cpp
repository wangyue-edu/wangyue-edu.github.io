#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>

using namespace std;

int main() {
    int N;
    cin >> N;
    int hang, lie;
    int a[100][100] = {0};
    hang = 0;
    lie = N / 2;
    a[hang][lie] = 1;
    for (int k = 2; k <= N * N; k++) {
        if (hang == 0 && lie != N - 1) {
            hang = N - 1;
            lie++;
        } else if (lie == N - 1 && hang != 0) {
            lie = 0;
            hang--;
        } else if (hang == 0 && lie == N - 1) {
            hang++;
        } else if (hang != 0 && lie != N - 1) {
            if (a[hang - 1][lie + 1] == 0) {
                hang--;
                lie++;
            } else {
                hang++;
            }
        }
        a[hang][lie] = k;
    }
    for (hang = 0; hang <= N - 1; hang++) {
        for (lie = 0; lie <= N - 2; lie++) {
            cout << a[hang][lie] << " ";
        }
        cout << a[hang][N - 1] << endl;
    }
    return 0;
}