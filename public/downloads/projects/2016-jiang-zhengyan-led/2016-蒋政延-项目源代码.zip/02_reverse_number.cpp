#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cstdio>

using namespace std;

int main() {
    int a, b, t = 0;
    cin >> a;
    while (a != 0) {
        b = a % 10;
        t = t * 10 + b;
        a = a / 10;
    }
    cout << t;
    return 0;
}