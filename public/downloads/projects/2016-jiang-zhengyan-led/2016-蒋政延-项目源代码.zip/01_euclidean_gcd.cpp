#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>

using namespace std;

int main() {
    int a, b, r;
    cin >> a >> b;
    cout << "(" << a << "," << b << ")=";
    while (a % b != 0) {
        r = a % b;
        a = b;
        b = r;
    }
    cout << b;
    return 0;
}