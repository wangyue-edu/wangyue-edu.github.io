#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>

using namespace std;

int main() {
    int a[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int m;
    cin >> m;
    for (int j = 0; j < m; ++j) {
        int temp = a[0];
        for (int i = 0; i < 9; ++i) {
            a[i] = a[i + 1];
        }
        a[9] = temp;
        for (int i = 0; i < 10; ++i) {
            cout << setw(3) << a[i];
        }
    }
    return 0;
}