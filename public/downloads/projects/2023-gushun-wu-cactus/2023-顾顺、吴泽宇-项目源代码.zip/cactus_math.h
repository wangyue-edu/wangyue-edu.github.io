#include"cactus_in.h"

using namespace std;

double eps=1e-6;

void resize_eps(const double ep){
	eps=ep;
}

class doubles{
	public:
		double d;

	public:
		doubles(void){
			d=0.0000000;
		}
		
		doubles(const double x){
			d=x;
		}

		void operator=(const double x){
			d=x;
		}
		
		void operator=(const doubles x){
			d=x.d;
		}

		const bool operator==(const double x)const {
			return fabs(d-x)<=eps;
		}
		
		const bool operator==(const doubles x)const {
			return fabs(d-x.d)<=eps;
		}
		
		const bool operator!=(const double x)const {
			return fabs(d-x)>eps;
		}
		
		const bool operator!=(const doubles x)const {
			return fabs(d-x.d)>eps;
		}

		const bool operator>(const double x)const {
			return d-x>eps;
		}
		
		const bool operator>(const doubles x)const {
			return d-x.d>eps;
		}
		
		const bool operator<(const double x)const {
			return d-x<-eps;
		}
		
		const bool operator<(const doubles x)const {
			return d-x.d<-eps;
		}

		const bool operator>=(const double x)const {
			return d-x>=-eps;
		}
		
		const bool operator>=(const doubles x)const {
			return d-x.d>=-eps;
		}
		
		const bool operator<=(const double x)const {
			return d-x<=eps;
		}
		
		const bool operator<=(const doubles x)const {
			return d-x.d<=eps;
		}

		operator double()const {
			return d;
		}
		
		operator int()const {
			return (int)d;
		}

		const doubles operator+(const doubles x){
			return doubles(d+x.d);
		}
		
		const doubles operator-(const doubles x){
			return doubles(d-x.d);
		}
		
		const doubles operator*(const doubles x){
			return doubles(d*x.d);
		}
		
		const doubles operator/(const doubles x){
			return doubles(d/x.d);
		}

		const doubles operator+(const double x){
			return doubles(d+x);
		}
		
		const doubles operator-(const double x){
			return doubles(d-x);
		}
		
		const doubles operator*(const double x){
			return doubles(d*x);
		}
		
		const doubles operator/(const double x){
			return doubles(d/x);
		}

		void operator+=(const doubles x){
			d+=x.d;
		}
		
		void operator-=(const doubles x){
			d-=x.d;
		}
		
		void operator*=(const doubles x){
			d*=x.d;
		}
		
		void operator/=(const doubles x){
			d/=x.d;
		}

		void operator+=(const double x){
			d+=x;
		}
		
		void operator-=(const double x){
			d-=x;
		}
		
		void operator*=(const double x){
			d*=x;
		}
		
		void operator/=(const double x){
			d/=x;
		}
		
};

const doubles log(const doubles x){
	return doubles(log(x.d));
}

const doubles log10(const doubles x){
	return doubles(log10(x.d));
}

const doubles sqrt(const doubles x){
	return doubles(sqrt(x.d));
}

const doubles exp(const doubles x){
	return doubles(exp(x.d));
}

const doubles pow(const doubles x,const doubles y){
	return doubles(pow(x.d,y.d));
}

const doubles sin(const doubles x){
	return doubles(sin(x.d));
}

const doubles cos(const doubles x){
	return doubles(cos(x.d));
}

const doubles tan(const doubles x){
	return doubles(tan(x.d));
}

const doubles cot(const doubles x){
	return doubles(cot(x.d));
}

const doubles asin(const doubles x){
	return doubles(asin(x.d));
}

const doubles acos(const doubles x){
	return doubles(acos(x.d));
}

const doubles atan(const doubles x){
	return doubles(atan(x.d));
}

const doubles atan2(const doubles x,const doubles y){
	return doubles(atan2(x.d,y.d));
}

const doubles acot(const doubles x){
	return doubles(acot(x.d));
}

const doubles sinh(const doubles x){
	return doubles(sinh(x.d));
}

const doubles cosh(const doubles x){
	return doubles(cosh(x.d));
}

const doubles tanh(const doubles x){
	return doubles(tanh(x.d));
}

const doubles coth(const doubles x){
	return doubles(coth(x.d));
}

const doubles asinh(const doubles x){
	return doubles(asinh(x.d));
}

const doubles acosh(const doubles x){
	return doubles(acosh(x.d));
}

const doubles atanh(const doubles x){
	return doubles(atanh(x.d));
}

const doubles acoth(const doubles x){
	return doubles(acoth(x.d));
}

const doubles fabs(const doubles x){
	return doubles(fabs(x.d));
}

const doubles floor(const doubles x){
	return doubles(floor(x.d));
}

const doubles ceil(const doubles x){
	return doubles(ceil(x.d));
}

const doubles operator+(const double x,const doubles y){
	return doubles(x+y.d);
}

const doubles operator-(const double x,const doubles y){
	return doubles(x-y.d);
}

const doubles operator*(const double x,const doubles y){
	return doubles(x*y.d);
}

const doubles operator/(const double x,const doubles y){
	return doubles(x/y.d);
}

const doubles operator-(const doubles x){
	return doubles(-x.d);
}

void operator+=(double& x,const doubles y){
	x+=y.d;
}

void operator-=(double& x,const doubles y){
	x-=y.d;
}

void operator*=(double& x,const doubles y){
	x*=y.d;
}

void operator/=(double& x,const doubles y){
	x/=y.d;
}

void operator=(double& x,const doubles y){
	x=y.d;
}

const doubles pi=acos(doubles(-1.0));
const doubles sqrt2=sqrt(doubles(2.0));

io operator>>(io iot,doubles &it){
	scanf("%lf",&it);
	return iot;
}

io operator<<(io iot,const doubles it){
	printf("%f",it);
	return iot;
}

/*******************************************************************************/

class vector2d;

class point2d {
	public:
		doubles x;
		doubles y;

	public:
		point2d(void){
			x=0.0;
			y=0.0;
		}

		point2d(const doubles posx,const doubles posy){
			x=posx;
			y=posy;
		}

		point2d(const double posx,const double posy){
			x=posx;
			y=posy;
		}

		void convert(const doubles posx,const doubles posy){
			x=posx;
			y=posy;
		}

		void convert(const double posx,const double posy){
			x=posx;
			y=posy;
		}

		const vector2d vector(void);

		const point2d operator+(const vector2d vt);
		const point2d operator-(const vector2d vt);

		void operator+=(const vector2d vt);
		void operator-=(const vector2d vt);
};

const doubles distance(const point2d p1,const point2d p2){
	return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}

const doubles distance_square(const point2d p1,const point2d p2){
	return (p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y);
}

class vector2d {
	public:
		doubles x;
		doubles y;

	public:
		vector2d(void){
			x=0.0;
			y=0.0;
		}

		vector2d(const double posx,const double posy){
			x=posx;
			y=posy;
		}

		vector2d(const doubles posx,const doubles posy){
			x=posx;
			y=posy;
		}

		const vector2d operator+(const vector2d vt)const {
			return vector2d(x+vt.x,y+vt.y);
		}
		
		const vector2d operator-(const vector2d vt)const {
			return vector2d(x-vt.x,y-vt.y);
		}

		const vector2d operator*(const double db){
			return vector2d(x*db,y*db);
		}
		
		const vector2d operator*(const doubles db)const {
			return vector2d(x*db,y*db);
		}
		
		const vector2d operator/(const double db){
			return vector2d(x/db,y/db);
		}
		
		const vector2d operator/(const doubles db)const {
			return vector2d(x/db,y/db);
		}

		const doubles mod(void){
			return sqrt(x*x+y*y);
		}
		
		const doubles mod_square(void){
			return x*x+y*y;
		}

		const point2d point(void){
			return point2d(x,y);
		}

		void operator+=(const vector2d vt){
			x+=vt.x;
			y+=vt.y;
		}
		
		void operator-=(const vector2d vt){
			x-=vt.x;
			y-=vt.y;
		}
		
		void operator*=(const double db){
			x*=db;
			y*=db;
		}
		
		void operator/=(const double db){
			x/=db;
			y/=db;
		}
		
		void operator*=(const doubles db){
			x*=db;
			y*=db;
		}
		
		void operator/=(const doubles db){
			x/=db;
			y/=db;
		}

		const vector2d operator+(const point2d pt){
			return vector2d(x+pt.x,y+pt.y);
		}
		
		const vector2d operator-(const point2d pt){
			return vector2d(x-pt.x,y-pt.y);
		}
		
		const doubles operator*(const vector2d vt);
};

const vector2d point2d::vector(void){
	return vector2d(x,y);
}

const point2d point2d::operator+(const vector2d vt){
	return point2d(x+vt.x,y+vt.y);
}

const point2d point2d::operator-(const vector2d vt){
	return point2d(x-vt.x,y-vt.y);
}

void point2d::operator+=(const vector2d vt){
	x+=vt.x;
	y+=vt.y;
}

void point2d::operator-=(const vector2d vt){
	x-=vt.x;
	y-=vt.y;
}

const doubles dot(const vector2d v1,const vector2d v2){
	return v1.x*v2.x+v1.y*v2.y;
}

const doubles cross(const vector2d v1,const vector2d v2){
	return v1.x*v2.y+v1.y*v2.x;
}

const doubles vector2d::operator*(const vector2d vt){
	return x*vt.x+y*vt.y;
}

const doubles cos_angle(vector2d v1,vector2d v2){
	return v1*v2/v1.mod()/v2.mod();
}

const doubles angle(const vector2d v1,const vector2d v2){
	return acos(cos_angle(v1,v2));
}

/*

{ }

*/