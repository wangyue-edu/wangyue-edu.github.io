#include"cactus.h"
using namespace std;
//unfinished 
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#define exKMP z_algorithm
#define exkmp z_algorithm
template <typename cactus>
class z_algorithm{
	private:
	public:
		int n;
		cactus c[MAXN];
		int z[MAXN];
		int l,r;
		void init(void);
		void init(cactus *a1,cactus *a2);
		int add_in(cactus v);
	public:
		z_algorithm(void);
		z_algorithm(const cactus *a1,const cactus *a2);
		const SIZE_C size(void);
		const int add(const cactus v);
		const int operator+=(const cactus v);
		const cactus operator()(const int addr);
		const int operator[](const int addr);
};

template <typename cactus>
void z_algorithm<cactus>::init(void){
	n=0;
	l=r=0;
}

template <typename cactus>
void z_algorithm<cactus>::init(cactus *a1,cactus *a2){
	int len=a2-a1;
	for(int i=0;i<len;i++){
		add_in(*s);
		s++;
	}
}

template <typename cactus>
int z_algorithm<cactus>::add_in(cactus v){
	int i=n;
	c[n]=v;
	n++;
	if(i<=r){
		if(z[i-l])
	}else{
		
	}
}

template <typename cactus>
z_algorithm<cactus>::z_algorithm(void){
	
}
template <typename cactus>
z_algorithm<cactus>::z_algorithm(const cactus *a1,const cactus *a2){
	
}

template <typename cactus>
const SIZE_C z_algorithm<cactus>::size(void){
	
}

template <typename cactus>
const int z_algorithm<cactus>::add(const cactus v){
	
}

template <typename cactus>
const int z_algorithm<cactus>::operator+=(const cactus v){
	
}

template <typename cactus>
const cactus z_algorithm<cactus>::operator()(const int addr){
	
}

template <typename cactus>
const int z_algorithm<cactus>::operator[](const int addr){
	
}

/**********************************************************************************/

#define weighed_DSU weighed_union_set
#define WDSU weighed_union_set
template <typename cactus>
class weighed_union_set{
	private:
	public:
		
	public:
		
};




