/*
C++14 9.2.0 64-bit Release

compilation command:
-O2 -std=c++17 -Wno-unused-result -Wall -pedantic-errors -Werror -fsanitize=undefined
*/
#pragma warning(disable:4996)
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>

const int MAXN=1003;
const int MAXNUM=20004;
const int MAXBI=1003;
const int MAXH=31;
const int INF=0x7fffffff;
const int MOD=1000000007;
const double eps=1e-6;
#define SIZE_C int

using namespace std;

/*******************************************************************************/
#ifndef CACTUS_H
#define CACTUS_H

/*******************************************************************************/
//declarations of all functions

const int sqrt_c(const int x);
template <typename cactus>void swap_c(cactus &c1,cactus &c2);
template <typename cactus> const cactus abs_c(const cactus v);
template <typename cactus> const cactus add_c(const cactus a,const cactus b);
template <typename cactus> const cactus minus_c(const cactus a,const cactus b);
template <typename cactus> const cactus multiply_c(const cactus a,const cactus b);
template <typename cactus> const cactus divide_c(const cactus a,const cactus b);
template <typename cactus> const cactus max_c(const cactus a,const cactus b);
template <typename cactus> const cactus min_c(const cactus a,const cactus b);
const int log2n(const int n);
const bool kth_bool(const int n,const int k);
template <typename cactus> const cactus gcd_c(const cactus& a,const cactus& b);
template <typename cactus> const cactus lcm_c(const cactus& a,const cactus& b);
template <typename cactus,typename cactusx> const cactus pow_c(const cactus& a,const cactusx& n);
template <typename cactus,typename cactusx> const cactus pow_c(const cactus& a,const cactusx& n,const cactus& mod);
const int phi(const int n);
const int prime(const int id);

/*******************************************************************************/

//declaration of all classes as below
class io_assist;
template <typename cactus=int> class io_pointer_i;
template <typename cactus=int> class io_pointer_o;
class io;
template <typename cactus=int,int MaxSize=MAXN> class array_c;
template <typename cactus=int> class queue_c;
template <typename cactus=int> class stack_c;
template <typename cactus=int> class deque_c;
template <typename cactus=int> class min_mono_queue;
template <typename cactus=int> class max_mono_queue;
template <typename T_1=int,typename T_2=int> class pair_c;
template <typename cactus=int> class small_heap;
template <typename cactus=int> class big_heap;
class union_set;
template <typename cactus=int> class tree_array;
template <typename cactus=int> class max_seg_tree;
template <typename cactus=int> class min_seg_tree;
template <typename cactus=int> class max_st_list;
template <typename cactus=int> class min_st_list;
template <typename cactus=int> class sum_segment_tree;
template <typename cactus=int,cactus (*f)(cactus,cactus)=add_c,cactus (*chg)(cactus,cactus)=add_c> class segment_tree;
template <typename cactus=int> class splay_node;
template <typename cactus=int> class splay;
template <typename cactus=int> class multi_splay_node;
template <typename cactus=int> class multi_splay;
class weighed_node;
class weighed_tree;
class president_node;
class president_tree;
class range_seg_node;
class range_weighed_query_tree;
class discrete_range_weighed_query_tree;
template <typename cactus=int> class treap_node;
template <typename cactus=int> class treap;
template <typename cactus=int> class multi_treap_node;
template <typename cactus=int> class multi_treap;
template <typename cactus=int> class single_block;
template <typename cactus=int> class block_list;
template <typename cactus=int> class fhq_node;
template <typename cactus=int> class fhq_treap;
template <typename cactus=int> class multi_fhq_node;
template <typename cactus=int> class multi_fhq_treap;
template <typename cactus=int> class persistent_node;
template <typename cactus=int> class max_persistent_segment_tree;
template <typename cactus=int> class min_persistent_segment_tree;
template <typename cactus=int> class sum_persistent_segment_tree;
class union_node;
class persistent_union_set;
template <typename cactus=int> class reverse_splay_node;
template <typename cactus=int> class reverse_splay;
template <typename cactus=int> class reverse_fhq_node;
template <typename cactus=int> class reverse_fhq_treap;
template <typename cactus=int> class persistent_fhq_node;
template <typename cactus=int> class persistent_fhq_treap;
template <typename cactus=int> class persistent_multi_fhq_node;
template <typename cactus=int> class persistent_multi_fhq_treap;
template <typename cactus=int> class persistent_reverse_fhq_node;
template <typename cactus=int> class persistent_reverse_fhq_treap;
class ascii_trie;
class alphabet_trie;
class trie;
class lowercase_trie;
class uppercase_trie;
class range_node;
class range_weighed_tree;
template <typename cactus=int> class range_fhq_node;
template <typename cactus=int> class range_fhq_treap;
template <typename cactus=int> class leftist_node;
template <typename cactus=int> class min_leftist_tree;
template <typename cactus=int> class max_leftist_tree;
class inverse_element;
template <typename cactus=int> class discrete_array;
class t01_node;
class trie01;
template <typename cactus=int> class exGCD;
template <typename cactus=int> class area_sum;
template <typename cactus=int> class area_sum_calc;
template <typename cactus=int> class area_sum_ndtr;
template <typename cactus=int> class area_sum_node;
template <typename cactus=int> class sum_lct_node;
template <typename cactus=int> class sum_link_cut_trees;
template <typename cactus=int,cactus (*fx)(cactus,cactus)=add_c> class lct_node;
template <typename cactus=int,cactus (*fx)(cactus,cactus)=add_c> class link_cut_trees;
class map_node;
class directed_graph;
class undirected_graph;
class p_trie_node;
class persistent_trie;
class p_upper_trie_node;
class persistent_uppercase_trie;
class p_lower_trie_node;
class persistent_lowercase_trie;
class p_asc_trie_node;
class persistent_ascii_trie;
class dinic_node;
class dinic;
class dinic_mcmf_node;
class dinic_mcmf;
class lc_segment;
class max_line_segment_tree;
class min_line_segment_tree;

/*******************************************************************************/

const int sqrt_c(const int x){
	int l=0;
	int r=MAXN;
	int mid;
	while(1){
		if(r-l==1){
			return l;
		}
		mid=(l+r)>>1;
		if(mid*mid<=x){
			l=mid;
		}else{
			r=mid;
		}
	}
}

template <typename cactus>
void swap_c(cactus &c1,cactus &c2){
	cactus t=c1;
	c1=c2;
	c2=t;
}

template <typename cactus>
const cactus abs_c(const cactus v){
	if(v>=0){
		return v;
	}
	return -v;
}

template <typename cactus>
const cactus add_c(const cactus a,const cactus b){
	return a+b;
}

template <typename cactus>
const cactus minus_c(const cactus a,const cactus b){
	return a-b;
}

template <typename cactus>
const cactus multiply_c(const cactus a,const cactus b){
	return a*b;
}

template <typename cactus>
const cactus divide_c(const cactus a,const cactus b){
	return a/b;
}

template <typename cactus>
const cactus max_c(const cactus a,const cactus b){
	return a>b?a:b;
}

template <typename cactus>
const cactus min_c(const cactus a,const cactus b){
	return a<b?a:b;
}

bool log2n_flag=1;
int log2n_[MAXN];

inline void log2n_init(void){
	log2n_[0]=log2n_[1]=0;
	for(int i=2;i<MAXN;i++){
		log2n_[i]=log2n_[i>>1]+1;
	}
	log2n_flag=0;
}

const int log2n(const int n){
	if(log2n_flag){
		log2n_init();
	}
	return log2n_[n];
}

const bool kth_bool(const int n,const int k){
	return bool(n&(1<<k));
}

template <typename cactus>
const cactus gcd_c(const cactus& a,const cactus& b){
	cactus a_=a,b_=b,t;
	while(b_){
		t=b_;
		b_=a_%b_;
		a_=t;
	}
	return a_;
}

template <typename cactus>
const cactus lcm_c(const cactus& a,const cactus& b){
	return a/gcd_c(a,b)*b;
}

template <typename cactus,typename cactusx>
const cactus pow_c(const cactus& a,const cactusx& n){//a^n
	cactus ret=0;
	cactus temp=a;
	cactusx n_=n;
	while(n_){
		if(n_&1){
			ret+=temp;
		}
		temp*=temp;
		n_>>1;
	}
	return ret;
}

template <typename cactus,typename cactusx>
const cactus pow_c(const cactus& a,const cactusx& n,const cactus& mod){//a^n
	cactus ret=0;
	cactus temp=a%mod;
	cactusx n_=n;
	while(n_){
		if(n_&1){
			ret+=temp;
			ret%=mod;
		}
		temp=(temp*temp)%mod;
		n_>>1;
	}
	return ret;
}

int pri_phif[MAXN];
int cnt_phif=0;
int ph_phif[MAXN]={0,1};
bool vis_phif[MAXN];
int flag_phif=2;
const int phi(const int n){
	if(n<flag_phif){
		return ph_phif[n];
	}
	for(;flag_phif<=n;flag_phif++){
		if(!vis_phif[flag_phif]){
			cnt_phif++;
			pri_phif[cnt_phif]=flag_phif;
			ph_phif[flag_phif]=flag_phif-1;
		}
		for(int j=1;j<=cnt_phif;j++){
			if(pri_phif[j]*flag_phif>=MAXN-3)break;
			vis_phif[pri_phif[j]*flag_phif]=1;
			if(flag_phif%pri_phif[j]){
				ph_phif[pri_phif[j]*flag_phif]=ph_phif[flag_phif]*(pri_phif[j]-1);
			}else{
				ph_phif[pri_phif[j]*flag_phif]=ph_phif[flag_phif]*pri_phif[j];
				break;
			}
		}
	}
	return ph_phif[n];
}

const int prime(const int id){
	if(id<=cnt_phif){
		return pri_phif[id];
	}
	for(;cnt_phif<=id;flag_phif++){
		if(!vis_phif[flag_phif]){
			cnt_phif++;
			pri_phif[cnt_phif]=flag_phif;
			ph_phif[flag_phif]=flag_phif-1;
		}
		for(int j=1;j<=cnt_phif;j++){
			if(pri_phif[j]*flag_phif>=MAXN-3)break;
			vis_phif[pri_phif[j]*flag_phif]=1;
			if(flag_phif%pri_phif[j]){
				ph_phif[pri_phif[j]*flag_phif]=ph_phif[flag_phif]*(pri_phif[j]-1);
			}else{
				ph_phif[pri_phif[j]*flag_phif]=ph_phif[flag_phif]*pri_phif[j];
				break;
			}
		}
	}
	return pri_phif[id];
}

/*******************************************************************************/
//quick write
const bool isnum(const char ch){
	return ch>='0'&&ch<='9';
}

const bool isnum(const int ch){
	return ch>='0'&&ch<='9';
}

const bool notnum(const char ch){
	return ch<'0'||ch>'9';
}

const bool notnum(const int ch){
	return ch<'0'||ch>'9';
}

inline void print(int pr){
	if(pr<0){
		putchar('-');
		pr=-pr;
	}
	if(pr>=0&&pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(short pr){
	if(pr<0){
		putchar('-');
		pr=-pr;
	}
	if(pr>=0&&pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(long pr){
	if(pr<0){
		putchar('-');
		
	}
	if(pr>=0&&pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(long long pr){
	if(pr<0){
		putchar('-');
		pr=-pr;
	}
	if(pr>=0&&pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(__int128 pr){
	if(pr<0){
		putchar('-');
		pr=-pr;
	}
	if(pr>=0&&pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(unsigned int pr){
	if(pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(unsigned short pr){
	if(pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(unsigned long pr){
	if(pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(unsigned long long pr){
	if(pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(unsigned __int128 pr){
	if(pr<10){
		putchar(pr+'0');
		return;
	}
	print(pr/10);
	putchar(pr%10+'0');
}

inline void print(const bool pr){
	putchar(pr+'0');
}

inline void print(const char ch){
	putchar(ch);
}

inline void print(const char *c){
	while(*c!='\0'){
		putchar(*c);
		c++;
	}
}

inline void print(const string str){
	int lng=str.length();
	for(int i=0;i<lng;i++){
		putchar(str[i]);
	}
}

inline void print(const double db){
	printf("%f",db);
}

inline void print(const float db){
	printf("%f",db);
}

/*******************************************************************************/
//quick read
inline void qread(int &rd){
	int sgn=1;
	int ret=0;
	char r=getchar();
	while(notnum(r)&&r!='-'){
		r=getchar();
	}
	if(r=='-'){
		sgn=-1;
	}else{
		ret=r-'0';
	}
	r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=sgn*ret;
}

inline void qread(long long &rd){
	long long sgn=1;
	long long ret=0;
	char r=getchar();
	while(notnum(r)&&r!='-'){
		r=getchar();
	}
	if(r=='-'){
		sgn=-1;
	}else{
		ret=r-'0';
	}
	r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=sgn*ret;
}

inline void qread(short &rd){
	int sgn=1;
	int ret=0;
	char r=getchar();
	while(notnum(r)&&r!='-'){
		r=getchar();
	}
	if(r=='-'){
		sgn=-1;
	}else{
		ret=r-'0';
	}
	r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=sgn*ret;
}

inline void qread(long &rd){
	long sgn=1;
	long ret=0;
	char r=getchar();
	while(notnum(r)&&r!='-'){
		r=getchar();
	}
	if(r=='-'){
		sgn=-1;
	}else{
		ret=r-'0';
	}
	r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=sgn*ret;
}

inline void qread(__int128 &rd){
	__int128 sgn=1;
	__int128 ret=0;
	char r=getchar();
	while(notnum(r)&&r!='-'){
		r=getchar();
	}
	if(r=='-'){
		sgn=-1;
	}else{
		ret=r-'0';
	}
	r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=sgn*ret;
}

inline void qread(unsigned int &rd){
	unsigned int ret=0;
	char r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=ret;
}

inline void qread(unsigned long long &rd){
	unsigned long long ret=0;
	char r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=ret;
}

inline void qread(unsigned short &rd){
	unsigned short ret=0;
	char r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=ret;
}

inline void qread(unsigned long &rd){
	unsigned long ret=0;
	char r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=ret;
}

inline void qread(unsigned __int128 &rd){
	unsigned __int128 ret=0;
	char r=getchar();
	while(isnum(r)){
		ret*=10;
		ret+=r-'0';
		r=getchar();
	}
	rd=ret;
}

inline void qread(bool &rd){
	char r=getchar();
	while(r!='0'&&r!='1'){
		r=getchar();
	}
	rd=(r=='1');
}

inline const bool char_in_end(const char c){
	return c=='\n'||c==' ';
}

inline void qread(char &rd){
	rd=getchar();
	while(char_in_end(rd)){
		rd=getchar();
	}
}

inline void qread(string &rd){
	char gt=getchar();
	rd="";
	while(char_in_end(gt)){
		gt=getchar();
	}
	while(!char_in_end(gt)){
		rd+=gt;
		gt=getchar();
	}
}

inline void qread(char *rd){
	char gt=getchar();
	while(char_in_end(gt)){
		gt=getchar();
	}
	while(!char_in_end(gt)){
		*rd+=gt;
		rd++;
		gt=getchar();
	}
	*rd='\0';
}

inline void qread(double &rd){
	scanf("%lf",&rd);
}

inline void qread(float &rd){
	scanf("%f",&rd);
}

/*******************************************************************************/
//io class
char iofx[MAXNUM]={' ','\n','\t'};

class io_assist{
	private:
		unsigned int num;
	public:
		io_assist(const unsigned int n);
		io_assist(void);
		const char fx(void);
		void operator=(const unsigned int n);
		void redirect(char rdr);
		void redirect(unsigned int re,char rdr);
}space(0),enter(1),tab(2);

io_assist::io_assist(const unsigned int n){
	num=n;
}

io_assist::io_assist(void){
	num=0;
}

const char io_assist::fx(void){
	return iofx[num];
}

void io_assist::operator=(const unsigned int n){
	num=n;
}

void io_assist::redirect(char rdr){
	iofx[num]=rdr;
}

void io_assist::redirect(unsigned int re,char rdr){
	iofx[re]=rdr;
}



class io{
	public:
		io operator>>(int &it);
		io operator>>(long &it);
		io operator>>(short &it);
		io operator>>(long long &it);
		io operator>>(__int128 &it);
		io operator>>(unsigned int &it);
		io operator>>(unsigned long &it);
		io operator>>(unsigned short &it);
		io operator>>(unsigned long long &it);
		io operator>>(unsigned __int128 &it);
		io operator>>(bool &it);
		io operator>>(char &it);
		io operator>>(string &it);
		io operator>>(char *it);
		io operator>>(float &it);
		io operator>>(double &it);
		io operator<<(const int ot);
		io operator<<(const short ot);
		io operator<<(const long ot);
		io operator<<(const long long ot);
		io operator<<(const __int128 ot);
		io operator<<(const unsigned int ot);
		io operator<<(const unsigned short ot);
		io operator<<(const unsigned long ot);
		io operator<<(const unsigned long long ot);
		io operator<<(const unsigned __int128 ot);
		io operator<<(const bool ot);
		io operator<<(const char ot);
		io operator<<(const string ot);
		io operator<<(io_assist ot);
		io operator<<(const char *ot);
		io operator<<(const double ot);
		io operator<<(const float ot);
}cactusin,cactusout,cactusio,cio;

io io::operator>>(int &it){
	qread(it);
	return *this;
}

io io::operator>>(long &it){
	qread(it);
	return *this;
}

io io::operator>>(short &it){
	qread(it);
	return *this;
}

io io::operator>>(long long &it){
	qread(it);
	return *this;
}

io io::operator>>(__int128 &it){
	qread(it);
	return *this;
}

io io::operator>>(unsigned int &it){
	qread(it);
	return *this;
}

io io::operator>>(unsigned long &it){
	qread(it);
	return *this;
}

io io::operator>>(unsigned short &it){
	qread(it);
	return *this;
}

io io::operator>>(unsigned long long &it){
	qread(it);
	return *this;
}

io io::operator>>(unsigned __int128 &it){
	qread(it);
	return *this;
}

io io::operator>>(bool &it){
	qread(it);
	return *this;
}

io io::operator>>(char &it){
	qread(it);
	return *this;
}

io io::operator>>(string &it){
	cin>>it;
//	qread(it);
	return *this;
}

io io::operator>>(char *it){
	cin>>it;
//	qread(it);
	return *this;
}

io io::operator>>(float &it){
	qread(it);
	return *this;
}

io io::operator>>(double &it){
	qread(it);
	return *this;
}

io io::operator<<(const int ot){
	print(ot);
	return *this;
}

io io::operator<<(const short ot){
	print(ot);
	return *this;
}

io io::operator<<(const long ot){
	print(ot);
	return *this;
}

io io::operator<<(const long long ot){
	print(ot);
	return *this;
}

io io::operator<<(const __int128 ot){
	print(ot);
	return *this;
}

io io::operator<<(const unsigned int ot){
	print(ot);
	return *this;
}

io io::operator<<(const unsigned short ot){
	print(ot);
	return *this;
}

io io::operator<<(const unsigned long ot){
	print(ot);
	return *this;
}

io io::operator<<(const unsigned long long ot){
	print(ot);
	return *this;
}

io io::operator<<(const unsigned __int128 ot){
	print(ot);
	return *this;
}

io io::operator<<(const bool ot){
	print(ot);
	return *this;
}

io io::operator<<(const char ot){
	print(ot);
	return *this;
}

io io::operator<<(const string ot){
	cout<<ot;
//	print(ot);
	return *this;
}

io io::operator<<(io_assist ot){
	print(ot.fx());
	return *this;
}

io io::operator<<(const char *ot){
	cout<<ot;
//	print(ot);
	return *this;
}

io io::operator<<(const double ot){
	print(ot);
	return *this;
}

io io::operator<<(const float ot){
	print(ot);
	return *this;
}



template <typename cactus>
class io_pointer_i{
	friend class io;
	private:
		cactus *st_l;
		io iox;
	public:
		explicit io_pointer_i(cactus *al,io io_x);
		io operator>>(cactus *ar);
		io operator>>(const int len);
};

template <typename cactus>
io_pointer_i<cactus>::io_pointer_i(cactus *al,io io_x){
	st_l=al;
	iox=io_x;
}

template <typename cactus>
io io_pointer_i<cactus>::operator>>(cactus *ar){
	for(;st_l<ar;st_l++){
		qread(*st_l);
	}
	return iox;
}

template <typename cactus>
io io_pointer_i<cactus>::operator>>(const int len){
	for(int i=1;i<=len;i++){
		qread(*st_l);
		st_l++;
	}
	return iox;
}



template <typename cactus>
class io_pointer_o{
	friend class io;
	private:
		cactus *st_l;
		io iox;
		io_assist sep;
	public:
		explicit io_pointer_o(cactus *al,io io_x);
		io operator<<(cactus *ar);
		io operator<<(const int len);
		io_pointer_o<cactus> operator<<(io_assist ioassist);
};

template <typename cactus>
io_pointer_o<cactus>::io_pointer_o(cactus *al,io io_x){
	st_l=al;
	iox=io_x;
}

template <typename cactus>
io io_pointer_o<cactus>::operator<<(cactus *ar){
	for(;st_l<ar;st_l++){
		print(*st_l);
		print(sep.fx());
	}
	return iox;
}

template <typename cactus>
io io_pointer_o<cactus>::operator<<(const int len){
	for(int i=1;i<=len;i++){
		print(*st_l);
		print(sep.fx());
		st_l++;
	}
	return iox;
}



template <typename cactus>
io_pointer_i<cactus> operator>>(io io_tag,cactus *a1){
	io_pointer_i<cactus> io_it(a1,io_tag);
	return io_it;
}

template <typename cactus>
io_pointer_o<cactus> operator<<(io io_tag,cactus *a1){
	io_pointer_o<cactus> io_ot(a1,io_tag);
	return io_ot;
}

template <typename cactus>
io_pointer_o<cactus> io_pointer_o<cactus>::operator<<(io_assist ioassist){
	sep=ioassist;
	return *this;
}

/*******************************************************************************/

template <typename cactus>
//queue
class queue_c{
	private:
		cactus q[MAXN+5];
		int head,tail;
		int inq;
	public:
		queue_c(void);
		queue_c(const cactus v);
		queue_c(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		void insert(const cactus v);
		void pop(void);
		const cactus front(void);
		void clear(void);
		void pop(const int cnt);
		const bool empty(void);
};

template <typename cactus>
queue_c<cactus>::queue_c(void){
	head=0;
	tail=-1;
	inq=0;
}

template <typename cactus>
queue_c<cactus>::queue_c(const cactus v){
	head=0;
	tail=0;
	inq=1;
	q[0]=v;
}

template <typename cactus>
queue_c<cactus>::queue_c(cactus *p1,cactus *p2){
	head=0;
	inq=*p2-*p1;
	for(int i=0;i<inq;i++,p1++){
		q[i]=*p1;
	}
	tail=inq-1;
}

template <typename cactus>
const SIZE_C queue_c<cactus>::size(void){
	return inq;
}

template <typename cactus>
void queue_c<cactus>::insert(const cactus v){
	inq++;
	if(tail==MAXN){
		tail=0;
	}else{
		tail++;
	}
	q[tail]=v;
}

template <typename cactus>
void queue_c<cactus>::pop(void){
	if(!inq)return;
	inq--;
	if(head==MAXN){
		head=0;
	}else{
		head++;
	}
}

template <typename cactus>
const cactus queue_c<cactus>::front(void){
	return q[head];
}

template <typename cactus>
void queue_c<cactus>::clear(void){
	head=0;
	tail=-1;
}

template <typename cactus>
void queue_c<cactus>::pop(const int cnt){
	if(cnt>=inq){
		*this->clear();
	}else{
		head+=cnt;
		if(head>MAXN){
			head-=MAXN;
			head--;
		}
	}
}

template <typename cactus>
const bool queue_c<cactus>::empty(void){
	return !(bool)inq;
}

/*******************************************************************************/	

template <typename cactus>
//stack
class stack_c{
	private:
		cactus s[MAXN+5]; 
		int ins;
		int head;
	public:
		stack_c(void);
		stack_c(const cactus v);
		stack_c(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		void pop(void);
		void insert(const cactus v);
		const cactus top(void);
		void clear(void);
		const bool empty(void);
};

template <typename cactus>
stack_c<cactus>::stack_c(void){
	head=-1;
	ins=0;
}

template <typename cactus>
stack_c<cactus>::stack_c(const cactus v){
	head=0;
	ins=1;
	s[0]=v;
}

template <typename cactus>
stack_c<cactus>::stack_c(cactus *p1,cactus *p2){
	ins=p2-p1;
	head=ins-1;
	for(int i=0;i<ins;i++){
		s[i]=*p1;
		p1++;
	}
}

template <typename cactus>
const SIZE_C stack_c<cactus>::size(void){
	return ins;
}

template <typename cactus>
void stack_c<cactus>::pop(void){
	if(!ins) return;
	head--;
	ins--;
}

template <typename cactus>
void stack_c<cactus>::insert(const cactus v){
	s[ins]=v;
	ins++;
	head++;
}

template <typename cactus>
const cactus stack_c<cactus>::top(void){
	return s[head];
}

template <typename cactus>
void stack_c<cactus>::clear(void){
	ins=0;
	head=-1;
}

template <typename cactus>
const bool stack_c<cactus>::empty(void){
	return !(bool)ins;
}

/*******************************************************************************/

template<typename cactus>
//deque
class deque_c{
	private:
		cactus c[MAXN+5];
		int inq;
		int head,tail;
	public:
		deque_c(void);
		deque_c(const cactus v);
		deque_c(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		void pop_front(void);
		void pop_back(void);
		void insert_front(const cactus v);
		void insert_back(const cactus v);
		const cactus front(void);
		const cactus back(void);
		void clear(void);
		const bool empty(void);
};

template <typename cactus>
deque_c<cactus>::deque_c(void){
	inq=0;
	head=-1;
	tail=0;
}

template <typename cactus>
deque_c<cactus>::deque_c(const cactus v){
	inq=1;
	head=0;
	tail=0;
	c[0]=v;
}

template <typename cactus>
deque_c<cactus>::deque_c(cactus *p1,cactus *p2){
	inq=p2-p1;
	tail=0;
	head=inq-1;
	for(int i=0;i<inq;i++){
		c[i]=*p1;
		p1++;
	}
}

template <typename cactus>
const SIZE_C deque_c<cactus>::size(void){
	return inq;
}

template <typename cactus>
void deque_c<cactus>::pop_front(void){
	if(head==0){
		head=MAXN;
	}else{
		head--;
	}
	inq--;
}

template <typename cactus>
void deque_c<cactus>::pop_back(void){
	if(tail==MAXN){
		tail=0;
	}else{
		tail++;
	}
	inq--;
}

template <typename cactus>
void deque_c<cactus>::insert_front(const cactus v){
	if(head==MAXN){
		head=0;
	}else{
		head++;
	}
	c[head]=v;
	inq++;
}

template <typename cactus>
void deque_c<cactus>::insert_back(const cactus v){
	if(tail==0){
		tail=MAXN;
	}else{
		tail--;
	}
	c[tail]=v;
	inq++;
}

template <typename cactus>
const cactus deque_c<cactus>::front(void){
	return c[head];
}

template <typename cactus>
const cactus deque_c<cactus>::back(void){
	return c[tail];
}

template <typename cactus>
void deque_c<cactus>::clear(void){
	inq=0;
	head=-1;
	tail=0;
}

template <typename cactus>
const bool deque_c<cactus>::empty(void){
	return !(bool)inq;
}

/*******************************************************************************/

template <typename cactus>
class min_mono_queue{
	private:
		int n,k;
		cactus mina[MAXN];
	public:
		explicit min_mono_queue(cactus *c1,cactus* c2,const int length_);
		const cactus min(const int pos);//starting from pos
};

template <typename cactus>
min_mono_queue<cactus>::min_mono_queue(cactus *c1,cactus* c2,const int length_){
	k=length_;
	n=c2-c1;
	if(k==1){
		for(int i=1;i<=n;i++){
			mina[i]=*c1;
			c1++;
		}
	}else{
		deque_c <int> qmin;
		qmin.insert_front(1);
		for(int i=2;i<=n;i++){
			if(qmin.front()==i-k){
				qmin.pop_front();
			}
			while(!qmin.empty()&&(c1[qmin.back()-1]>c1[i-1])){
				qmin.pop_back();
			}
			qmin.insert_back(i);
			mina[i]=qmin.front();
		}
	}
}

template <typename cactus>
const cactus min_mono_queue<cactus>::min(const int pos){
	return mina[pos-k+1];
}



template <typename cactus>
class max_mono_queue{
	private:
		int n,k;
		cactus maxa[MAXN];
	public:
		explicit max_mono_queue(cactus *c1,cactus* c2,const int length_);
		const cactus max(const int pos);//starting from pos
};

template <typename cactus>
max_mono_queue<cactus>::max_mono_queue(cactus *c1,cactus* c2,const int length_){
	k=length_;
	n=c2-c1;
	if(k==1){
		for(int i=1;i<=n;i++){
			maxa[i]=*c1;
			c1++;
		}
	}else{
		deque_c <int> qmax;
		qmax.insert_front(1);
		for(int i=2;i<=n;i++){
			if(qmax.front()==i-k){
				qmax.pop_front();
			}
			while(!qmax.empty()&&(c1[qmax.back()-1]>c1[i-1])){
				qmax.pop_back();
			}
			qmax.insert_back(i);
			maxa[i]=qmax.front();
		}
	}
}

template <typename cactus>
const cactus max_mono_queue<cactus>::max(const int pos){
	return maxa[pos-k+1];
}

/*******************************************************************************/

template <typename T_1,typename T_2>
class pair_c{
	public:
		T_1 x1;
		T_2 x2;
		
		pair_c(void){}
		pair_c(T_1 t1,T_2 t2);
		const bool operator>(const pair_c p)const;
		const bool operator<(const pair_c p)const;
		const bool operator>=(const pair_c p)const;
		const bool operator<=(const pair_c p)const;
		const bool operator==(const pair_c p);
		const bool operator!=(const pair_c p);
};

template <typename T_1,typename T_2>
pair_c<T_1,T_2>::pair_c(T_1 t1,T_2 t2){
	x1=t1;
	x2=t2;
}

template <typename T_1,typename T_2>
const bool pair_c<T_1,T_2>::operator>(const pair_c p)const{
	if(x1>p.x1){
		return true;
	}else{
		if(x1<p.x1){
			return false;
		}else{
			if(x2<p.x2){
				return false;
			}else{
				if(x2>p.x2){
					return true;
				}else{
					return false;
				}
			}
		}
	}
}

template <typename T_1,typename T_2>
const bool pair_c<T_1,T_2>::operator<(const pair_c p)const{
	if(x1>p.x1){
		return false;
	}else{
		if(x1<p.x1){
			return true;
		}else{
			if(x2<p.x2){
				return true;
			}else{
				if(x2>p.x2){
					return false;
				}else{
					return false;
				}
			}
		}
	}
}

template <typename T_1,typename T_2>
const bool pair_c<T_1,T_2>::operator>=(const pair_c p)const{
	if(x1>p.x1){
		return true;
	}else{
		if(x1<p.x1){
			return false;
		}else{
			if(x2<p.x2){
				return false;
			}else{
				if(x2>p.x2){
					return true;
				}else{
					return true;
				}
			}
		}
	}
}

template <typename T_1,typename T_2>
const bool pair_c<T_1,T_2>::operator<=(const pair_c p)const{
	if(x1>p.x1){
		return false;
	}else{
		if(x1<p.x1){
			return true;
		}else{
			if(x2<p.x2){
				return true;
			}else{
				if(x2>p.x2){
					return false;
				}else{
					return true;
				}
			}
		}
	}
}

template <typename T_1,typename T_2>
const bool pair_c<T_1,T_2>::operator==(const pair_c p){
	return x1==p.x1&&x2==p.x2;
}

template <typename T_1,typename T_2>
const bool pair_c<T_1,T_2>::operator!=(const pair_c p){
	return x1!=p.x1||x2!=p.x2;
}

/*******************************************************************************/

template <typename cactus,int MaxSize>
class array_c{
	private:
		mutable cactus ac[MaxSize];
	public:
		int n;
		array_c(void);
		cactus* operator+(const int addr){return ac+addr;}
		void insert(const cactus v);
		cactus& operator[](const int addr){return ac[addr];}
		void sort(const bool order=0);//0 rising ; 1 falling
		void sort(const int l,const int r,const bool order=0);
};

template <typename cactus,int MaxSize>
cactus* operator+(const int addr,array_c<cactus,MaxSize> arr){return arr+addr;}

template <typename cactus,int MaxSize>
array_c<cactus,MaxSize>::array_c(void){
	n=0;
}

template <typename cactus,int MaxSize>
void array_c<cactus,MaxSize>::insert(const cactus v){
	n++;
	ac[n]=v;
}

template <typename cactus,int MaxSize>
void array_c<cactus,MaxSize>::sort(const bool order){
	if(order){
		std::sort(ac+1,ac+n+1,greater <cactus> ());
	}else{
		std::sort(ac+1,ac+n+1);
	}
}

template <typename cactus,int MaxSize>
void array_c<cactus,MaxSize>::sort(const int l,const int r,const bool order){
	if(order){
		std::sort(ac+l,ac+r+1,greater <cactus> ());
	}else{
		std::sort(ac+l,ac+r+1);
	}
}

template <typename cactus,int MaxSize>
io operator>>(io iox,array_c<cactus,MaxSize> ix){
	for(int i=1;i<=ix.n;i++){
		cio>>ix[i];
	}
	return iox;
}

template <typename cactus,int MaxSize>
io operator<<(io iox,array_c<cactus,MaxSize> ox){
	for(int i=1;i<=ox.n;i++){
		cio<<ox[i]<<space;
	}
	return iox;
}

/*******************************************************************************/
//priority queue, small root heap
template <typename cactus>
class small_heap{
	private:
		int n;
		cactus c[MAXN];
	public:
		small_heap(void);
		void insert(const cactus v);
		const cactus top(void);
		const SIZE_C size(void);
		void pop(void);
		void clear(void);
		const bool empty(void);
};

template <typename cactus>
small_heap<cactus>::small_heap(void){
	n=0;
}

template <typename cactus>
void small_heap<cactus>::insert(const cactus v){
	n++;
	c[n]=v;
	int i=n;
	while(i!=1&&c[i]<c[i/2]){
		swap(c[i],c[i/2]);
		i/=2;
	}
}

template <typename cactus>
const cactus small_heap<cactus>::top(void){
	return c[1];
}

template <typename cactus>
const SIZE_C small_heap<cactus>::size(void){
	return n;
}

template <typename cactus>
void small_heap<cactus>::pop(void){
	int i=1;
	if(n==0)return;
	if(n==1){
		n--;
		return;
	}
	c[i]=c[n];
	n--;
	while(i*2<=n){
		if(i*2+1>n){
			if(c[i]>c[i*2]){
				swap(c[i],c[i*2]);
				i*=2;
			}else{
				return;
			}
		}else{
			if(c[i*2]<c[i*2+1]){
				if(c[i]>c[i*2]){
					swap(c[i],c[i*2]);
					i*=2;
				}else{
					return;
				}
			}else{
				if(c[i]>c[i*2+1]){
					swap(c[i],c[i*2+1]);
					i=i*2+1;
				}else{
					return;
				}
			}	
		}
	}
}

template <typename cactus>
void small_heap<cactus>::clear(void){
	n=0;
}

template <typename cactus>
const bool small_heap<cactus>::empty(void){
	return !(bool)n;
}



//priority queue, big root heap
template <typename cactus>
class big_heap{
	private:
		int n;
		cactus c[MAXN];
	public:
		big_heap(void);
		void insert(const cactus v);
		const cactus top(void);
		const SIZE_C size(void);
		void pop(void);
		void clear(void);
		const bool empty(void);
};

template <typename cactus>
big_heap<cactus>::big_heap(void){
	n=0;
}

template <typename cactus>
void big_heap<cactus>::insert(const cactus v){
	n++;
	c[n]=v;
	int i=n;
	while(i!=1&&c[i]>c[i/2]){
		swap(c[i],c[i/2]);
		i/=2;
	}
}

template <typename cactus>
const cactus big_heap<cactus>::top(void){
	return c[1];
}

template <typename cactus>
const SIZE_C big_heap<cactus>::size(void){
	return n;
}

template <typename cactus>
void big_heap<cactus>::pop(void){
	int i=1;
	if(n==0)return;
	if(n==1){
		n--;
		return;
	}
	c[i]=c[n];
	n--;
	while(i*2<=n){
		if(i*2+1>n){
			if(c[i]<c[i*2]){
				swap(c[i],c[i*2]);
				i*=2;
			}else{
				return;
			}
		}else{
			if(c[i*2]>c[i*2+1]){
				if(c[i]<c[i*2]){
					swap(c[i],c[i*2]);
					i*=2;
				}else{
					return;
				}
			}else{
				if(c[i]<c[i*2+1]){
					swap(c[i],c[i*2+1]);
					i=i*2+1;
				}else{
					return;
				}
			}
		}
	}
}

template <typename cactus>
void big_heap<cactus>::clear(void){
	n=0;
}

template <typename cactus>
const bool big_heap<cactus>::empty(void){
	return !(bool)n;
}

/*******************************************************************************/	

#define DSU union_set
class union_set{//union find set
	private:
		int pre[MAXNUM+5];
		int height[MAXNUM+5];
	public:
		union_set(void);
		const int find(const int x);
		void merge(int x1,int x2);
		const bool relate(const int x1,const int x2);
		void clear(void);
};

union_set::union_set(void){
	for(int i=1;i<=MAXNUM-1;i++){
		pre[i]=i;
		height[i]=0;
	}
}

const int union_set::find(const int x){
	if(pre[x]!=x){
		pre[x]=find(pre[x]);
	}
	return pre[x];
}

void union_set::merge(int x1,int x2){
	x1=find(x1);
	x2=find(x2);
	if(height[x1]<height[x2]){
		pre[x1]=x2;
	}else{
		pre[x2]=x1;
	}
}

const bool union_set::relate(const int x1,const int x2){
	return find(x1)==find(x2);
}

void union_set::clear(void){
	for(int i=1;i<=MAXNUM;i++){
		pre[i]=i;
		height[i]=0;
	}
}

/*******************************************************************************/

const int lowbit(int x){//lowbit for tree array
	return x&(-x);
}

//tree array
template <typename cactus>
class tree_array{
	private:
		cactus tra[MAXN];
		int n;
	public:
		tree_array(void);
		tree_array(const int len);
		void clear(void);
		const SIZE_C size(void);
		void add(const cactus val,int pos);
		void add(int pos);
		const int sum(int pos);
		const cactus sum(const int pos1,const int pos2);
};

template <typename cactus>
tree_array<cactus>::tree_array(void){
	n=0;
}

template <typename cactus>
tree_array<cactus>::tree_array(const int len){
	n=len;
	for(int i=1;i<=n;i++){
		tra[i]=0;
	}
}

template <typename cactus>
void tree_array<cactus>::clear(void){
	for(int i=1;i<=n;i++){
		tra[i]=0;
	}
}

template <typename cactus>
const SIZE_C tree_array<cactus>::size(void){
	return n;
}

template <typename cactus>
void tree_array<cactus>::add(const cactus val,int pos){
	if(pos<1) return;
	while(pos<=n){
		tra[pos]+=val;
		pos+=lowbit(pos);
	}
}

template <typename cactus>
void tree_array<cactus>::add(int pos){
	if(pos<1) return;
	while(pos<=n){
		tra[pos]++;
		pos+=lowbit(pos);
	}
}

template <typename cactus>
const int tree_array<cactus>::sum(int pos){
	if(pos<1) return INF;
	cactus ret=0;
	while(pos>0){
		ret+=tra[pos];
		pos-=lowbit(pos);
	}
	return ret;
}

template <typename cactus>
const cactus tree_array<cactus>::sum(const int pos1,const int pos2){
	return sum(pos2)-sum(pos1-1);
}

/*******************************************************************************/

const bool inrange(int l,int r,int lx,int rx){
	//if [l,r] is contained in [lx,rx]
	return l>=lx&&r<=rx;
}

const bool outofrange(int l,int r,int lx,int rx){
	//if [l,r] is not contained in [lx,rx]
	return r<lx||l>rx;
}

template <typename cactus>
class max_seg_tree{//max segment tree
	private:
		cactus t[MAXN];
		cactus a[MAXN];
		int n;
		cactus tag[MAXN];
		void buildin(int l,int r,int p);
		void build(void);
		void maketag(int k,cactus v);
		void pushdown(int k);
		cactus query1(int k,int l,int r,int p);
		void change1(int k,int l,int r,int p,cactus v);
		cactus query(int k,int l,int r,int p1,int p2);
		void change(int k,int l,int r,int p1,int p2,cactus v);
	public:
		max_seg_tree(const int num);
		max_seg_tree(cactus *a1,cactus *a2);
		const cactus find(const int p);
		void add(const int p,const cactus val);
		const cactus max(const int l,const int r);
		void add(const int l,const int r,const cactus val);
		const SIZE_C size(void);
};

template <typename cactus>
void max_seg_tree<cactus>::buildin(int l,int r,int p){
	if(l==r){
		t[p]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	p<<=1;
	buildin(l,mid,p);
	buildin(mid+1,r,p+1);
	t[p>>1]=((t[p]>t[p+1])?t[p]:t[p+1]);
}

template <typename cactus>
void max_seg_tree<cactus>::build(void){
	buildin(1,n,1);
}

template <typename cactus>
void max_seg_tree<cactus>::maketag(int k,cactus v){
	tag[k]+=v;
	t[k]+=v;
}

template <typename cactus>
void max_seg_tree<cactus>::pushdown(int k){
	maketag(k<<1,tag[k]);
	maketag((k<<1)+1,tag[k]);
	tag[k]=0;
}

template <typename cactus>
cactus max_seg_tree<cactus>::query1(int k,int l,int r,int p){
	if(l==r){
		return t[k];
	}else{
		int mid=(l+r)>>1;
		pushdown(k);
		if(p>mid){
			return query1((k<<1)+1,mid+1,r,p);
		}else{
			return query1(k<<1,l,mid,p);
		}
	}
}

template <typename cactus>
void max_seg_tree<cactus>::change1(int k,int l,int r,int p,cactus v){
	if(l==r){
		t[k]+=v;
		return;
	}else{
		int mid=(l+r)>>1;
		pushdown(k);
		if(p>mid){
			change1((k<<1)+1,mid+1,r,p,v);
		}else{
			change1(k<<1,l,mid,p,v);
		}
		t[k]=t[k<<1]>t[(k<<1)+1]?t[k<<1]:t[(k<<1)+1];
	}
}

template <typename cactus>
cactus max_seg_tree<cactus>::query(int k,int l,int r,int p1,int p2){
	if(inrange(l,r,p1,p2)){
		pushdown(k);
		return t[k];
	}
	if(outofrange(l,r,p1,p2)){
		return -INF;
	}else{
		int mid=(l+r)>>1;
		pushdown(k);
		cactus q1=query(k<<1,l,mid,p1,p2);
		cactus q2=query((k<<1)+1,mid+1,r,p1,p2);
		return q1>q2?q1:q2;
	}
}

template <typename cactus>
void max_seg_tree<cactus>::change(int k,int l,int r,int p1,int p2,cactus v){
	if(inrange(l,r,p1,p2)){
		maketag(k,v);
	}else{
		if(outofrange(l,r,p1,p2));
		else{
			pushdown(k);
			int mid=(l+r)>>1;
			change(k<<1,l,mid,p1,p2,v);
			change((k<<1)+1,mid+1,r,p1,p2,v);
			t[k]=t[k<<1]>t[(k<<1)+1]?t[k<<1]:t[(k<<1)+1];
		}
	}
}

template <typename cactus>
max_seg_tree<cactus>::max_seg_tree(const int num){
	n=num;
}

template <typename cactus>
max_seg_tree<cactus>::max_seg_tree(cactus *a1,cactus *a2){
	n=a2-a1;
	for(int i=1;i<=n;i++){
		a[i]=*a1;
		a1++;
		t[i]=0;
	}
	build();
}

template <typename cactus>
const cactus max_seg_tree<cactus>::find(const int p){
	return query1(1,1,n,p);
}

template <typename cactus>
void max_seg_tree<cactus>::add(const int p,const cactus val){
	change1(1,1,n,p,val);
}

template <typename cactus>
const cactus max_seg_tree<cactus>::max(const int l,const int r){
	return query(1,1,n,l,r);
}

template <typename cactus>
void max_seg_tree<cactus>::add(const int l,const int r,const cactus val){
	change(1,1,n,l,r,val);
}

template <typename cactus>
const SIZE_C max_seg_tree<cactus>::size(void){
	return n;
}



template <typename cactus>
class min_seg_tree{//min segment tree
	private:
		cactus t[MAXN];
		cactus a[MAXN];
		int n;
		cactus tag[MAXN];
		void buildin(int l,int r,int p);
		void build(void);
		int query1(int k,int l,int r,int p);
		void change1(int k,int l,int r,int p,cactus v);
		void maketag(int k,cactus v);
		void pushdown(int k);
		cactus query(int k,int l,int r,int p1,int p2);
		void change(int k,int l,int r,int p1,int p2,cactus v);
	public:
		min_seg_tree(const int num);
		min_seg_tree(cactus *a1,cactus *a2);
		const cactus find(const int p);
		void add(const int p,const cactus val);
		const cactus min(const int l,const int r);
		void add(const int l,const int r,const cactus val);
		const SIZE_C size(void);
};

template <typename cactus>
void min_seg_tree<cactus>::buildin(int l,int r,int p){
	if(l==r){
		t[p]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	p<<=1;
	buildin(l,mid,p);
	buildin(mid+1,r,p+1);
	t[p>>1]=((t[p]<t[p+1])?t[p]:t[p+1]);
}

template <typename cactus>
void min_seg_tree<cactus>::build(void){
	buildin(1,n,1);
}

template <typename cactus>
int min_seg_tree<cactus>::query1(int k,int l,int r,int p){
	if(l==r){
		return t[k];
	}else{
		int mid=(l+r)>>1;
		pushdown(k);
		if(p>mid){
			return query1((k<<1)+1,mid+1,r,p);
		}else{
			return query1(k<<1,l,mid,p);
		}
	}
}

template <typename cactus>
void min_seg_tree<cactus>::change1(int k,int l,int r,int p,cactus v){
	if(l==r){
		t[k]+=v;
		return;
	}else{
		int mid=(l+r)>>1;
		pushdown(k);
		if(p>mid){
			change1((k<<1)+1,mid+1,r,p,v);
		}else{
			change1(k<<1,l,mid,p,v);
		}
		t[k]=t[k<<1]<t[(k<<1)+1]?t[k<<1]:t[(k<<1)+1];
	}
}

template <typename cactus>
void min_seg_tree<cactus>::maketag(int k,cactus v){
	tag[k]+=v;
	t[k]+=v;
}

template <typename cactus>
void min_seg_tree<cactus>::pushdown(int k){
	maketag(k<<1,tag[k]);
	maketag((k<<1)+1,tag[k]);
	tag[k]=0;
}

template <typename cactus>
cactus min_seg_tree<cactus>::query(int k,int l,int r,int p1,int p2){
	if(inrange(l,r,p1,p2)){
		pushdown(k);
		return t[k];
	}
	if(outofrange(l,r,p1,p2)){
		return INF;
	}else{
		int mid=(l+r)>>1;
		pushdown(k);
		cactus q1=query(k<<1,l,mid,p1,p2);
		cactus q2=query((k<<1)+1,mid+1,r,p1,p2);
		return q1<q2?q1:q2;
	}
}

template <typename cactus>
void min_seg_tree<cactus>::change(int k,int l,int r,int p1,int p2,cactus v){
	if(inrange(l,r,p1,p2)){
		maketag(k,v);
	}else{
		if(outofrange(l,r,p1,p2));
		else{
			pushdown(k);
			int mid=(l+r)>>1;
			change(k<<1,l,mid,p1,p2,v);
			change((k<<1)+1,mid+1,r,p1,p2,v);
			t[k]=t[k<<1]<t[(k<<1)+1]?t[k<<1]:t[(k<<1)+1];
		}
	}
}

template <typename cactus>
min_seg_tree<cactus>::min_seg_tree(const int num){
	n=num;
}

template <typename cactus>
min_seg_tree<cactus>::min_seg_tree(cactus *a1,cactus *a2){
	n=a2-a1;
	for(int i=1;i<=n;i++){
		a[i]=*a1;
		a1++;
		t[i]=0;
	}
	build();
}

template <typename cactus>
const cactus min_seg_tree<cactus>::find(const int p){
	return query1(1,1,n,p);
}

template <typename cactus>
void min_seg_tree<cactus>::add(const int p,const cactus val){
	change1(1,1,n,p,val);
}

template <typename cactus>
const cactus min_seg_tree<cactus>::min(const int l,const int r){
	return query(1,1,n,l,r);
}

template <typename cactus>
void min_seg_tree<cactus>::add(const int l,const int r,const cactus val){
	change(1,1,n,l,r,val);
}

template <typename cactus>
const SIZE_C min_seg_tree<cactus>::size(void){
	return n;
}

/*******************************************************************************/

template <typename cactus>
class max_st_list{//max st list
	private:
		int n,logn;
		int log2n[MAXN];
		cactus st[MAXN][35];
	public:
		explicit max_st_list(cactus *a1,cactus *a2);
		const cactus max(const int l,const int r);
};

template <typename cactus>
max_st_list<cactus>::max_st_list(cactus *a1,cactus *a2){
	log2n[0]=0;
	log2n[1]=0;
	n=a2-a1;
	for(int i=0;i<=n*2;i++){
		for(int j=0;j<35;j++){
			st[i][j]=-INF;
		}
	}
	st[1][0]=*a1;
	a1++;
	for(int i=2;i<=n;i++,a1++){
		st[i][0]=*a1;
		log2n[i]=log2n[i>>1]+1;
	}
	for(int j=1;(1<<j)<=n;j++){
		for(int i=1;i<=n;i++){
			st[i][j]=((st[i][j-1]>st[i+(1<<(j-1))][j-1])?st[i][j-1]:st[i+(1<<(j-1))][j-1]);
		}
	}
}

template <typename cactus>
const cactus max_st_list<cactus>::max(const int l,const int r){
	int l1=r-l+1;
	int k=log2n[l1];
	return st[l][k]>st[r-(1<<k)+1][k]?st[l][k]:st[r-(1<<k)+1][k];
}

/*******************************************************************************/

template <typename cactus>
class min_st_list{//st list
	private:
		int n,logn;
		int log2n[MAXN];
		cactus st[MAXN][35];
	public:
		explicit min_st_list(cactus *a1,cactus *a2);
		const cactus min(const int l,const int r);
};

template <typename cactus>
min_st_list<cactus>::min_st_list(cactus *a1,cactus *a2){
	log2n[0]=0;
	log2n[1]=0;
	n=a2-a1;
	for(int i=0;i<=n*2;i++){
		for(int j=0;j<35;j++){
			st[i][j]=INF;
		}
	}
	st[1][0]=*a1;
	a1++;
	for(int i=2;i<=n;i++,a1++){
		st[i][0]=*a1;
		log2n[i]=log2n[i>>1]+1;
	}
	for(int j=1;(1<<j)<=n;j++){
		for(int i=1;i<=n;i++){
			st[i][j]=st[i][j-1]<st[i+(1<<j-1)][j-1]?st[i][j-1]:st[i+(1<<j-1)][j-1];
		}
	}
}

template <typename cactus>
const cactus min_st_list<cactus>::min(const int l,const int r){
	int l1=r-l+1;
	int k=log2n[l1];
	return st[l][k]<st[r-l-(1<<k)+1][k]?st[l][k]:st[r-l-(1<<k)+1][k];
}

/*******************************************************************************/

template <typename cactus>
class sum_segment_tree{
	private:
		int n;
		cactus tr[MAXN];
		cactus a[MAXN];
		cactus tag[MAXN];
		void buildin(int k,int l,int r);
		void build(void);
		void maketag(int k,cactus v,int l,int r);
		void pushdown(int k,int l,int r,int mid);
		const cactus query1(int k,int l,int r,int p);
		void change1(int k,int l,int r,int p,cactus v);
		const cactus query(int k,int l,int r,int pl,int pr);
		void change(int k,int l,int r,int pl,int pr,cactus v);
	public:
		sum_segment_tree(void);
		sum_segment_tree(const int num);
		sum_segment_tree(cactus *a1,cactus *a2);
		void add(const int p,const cactus val);
		void add(const int pl,const int pr,const cactus val);
		const cactus find(const int p);
		const cactus sum(const int pl,const int pr);
};

template <typename cactus>
void sum_segment_tree<cactus>::buildin(int k,int l,int r){
	tag[k]=0;
	if(l==r){
		tr[k]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	buildin((k<<1),l,mid);
	buildin((k<<1)+1,mid+1,r);
	tr[k]=tr[k<<1]+tr[(k<<1)+1];
}

template <typename cactus>
void sum_segment_tree<cactus>::build(void){
	buildin(1,1,n);
}

template <typename cactus>
void sum_segment_tree<cactus>::maketag(int k,cactus v,int l,int r){
	tag[k]+=v;
	tr[k]+=v*(r-l+1);
}

template <typename cactus>
void sum_segment_tree<cactus>::pushdown(int k,int l,int r,int mid){
	if(!tag[k])return;
	maketag(k<<1,tag[k],l,mid);
	maketag((k<<1)+1,tag[k],mid+1,r);
	tag[k]=0;
}

template <typename cactus>
const cactus sum_segment_tree<cactus>::query1(int k,int l,int r,int p){
	if(l==r){
		return tr[k];
	}
	int mid=(l+r)>>1;
	pushdown(k,l,r,mid);
	if(p>mid){
		return query1((k<<1)+1,mid+1,r,p);
	}else{
		return query1(k<<1,l,mid,p);
	}
}

template <typename cactus>
void sum_segment_tree<cactus>::change1(int k,int l,int r,int p,cactus v){
	if(l==r){
		tr[k]+=v;
		return;
	}
	tr[k]+=v;
	int mid=(l+r)>>1;
	pushdown(k,l,r,mid);
	if(p>mid){
		change1((k<<1)+1,mid+1,r,p,v);
	}else{
		change1(k<<1,l,mid,p,v);
	}
}

template <typename cactus>
const cactus sum_segment_tree<cactus>::query(int k,int l,int r,int pl,int pr){
	if(inrange(l,r,pl,pr)){
		pushdown(k,l,r,(l+r)>>1);
		return tr[k];
	}
	if(outofrange(l,r,pl,pr)){
		return 0;
	}
	int mid=(l+r)>>1;
	pushdown(k,l,r,mid);
	return query(k<<1,l,mid,pl,pr)+query((k<<1)+1,mid+1,r,pl,pr);
}

template <typename cactus>
void sum_segment_tree<cactus>::change(int k,int l,int r,int pl,int pr,cactus v){
	if(inrange(l,r,pl,pr)){
		maketag(k,v,l,r);
		return;
	}
	if(outofrange(l,r,pl,pr)){
		return;
	}
	int mid=(l+r)>>1;
	pushdown(k,l,r,mid);
	change(k<<1,l,mid,pl,pr,v);
	change((k<<1)+1,mid+1,r,pl,pr,v);
	tr[k]=tr[k<<1]+tr[(k<<1)+1];
}

template <typename cactus>
sum_segment_tree<cactus>::sum_segment_tree(void){
	n=0;
}

template <typename cactus>
sum_segment_tree<cactus>::sum_segment_tree(const int num){
	n=num;
	for(int i=0;i<n*4+1;i++){
		tr[i]=0;
	}
}

template <typename cactus>
sum_segment_tree<cactus>::sum_segment_tree(cactus *a1,cactus *a2){
	n=a2-a1;
	for(int i=1;i<=n;i++){
		a[i]=*a1;
		a1++;
	}
	build();
}

template <typename cactus>
void sum_segment_tree<cactus>::add(const int p,const cactus val){
	change1(1,1,n,p,val);
}

template <typename cactus>
void sum_segment_tree<cactus>::add(const int pl,const int pr,const cactus val){
	change(1,1,n,pl,pr,val);
}

template <typename cactus>
const cactus sum_segment_tree<cactus>::find(const int p){
	return query1(1,1,n,p);
}

template <typename cactus>
const cactus sum_segment_tree<cactus>::sum(const int pl,const int pr){
	return query(1,1,n,pl,pr);
}

/*******************************************************************************/

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
class segment_tree{
	private:
		int n;
		cactus tr[MAXN];
		cactus a[MAXN];
		void buildin(int k,int l,int r);
		void build(void);
		const cactus query1(int k,int l,int r,int p);
		void change1(int k,int l,int r,int p,cactus v,cactus (*chgf)(cactus,cactus));
		const cactus query(int k,int l,int r,int pl,int pr);
		void change(int k,int l,int r,int pl,int pr,cactus v,cactus (*chgf)(cactus,cactus));
	public:
		segment_tree(void);
		segment_tree(const int num);
		segment_tree(cactus *a1,cactus *a2);
		void add(const int p,const cactus val,cactus (*change_fx)(cactus,cactus)=chg);
		void add(const int pl,const int pr,const cactus val,cactus (*change_fx)(cactus,cactus)=chg);
		const cactus find(const int p);
		const cactus sum(const int pl,const int pr);
};

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
void segment_tree<cactus,f,chg>::buildin(int k,int l,int r){
	if(l==r){
		tr[k]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	buildin((k<<1),l,mid);
	buildin((k<<1)+1,mid+1,r);
	tr[k]=f(tr[k<<1],tr[(k<<1)+1]);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
void segment_tree<cactus,f,chg>::build(void){
	buildin(1,1,n);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
const cactus segment_tree<cactus,f,chg>::query1(int k,int l,int r,int p){
	if(l==r){
		return tr[k];
	}
	int mid=(l+r)>>1;
	if(p>mid){
		return query1((k<<1)+1,mid+1,r,p);
	}else{
		return query1(k<<1,l,mid,p);
	}
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
void segment_tree<cactus,f,chg>::change1(int k,int l,int r,int p,cactus v,cactus (*chgf)(cactus,cactus)){
	if(l==r){
		tr[k]=chgf(tr[k],v);
		return;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		change1((k<<1)+1,mid+1,r,p,v,chgf);
	}else{
		change1(k<<1,l,mid,p,v,chgf);
	}
	tr[k]=f(tr[k<<1],tr[(k<<1)+1]);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
const cactus segment_tree<cactus,f,chg>::query(int k,int l,int r,int pl,int pr){
	if(outofrange(l,r,pl,pr)){
		return 0;
	}
	if(l==r){
		return tr[k];
	}
	int mid=(l+r)>>1;
	return f(query(k<<1,l,mid,pl,pr),query((k<<1)+1,mid+1,r,pl,pr));
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
void segment_tree<cactus,f,chg>::change(int k,int l,int r,int pl,int pr,cactus v,cactus (*chgf)(cactus,cactus)){
	if(outofrange(l,r,pl,pr)){
		return;
		
	}
	if(l==r){
		tr[k]=chgf(tr[k],v);
		return;
	}
	int mid=(l+r)>>1;
	change(k<<1,l,mid,pl,pr,v,chgf);
	change((k<<1)+1,mid+1,r,pl,pr,v,chgf);
	tr[k]=f(tr[k<<1],tr[(k<<1)+1]);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
segment_tree<cactus,f,chg>::segment_tree(void){
	n=0;
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
segment_tree<cactus,f,chg>::segment_tree(const int num){
	n=num;
	for(int i=0;i<n*4+1;i++){
		tr[i]=0;
	}
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
segment_tree<cactus,f,chg>::segment_tree(cactus *a1,cactus *a2){
	n=a2-a1;
	for(int i=1;i<=n;i++){
		a[i]=*a1;
		a1++;
	}
	build();
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
void segment_tree<cactus,f,chg>::add(const int p,const cactus val,cactus (*change_fx)(cactus,cactus)){
	change1(1,1,n,p,val,change_fx);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
void segment_tree<cactus,f,chg>::add(const int pl,const int pr,const cactus val,cactus (*change_fx)(cactus,cactus)){
	change(1,1,n,pl,pr,val,change_fx);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
const cactus segment_tree<cactus,f,chg>::find(const int p){
	return query1(1,1,n,p);
}

template <typename cactus,cactus (*f)(cactus,cactus),cactus (*chg)(cactus,cactus)>
const cactus segment_tree<cactus,f,chg>::sum(const int pl,const int pr){
	return query(1,1,n,pl,pr);
}

/*******************************************************************************/

template <typename cactus>
class splay_node{
	friend class splay<cactus>;
	private:
		int left;
		int right;
		int p;
		cactus v;
		int size;
		splay_node();
		splay_node(int l,int r,cactus val,int pa,int sz);
};

template <typename cactus>
splay_node<cactus>::splay_node(){
	left=-1;
	right=-1;
	p=-1;
	size=1;
}

template <typename cactus>
splay_node<cactus>::splay_node(int l,int r,cactus val,int pa,int sz){
	left=l;
	right=r;
	p=pa;
	v=val;
	size=sz;
}



template <typename cactus>
class splay{
	private:
		splay_node <cactus> tr[MAXN];
		int n;
		int root;
		void resize(const int p);
		const bool lrson(const int p);
		void release_empty(const int p);
		void left_rotate(const int p);
		void right_rotate(const int p);
		void zig(const int p);
		void zag(const int p);
		void rotate_to(const int p,const int dtn=-1);
		bool get_node(const int p,const cactus v);
		const int get_root_rank(void);
		const int get_max(const int p);
		const int get_min(const int p);
		const cactus get_max_v(const int p);
		const cactus get_min_v(const int p);
		const bool find_in(const cactus v);
		const int rank_in(const cactus v);
		const cactus pre_in(const cactus v);
		const cactus suc_in(const cactus v);
		void delete_in(const cactus v);
		void insert_in(const cactus v);
		const cactus kth_in_root(const int rootx,const int kth);
		const cactus kth_in(const int kth);
		const cactus max_in(void);
		const cactus min_in(void);
		void printxroot(int p);
	public:
		const SIZE_C size(void);
		const SIZE_C count(void);
		void clear(void);
		splay(void);
		splay(const cactus v);
		const cactus max(void);
		const cactus min(void);
		const cactus kth(const int k);
		const int rank(const cactus v);
		const cactus suc(const cactus v);
		const cactus pre(const cactus v);
		void del(const cactus v);
		void insert(const cactus v);
		const bool find(const cactus v);
		void print(void);
};

template <typename cactus>
void splay<cactus>::resize(const int p){
	tr[p].size=1;
	if(tr[p].left!=-1){
		tr[p].size+=tr[tr[p].left].size;
	}
	if(tr[p].right!=-1){
		tr[p].size+=tr[tr[p].right].size;
	}
}

template <typename cactus>
const bool splay<cactus>::lrson(const int p){
	return tr[tr[p].p].right==p;
}

template <typename cactus>
void splay<cactus>::release_empty(const int p){
	n--;
	if(p==n){
		return;
	}
	if(n==root){
		root=p;
	}
	tr[p].size=tr[n].size;
	tr[p].v=tr[n].v;
	tr[p].left=tr[n].left;
	tr[p].right=tr[n].right;
	tr[p].p=tr[n].p;
	if(tr[p].right!=-1){
		tr[tr[p].right].p=p;
	}
	if(tr[p].left!=-1){
		tr[tr[p].left].p=p;
	}
	if(tr[p].p!=-1){
		if(lrson(n)){
			tr[tr[p].p].right=p;
		}else{
			tr[tr[p].p].left=p;
		}
	}
}

template <typename cactus>
void splay<cactus>::left_rotate(const int p){
	int pa=tr[p].p;
	int rght=tr[p].right;
	int rl=tr[rght].left;
	
	if(p==root){
		root=rght;
		tr[rght].p=-1;
	}else{
		if(lrson(p)){
			tr[pa].right=rght;
			tr[rght].p=pa;
		}else{
			tr[pa].left=rght;
			tr[rght].p=pa;
		}
	}
	
	tr[p].right=rl;
	tr[rl].p=p;
	
	tr[rght].left=p;
	tr[p].p=rght;
	resize(p);
	resize(rght);
}

template <typename cactus>
void splay<cactus>::right_rotate(const int p){
	int pa=tr[p].p;
	int lft=tr[p].left;
	int lr=tr[lft].right;
	
	if(p==root){
		tr[lft].p=-1;
		root=lft;
	}else{
		if(lrson(p)){
			tr[pa].right=lft;
			tr[lft].p=pa;
		}else{
			tr[pa].left=lft;
			tr[lft].p=pa;
		}
	}
	
	tr[p].left=lr;
	tr[lr].p=p;
	
	tr[lft].right=p;
	tr[p].p=lft;
	resize(p);
	resize(lft);
}

template <typename cactus>
void splay<cactus>::zig(const int p){
	right_rotate(tr[p].p);
}

template <typename cactus>
void splay<cactus>::zag(const int p){
	left_rotate(tr[p].p);
}

template <typename cactus>
void splay<cactus>::rotate_to(const int p,const int dtn){
	while(tr[p].p!=dtn){
		if(lrson(p)){
			zag(p);
		}else{
			zig(p);
		}
	}
}

template <typename cactus>
bool splay<cactus>::get_node(const int p,const cactus v){//fail 0, succeed 1
	if(p==-1){
		return 0;
	}
	if(v==tr[p].v){
		rotate_to(p);
		return 1;
	}else{
		if(v>tr[p].v){
			return get_node(tr[p].right,v);
		}else{
			return get_node(tr[p].left,v);
		}
	}
}

template <typename cactus>
const int splay<cactus>::get_root_rank(void){
	if(tr[root].left==-1){
		return 1;
	}else{
		return tr[tr[root].left].size+1;
	}
}

template <typename cactus>
const int splay<cactus>::get_max(const int p){
	if(p==-1){
		return -1;
	}
	else{
		if(tr[p].right==-1){
			return p;
		}else{
			return get_max(tr[p].right);
		}
	}
}

template <typename cactus>
const int splay<cactus>::get_min(const int p){
	if(p==-1){
		return -1;
	}
	else{
		if(tr[p].left==-1){
			return p;
		}else{
			return get_min(tr[p].left);
		}
	}
}

template <typename cactus>
const cactus splay<cactus>::get_max_v(const int p){
	if(p==-1){
		return INF;
	}
	else{
		if(tr[p].right==-1){
			return tr[p].v;
		}else{
			return get_max_v(tr[p].right);
		}
	}
}

template <typename cactus>
const cactus splay<cactus>::get_min_v(const int p){
	if(p==-1){
		return INF;
	}
	else{
		if(tr[p].left==-1){
			return tr[p].v;
		}else{
			return get_min_v(tr[p].left);
		}
	}
}

template <typename cactus>
const bool splay<cactus>::find_in(const cactus v){
	if(n==0){
		return 0;
	}
	return get_node(root,v);
}

template <typename cactus>
const int splay<cactus>::rank_in(const cactus v){
	if(n==0){
		return INF;
	}
	if(get_node(root,v)){
		return get_root_rank();
	}else{
		return INF;
	}
}

template <typename cactus>
const cactus splay<cactus>::pre_in(const cactus v){
	int pos=root;
	cactus res=INF;
	while(pos!=-1){
		if(v>tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].right;
		}else{
			pos=tr[pos].left;
		}
	}
	get_node(root,res);
	return res;
}

template <typename cactus>
const cactus splay<cactus>::suc_in(const cactus v){
	int pos=root;
	cactus res=-INF;
	while(pos!=-1){
		if(v<tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].left;
		}else{
			pos=tr[pos].right;
		}
	}
	get_node(root,res);
	return res;
}

template <typename cactus>
void splay<cactus>::delete_in(const cactus v){
	if(n==0){
		return;
	}
	if(!get_node(root,v)){
		return;
	}
	cactus pre=get_max(tr[root].left);
	cactus suc=get_min(tr[root].right);
	int pt=root;
	if(pre==-1){
		if(suc==-1){
			n--;
			return;
		}else{
			rotate_to(suc);
			tr[suc].left=-1;
			release_empty(pt);
			tr[suc].size--;
		}
	}else{
		if(suc==-1){
			rotate_to(pre);
			tr[pre].right=-1;
			release_empty(pt);
			tr[pre].size--;
		}else{
			rotate_to(pre);
			rotate_to(suc,pre);
			tr[suc].left=-1;
			release_empty(pt);
			tr[pre].size--;
			tr[suc].size--;
		}
	}
}

template <typename cactus>
void splay<cactus>::insert_in(const cactus v){
	if(n==0){
		tr[n]=splay_node <cactus> (-1,-1,v,-1,1);
		root=0;
		n++;
		return;
	}
	if(get_node(root,v)){
		return;
	}else{
		int np=root;
		while(1){
			tr[np].size++;
			if(v>tr[np].v){
				if(tr[np].right==-1){
					tr[n]=splay_node <cactus> (-1,-1,v,np,1);
					tr[np].right=n;
					rotate_to(n);
					n++;
					return;
				}else{
					np=tr[np].right;
					continue;
				}
			}else{
				if(tr[np].left==-1){
					tr[n]=splay_node <cactus> (-1,-1,v,np,1);
					tr[np].left=n;
					rotate_to(n);
					n++;
					return;
				}else{
					np=tr[np].left;
					continue;
				}
			}
		}
	}
}

template <typename cactus>
const cactus splay<cactus>::kth_in_root(const int rootx,const int kth){
	if(tr[rootx].size==1){
		rotate_to(rootx);
		return tr[rootx].v;
	}
	if(tr[rootx].left==-1){
		if(kth==1){
			return tr[rootx].v;
		}
		return kth_in_root(tr[rootx].right,kth-1);
	}else{
		if(kth>tr[tr[rootx].left].size+1){
			return kth_in_root(tr[rootx].right,kth-tr[tr[rootx].left].size-1);
		}else{
			if(kth==tr[tr[rootx].left].size+1){
				rotate_to(rootx);
				return tr[rootx].v;
			}else{
				return kth_in_root(tr[rootx].left,kth);
			}
		}
	}
}

template <typename cactus>
const cactus splay<cactus>::kth_in(const int kth){
	if(n==0||kth<1||kth>n){
		return INF;
	}
	return kth_in_root(root,kth);
}

template <typename cactus>
const cactus splay<cactus>::max_in(void){
	if(n==0){
		return INF;
	}
	int np=root;
	while(tr[np].right!=-1){
		np=tr[np].right;
	}
	return tr[np].v;
}

template <typename cactus>
const cactus splay<cactus>::min_in(void){
	if(n==0){
		return INF;
	}
	int np=root;
	while(tr[np].left!=-1){
		np=tr[np].left;
	}
	return tr[np].v;
}

template <typename cactus>
void splay<cactus>::printxroot(int p){
	if(p==-1){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
const SIZE_C splay<cactus>::size(void){
	return n;
}

template <typename cactus>
const SIZE_C splay<cactus>::count(void){
	if(n==0){
		return 0;
	}
	else{
		return tr[root].size;
	}
}

template <typename cactus>
void splay<cactus>::clear(void){
	n=0;
}

template <typename cactus>
splay<cactus>::splay(void){
	n=0;
}

template <typename cactus>
splay<cactus>::splay(const cactus v){
	tr[0]=splay_node <cactus> (-1,-1,v,-1,1);
	root=0;
	n=1;
}

template <typename cactus>
const cactus splay<cactus>::max(void){
	return max_in();
}

template <typename cactus>
const cactus splay<cactus>::min(void){
	return min_in();
}

template <typename cactus>
const cactus splay<cactus>::kth(const int k){
	return kth_in(k);
}

template <typename cactus>
const int splay<cactus>::rank(const cactus v){
	return rank_in(v);
}

template <typename cactus>
const cactus splay<cactus>::suc(const cactus v){
	return suc_in(v);
}

template <typename cactus>
const cactus splay<cactus>::pre(const cactus v){
	return pre_in(v);
}

template <typename cactus>
void splay<cactus>::del(const cactus v){
	delete_in(v);
}

template <typename cactus>
void splay<cactus>::insert(const cactus v){
	insert_in(v);
}

template <typename cactus>
const bool splay<cactus>::find(const cactus v){
	return find_in(v);
}

template <typename cactus>
void splay<cactus>::print(void){
	if(n==0){
		return;
	}
	printxroot(root);
}



template <typename cactus>
class multi_splay_node{
	friend class multi_splay<cactus>;
	private:
		int left;
		int right;
		int p;
		cactus v;
		int cnt;
		int size;
		multi_splay_node();
		multi_splay_node(int l,int r,cactus val,int pa,int sz,int tot);
};

template <typename cactus>
multi_splay_node<cactus>::multi_splay_node(){
	left=-1;
	right=-1;
	p=-1;
	cnt=1;
	size=1;
}

template <typename cactus>
multi_splay_node<cactus>::multi_splay_node(int l,int r,cactus val,int pa,int sz,int tot){
	left=l;
	right=r;
	p=pa;
	v=val;
	size=sz;
	cnt=tot;
}



template <typename cactus>
class multi_splay{
	private:
		multi_splay_node <cactus> tr[MAXN];
		int n;
		int root;
		void resize(const int p);
		const bool lrson(const int p);
		void release_empty(const int p);
		void left_rotate(const int p);
		void right_rotate(const int p);
		void zig(const int p);
		void zag(const int p);
		void rotate_to(const int p,const int dtn=-1);
		bool get_node(const int p,const cactus v);
		const int get_root_rank(void);
		const int get_max(const int p);
		const int get_min(const int p);
		const cactus get_max_v(const int p);
		const cactus get_min_v(const int p);
		const bool find_in(const cactus v);
		const int rank_in(const cactus v);
		const cactus pre_in(const cactus v);
		const cactus suc_in(const cactus v);
		void delete_in(const cactus v);
		void insert_in(const cactus v);
		const cactus kth_in_root(const int rootx,const int kth);
		const cactus kth_in(const int kth);
		const cactus max_in(void);
		const cactus min_in(void);
		void printxroot(int p);
	public:
		const SIZE_C size(void);
		const SIZE_C count(void);
		void clear(void);
		multi_splay();
		multi_splay(const cactus v);
		const cactus max(void);
		const cactus min(void);
		const cactus kth(const int k);
		const int rank(const cactus v);
		const cactus suc(const cactus v);
		const cactus pre(const cactus v);
		void del(const cactus v);
		void insert(const cactus v);
		const bool find(const cactus v);
		void print(void);
};

template <typename cactus>
void multi_splay<cactus>::resize(const int p){
	tr[p].size=tr[p].cnt;
	if(tr[p].left!=-1){
		tr[p].size+=tr[tr[p].left].size;
	}
	if(tr[p].right!=-1){
		tr[p].size+=tr[tr[p].right].size;
	}
}

template <typename cactus>
const bool multi_splay<cactus>::lrson(const int p){
	return tr[tr[p].p].right==p;
}

template <typename cactus>
void multi_splay<cactus>::release_empty(const int p){
	n--;
	if(p==n){
		return;
	}
	if(root==n){
		root=p;
	}
	tr[p]=tr[n];
	if(tr[p].right!=-1){
		tr[tr[p].right].p=p;
	}
	if(tr[p].left!=-1){
		tr[tr[p].left].p=p;
	}
	if(tr[p].p!=-1){
		if(lrson(n)){
			tr[tr[p].p].right=p;
		}else{
			tr[tr[p].p].left=p;
		}
	}
}

template <typename cactus>
void multi_splay<cactus>::left_rotate(const int p){
	int pa=tr[p].p;
	int rght=tr[p].right;
	int rl=tr[rght].left;
	
	if(p==root){
		root=rght;
		tr[rght].p=-1;
	}else{
		if(lrson(p)){
			tr[pa].right=rght;
			tr[rght].p=pa;
		}else{
			tr[pa].left=rght;
			tr[rght].p=pa;
		}
	}
	
	tr[p].right=rl;
	tr[rl].p=p;
	
	tr[rght].left=p;
	tr[p].p=rght;
	
	resize(p);
	resize(rght);
}

template <typename cactus>
void multi_splay<cactus>::right_rotate(const int p){
	int pa=tr[p].p;
	int lft=tr[p].left;
	int lr=tr[lft].right;
	
	if(p==root){
		tr[lft].p=-1;
		root=lft;
	}else{
		if(lrson(p)){
			tr[pa].right=lft;
			tr[lft].p=pa;
		}else{
			tr[pa].left=lft;
			tr[lft].p=pa;
		}
	}
	
	tr[p].left=lr;
	tr[lr].p=p;
	
	tr[lft].right=p;
	tr[p].p=lft;
	
	resize(p);
	resize(p);
}

template <typename cactus>
void multi_splay<cactus>::zig(const int p){
	right_rotate(tr[p].p);
}

template <typename cactus>
void multi_splay<cactus>::zag(const int p){
	left_rotate(tr[p].p);
}

template <typename cactus>
void multi_splay<cactus>::rotate_to(const int p,const int dtn){
	while(tr[p].p!=dtn){
		if(lrson(p)){
			zag(p);
		}else{
			zig(p);
		}
	}
}

template <typename cactus>
bool multi_splay<cactus>::get_node(const int p,const cactus v){//fail 0, succeed 1
	if(p==-1){
		return 0;
	}
	if(v==tr[p].v){
		rotate_to(p);
		return 1;
	}else{
		if(v>tr[p].v){
			return get_node(tr[p].right,v);
		}else{
			return get_node(tr[p].left,v);
		}
	}
}

template <typename cactus>
const int multi_splay<cactus>::get_root_rank(void){
	if(tr[root].left==-1){
		return 1;
	}else{
		return tr[tr[root].left].size+1;
	}
}

template <typename cactus>
const int multi_splay<cactus>::get_max(const int p){
	if(p==-1){
		return -1;
	}
	else{
		if(tr[p].right==-1){
			return p;
		}else{
			return get_max(tr[p].right);
		}
	}
}

template <typename cactus>
const int multi_splay<cactus>::get_min(const int p){
	if(p==-1){
		return -1;
	}
	else{
		if(tr[p].left==-1){
			return p;
		}else{
			return get_min(tr[p].left);
		}
	}
}

template <typename cactus>
const cactus multi_splay<cactus>::get_max_v(const int p){
	if(p==-1){
		return INF;
	}
	else{
		if(tr[p].right==-1){
			return tr[p].v;
		}else{
			return get_max_v(tr[p].right);
		}
	}
}

template <typename cactus>
const cactus multi_splay<cactus>::get_min_v(const int p){
	if(p==-1){
		return INF;
	}
	else{
		if(tr[p].left==-1){
			return tr[p].v;
		}else{
			return get_min_v(tr[p].left);
		}
	}
}

template <typename cactus>
const bool multi_splay<cactus>::find_in(const cactus v){
	if(n==0){
		return 0;
	}
	return get_node(root,v);
}

template <typename cactus>
const int multi_splay<cactus>::rank_in(const cactus v){
	if(n==0){
		return INF;
	}
	if(get_node(root,v)){
		return get_root_rank();
	}else{
		return INF;
	}
}

template <typename cactus>
const cactus multi_splay<cactus>::pre_in(const cactus v){
	int pos=root;
	cactus res=-INF;
	while(pos!=-1){
		if(v>tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].right;
		}else{
			pos=tr[pos].left;
		}
	}
	get_node(root,res);
	return res;
}

template <typename cactus>
const cactus multi_splay<cactus>::suc_in(const cactus v){
	int pos=root;
	cactus res=INF;
	while(pos!=-1){
		if(v<tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].left;
		}else{
			pos=tr[pos].right;
		}
	}
	get_node(root,res);
	return res;
}

template <typename cactus>
void multi_splay<cactus>::delete_in(const cactus v){
	if(n==0){
		return;
	}
	if(!get_node(root,v)){
		return;
	}
	if(tr[root].cnt>1){
		tr[root].cnt--;
		tr[root].size--;
		return;
	}
	int pre=get_max(tr[root].left);
	int suc=get_min(tr[root].right);
	int pt=root;
	if(pre==-1){
		if(suc==-1){
			n--;
			return;
		}else{
			rotate_to(suc);
			tr[suc].left=-1;
			release_empty(pt);
			tr[suc].size--;
		}
	}else{
		if(suc==-1){
			rotate_to(pre);
			tr[pre].right=-1;
			release_empty(pt);
			tr[pre].size--;
		}else{
			rotate_to(pre);
			rotate_to(suc,pre);
			tr[suc].left=-1;
			release_empty(pt);
			tr[pre].size--;
			tr[suc].size--;
		}
	}
}

template <typename cactus>
void multi_splay<cactus>::insert_in(const cactus v){
	if(n==0){
		tr[n]=multi_splay_node <cactus> (-1,-1,v,-1,1,1);
		root=0;
		n++;
		return;
	}
	if(get_node(root,v)){
		tr[root].cnt++;
		tr[root].size++;
		return;
	}else{
		int np=root;
		while(1){
			tr[np].size++;
			if(v>tr[np].v){
				if(tr[np].right==-1){
					tr[n]=multi_splay_node <cactus> (-1,-1,v,np,1,1);
					tr[np].right=n;
					rotate_to(n);
					n++;
					return;
				}else{
					np=tr[np].right;
					continue;
				}
			}else{
				if(tr[np].left==-1){
					tr[n]=multi_splay_node <cactus> (-1,-1,v,np,1,1);
					tr[np].left=n;
					rotate_to(n);
					n++;
					return;
				}else{
					np=tr[np].left;
					continue;
				}
			}
		}
	}
}

template <typename cactus>
const cactus multi_splay<cactus>::kth_in_root(const int rootx,const int kth){
	if(tr[rootx].left==-1){
		if(kth<=tr[rootx].cnt){
			return tr[rootx].v;
		}
		return kth_in_root(tr[rootx].right,kth-tr[rootx].cnt);
	}else{
		if(kth>tr[tr[rootx].left].size+tr[rootx].cnt){
			return kth_in_root(tr[rootx].right,kth-tr[tr[rootx].left].size-tr[rootx].cnt);
		}else{
			if(kth<=tr[tr[rootx].left].size){
				return kth_in_root(tr[rootx].left,kth);
			}else{
				return tr[rootx].v;
			}
		}
	}
}

template <typename cactus>
const cactus multi_splay<cactus>::kth_in(const int kth){
	if(n==0||kth<1||kth>tr[root].size){
		return INF;
	}
	return kth_in_root(root,kth);
}

template <typename cactus>
const cactus multi_splay<cactus>::max_in(void){
	if(n==0){
		return INF;
	}
	int np=root;
	while(tr[np].right!=-1){
		np=tr[np].right;
	}
	return tr[np].v;
}

template <typename cactus>
const cactus multi_splay<cactus>::min_in(void){
	if(n==0){
		return INF;
	}
	int np=root;
	while(tr[np].left!=-1){
		np=tr[np].left;
	}
	return tr[np].v;
}

template <typename cactus>
void multi_splay<cactus>::printxroot(int p){
	if(p==-1){
		return;
	}
	printxroot(tr[p].left);
	for(int i=0;i<tr[p].cnt;i++){
		cactusout<<tr[p].v<<space;
	}
	printxroot(tr[p].right);
}

template <typename cactus>
const SIZE_C multi_splay<cactus>::size(void){
	return n;
}

template <typename cactus>
const SIZE_C multi_splay<cactus>::count(void){
	if(n==0){
		return 0;
	}
	else{
		return tr[root].size;
	}
}

template <typename cactus>
void multi_splay<cactus>::clear(void){
	n=0;
}

template <typename cactus>
multi_splay<cactus>::multi_splay(){
	n=0;
}

template <typename cactus>
multi_splay<cactus>::multi_splay(const cactus v){
	tr[0]=multi_splay_node <cactus> (-1,-1,v,-1,1,1);
	root=0;
	n=1;
}

template <typename cactus>
const cactus multi_splay<cactus>::max(void){
	return max_in();
}

template <typename cactus>
const cactus multi_splay<cactus>::min(void){
	return min_in();
}

template <typename cactus>
const cactus multi_splay<cactus>::kth(const int k){
	return kth_in(k);
}

template <typename cactus>
const int multi_splay<cactus>::rank(const cactus v){
	return rank_in(v);
}

template <typename cactus>
const cactus multi_splay<cactus>::suc(const cactus v){
	return suc_in(v);
}

template <typename cactus>
const cactus multi_splay<cactus>::pre(const cactus v){
	return pre_in(v);
}

template <typename cactus>
void multi_splay<cactus>::del(const cactus v){
	delete_in(v);
}

template <typename cactus>
void multi_splay<cactus>::insert(const cactus v){
	insert_in(v);
}

template <typename cactus>
const bool multi_splay<cactus>::find(const cactus v){
	return find_in(v);
}

template <typename cactus>
void multi_splay<cactus>::print(void){
	if(n==0){
		return;
	}
	printxroot(root);
}

/*******************************************************************************/

class weighed_node{
	private:
		int left;
		int right;
		int v;
		weighed_node();
		weighed_node(int l,int r,int val);
		friend class weighed_tree;
};

weighed_node::weighed_node(){
	left=-1;
	right=-1;
	v=0;
}

weighed_node::weighed_node(int l,int r,int val){
	left=l;
	right=r;
	v=val;
}



class weighed_tree{
	private:
		weighed_node tr[MAXN];
		int val;
		int n;
		int new_node(int l=-1,int r=-1,int v=0);
		void build(void);
		void buildin(int k,int l,int r);
		void init(const int value);
		void init(void);
		void point_add_in(int k,int l,int r,int v,int cnt);
		void point_add(int v,int cnt);
		const int point_query_in(int k,int l,int r,int v);
		const int point_query(int v);
		const int range_query_in(int k,int l,int r,int vl,int vr);
		const int range_query(int vl,int vr);
		const int kth_in_root(int rootx,int l,int r,int kth);
		void insert_in(const int v);
		void multi_insert_in(const int v,const int cnt);
		void del_in(const int v);
		void multi_del_in(const int v,const int cnt);
		const int count_in(const int v);
		const int count_in(const int vl,const int vr);
		const bool find_in(const int v);
		const int rank_in(const int v);
		const int kth_in(const int kth);
		void add_in(const int v,const int add_value);
		void multi_add_in(const int v,const int add_value,const int cnt);
		void minus_in(const int v,const int minus_value);
		void multi_minus_in(const int v,const int minus_value,const int cnt);
		void merge_in(const weighed_tree& w_tr);
		void anti_merge_in(const weighed_tree& w_tr);
	public:
		weighed_tree(void);
		weighed_tree(const int value_range);
		const SIZE_C size(void);
		const SIZE_C value_range(void);
		const bool find(const int v);
		void insert(const int v);
		void insert(const int v,const int cnt);
		void del(const int v);
		void del(const int v,const int cnt);
		const int count(const int v);
		const int count(const int vl,const int vr);
		const int rank(const int v);
		const int kth(const int k);
		void add(const int v,const int add_value);
		void add(const int v,const int add_value,const int cnt);
		void minus(const int v,const int minus_value);
		void minus(const int v,const int minus_value,const int cnt);
		void clear(void);
		void operator+=(const weighed_tree& w_tr);
		const weighed_tree operator+(const weighed_tree& w_tr)const;
		void operator-=(const weighed_tree& w_tr);
		const weighed_tree operator-(const weighed_tree& w_tr)const;
};

int weighed_tree::new_node(int l,int r,int v){
	tr[n]=weighed_node(l,r,v);
	n++;
	return n-1;
}

void weighed_tree::buildin(int k,int l,int r){
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	tr[k].left=new_node(-1,-1,0);
	tr[k].right=new_node(-1,-1,0);
	buildin(tr[k].left,l,mid);
	buildin(tr[k].right,mid+1,r);
}

void weighed_tree::build(void){
	tr[0]=weighed_node();
	n=1;
	buildin(0,1,val);
}

void weighed_tree::init(const int value){
	val=value;
	n=0;
	build();
}

void weighed_tree::init(void){
	val=MAXNUM;
	n=0;
	build();
}

void weighed_tree::point_add_in(int k,int l,int r,int v,int cnt){
	if(l==r){
		tr[k].v+=cnt;
		if(tr[k].v<0){
			tr[k].v=0;
		}
		return;
	}
	int mid=(l+r)>>1;
	if(v>mid){
		point_add_in(tr[k].right,mid+1,r,v,cnt);
	}else{
		point_add_in(tr[k].left,l,mid,v,cnt);
	}
	tr[k].v=tr[tr[k].left].v+tr[tr[k].right].v;
}

void weighed_tree::point_add(int v,int cnt){
	point_add_in(0,1,val,v,cnt);
}

const int weighed_tree::point_query_in(int k,int l,int r,int v){
	if(l==r){
		return tr[k].v;
	}
	int mid=(l+r)>>1;
	if(v>mid){
		return point_query_in(tr[k].right,mid+1,r,v);
	}else{
		return point_query_in(tr[k].left,l,mid,v);
	}
}

const int weighed_tree::point_query(int v){
	return point_query_in(0,1,val,v);
}

const int weighed_tree::range_query_in(int k,int l,int r,int vl,int vr){
	if(inrange(l,r,vl,vr)){
		return tr[k].v;
	}
	if(outofrange(l,r,vl,vr)){
		return 0;
	}
	int mid=(l+r)>>1;
	return range_query_in(tr[k].left,l,mid,vl,vr)+range_query_in(tr[k].right,mid+1,r,vl,vr);
}

const int weighed_tree::range_query(int vl,int vr){
	return range_query_in(0,1,val,vl,vr);
}

const int weighed_tree::kth_in_root(int rootx,int l,int r,int kth){
	if(l==r){
		return l;
	}
	int mid=(l+r)>>1;
	if(kth>tr[tr[rootx].left].v){
		return kth_in_root(tr[rootx].right,mid+1,r,kth-tr[tr[rootx].left].v);
	}else{
		return kth_in_root(tr[rootx].left,l,mid,kth);
	}
}

void weighed_tree::insert_in(const int v){
	point_add(v,1);
}

void weighed_tree::multi_insert_in(const int v,const int cnt){
	point_add(v,cnt);
}

void weighed_tree::del_in(const int v){
	point_add(v,-1);
}

void weighed_tree::multi_del_in(const int v,const int cnt){
	point_add(v,-cnt);
}

const int weighed_tree::count_in(const int v){
	return point_query(v);
}

const int weighed_tree::count_in(const int vl,const int vr){
	return range_query(vl,vr);
}

const bool weighed_tree::find_in(const int v){
	return (bool)point_query(v);
}

const int weighed_tree::rank_in(const int v){
	if(v==1){
		return 1;
	}
	return count_in(1,v-1)+1;
}

const int weighed_tree::kth_in(const int kth){
	return kth_in_root(0,1,val,kth);
}

void weighed_tree::add_in(const int v,const int add_value){
	point_add(v,-1);
	point_add(v+add_value,1);
}

void weighed_tree::multi_add_in(const int v,const int add_value,const int cnt){
	point_add(v,-cnt);
	point_add(v+add_value,cnt);
}

void weighed_tree::minus_in(const int v,const int minus_value){
	point_add(v,-1);
	point_add(v-minus_value,1);
}

void weighed_tree::multi_minus_in(const int v,const int minus_value,const int cnt){
	point_add(v,-cnt);
	point_add(v-minus_value,cnt);
}

void weighed_tree::merge_in(const weighed_tree& w_tr){
	if(val!=w_tr.val){
		return;
	}
	for(int i=0;i<n;i++){
		tr[i].v+=w_tr.tr[i].v;
	}
}

void weighed_tree::anti_merge_in(const weighed_tree& w_tr){
	if(val!=w_tr.val){
		return;
	}
	for(int i=0;i<n;i++){
		tr[i].v-=w_tr.tr[i].v;
	}
}

weighed_tree::weighed_tree(void){
	init();
}

weighed_tree::weighed_tree(const int value_range){
	init(value_range);
}

const SIZE_C weighed_tree::size(void){
	return tr[0].v;
}

const SIZE_C weighed_tree::value_range(void){
	return val;
}

const bool weighed_tree::find(const int v){
	return find_in(v);
}

void weighed_tree::insert(const int v){
	insert_in(v);
}

void weighed_tree::insert(const int v,const int cnt){
	multi_insert_in(v,cnt);
}

void weighed_tree::del(const int v){
	del_in(v);
}

void weighed_tree::del(const int v,const int cnt){
	multi_del_in(v,cnt);
}

const int weighed_tree::count(const int v){
	return count_in(v);
}

const int weighed_tree::count(const int vl,const int vr){
	return count_in(vl,vr);
}

const int weighed_tree::rank(const int v){
	return rank_in(v);
}

const int weighed_tree::kth(const int k){
	return kth_in(k);
}

void weighed_tree::add(const int v,const int add_value){
	add_in(v,add_value);
}

void weighed_tree::add(const int v,const int add_value,const int cnt){
	multi_add_in(v,add_value,cnt);
}

void weighed_tree::minus(const int v,const int minus_value){
	minus_in(v,minus_value);
}

void weighed_tree::minus(const int v,const int minus_value,const int cnt){
	multi_minus_in(v,minus_value,cnt);
}

void weighed_tree::clear(void){
	for(int i=0;i<n;i++){
		tr[i].v=0;
	}
}

void weighed_tree::operator+=(const weighed_tree& w_tr){
	merge_in(w_tr);
}

const weighed_tree weighed_tree::operator+(const weighed_tree& w_tr)const{
	weighed_tree cop=(*this);
	cop+=w_tr;
	return cop;
}

void weighed_tree::operator-=(const weighed_tree& w_tr){
	anti_merge_in(w_tr);
}

const weighed_tree weighed_tree::operator-(const weighed_tree& w_tr)const{
	weighed_tree cop=(*this);
	cop-=w_tr;
	return cop;
}

/*******************************************************************************/

class president_node{
	private:
		int left;
		int right;
		int v;
		president_node();
		president_node(int l,int r,int val);
		friend class president_tree;
};

president_node::president_node(){
	left=-1;
	right=-1;
	v=0;
}

president_node::president_node(int l,int r,int val){
	left=l;
	right=r;
	v=val;
}



class president_tree{
	private:
		president_node tr[MAXN*4];
		int val;
		int n;
		int root[MAXN];
		int r;//number of trees
		const int new_node(void);
		const int new_node(int l,int r,int v);
		void buildin(int k,int l,int r);
		void build(void);
		void init(void);
		void init(const int vrange);
		const int point_query_in(int k,int l,int r,int v);
		const int point_query(int version,int v);
		const int range_query_in(int k,int l,int r,int vl,int vr);
		const int range_query(int version,int vl,int vr);
		void build_linear_in(const int pre_pt,const int k,const int l,const int r,const int p,const int v);
		void build_linear(const int pre_root,const int p,const int v);
		void build_new(const int pre_root,const int p,const int v);
		void insert_on_pre_root(const int pre_root,const int v,const int cnt);
		const int kth_in_root(int rootx,int l,int r,int kth);
		const int kth_of_root_in(const int root,const int kth);
		void insert_in(const int version,const int v);
		void multi_insert_in(const int version,const int v,const int cnt);
		void simple_insert_in(const int v);
		void multi_simple_insert_in(const int v,const int cnt);
		void delete_in(const int version,const int v);
		void multi_delete_in(const int version,const int v,const int cnt);
		void simple_delete_in(const int v);
		void multi_simple_delete_in(const int v,const int cnt);
		const int kth_in(const int version,const int k);
		const int simple_kth_in(const int k);
		const int count_in(const int version,const int v);
		const int simple_count_in(const int v);
		const int multi_count_in(const int version,const int vl,const int vr);
		const int multi_simple_count_in(const int vl,const int vr);
		const bool find_in(const int version,const int v);
		const bool simple_find_in(const int v);
		const int rank_in(const int version,const int v);
		const int simple_rank_in(const int v);
	public:
		president_tree(void);
		president_tree(const int value_range);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		const SIZE_C value_range(void);
		const SIZE_C total_versions(void);
		const int insert(const int version,const int v);
		const int insert(const int version,const int v,const int cnt);
		const int simple_insert(const int v);
		const int simple_insert(const int v,const int cnt);
		const int del(const int version,const int v);
		const int del(const int version,const int v,const int cnt);
		const int simple_del(const int v);
		const int simple_del(const int v,const int cnt);
		const int kth(const int version,const int k);
		const int simple_kth(const int k);
		const int count(const int version,const int v);
		const int simple_count(const int v);
		const int count(const int version,const int vl,const int vr);
		const int simple_count(const int vl,const int vr);
		const bool find(const int version,const int v);
		const bool simple_find(const int v);
		const int rank(const int version,const int v);
		void version_copy(const int version);
		void simple_version_copy(void);
		const int simple_rank(const int v);
};

const int president_tree::new_node(void){
	tr[n]=president_node(-1,-1,0);
	n++;
	return n-1;
}

const int president_tree::new_node(int l,int r,int v){
	tr[n]=president_node(l,r,v);
	n++;
	return n-1;
}

void president_tree::buildin(int k,int l,int r){
	if(l==r){
		return;
	}
	tr[k].left=new_node();
	tr[k].right=new_node();
	int mid=(l+r)>>1;
	buildin(tr[k].left,l,mid);
	buildin(tr[k].right,mid+1,r);
}

void president_tree::build(void){
	r=1;
	root[0]=0;
	n=1;
	tr[0]=president_node();
	buildin(0,1,val);
}

void president_tree::init(void){
	val=MAXNUM;
	build();
}

void president_tree::init(const int vrange){
	val=vrange;
	build();
}

const int president_tree::point_query_in(int k,int l,int r,int v){
	if(l==r){
		return tr[k].v;
	}
	int mid=(l+r)>>1;
	if(v>mid){
		return point_query_in(tr[k].right,mid+1,r,v);
	}else{
		return point_query_in(tr[k].left,l,mid,v);
	}
}

const int president_tree::point_query(int version,int v){
	return point_query_in(root[version],1,val,v);
}

const int president_tree::range_query_in(int k,int l,int r,int vl,int vr){
	if(inrange(l,r,vl,vr)){
		return tr[k].v;
	}
	if(outofrange(l,r,vl,vr)){
		return 0;
	}
	int mid=(l+r)>>1;
	return range_query_in(tr[k].left,l,mid,vl,vr)+range_query_in(tr[k].right,mid+1,r,vl,vr);
}

const int president_tree::range_query(int version,int vl,int vr){
	return range_query_in(root[version],1,val,vl,vr);
}

void president_tree::build_linear_in(const int pre_pt,const int k,const int l,const int r,const int p,const int v){
	if(l==r){
		tr[k].v=tr[pre_pt].v+v;
		if(tr[k].v<0){
			tr[k].v=0;
		}
		n++;
		return;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		tr[k].left=tr[pre_pt].left;
		tr[k].right=n+1;
		n++;
		build_linear_in(tr[pre_pt].right,n,mid+1,r,p,v);
		tr[k].v=tr[tr[k].left].v+tr[tr[k].right].v;
		return;
	}else{
		tr[k].right=tr[pre_pt].right;
		tr[k].left=n+1;
		n++;
		build_linear_in(tr[pre_pt].left,n,l,mid,p,v);
		tr[k].v=tr[tr[k].left].v+tr[tr[k].right].v;
		return;
	}
}

void president_tree::build_linear(const int pre_root,const int p,const int v){
	build_linear_in(pre_root,n,1,val,p,v);
}

void president_tree::build_new(const int pre_root,const int p,const int v){
	root[r]=n;
	r++;
	build_linear(pre_root,p,v);
}

void president_tree::insert_on_pre_root(const int pre_root,const int v,const int cnt){
	build_new(pre_root,v,cnt);
}

const int president_tree::kth_in_root(int rootx,int l,int r,int kth){
	if(l==r){
		return l;
	}
	int mid=(l+r)>>1;
	if(kth>tr[tr[rootx].left].v){
		return kth_in_root(tr[rootx].right,mid+1,r,kth-tr[tr[rootx].left].v);
	}else{
		return kth_in_root(tr[rootx].left,l,mid,kth);
	}
}

const int president_tree::kth_of_root_in(const int root,const int kth){
	return kth_in_root(root,1,val,kth);
}

void president_tree::insert_in(const int version,const int v){
	insert_on_pre_root(root[version],v,1);
}

void president_tree::multi_insert_in(const int version,const int v,const int cnt){
	insert_on_pre_root(root[version],v,cnt);
}

void president_tree::simple_insert_in(const int v){
	insert_on_pre_root(root[r-1],v,1);
}

void president_tree::multi_simple_insert_in(const int v,const int cnt){
	insert_on_pre_root(root[r-1],v,cnt);
}

void president_tree::delete_in(const int version,const int v){
	insert_on_pre_root(root[version],v,-1);
}

void president_tree::multi_delete_in(const int version,const int v,const int cnt){
	insert_on_pre_root(root[version],v,-cnt);
}

void president_tree::simple_delete_in(const int v){
	insert_on_pre_root(root[r-1],v,-1);
}

void president_tree::multi_simple_delete_in(const int v,const int cnt){
	insert_on_pre_root(root[r-1],v,-cnt);
}

const int president_tree::kth_in(const int version,const int k){
	return kth_of_root_in(root[version],k);
}

const int president_tree::simple_kth_in(const int k){
	return kth_of_root_in(root[r-1],k);
}

const int president_tree::count_in(const int version,const int v){
	return point_query(version,v);
}

const int president_tree::simple_count_in(const int v){
	return point_query(r-1,v);
}

const int president_tree::multi_count_in(const int version,const int vl,const int vr){
	return range_query(version,vl,vr);
}

const int president_tree::multi_simple_count_in(const int vl,const int vr){
	return range_query(r-1,vl,vr);
}

const bool president_tree::find_in(const int version,const int v){
	return (bool)count_in(version,v);
}

const bool president_tree::simple_find_in(const int v){
	return (bool)simple_count_in(v);
}

const int president_tree::rank_in(const int version,const int v){
	if(v==1){
		return 1;
	}
	return multi_count_in(version,1,v-1)+1;
}

const int president_tree::simple_rank_in(const int v){
	if(v==1){
		return 1;
	}
	return multi_simple_count_in(1,v-1)+1;
}

president_tree::president_tree(void){
	init();
}

president_tree::president_tree(const int value_range){
	init(value_range);
}

const SIZE_C president_tree::size(const int version){
	return tr[root[version]].v;
}

const SIZE_C president_tree::simple_size(void){
	return tr[root[r-1]].v;
}

const SIZE_C president_tree::value_range(void){
	return val;
}

const SIZE_C president_tree::total_versions(void){
	return r;
}

const int president_tree::insert(const int version,const int v){
	insert_in(version,v);
	return r-1;
}

const int president_tree::insert(const int version,const int v,const int cnt){
	multi_insert_in(version,v,cnt);
	return r-1;
}

const int president_tree::simple_insert(const int v){
	simple_insert_in(v);
	return r-1;
}

const int president_tree::simple_insert(const int v,const int cnt){
	multi_simple_insert_in(v,cnt);
	return r-1;
}

const int president_tree::del(const int version,const int v){
	delete_in(version,v);
	return r-1;
}

const int president_tree::del(const int version,const int v,const int cnt){
	multi_delete_in(version,v,cnt);
	return r-1;
}

const int president_tree::simple_del(const int v){
	simple_delete_in(v);
	return r-1;
}

const int president_tree::simple_del(const int v,const int cnt){
	multi_simple_delete_in(v,cnt);
	return r-1;
}

const int president_tree::kth(const int version,const int k){
	return kth_in(version,k);
}

const int president_tree::simple_kth(const int k){
	return simple_kth_in(k);
}

const int president_tree::count(const int version,const int v){
	return count_in(version,v);
}

const int president_tree::simple_count(const int v){
	return simple_count_in(v);
}

const int president_tree::count(const int version,const int vl,const int vr){
	return multi_count_in(version,vl,vr);
}

const int president_tree::simple_count(const int vl,const int vr){
	return multi_simple_count_in(vl,vr);
}

const bool president_tree::find(const int version,const int v){
	return find_in(version,v);
}

const bool president_tree::simple_find(const int v){
	return simple_find_in(v);
}

const int president_tree::rank(const int version,const int v){
	return rank_in(version,v);
}

const int president_tree::simple_rank(const int v){
	return simple_rank_in(v);
}

void president_tree::version_copy(const int version){
	multi_insert_in(version,1,0);
}

void president_tree::simple_version_copy(void){
	multi_insert_in(r-1,1,0);
}

/*******************************************************************************/

class range_seg_node{
	private:
		int left;
		int right;
		int v;
		range_seg_node();
		range_seg_node(int l,int r,int val);
		friend class range_weighed_query_tree;
};

range_seg_node::range_seg_node(){
	left=-1;
	right=-1;
	v=0;
}

range_seg_node::range_seg_node(int l,int r,int val){
	left=l;
	right=r;
	v=val;
}

class range_weighed_query_tree{
	private:
		int n;
		int val;
		range_seg_node tr[MAXN*4];
		int r;
		int root[MAXN];
		const int new_node(void);
		const int new_node(int l,int r,int v);
		void buildin(int k,int l,int r);
		void build(void);
		void build_new(int pre_node,int k,int l,int r,int v);
		void init(int *pl,int *pr);
		int point_query(int k,int l,int r,int v);
		int range_query(int k,int l,int r,int vl,int vr);
		int kth_value(int root,int l,int r,int kth);
		int v_rank(int root,int v);
		bool find_exist(int root,int v);
		const int get_sum_value_in(int k1,int k2,int l,int r,int v);
		const int get_sum_value(const int pl,const int pr,int v);
		const int get_sum_range_in(int k1,int k2,int l,int r,int vl,int vr);
		const int get_sum_range(const int vl,const int vr,const int pl,const int pr);
		const int range_rank_in(int pl,int pr,int v);
		const int range_kth_inline(int k1,int k2,int l,int r,int kth);
		const int range_kth_in(int pl,int pr,int kth);
		const bool find_in(int pl,int pr,int v);
	public:
		explicit range_weighed_query_tree(int *a1,int *a2);
		const SIZE_C value_range(void);
		const bool find(const int range_l,const int range_r,const int v);
		const int count(const int range_l,const int range_r,const int v);
		const int count(const int range_l,const int range_r,const int vl,const int vr);
		const bool rank(const int range_l,const int range_r,const int v);
		const int kth(const int range_l,const int range_r,const int k);
};

const int range_weighed_query_tree::new_node(void){
	n++;
	return n-1;
}

const int range_weighed_query_tree::new_node(int l,int r,int v){
	tr[n]=range_seg_node(l,r,v);
	n++;
	return n-1;
}

void range_weighed_query_tree::buildin(int k,int l,int r){
	if(l==r){
		return;
	}
	tr[k].left=new_node();
	tr[k].right=new_node();
	int mid=(l+r)>>1;
	buildin(tr[k].left,l,mid);
	buildin(tr[k].right,mid+1,r);
}

void range_weighed_query_tree::build(void){
	r=1;
	n=1;
	root[0]=0;
	buildin(0,1,val);
}

void range_weighed_query_tree::build_new(int pre_node,int k,int l,int r,int v){
	if(l==r){
		tr[k].v=tr[pre_node].v+1;
		return;
	}
	tr[k].v=tr[pre_node].v+1;
	int mid=(l+r)>>1;
	if(v>mid){
		tr[k].left=tr[pre_node].left;
		tr[k].right=new_node();
		build_new(tr[pre_node].right,tr[k].right,mid+1,r,v);
		return;
	}else{
		tr[k].right=tr[pre_node].right;
		tr[k].left=new_node();
		build_new(tr[pre_node].left,tr[k].left,l,mid,v);
		return;
	}
}

void range_weighed_query_tree::init(int *pl,int *pr){
	val=10;
	for(int *x=pl;x<pr;x++){
		val=val>*x?val:*x;
	}
	build();
	for(;pl<pr;pl++){
		root[r]=new_node();
		build_new(root[r-1],n-1,1,val,*pl);
		r++;
	}
}

int range_weighed_query_tree::point_query(int k,int l,int r,int v){
	if(l==r){
		return tr[k].v;
	}
	int mid=(l+r)>>1;
	if(v>mid){
		return point_query(tr[k].right,mid+1,r,v);
	}else{
		return point_query(tr[k].left,l,mid,v);
	}
}

int range_weighed_query_tree::range_query(int k,int l,int r,int vl,int vr){
	if(inrange(l,r,vl,vr)){
		return tr[k].v;
	}
	if(outofrange(l,r,vl,vr)){
		return 0;
	}
	int mid=(l+r)>>1;
	return range_query(tr[k].left,l,mid,vl,vr)+range_query(tr[k].right,mid+1,r,vl,vr);
}

int range_weighed_query_tree::kth_value(int root,int l,int r,int kth){
	if(l==r){
		return l;
	}
	int mid=(l+r)>>1;
	if(kth>tr[tr[root].left].v){
		return kth_value(tr[root].right,mid+1,r,kth-tr[tr[root].left].v);
	}else{
		return kth_value(tr[root].left,l,mid,kth);
	}
}

int range_weighed_query_tree::v_rank(int root,int v){
	if(v==1){
		return 1;
	}
	return range_query(root,1,val,1,v-1)+1;
}

bool range_weighed_query_tree::find_exist(int root,int v){
	return (bool)point_query(root,1,val,v);
}

const int range_weighed_query_tree::get_sum_value_in(int k1,int k2,int l,int r,int v){
	if(l==r){
		return tr[k2].v-tr[k1].v;
	}
	int mid=(l+r)>>1;
	if(v>mid){
		return get_sum_value_in(tr[k1].right,tr[k2].right,mid+1,r,v);
	}else{
		return get_sum_value_in(tr[k1].left,tr[k2].left,l,mid,v);
	}
}

const int range_weighed_query_tree::get_sum_value(const int pl,const int pr,int v){
	if(pl==1){
		return point_query(root[pr],1,val,v);
	}else{
		return get_sum_value_in(root[pl-1],root[pr],1,val,v);
	}
}

const int range_weighed_query_tree::get_sum_range_in(int k1,int k2,int l,int r,int vl,int vr){
	if(inrange(l,r,vl,vr)){
		return tr[k2].v-tr[k1].v;
	}
	if(outofrange(l,r,vl,vr)){
		return 0;
	}
	int mid=(l+r)>>1;
	return get_sum_range_in(tr[k1].left,tr[k2].left,l,mid,vl,vr)+get_sum_range_in(tr[k1].right,tr[k2].right,mid+1,r,vl,vr);
}

const int range_weighed_query_tree::get_sum_range(const int vl,const int vr,const int pl,const int pr){
	if(vl==1){
		return range_query(root[pr],1,val,vl,vr);
	}
	return get_sum_range_in(root[pl-1],root[pr],1,val,vl,vr);
}

const int range_weighed_query_tree::range_rank_in(int pl,int pr,int v){
	if(v==1){
		return 1;
	}
	return get_sum_range(1,v-1,pl,pr);
}

const int range_weighed_query_tree::range_kth_inline(int k1,int k2,int l,int r,int kth){
	if(l==r){
		return l;
	}
	int mid=(l+r)>>1;
	if(kth>tr[tr[k2].left].v-tr[tr[k1].left].v){
		return range_kth_inline(tr[k1].right,tr[k2].right,mid+1,r,kth-tr[tr[k2].left].v+tr[tr[k1].left].v);
	}else{
		return range_kth_inline(tr[k1].left,tr[k2].left,l,mid,kth);
	}
}

const int range_weighed_query_tree::range_kth_in(int pl,int pr,int kth){
	if(pl==1){
		return kth_value(root[pr],1,val,kth);
	}
	return range_kth_inline(root[pl-1],root[pr],1,val,kth);
}

const bool range_weighed_query_tree::find_in(int pl,int pr,int v){
	return (bool)get_sum_value(pl,pr,v);
}

//note that numbers begin from 1
range_weighed_query_tree::range_weighed_query_tree(int *a1,int *a2){
	init(a1,a2);
}

const SIZE_C range_weighed_query_tree::value_range(void){
	return val;
}

const bool range_weighed_query_tree::find(const int range_l,const int range_r,const int v){
	return find_in(range_l,range_r,v);
}

const int range_weighed_query_tree::count(const int range_l,const int range_r,const int v){
	return get_sum_value(range_l,range_r,v);
}

const int range_weighed_query_tree::count(const int range_l,const int range_r,const int vl,const int vr){
	return get_sum_range(range_l,range_r,vl,vr);
}

const bool range_weighed_query_tree::rank(const int range_l,const int range_r,const int v){
	return range_rank_in(range_l,range_r,v);
}

const int range_weighed_query_tree::kth(const int range_l,const int range_r,const int k){
	return range_kth_in(range_l,range_r,k);
}



class discrete_range_weighed_query_tree{
	private:
		pair_c <int,int> a[MAXN];
		int ax[MAXN];
		int d[MAXN];//disctete
		int n;
		range_weighed_query_tree t=range_weighed_query_tree(d+1,d+5+1);
	public:
		//note that numbers begin from 1
		explicit discrete_range_weighed_query_tree(int *a1,int *a2);
		const SIZE_C value_range(void);
		const bool find(const int range_l,const int range_r,const int v);
		const int count(const int range_l,const int range_r,const int v);
		const int count(const int range_l,const int range_r,const int vl,const int vr);
		const bool rank(const int range_l,const int range_r,const int v);
		const int kth(const int range_l,const int range_r,const int k);
};

discrete_range_weighed_query_tree::discrete_range_weighed_query_tree(int *a1,int *a2){
	int *x=a1;
	for(n=0;x<a2;x++){
		a[n]=pair_c <int,int> (*x,n);
		n++;
	}
	sort(a,a+n);
	d[1]=a[0].x1;
	ax[a[0].x2]=1;
	for(int i=1,j=1;i<n;i++){
		if(a[i].x1!=a[i-1].x1){
			j++;
			d[j]=a[i].x1;
		}
		ax[a[i].x2]=j;
	}
	t=range_weighed_query_tree(ax,ax+n);
}

const SIZE_C discrete_range_weighed_query_tree::value_range(void){
	return t.value_range();
}

const bool discrete_range_weighed_query_tree::find(const int range_l,const int range_r,const int v){
	return d[t.find(range_l,range_r,v)];
}

const int discrete_range_weighed_query_tree::count(const int range_l,const int range_r,const int v){
	return d[t.count(range_l,range_r,v)];
}

const int discrete_range_weighed_query_tree::count(const int range_l,const int range_r,const int vl,const int vr){
	return d[count(range_l,range_r,vl,vr)];
}

const bool discrete_range_weighed_query_tree::rank(const int range_l,const int range_r,const int v){
	return d[t.rank(range_l,range_r,v)];
}

const int discrete_range_weighed_query_tree::kth(const int range_l,const int range_r,const int k){
	return d[t.kth(range_l,range_r,k)];
}

/*******************************************************************************/

template <typename cactus>
class treap_node{
	friend class treap<cactus>;
	private:
		int left;
		int right;
		int p;
		cactus v;
		int priority;
		int size;
		treap_node(void);
		treap_node(const int l,const int r,const int pa,const cactus val,const int prio,const int sz);
};

template <typename cactus>
treap_node<cactus>::treap_node(void){
	left=0;
	right=0;
	p=0;
	v=0;
	priority=0;
	size=1;
}

template <typename cactus>
treap_node<cactus>::treap_node(const int l,const int r,const int pa,const cactus val,const int prio,const int sz){
	left=l;
	right=r;
	p=pa;
	v=val;
	priority=prio;
	size=sz;
}



template <typename cactus>
class treap{
	private:
		int n;
		int root;
		treap_node <cactus> tr[MAXN];
		int seed=803;
		const int rand_c(void);
		void resize(const int p);
		void release_empty(const int p);
		const bool lrson(const int p);
		void left_rotate(const int p);
		void right_rotate(const int p);
		void zig(const int p);
		void zag(const int p);
		const int find_or_get_p(const cactus v);
		const cactus get_max_in(const int p);
		const cactus get_min_in(const int p);
		const cactus max_in(void);
		const cactus min_in(void);
		const cactus pre_in(const cactus v);
		const cactus suc_in(const cactus v);
		void init(void);
		void insert_in(cactus v);
		void del_in(const cactus v);
		const int rank_inline(const int p,const cactus v);
		const cactus kth_in_root(const int rootx,const int kth);
		const cactus kth_in(const int kth);
		const int rank_in(const cactus v);
		void printxroot(int p);
	public:
		treap(void);
		const SIZE_C size(void);
		const cactus max(void);
		const cactus min(void);
		void insert(const cactus v);
		void del(const cactus v);
		const cactus kth(const int kth);
		const int rank(const cactus v);
		const bool find(const cactus v);
		const cactus pre(const cactus v);
		const cactus suc(const cactus v);
		void print(void);
};

template <typename cactus>
inline const int treap<cactus>::rand_c(void){
    return seed=(int)((seed*4827153LL+114514)%2147483647);
}

template <typename cactus>
void treap<cactus>::resize(const int p){
	tr[p].size=1+tr[tr[p].left].size+tr[tr[p].right].size;
}

template <typename cactus>
void treap<cactus>::release_empty(const int p){
	if(p==n){
		n--;
		return;
	}
	tr[p].size=tr[n].size;
	tr[p].v=tr[n].v;
	tr[p].left=tr[n].left;
	tr[p].right=tr[n].right;
	tr[p].p=tr[n].p;
	tr[p].priority=tr[n].priority;
	if(tr[p].right!=0){
		tr[tr[p].right].p=p;
	}
	if(tr[p].left!=0){
		tr[tr[p].left].p=p;
	}
	if(tr[p].p!=0){
		if(lrson(n)){
			tr[tr[p].p].right=p;
		}else{
			tr[tr[p].p].left=p;
		}
	}else{
		root=p;
	}
	n--;
}

template <typename cactus>
const bool treap<cactus>::lrson(const int p){
	return p==tr[tr[p].p].right;
}

template <typename cactus>
void treap<cactus>::left_rotate(const int p){
	const int rp=tr[p].right;
	const int pa=tr[p].p;
	const int rl=tr[tr[p].right].left;
	
	if(p==root){
		root=rp;
		tr[rp].p=0;
	}else{
		if(lrson(p)){
			tr[pa].right=rp;
			tr[rp].p=pa;
		}else{
			tr[pa].left=rp;
			tr[rp].p=pa;
		}
	}
	
	tr[p].p=rp;
	tr[rp].left=p;
	
	tr[p].right=rl;
	tr[rl].p=p;
	
	resize(p);
	resize(rp);
	
	tr[0].p=0;
	tr[0].left=0;
	tr[0].right=0;
}

template <typename cactus>
void treap<cactus>::right_rotate(const int p){
	const int lp=tr[p].left;
	const int pa=tr[p].p;
	const int lr=tr[tr[p].left].right;
	
	if(p==root){
		root=lp;
		tr[lp].p=0;
	}else{
		if(lrson(p)){
			tr[pa].right=lp;
			tr[lp].p=pa;
		}else{
			tr[pa].left=lp;
			tr[lp].p=pa;
		}
	}
	
	tr[p].p=lp;
	tr[lp].right=p;
	
	tr[p].left=lr;
	tr[lr].p=p;
	
	resize(p);
	resize(lp);
	
	tr[0].p=0;
	tr[0].left=0;
	tr[0].right=0;
}

template <typename cactus>
void treap<cactus>::zig(const int p){
	right_rotate(tr[p].p);
}

template <typename cactus>
void treap<cactus>::zag(const int p){
	left_rotate(tr[p].p);
}

template <typename cactus>
const int treap<cactus>::find_or_get_p(const cactus v){//returns 0-pos if found and parent if not
	int pos=root;
	while(1){
		if(tr[pos].v>v){
			if(tr[pos].left==0){
				return pos;
			}else{
				pos=tr[pos].left;
				continue;
			}
		}else{
			if(tr[pos].v<v){
				if(tr[pos].right==0){
					return pos;
				}else{
					pos=tr[pos].right;
					continue;
				}
			}else{
				return -pos;
			}
		}
	}
}

template <typename cactus>
const cactus treap<cactus>::get_max_in(const int p){
	if(tr[p].right==0){
		return tr[p].v;
	}
	return get_max_in(tr[p].right);
}

template <typename cactus>
const cactus treap<cactus>::get_min_in(const int p){
	if(tr[p].left==0){
		return tr[p].v;
	}
	return get_min_in(tr[p].left);
}

template <typename cactus>
const cactus treap<cactus>::max_in(void){
	return get_max_in(root);
}

template <typename cactus>
const cactus treap<cactus>::min_in(void){
	return get_min_in(root);
}

template <typename cactus>
const cactus treap<cactus>::pre_in(const cactus v){
	int pos=root;
	cactus res=INF;
	while(pos){
		if(v>tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].right;
		}else{
			pos=tr[pos].left;
		}
	}
	return res;
}

template <typename cactus>
const cactus treap<cactus>::suc_in(const cactus v){
	int pos=root;
	cactus res=-INF;
	while(pos){
		if(v<tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].left;
		}else{
			pos=tr[pos].right;
		}
	}
	return res;
}

template <typename cactus>
void treap<cactus>::init(void){
	tr[0]=treap_node <cactus> (0,0,0,0,-1,0);
	n=0;
	root=0;
}

template <typename cactus>
void treap<cactus>::insert_in(cactus v){
	if(n==0){
		tr[1]=treap_node <cactus> (0,0,0,v,rand_c(),1);
		root=1;
		n=1;
		return;
	}
	int px=find_or_get_p(v);
	if(px<0){
		return;
	}
	n++;
	tr[n].p=px;
	if(tr[px].v>v){
		tr[px].left=n;
	}else{
		tr[px].right=n;
	}
	tr[n].left=0;
	tr[n].right=0;
	tr[n].v=v;
	tr[n].priority=rand_c();
	while(tr[n].p&&tr[n].priority<tr[tr[n].p].priority){
		if(lrson(n)){
			zag(n);
		}else{
			zig(n);
		}
	}
	px=tr[n].p;
	while(px){
		resize(px);
		px=tr[px].p;
	}
}

template <typename cactus>
void treap<cactus>::del_in(const cactus v){
	if(n==0||n==1){
		n=0;
		return;
	}
	int px=find_or_get_p(v);
	if(px>0){
		return;
	}
	px=-px;
	while(1){
		if(tr[px].left==0){
			if(tr[px].right==0){
				int pp=px;
				tr[pp].size=0;
				if(lrson(pp)){
					tr[tr[pp].p].right=0;
				}else{
					tr[tr[pp].p].left=0;
				}
				pp=tr[pp].p;
				while(pp){
					resize(pp);
					pp=tr[pp].p;
				}
				release_empty(px);
				return;
			}else{
				left_rotate(px);
			}
		}else{
			if(tr[px].right==0){
				right_rotate(px);
			}else{
				if(tr[tr[px].left].priority<tr[tr[px].right].priority){
					right_rotate(px);
				}else{
					left_rotate(px);
				}
			}
		}
	}
}

template <typename cactus>
const int treap<cactus>::rank_inline(const int p,const cactus v){
	if(tr[p].v>v){
		return rank_inline(tr[p].left,v);
	}else{
		if(tr[p].v<v){
			return rank_inline(tr[p].right,v)+1+tr[tr[p].left].size;
		}else{
			return 1+tr[tr[p].left].size;
		}
	}
}

template <typename cactus>
const cactus treap<cactus>::kth_in_root(const int rootx,const int kth){
	if(tr[rootx].size==1){
		return tr[rootx].v;
	}
	if(tr[rootx].left==0){
		if(kth==1){
			return tr[rootx].v;
		}
		return kth_in_root(tr[rootx].right,kth-1);
	}else{
		if(kth>tr[tr[rootx].left].size+1){
			return kth_in_root(tr[rootx].right,kth-tr[tr[rootx].left].size-1);
		}else{
			if(kth==tr[tr[rootx].left].size+1){
				return tr[rootx].v;
			}else{
				return kth_in_root(tr[rootx].left,kth);
			}
		}
	}
}

template <typename cactus>
const cactus treap<cactus>::kth_in(const int kth){
	return kth_in_root(root,kth);
}

template <typename cactus>
const int treap<cactus>::rank_in(const cactus v){
	return rank_inline(root,v);
}

template <typename cactus>
void treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
treap<cactus>::treap(void){
	init();
}

template <typename cactus>
const SIZE_C treap<cactus>::size(void){
	return tr[root].size;
}

template <typename cactus>
const cactus treap<cactus>::max(void){
	return max_in();
}

template <typename cactus>
const cactus treap<cactus>::min(void){
	return min_in();
}

template <typename cactus>
void treap<cactus>::insert(const cactus v){
	insert_in(v);
}

template <typename cactus>
void treap<cactus>::del(const cactus v){
	del_in(v);
}

template <typename cactus>
const cactus treap<cactus>::kth(const int kth){
	return kth_in(kth);
}

template <typename cactus>
const int treap<cactus>::rank(const cactus v){
	return rank_in(v);
}

template <typename cactus>
const bool treap<cactus>::find(const cactus v){
	return find_or_get_p(v)<0;
}

template <typename cactus>
const cactus treap<cactus>::pre(const cactus v){
	return pre_in(v);
}

template <typename cactus>
const cactus treap<cactus>::suc(const cactus v){
	return suc_in(v);
}

template <typename cactus>
void treap<cactus>::print(void){
	if(n==0){
		return;
	}
	printxroot(root);
}



template <typename cactus>
class multi_treap_node{
	friend class multi_treap<cactus>;
	private:
		int left;
		int right;
		int p;
		cactus v;
		int priority;
		int cnt;
		int size;
		multi_treap_node(void);
		multi_treap_node(const int l,const int r,const int pa,const cactus val,const int prio,const int sz,const int num);
};

template <typename cactus>
multi_treap_node<cactus>::multi_treap_node(void){
	left=0;
	right=0;
	p=0;
	v=0;
	priority=0;
	size=1;
	cnt=1;
}

template <typename cactus>
multi_treap_node<cactus>::multi_treap_node(const int l,const int r,const int pa,const cactus val,const int prio,const int sz,const int num){
	left=l;
	right=r;
	p=pa;
	v=val;
	priority=prio;
	size=sz;
	cnt=num;
}



template <typename cactus>
class multi_treap{
	private:
		int n;
		int root;
		multi_treap_node <cactus> tr[MAXN];
		int seed=114514;
		inline const int rand_c(void);
		void resize(const int p);
		void release_empty(const int p);
		const bool lrson(const int p);
		void left_rotate(const int p);
		void right_rotate(const int p);
		void zig(const int p);
		void zag(const int p);
		const int find_or_get_p(const cactus v);
		const cactus get_max_in(const int p);
		const cactus get_min_in(const int p);
		const cactus max_in(void);
		const cactus min_in(void);
		const cactus pre_in(const cactus v);
		const cactus suc_in(const cactus v);
		void init(void);
		void insert_in(cactus v);
		void del_in(const cactus v);
		const int rank_inline(const int p,const cactus v);
		const cactus kth_in_root(const int rootx,const int kth);
		const int kth_in(const int kth);
		const int rank_in(const int v);
		void printxroot(int p);
	public:
		multi_treap(void);
		const SIZE_C size(void);
		const cactus max(void);
		const cactus min(void);
		void insert(const cactus v);
		void del(const cactus v);
		const cactus kth(const int kth);
		const int rank(const cactus v);
		const bool find(const cactus v);
		const cactus pre(const cactus v);
		const cactus suc(const cactus v);
		void print(void);
};

template <typename cactus>
inline const int multi_treap<cactus>::rand_c(void){
    return seed=(int)(seed*4827153LL%2147483647);
}

template <typename cactus>
void multi_treap<cactus>::resize(const int p){
	tr[p].size=tr[p].cnt+tr[tr[p].left].size+tr[tr[p].right].size;
}

template <typename cactus>
void multi_treap<cactus>::release_empty(const int p){
	if(p==n){
		n--;
		return;
	}
	if(n==root){
		root=p;
	}
	tr[p]=tr[n];
	if(tr[p].right!=0){
		tr[tr[p].right].p=p;
	}
	if(tr[p].left!=0){
		tr[tr[p].left].p=p;
	}
	if(tr[p].p!=0){
		if(lrson(n)){
			tr[tr[p].p].right=p;
		}else{
			tr[tr[p].p].left=p;
		}
	}
	n--;
}

template <typename cactus>
const bool multi_treap<cactus>::lrson(const int p){
	return p==tr[tr[p].p].right;
}

template <typename cactus>
void multi_treap<cactus>::left_rotate(const int p){	
	const int rp=tr[p].right;
	const int pa=tr[p].p;
	const int rl=tr[tr[p].right].left;
	
	if(p==root){
		root=rp;
		tr[rp].p=0;
	}else{
		if(lrson(p)){
			tr[pa].right=rp;
			tr[rp].p=pa;
		}else{
			tr[pa].left=rp;
			tr[rp].p=pa;
		}
	}
	
	tr[p].p=rp;
	tr[rp].left=p;
	
	tr[p].right=rl;
	tr[rl].p=p;
	
	resize(p);
	resize(rp);
	
	tr[0].p=0;
	tr[0].left=0;
	tr[0].right=0;
}

template <typename cactus>
void multi_treap<cactus>::right_rotate(const int p){
	const int lp=tr[p].left;
	const int pa=tr[p].p;
	const int lr=tr[tr[p].left].right;
	
	if(p==root){
		root=lp;
		tr[lp].p=0;
	}else{
		if(lrson(p)){
			tr[pa].right=lp;
			tr[lp].p=pa;
		}else{
			tr[pa].left=lp;
			tr[lp].p=pa;
		}
	}
	
	tr[p].p=lp;
	tr[lp].right=p;
	
	tr[p].left=lr;
	tr[lr].p=p;
	
	resize(p);
	resize(lp);
	
	tr[0].p=0;
	tr[0].left=0;
	tr[0].right=0;
}

template <typename cactus>
void multi_treap<cactus>::zig(const int p){
	right_rotate(tr[p].p);
}

template <typename cactus>
void multi_treap<cactus>::zag(const int p){
	left_rotate(tr[p].p);
}

template <typename cactus>
const int multi_treap<cactus>::find_or_get_p(const cactus v){
	int pos=root;
	while(1){
		if(tr[pos].v>v){
			if(tr[pos].left==0){
				return pos;
			}else{
				pos=tr[pos].left;
				continue;
			}
		}else{
			if(tr[pos].v<v){
				if(tr[pos].right==0){
					return pos;
				}else{
					pos=tr[pos].right;
					continue;
				}
			}else{
				return -pos;
			}
		}
	}
}

template <typename cactus>
const cactus multi_treap<cactus>::get_max_in(const int p){
	if(tr[p].right==0){
		return tr[p].v;
	}
	return get_max_in(tr[p].right);
}

template <typename cactus>
const cactus multi_treap<cactus>::get_min_in(const int p){
	if(tr[p].left==0){
		return tr[p].v;
	}
	return get_min_in(tr[p].left);
}

template <typename cactus>
const cactus multi_treap<cactus>::max_in(void){
	return get_max_in(root);
}

template <typename cactus>
const cactus multi_treap<cactus>::min_in(void){
	return get_min_in(root);
}

template <typename cactus>
const cactus multi_treap<cactus>::pre_in(const cactus v){
	int pos=root;
	cactus res=INF;
	while(pos){
		if(v>tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].right;
		}else{
			pos=tr[pos].left;
		}
	}
	return res;
}

template <typename cactus>
const cactus multi_treap<cactus>::suc_in(const cactus v){
	int pos=root;
	cactus res=-INF;
	while(pos){
		if(v<tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].left;
		}else{
			pos=tr[pos].right;
		}
	}
	return res;
}

template <typename cactus>
void multi_treap<cactus>::init(void){
	tr[0]=multi_treap_node <cactus> (0,0,0,0,-1,0,0);
	n=0;
	root=1;
}

template <typename cactus>
void multi_treap<cactus>::insert_in(cactus v){
	if(n==0){
		tr[1]=multi_treap_node <cactus> (0,0,0,v,rand_c(),1,1);
		root=1;
		n=1;
		return;
	}
	int px=find_or_get_p(v);
	if(px<0){
		px=-px;
		tr[px].cnt++;
		while(px){
			resize(px);
			px=tr[px].p;
		}
		return;
	}
	n++;
	tr[n].p=px;
	if(tr[px].v>v){
		tr[px].left=n;
	}else{
		tr[px].right=n;
	}
	tr[n].left=0;
	tr[n].right=0;
	tr[n].v=v;
	tr[n].priority=rand_c();
	while(tr[n].p&&tr[n].priority<tr[tr[n].p].priority){
		if(lrson(n)){
			zag(n);
		}else{
			zig(n);
		}
	}
	px=n;
	while(px){
		resize(px);
		px=tr[px].p;
	}
}

template <typename cactus>
void multi_treap<cactus>::del_in(const cactus v){
	if(n==0||n==1){
		n=0;
		return;
	}
	int px=find_or_get_p(v);
	if(px>0){
		return;
	}
	px=-px;
	if(tr[px].cnt>1){
		tr[px].cnt--;
		while(px){
			resize(px);
			px=tr[px].p;
		}
		return;
	}
	while(1){
		if(tr[px].left==0){
			if(tr[px].right==0){
				int pp=px;
				tr[pp].size=0;
				if(lrson(pp)){
					tr[tr[pp].p].right=0;
				}else{
					tr[tr[pp].p].left=0;
				}
				pp=tr[pp].p;
				while(pp){
					resize(pp);
					pp=tr[pp].p;
				}
				release_empty(px);
				return;
			}else{
				left_rotate(px);
			}
		}else{
			if(tr[px].right==0){
				right_rotate(px);
			}else{
				if(tr[tr[px].left].priority<tr[tr[px].right].priority){
					right_rotate(px);
				}else{
					left_rotate(px);
				}
			}
		}
	}
}

template <typename cactus>
const int multi_treap<cactus>::rank_inline(const int p,const cactus v){
	if(tr[p].v>v){
		return rank_inline(tr[p].left,v);
	}else{
		if(tr[p].v<v){
			return rank_inline(tr[p].right,v)+tr[p].cnt+tr[tr[p].left].size;
		}else{
			return 1+tr[tr[p].left].size;
		}
	}
}

template <typename cactus>
const cactus multi_treap<cactus>::kth_in_root(const int rootx,const int kth){
	if(tr[rootx].left==0){
		if(kth<=tr[rootx].cnt){
			return tr[rootx].v;
		}
		return kth_in_root(tr[rootx].right,kth-tr[rootx].cnt);
	}else{
		if(kth>tr[tr[rootx].left].size+tr[rootx].cnt){
			return kth_in_root(tr[rootx].right,kth-tr[tr[rootx].left].size-tr[rootx].cnt);
		}else{
			if(kth<=tr[tr[rootx].left].size){
				return kth_in_root(tr[rootx].left,kth);
			}else{
				return tr[rootx].v;
			}
		}
	}
}

template <typename cactus>
const int multi_treap<cactus>::kth_in(const int kth){
	return kth_in_root(root,kth);
}

template <typename cactus>
const int multi_treap<cactus>::rank_in(const int v){
	return rank_inline(root,v);
}

template <typename cactus>
void multi_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
multi_treap<cactus>::multi_treap(void){
	init();
}

template <typename cactus>
const SIZE_C multi_treap<cactus>::size(void){
	return tr[root].size;
}

template <typename cactus>
const cactus multi_treap<cactus>::max(void){
	return max_in();
}

template <typename cactus>
const cactus multi_treap<cactus>::min(void){
	return min_in();
}

template <typename cactus>
void multi_treap<cactus>::insert(const cactus v){
	insert_in(v);
}

template <typename cactus>
void multi_treap<cactus>::del(const cactus v){
	del_in(v);
}

template <typename cactus>
const cactus multi_treap<cactus>::kth(const int kth){
	return kth_in(kth);
}

template <typename cactus>
const int multi_treap<cactus>::rank(const cactus v){
	return rank_in(v);
}

template <typename cactus>
const bool multi_treap<cactus>::find(const cactus v){
	return find_or_get_p(v)<0;
}

template <typename cactus>
const cactus multi_treap<cactus>::pre(const cactus v){
	return pre_in(v);
}

template <typename cactus>
const cactus multi_treap<cactus>::suc(const cactus v){
	return suc_in(v);
}

template <typename cactus>
void multi_treap<cactus>::print(void){
	if(n==0){
		return;
	}
	printxroot(root);
}



/*******************************************************************************/

template <typename cactus>
class single_block{
	friend class block_list<cactus>;
	private:
		cactus c[15];
		int len;
		int pre;
		int nex;
		single_block(void);
		const single_block resize(const int p);
		void connect(const single_block bk);
};

template <typename cactus>
single_block<cactus>::single_block(void){
	len=0;
	pre=-1;
	nex=-1;
}

template <typename cactus>
const single_block<cactus> single_block<cactus>::resize(const int p){//the splitted block includes p
	single_block bk;
	for(int i=p;i<len;i++){
		bk.c[bk.len]=c[i];
		bk.len++;
	}
	len=p;
	return bk;
}

template <typename cactus>
void single_block<cactus>::connect(const single_block bk){
	for(int i=0;i<bk.len;i++,len++){
		c[len]=bk.c[i];
	}
}



template <typename cactus>
class block_list{//numbers start from 0
	public:
		cactus null_block;
	private:
		int m_sz;
		single_block<cactus> b[MAXNUM];
		int n;
		int n_sz;
		int root;
		void renew_m(void);
		void release_empty(const int pos);
		void split_in(const int pos,const int in_p);
		void merge_in(const int pos1,const int pos2);
		const cactus get_pos_in(const int bk_n,const int p);
		cactus& get_value_in(int pos_n);
		void maintain_n(void);
		void point_insert_in(int pos,const cactus v);
		void point_del_in(const int pos);
	public:
		block_list(void);
		cactus& operator[](const cactus pos);
		void insert(const int pos,const cactus v);
		void del(const int pos);
		void insert(const cactus v);
		void del(void);
};

template <typename cactus>
void block_list<cactus>::renew_m(void){
	m_sz=sqrt_c(n_sz);
}

template <typename cactus>
void block_list<cactus>::release_empty(const int pos){
	if(pos==n-1){
		n--;
		return;
	}
	if(n-1==root){
		root=pos;
	}
	b[pos]=b[n-1];
	if(b[pos].nex!=-1){
		b[b[pos].nex].pre=pos;
	}
	if(b[pos].pre!=-1){
		b[b[pos].pre].nex=pos;
	}
	n--;
	return;
}

template <typename cactus>
void block_list<cactus>::split_in(const int pos,const int in_p){
	b[n]=b[pos].resize(in_p);
	b[n].nex=b[pos].nex;
	b[n].pre=pos;
	b[pos].nex=n;
	n++;
}

template <typename cactus>
void block_list<cactus>::merge_in(const int pos1,const int pos2){//pos1<pos2
	b[pos1].connect(b[pos2]);
	b[pos1].nex=b[pos2].nex;
	if(b[pos2].nex!=-1){
		b[b[pos2].nex].pre=pos1;
	}
	release_empty(pos2);
}

template <typename cactus>
const cactus block_list<cactus>::get_pos_in(const int bk_n,const int p){
	return b[bk_n].c[p];
}

template <typename cactus>
cactus& block_list<cactus>::get_value_in(int pos_n){
	if(pos_n>=n_sz||pos_n<0){
		return null_block;
	}
	int cur=root;
	while(pos_n>=b[cur].len){
		pos_n-=b[cur].len;
		cur=b[cur].nex;
	}
	return b[cur].c[pos_n];
}

template <typename cactus>
void block_list<cactus>::maintain_n(void){
	renew_m();
	for(int i=root;i!=-1;i=b[i].nex){
		if(b[i].len>m_sz){
			split_in(i,b[i].len/2);
		}else{
			if(b[i].pre==-1){
				if(b[i].nex==-1){
					return;
				}else{
					if(b[i].len+b[b[i].nex].len<=m_sz){
						merge_in(i,b[i].nex);
					}
				}
			}else{
				if(b[i].nex==-1){
					if(b[b[i].pre].len+b[i].len<=m_sz){
						merge_in(b[i].pre,i);
					}
				}else{
					if(b[i].len+b[b[i].nex].len<=m_sz){
						merge_in(i,b[i].nex);
						continue;
					}
					if(b[b[i].pre].len+b[i].len<=m_sz){
						merge_in(b[i].pre,i);
						continue;
					}
				}
			}
		}
	}
}

template <typename cactus>
void block_list<cactus>::point_insert_in(int pos,const cactus v){
	if(pos>n_sz||pos<0){
		return;
	}
	if(n_sz==0){
		root=0;
		b[0]=single_block<cactus>();
		n=1;
		n_sz=1;
		b[0].len=1;
		b[0].c[0]=v;
		return;
	}
	int bk_p=root;
	while(pos>=b[bk_p].len+1){
		pos-=b[bk_p].len;
		bk_p=b[bk_p].nex;
	}
	for(int i=b[bk_p].len;i>pos;i--){
		b[bk_p].c[i]=b[bk_p].c[i-1];
	}
	b[bk_p].c[pos]=v;
	b[bk_p].len++;
	n_sz++;
	maintain_n();
}

template <typename cactus>
void block_list<cactus>::point_del_in(const int pos){
	if(pos>=n_sz||pos<0){
		return;
	}
	int bk_p=root;
	while(pos>=b[bk_p].len+1){
		pos-=b[bk_p].len;
		bk_p=b[bk_p].nex;
	}
	if(b[bk_p].len==1){
		release_empty(bk_p);
		return;
	}
	for(int i=pos;i<b[bk_p].len;i++){
		b[bk_p].c[i]=b[bk_p].c[i+1];
	}
	b[bk_p].len--;
	maintain_n();
}

template <typename cactus>
block_list<cactus>::block_list(void){
	n=0;
	root=0;
	n_sz=0;
	m_sz=0;
}

template <typename cactus>
cactus& block_list<cactus>::operator[](const cactus pos){
	return get_value_in(pos);
}

template <typename cactus>
void block_list<cactus>::insert(const int pos,const cactus v){
	point_insert_in(pos,v);
}

template <typename cactus>
void block_list<cactus>::del(const int pos){
	point_del_in(pos);
}

template <typename cactus>
void block_list<cactus>::insert(const cactus v){
	point_insert_in(n_sz,v);
}

template <typename cactus>
void block_list<cactus>::del(void){
	point_del_in(n_sz-1);
}

/*******************************************************************************/

template <typename cactus>
class fhq_node{
	friend class fhq_treap<cactus>;
	private:
		cactus v;
		int left;
		int right;
		int size;
		int priority;
		fhq_node(int rd);
		fhq_node(void);
		fhq_node(cactus val,int l,int r,int sz,int rd);
};

template <typename cactus>
fhq_node<cactus>::fhq_node(int rd){
	v=0;
	left=0;
	right=0;
	size=0;
	priority=rd;
}

template <typename cactus>
fhq_node<cactus>::fhq_node(void){
	v=0;
	left=0;
	right=0;
	size=0;
	priority=114514;
}

template <typename cactus>
fhq_node<cactus>::fhq_node(cactus val,int l,int r,int sz,int rd){
	v=val;
	left=l;
	right=r;
	size=sz;
	priority=rd;
}



template <typename cactus>
class fhq_treap{
	private:
		fhq_node <cactus> tr[MAXN];
		int n;
		int root;
		int em[MAXN],emp;
		void init(void);
		int seed=207803;
		inline const int rand_c(void);
		void resize(const int p);
		void release_empty(const int p);
		void split_by_value(const int pos,const cactus val,int &root1,int &root2);
		void split_by_size(const int pos,const int sz,int &root1,int &root2);
		void merge_in(int &rootx,const int pos1,const int pos2);
		const bool find_p(const cactus v);
		const cactus get_max_in(const int p);
		const cactus get_min_in(const int p);
		const cactus max_in(void);
		const cactus min_in(void);
		const cactus pre_in(const cactus v);
		const cactus suc_in(const cactus v);
		const int rank_inline(const int p,const cactus v);
		const cactus kth_in_root(const int rootx,const int kth);
		const cactus kth_in(const int kth);
		const int rank_in(const cactus v);
		void printxroot(int p);
		void insert_in(const cactus v);
		void del_in(const cactus v);
	public:
		fhq_treap(void);
		const SIZE_C size(void);
		void insert(const cactus v);
		void del(const cactus v);
		const cactus max(void);
		const cactus min(void);
		const bool find(const cactus v);
		const cactus pre(const cactus v);
		const cactus suc(const cactus v);
		const int rank(const cactus v);
		const cactus kth(const int k);
};

template <typename cactus>
void fhq_treap<cactus>::init(void){
	n=0;
	root=0;
	emp=0;
}

template <typename cactus>
inline const int fhq_treap<cactus>::rand_c(void){
    return seed=(int)((seed*4827153LL+114514)%2147483647);
}

template <typename cactus>
void fhq_treap<cactus>::resize(const int p){
	tr[0].size=0;
	tr[p].size=tr[tr[p].left].size+tr[tr[p].right].size+1;
}

template <typename cactus>
void fhq_treap<cactus>::release_empty(const int p){
	em[emp]=p;
	emp++;
}

template <typename cactus>
void fhq_treap<cactus>::split_by_value(const int pos,const cactus val,int &root1,int &root2){
	if(pos==0){
		root1=0;
		root2=0;
		return;
	}
	if(tr[pos].v>val){
		root2=pos;
		split_by_value(tr[pos].left,val,root1,tr[root2].left);
	}else{
		root1=pos;
		split_by_value(tr[pos].right,val,tr[root1].right,root2);
	}
	resize(pos);
}

template <typename cactus>
void fhq_treap<cactus>::split_by_size(const int pos,const int sz,int &root1,int &root2){
	if(pos==0){
		root1=0;
		root2=0;
		return;
	}
	if(tr[pos].v>sz){
		root2=pos;
		split_by_size(pos,sz,root1,tr[root2].left);
	}else{
		root1=pos;
		split_by_size(pos,sz-tr[tr[pos].left].size-1,tr[root1].left,root2);
	}
	resize(pos);
}

template <typename cactus>
void fhq_treap<cactus>::merge_in(int &rootx,const int pos1,const int pos2){//pos1<pos2
	if(pos1==0||pos2==0){
		rootx=pos1+pos2;
		return;
	}
	if(tr[pos1].priority<tr[pos2].priority){
		rootx=pos1;
		merge_in(tr[rootx].right,tr[pos1].right,pos2);
		resize(rootx);
	}else{
		rootx=pos2;
		merge_in(tr[rootx].left,pos1,tr[pos2].left);
		resize(rootx);
	}
}

template <typename cactus>
const bool fhq_treap<cactus>::find_p(const cactus v){//returns 0-pos if found and parent if not
	int pos=root;
	while(1){
		if(tr[pos].v>v){
			if(tr[pos].left==0){
				return 0;
			}else{
				pos=tr[pos].left;
				continue;
			}
		}else{
			if(tr[pos].v<v){
				if(tr[pos].right==0){
					return 0;
				}else{
					pos=tr[pos].right;
					continue;
				}
			}else{
				return 1;
			}
		}
	}
}

template <typename cactus>
const cactus fhq_treap<cactus>::get_max_in(const int p){
	if(tr[p].right==0){
		return tr[p].v;
	}
	return get_max_in(tr[p].right);
}

template <typename cactus>
const cactus fhq_treap<cactus>::get_min_in(const int p){
	if(tr[p].left==0){
		return tr[p].v;
	}
	return get_min_in(tr[p].left);
}

template <typename cactus>
const cactus fhq_treap<cactus>::max_in(void){
	return get_max_in(root);
}

template <typename cactus>
const cactus fhq_treap<cactus>::min_in(void){
	return get_min_in(root);
}

template <typename cactus>
const cactus fhq_treap<cactus>::pre_in(const cactus v){
	int pos=root;
	cactus res=INF;
	while(pos){
		if(v>tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].right;
		}else{
			pos=tr[pos].left;
		}
	}
	return res;
}

template <typename cactus>
const cactus fhq_treap<cactus>::suc_in(const cactus v){
	int pos=root;
	cactus res=-INF;
	while(pos){
		if(v<tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].left;
		}else{
			pos=tr[pos].right;
		}
	}
	return res;
}

template <typename cactus>
const int fhq_treap<cactus>::rank_inline(const int p,const cactus v){
	if(tr[p].v>v){
		return rank_inline(tr[p].left,v);
	}else{
		if(tr[p].v<v){
			return rank_inline(tr[p].right,v)+1+tr[tr[p].left].size;
		}else{
			return 1+tr[tr[p].left].size;
		}
	}
}

template <typename cactus>
const cactus fhq_treap<cactus>::kth_in_root(const int rootx,const int kth){
	if(tr[rootx].size==1){
		return tr[rootx].v;
	}
	if(tr[rootx].left==0){
		if(kth==1){
			return tr[rootx].v;
		}
		return kth_in_root(tr[rootx].right,kth-1);
	}else{
		if(kth>tr[tr[rootx].left].size+1){
			return kth_in_root(tr[rootx].right,kth-tr[tr[rootx].left].size-1);
		}else{
			if(kth==tr[tr[rootx].left].size+1){
				return tr[rootx].v;
			}else{
				return kth_in_root(tr[rootx].left,kth);
			}
		}
	}
}

template <typename cactus>
const cactus fhq_treap<cactus>::kth_in(const int kth){
	return kth_in_root(root,kth);
}

template <typename cactus>
const int fhq_treap<cactus>::rank_in(const cactus v){
	return rank_inline(root,v);
}

template <typename cactus>
void fhq_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
void fhq_treap<cactus>::insert_in(const cactus v){
	int r1,r2;
	if(find_p(v)){
		return;
	}
	split_by_value(root,v,r1,r2);
	if(emp){
		emp--;
		tr[em[emp]]=fhq_node <cactus> (v,0,0,1,rand_c());
		int x;
		merge_in(x,r1,em[emp]);
		merge_in(root,x,r2);
	}else{
		n++;
		tr[n]=fhq_node <cactus> (v,0,0,1,rand_c());
		int x;
		merge_in(x,r1,n);
		merge_in(root,x,r2);	
	}
}

template <typename cactus>
void fhq_treap<cactus>::del_in(const cactus v){
	if(find_p(v)){
		int r1,rv,r2;
		split_by_value(root,v-1,r1,rv);
		split_by_value(rv,v,rv,r2);
		release_empty(rv);
		merge_in(root,r1,r2);
	}else{
		return;
	}
}

template <typename cactus>
fhq_treap<cactus>::fhq_treap(void){
	init();
}

template <typename cactus>
const SIZE_C fhq_treap<cactus>::size(void){
	return tr[root].size;
}

template <typename cactus>
void fhq_treap<cactus>::insert(const cactus v){
	insert_in(v);
}

template <typename cactus>
void fhq_treap<cactus>::del(const cactus v){
	del_in(v);
}

template <typename cactus>
const cactus fhq_treap<cactus>::max(void){
	return max_in();
}

template <typename cactus>
const cactus fhq_treap<cactus>::min(void){
	return min_in();
}

template <typename cactus>
const bool fhq_treap<cactus>::find(const cactus v){
	return find_p(v);
}

template <typename cactus>
const cactus fhq_treap<cactus>::pre(const cactus v){
	return pre_in(v);
}

template <typename cactus>
const cactus fhq_treap<cactus>::suc(const cactus v){
	return suc_in(v);
}

template <typename cactus>
const int fhq_treap<cactus>::rank(const cactus v){
	return rank_in(v);
}

template <typename cactus>
const cactus fhq_treap<cactus>::kth(const int k){
	return kth_in(k);
}

/*******************************************************************************/

template <typename cactus>
class multi_fhq_node{
	friend class multi_fhq_treap<cactus>;
	private:
		cactus v;
		int left;
		int right;
		int size;
		int cnt;
		int priority;
		multi_fhq_node(int rd);
		multi_fhq_node(void);
		multi_fhq_node(cactus val,int l,int r,int sz,int rd,int tot);
};

template <typename cactus>
multi_fhq_node<cactus>::multi_fhq_node(int rd){
	cnt=1;
	v=0;
	left=0;
	right=0;
	size=1;
	priority=rd;
}

template <typename cactus>
multi_fhq_node<cactus>::multi_fhq_node(void){
	cnt=1;
	v=0;
	left=0;
	right=0;
	size=1;
	priority=114514;
}

template <typename cactus>
multi_fhq_node<cactus>::multi_fhq_node(cactus val,int l,int r,int sz,int rd,int tot){
	v=val;
	left=l;
	right=r;
	size=sz;
	priority=rd;
	cnt=tot;
}



template <typename cactus>
class multi_fhq_treap{
	private:
		multi_fhq_node <cactus> tr[MAXN];
		int n;
		int root;
		int em[MAXN],emp;
		void init(void);
		int seed=70803;
		inline const int rand_c(void);
		void resize(const int p);
		void release_empty(const int p);
		void split_by_value(const int pos,const cactus val,int &root1,int &root2);
		void split_by_size(const int pos,const int sz,int &root1,int &root2);
		void merge_in(int &rootx,const int pos1,const int pos2);
		const int find_p(const cactus v);
		void find_and_add(const cactus v);
		void find_and_minus(const cactus v);
		const cactus get_max_in(const int p);
		const cactus get_min_in(const int p);
		const cactus max_in(void);
		const cactus min_in(void);
		const cactus pre_in(const cactus v);
		const cactus suc_in(const cactus v);	
		const int rank_inline(const int p,const cactus v);
		const cactus kth_in_root(const int rootx,const int kth);
		const cactus kth_in(const int kth);
		const int rank_in(const cactus v);
		void printxroot(int p);
		void insert_in(const cactus v);
		void del_in(const cactus v);
	public:
		multi_fhq_treap(void);
		void insert(const cactus v);
		void del(const cactus v);
		const cactus max(void);
		const cactus min(void);
		const bool find(const cactus v);
		const cactus pre(const cactus v);
		const cactus suc(const cactus v);
		const int rank(const cactus v);
		const cactus kth(const int k);
};

template <typename cactus>
void multi_fhq_treap<cactus>::init(void){
	n=0;
	root=0;
	emp=0;
}

template <typename cactus>
inline const int multi_fhq_treap<cactus>::rand_c(void){
    return seed=(int)((seed*4827153LL+114514)%2147483647);
}

template <typename cactus>
void multi_fhq_treap<cactus>::resize(const int p){
	tr[0].size=0;
	tr[p].size=tr[tr[p].left].size+tr[tr[p].right].size+tr[p].cnt;
}

template <typename cactus>
void multi_fhq_treap<cactus>::release_empty(const int p){
	em[emp]=p;
	emp++;
}

template <typename cactus>
void multi_fhq_treap<cactus>::split_by_value(const int pos,const cactus val,int &root1,int &root2){
	if(pos==0){
		root1=0;
		root2=0;
		return;
	}
	if(tr[pos].v>val){
		root2=pos;
		split_by_value(tr[pos].left,val,root1,tr[root2].left);
	}else{
		root1=pos;
		split_by_value(tr[pos].right,val,tr[root1].right,root2);
	}
	resize(pos);
}

template <typename cactus>
void multi_fhq_treap<cactus>::split_by_size(const int pos,const int sz,int &root1,int &root2){
	if(pos==0){
		root1=0;
		root2=0;
		return;
	}
	if(tr[pos].size>sz){
		root2=pos;
		split_by_size(pos,sz,root1,tr[root2].left);
	}else{
		root1=pos;
		split_by_size(pos,sz-tr[tr[pos].left].size-1,tr[root1].left,root2);
	}
	resize(pos);
}

template <typename cactus>
void multi_fhq_treap<cactus>::merge_in(int &rootx,const int pos1,const int pos2){//pos1<pos2
	if(pos1==0||pos2==0){
		rootx=pos1+pos2;
		return;
	}
	if(tr[pos1].priority<tr[pos2].priority){
		rootx=pos1;
		merge_in(tr[rootx].right,tr[pos1].right,pos2);
		resize(rootx);
	}else{
		rootx=pos2;
		merge_in(tr[rootx].left,pos1,tr[pos2].left);
		resize(rootx);
	}
}

template <typename cactus>
const int multi_fhq_treap<cactus>::find_p(const cactus v){
	int pos=root;
	while(1){
		if(tr[pos].v>v){
			if(tr[pos].left==0){
				return 0;
			}else{
				pos=tr[pos].left;
				continue;
			}
		}else{
			if(tr[pos].v<v){
				if(tr[pos].right==0){
					return 0;
				}else{
					pos=tr[pos].right;
					continue;
				}
			}else{
				return pos;
			}
		}
	}
}

template <typename cactus>
void multi_fhq_treap<cactus>::find_and_add(const cactus v){
	int pos=root;
	while(1){
		tr[pos].size++;
		if(tr[pos].v>v){
			if(tr[pos].left==0){
				return;
			}else{
				pos=tr[pos].left;
				continue;
			}
		}else{
			if(tr[pos].v<v){
				if(tr[pos].right==0){
					return;
				}else{
					pos=tr[pos].right;
					continue;
				}
			}else{
				return;
			}
		}
	}
}

template <typename cactus>
void multi_fhq_treap<cactus>::find_and_minus(const cactus v){
	int pos=root;
	while(1){
		tr[pos].size--;
		if(tr[pos].v>v){
			if(tr[pos].left==0){
				return;
			}else{
				pos=tr[pos].left;
				continue;
			}
		}else{
			if(tr[pos].v<v){
				if(tr[pos].right==0){
					return;
				}else{
					pos=tr[pos].right;
					continue;
				}
			}else{
				return;
			}
		}
	}
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::get_max_in(const int p){
	if(tr[p].right==0){
		return tr[p].v;
	}
	return get_max_in(tr[p].right);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::get_min_in(const int p){
	if(tr[p].left==0){
		return tr[p].v;
	}
	return get_min_in(tr[p].left);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::max_in(void){
	return get_max_in(root);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::min_in(void){
	return get_min_in(root);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::pre_in(const cactus v){
	int pos=root;
	cactus res=INF;
	while(pos){
		if(v>tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].right;
		}else{
			pos=tr[pos].left;
		}
	}
	return res;
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::suc_in(const cactus v){
	int pos=root;
	cactus res=-INF;
	while(pos){
		if(v<tr[pos].v){
			res=tr[pos].v;
			pos=tr[pos].left;
		}else{
			pos=tr[pos].right;
		}
	}
	return res;
}

template <typename cactus>
const int multi_fhq_treap<cactus>::rank_inline(const int p,const cactus v){
	tr[0].size=0;
	if(tr[p].v>v){
		return rank_inline(tr[p].left,v);
	}else{
		if(tr[p].v<v){
			return rank_inline(tr[p].right,v)+tr[p].cnt+tr[tr[p].left].size;
		}else{
			return 1+tr[tr[p].left].size;
		}
	}
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::kth_in_root(const int rootx,const int kth){
	if(tr[rootx].left==0){
		if(kth<=tr[rootx].cnt){
			return tr[rootx].v;
		}
		return kth_in_root(tr[rootx].right,kth-tr[rootx].cnt);
	}else{
		if(kth>tr[tr[rootx].left].size+tr[rootx].cnt){
			return kth_in_root(tr[rootx].right,kth-tr[tr[rootx].left].size-tr[rootx].cnt);
		}else{
			if(kth<=tr[tr[rootx].left].size){
				return kth_in_root(tr[rootx].left,kth);
			}else{
				return tr[rootx].v;
			}
		}
	}
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::kth_in(const int kth){
	return kth_in_root(root,kth);
}

template <typename cactus>
const int multi_fhq_treap<cactus>::rank_in(const cactus v){
	return rank_inline(root,v);
}

template <typename cactus>
void multi_fhq_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
void multi_fhq_treap<cactus>::insert_in(const cactus v){
	if(n==0){
		tr[0]=multi_fhq_node <cactus> (0,0,0,0,-1,0);
		tr[1]=multi_fhq_node <cactus> (v,0,0,1,rand_c(),1);
		n=1;
		root=1;
		return;
	}
	int r1,r2;
	int k;
	if(k=find_p(v)){
		tr[k].cnt++;
		find_and_add(v);
		return;
	}
	split_by_value(root,v,r1,r2);
	if(emp){
		emp--;
		tr[em[emp]]=multi_fhq_node <cactus> (v,0,0,1,rand_c(),1);
		int x;
		merge_in(x,r1,em[emp]);
		merge_in(root,x,r2);
	}else{
		n++;
		tr[n]=multi_fhq_node <cactus> (v,0,0,1,rand_c(),1);
		int x;
		merge_in(x,r1,n);
		merge_in(root,x,r2);	
	}
}

template <typename cactus>
void multi_fhq_treap<cactus>::del_in(const cactus v){
	if(n==0||n==1){
		n=0;
		return;
	}
	int k;
	if(k=find_p(v)){
		if(tr[k].cnt>1){
			tr[k].cnt--;
			find_and_minus(v);
			return;
		}
		int r1,rv,r2;
		split_by_value(root,v-1,r1,rv);
		split_by_value(rv,v,rv,r2);
		release_empty(rv);
		merge_in(root,r1,r2);
	}else{
		return;
	}
}

template <typename cactus>
multi_fhq_treap<cactus>::multi_fhq_treap(void){
	init();
}

template <typename cactus>
void multi_fhq_treap<cactus>::insert(const cactus v){
	insert_in(v);
}

template <typename cactus>
void multi_fhq_treap<cactus>::del(const cactus v){
	del_in(v);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::max(void){
	return max_in();
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::min(void){
	return min_in();
}

template <typename cactus>
const bool multi_fhq_treap<cactus>::find(const cactus v){
	return find_p(v);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::pre(const cactus v){
	return pre_in(v);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::suc(const cactus v){
	return suc_in(v);
}

template <typename cactus>
const int multi_fhq_treap<cactus>::rank(const cactus v){
	return rank_in(v);
}

template <typename cactus>
const cactus multi_fhq_treap<cactus>::kth(const int k){
	return kth_in(k);
}

/*******************************************************************************/

template <typename cactus>
class persistent_node{
	friend class max_persistent_segment_tree <cactus>;
	friend class min_persistent_segment_tree <cactus>;
	friend class sum_persistent_segment_tree <cactus>;
	private:
		int left;
		int right;
		cactus v;
		persistent_node(void);
		persistent_node(const int l,const int r,const cactus val);
};

template <typename cactus>
persistent_node<cactus>::persistent_node(void){
	left=-1;
	right=-1;
}

template <typename cactus>
persistent_node<cactus>::persistent_node(const int l,const int r,const cactus val){
	left=l;
	right=r;
	v=val;
}



template <typename cactus>
class max_persistent_segment_tree{
	private:
		persistent_node <cactus> tr[MAXN];
		int n;
		int root[MAXNUM];
		int len;
		cactus a[MAXNUM];
		int num;
		const int new_node(void);
		const int new_node(const cactus val);
		const int new_node(const int l,const int r,const int val);
		void build_in_a(const int l,const int r,const int p);
		void build_by_a(void);
		void build_in_empty(const int l,const int r,const int p);
		void build_empty(void);
		void init_empty(const int sz);
		void init(cactus *p1,cactus *p2);
		void add_linear_in(const int pre,const int k,const int l,const int r,const int p,const cactus val);
		void add_linear(const int pre_root,const int p,const cactus val);
		const cactus point_query_in(const int rootx,const int l,const int r,const int p);
		const cactus range_query_in(const int rootx,const int l,const int r,const int pl,const int pr);
		void add_in(const int p,const cactus val,const int version);
		void simple_add_in(const int p,const cactus val);
		const cactus find_in(const int p,const int version);
		const cactus simple_find_in(const int p);
		const cactus max_in(const int pl,const int pr,const int version);
		const cactus simple_max_in(const int pl,const int pr);
	public:
		max_persistent_segment_tree(void);
		max_persistent_segment_tree(const int size);
		max_persistent_segment_tree(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		const SIZE_C versions(void);
		void add(const int p,const cactus value,const int version);
		void simple_add(const int p,const cactus value);
		void replace(const int p,const cactus val,const int version);
		void simple_replace(const int p,const cactus val);
		const cactus find(const int p,const int version);
		const cactus simple_find(const int p);
		const cactus max(const int pl,const int pr,const int version);
		const cactus simple_max(const int pl,const int pr);
		void version_copy(const int version);
		void simple_version_copy(void);
};

template <typename cactus>
const int max_persistent_segment_tree<cactus>::new_node(void){
	n++;
	return n-1;
}

template <typename cactus>
const int max_persistent_segment_tree<cactus>::new_node(const cactus val){
	tr[n]=persistent_node <cactus> (-1,-1,val);
	n++;
	return n-1;
}

template <typename cactus>
const int max_persistent_segment_tree<cactus>::new_node(const int l,const int r,const int val){
	tr[n]=persistent_node <cactus> (l,r,val);
	n++;
	return n-1;
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::build_in_a(const int l,const int r,const int p){
	if(l==r){
		tr[p].v=a[l];
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	build_in_a(l,mid,tr[p].left);
	build_in_a(mid+1,r,tr[p].right);
	tr[p].v=tr[tr[p].left].v>tr[tr[p].right].v?tr[tr[p].left].v:tr[tr[p].right].v;
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::build_by_a(void){
	n=1;
	len=1;
	root[0]=0;
	build_in_a(1,num,0);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::build_in_empty(const int l,const int r,const int p){
	if(l==r){
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	build_in_empty(l,mid,tr[p].left);
	build_in_empty(mid+1,r,tr[p].right);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::build_empty(void){
	n=1;
	len=1;
	root[0]=0;
	build_in_empty(1,num,0);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::init_empty(const int sz){
	num=sz;
	build_empty();
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::init(cactus *p1,cactus *p2){
	num=p2-p1;
	for(int i=1;i<=num;i++){
		a[i]=*p1;
		p1++;
	}
	build_by_a();
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::add_linear_in(const int pre,const int k,const int l,const int r,const int p,const cactus val){
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		tr[k].left=tr[pre].left;
		tr[k].right=new_node(tr[tr[pre].right].v>val?tr[tr[pre].right].v:val);
		add_linear_in(tr[pre].right,tr[k].right,mid+1,r,p,val);
	}else{
		tr[k].right=tr[pre].right;
		tr[k].left=new_node(tr[tr[pre].left].v>val?tr[tr[pre].left].v:val);
		add_linear_in(tr[pre].left,tr[k].left,l,mid,p,val);
	}
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::add_linear(const int pre_root,const int p,const cactus val){
	root[len]=new_node(tr[pre_root].v>val?tr[pre_root].v:val);
	add_linear_in(pre_root,root[len],1,num,p,val);
	len++;
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::point_query_in(const int rootx,const int l,const int r,const int p){
	if(l==r){
		return tr[rootx].v;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		return point_query_in(tr[rootx].right,mid+1,r,p);
	}else{
		return point_query_in(tr[rootx].left,l,mid,p);
	}
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::range_query_in(const int rootx,const int l,const int r,const int pl,const int pr){
	if(inrange(pl,pr,l,r)){
		return tr[rootx].v;
	}
	if(outofrange(pl,pr,l,r)){
		return 0;
	}
	int mid=(l+r)>>1;
	int ml=range_query_in(tr[rootx].left,l,mid,pl,pr);
	int mr=range_query_in(tr[rootx].right,mid+1,r,pl,pr);
	return ml>mr?ml:mr;
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::add_in(const int p,const cactus val,const int version){
	add_linear(root[version],p,val);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::simple_add_in(const int p,const cactus val){
	add_linear(root[len-1],p,val);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::find_in(const int p,const int version){
	return point_query_in(root[version],1,num,p);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::simple_find_in(const int p){
	return point_query_in(root[len-1],1,num,p);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::max_in(const int pl,const int pr,const int version){
	return range_query_in(root[version],1,num,pl,pr);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::simple_max_in(const int pl,const int pr){
	return range_query_in(root[len-1],1,num,pl,pr);
}

template <typename cactus>
max_persistent_segment_tree<cactus>::max_persistent_segment_tree(void){
	init_empty(MAXNUM);
}

template <typename cactus>
max_persistent_segment_tree<cactus>::max_persistent_segment_tree(const int size){
	init_empty(size);
}

template <typename cactus>
max_persistent_segment_tree<cactus>::max_persistent_segment_tree(cactus *p1,cactus *p2){
	init(p1,p2);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::add(const int p,const cactus value,const int version){
	add_in(p,value,version);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::simple_add(const int p,const cactus value){
	simple_add_in(p,value);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::replace(const int p,const cactus val,const int version){
	add_in(p,val-find_in(p,version),version);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::simple_replace(const int p,const cactus val){
	simpe_add_in(p,val-simple_find_in(p));
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::find(const int p,const int version){
	return find_in(p,version);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::simple_find(const int p){
	return simple_find_in(p);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::max(const int pl,const int pr,const int version){
	return max_in(pl,pr,version);
}

template <typename cactus>
const cactus max_persistent_segment_tree<cactus>::simple_max(const int pl,const int pr){
	return simple_max_in(pl,pr);
}

template <typename cactus>
const SIZE_C max_persistent_segment_tree<cactus>::size(void){
	return num;
}

template <typename cactus>
const SIZE_C max_persistent_segment_tree<cactus>::versions(void){
	return len;
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::version_copy(const int version){
	add_in(1,0,version);
}

template <typename cactus>
void max_persistent_segment_tree<cactus>::simple_version_copy(void){
	add_in(1,0,len-1);
}


template <typename cactus>
class min_persistent_segment_tree{
	private:
		persistent_node <cactus> tr[MAXN];
		int n;
		int root[MAXNUM];
		int len;
		cactus a[MAXNUM];
		int num;
		const int new_node(void);
		const int new_node(const cactus val);
		const int new_node(const int l,const int r,const int val);
		void build_in_a(const int l,const int r,const int p);
		void build_by_a(void);
		void build_in_empty(const int l,const int r,const int p);
		void build_empty(void);
		void init_empty(const int sz);
		void init(cactus *p1,cactus *p2);
		void add_linear_in(const int pre,const int k,const int l,const int r,const int p,const cactus val);
		void add_linear(const int pre_root,const int p,const cactus val);
		const cactus point_query_in(const int rootx,const int l,const int r,const int p);
		const cactus range_query_in(const int rootx,const int l,const int r,const int pl,const int pr);
		void add_in(const int p,const cactus val,const int version);
		void simple_add_in(const int p,const cactus val);
		const cactus find_in(const int p,const int version);
		const cactus simple_find_in(const int p);
		const cactus min_in(const int pl,const int pr,const int version);
		const cactus simple_min_in(const int pl,const int pr);
	public:
		min_persistent_segment_tree(void);
		min_persistent_segment_tree(const int size);
		min_persistent_segment_tree(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		const SIZE_C versions(void);
		void add(const int p,const cactus value,const int version);
		void simple_add(const int p,const cactus value);
		void replace(const int p,const cactus val,const int version);
		void simple_replace(const int p,const cactus val);
		const cactus find(const int p,const int version);
		const cactus simple_find(const int p);
		const cactus min(const int pl,const int pr,const int version);
		const cactus simple_min(const int pl,const int pr);
		void version_copy(const int version);
		void simple_version_copy(void);
};

template <typename cactus>
const int min_persistent_segment_tree<cactus>::new_node(void){
	n++;
	return n-1;
}

template <typename cactus>
const int min_persistent_segment_tree<cactus>::new_node(const cactus val){
	tr[n]=persistent_node <cactus> (-1,-1,val);
	n++;
	return n-1;
}

template <typename cactus>
const int min_persistent_segment_tree<cactus>::new_node(const int l,const int r,const int val){
	tr[n]=persistent_node <cactus> (l,r,val);
	n++;
	return n-1;
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::build_in_a(const int l,const int r,const int p){
	if(l==r){
		tr[p].v=a[l];
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	build_in_a(l,mid,tr[p].left);
	build_in_a(mid+1,r,tr[p].right);
	tr[p].v=tr[tr[p].left].v<tr[tr[p].right].v?tr[tr[p].left].v:tr[tr[p].right].v;
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::build_by_a(void){
	n=1;
	len=1;
	root[0]=0;
	build_in_a(1,num,0);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::build_in_empty(const int l,const int r,const int p){
	if(l==r){
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	build_in_empty(l,mid,tr[p].left);
	build_in_empty(mid+1,r,tr[p].right);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::build_empty(void){
	n=1;
	len=1;
	root[0]=0;
	build_in_empty(1,num,0);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::init_empty(const int sz){
	num=sz;
	build_empty();
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::init(cactus *p1,cactus *p2){
	num=p2-p1;
	for(int i=1;i<=num;i++){
		a[i]=*p1;
		p1++;
	}
	build_by_a();
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::add_linear_in(const int pre,const int k,const int l,const int r,const int p,const cactus val){
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		tr[k].left=tr[pre].left;
		tr[k].right=new_node(tr[tr[pre].right].v<val?tr[tr[pre].right].v:val);
		add_linear_in(tr[pre].right,tr[k].right,mid+1,r,p,val);
	}else{
		tr[k].right=tr[pre].right;
		tr[k].left=new_node(tr[tr[pre].left].v<val?tr[tr[pre].left].v:val);
		add_linear_in(tr[pre].left,tr[k].left,l,mid,p,val);
	}
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::add_linear(const int pre_root,const int p,const cactus val){
	root[len]=new_node(tr[pre_root].v>val?tr[pre_root].v:val);
	add_linear_in(pre_root,root[len],1,num,p,val);
	len++;
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::point_query_in(const int rootx,const int l,const int r,const int p){
	if(l==r){
		return tr[rootx].v;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		return point_query_in(tr[rootx].right,mid+1,r,p);
	}else{
		return point_query_in(tr[rootx].left,l,mid,p);
	}
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::range_query_in(const int rootx,const int l,const int r,const int pl,const int pr){
	if(inrange(pl,pr,l,r)){
		return tr[rootx].v;
	}
	if(outofrange(pl,pr,l,r)){
		return 0;
	}
	int mid=(l+r)>>1;
	int ml=range_query_in(tr[rootx].left,l,mid,pl,pr);
	int mr=range_query_in(tr[rootx].right,mid+1,r,pl,pr);
	return ml<mr?ml:mr;
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::add_in(const int p,const cactus val,const int version){
	add_linear(root[version],p,val);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::simple_add_in(const int p,const cactus val){
	add_linear(root[len-1],p,val);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::find_in(const int p,const int version){
	return point_query_in(root[version],1,num,p);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::simple_find_in(const int p){
	return point_query_in(root[len-1],1,num,p);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::min_in(const int pl,const int pr,const int version){
	return range_query_in(root[version],1,num,pl,pr);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::simple_min_in(const int pl,const int pr){
	return range_query_in(root[len-1],1,num,pl,pr);
}

template <typename cactus>
min_persistent_segment_tree<cactus>::min_persistent_segment_tree(void){
	init_empty(MAXNUM);
}

template <typename cactus>
min_persistent_segment_tree<cactus>::min_persistent_segment_tree(const int size){
	init_empty(size);
}

template <typename cactus>
min_persistent_segment_tree<cactus>::min_persistent_segment_tree(cactus *p1,cactus *p2){
	init(p1,p2);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::add(const int p,const cactus value,const int version){
	add_in(p,value,version);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::simple_add(const int p,const cactus value){
	simple_add_in(p,value);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::replace(const int p,const cactus val,const int version){
	add_in(p,val-find_in(p,version),version);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::simple_replace(const int p,const cactus val){
	simpe_add_in(p,val-simple_find_in(p));
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::find(const int p,const int version){
	return find_in(p,version);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::simple_find(const int p){
	return simple_find_in(p);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::min(const int pl,const int pr,const int version){
	return min_in(pl,pr,version);
}

template <typename cactus>
const cactus min_persistent_segment_tree<cactus>::simple_min(const int pl,const int pr){
	return simple_min_in(pl,pr);
}

template <typename cactus>
const SIZE_C min_persistent_segment_tree<cactus>::size(void){
	return num;
}

template <typename cactus>
const SIZE_C min_persistent_segment_tree<cactus>::versions(void){
	return len;
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::version_copy(const int version){
	add_in(1,0,version);
}

template <typename cactus>
void min_persistent_segment_tree<cactus>::simple_version_copy(void){
	add_in(1,0,len-1);
}



template <typename cactus>
class sum_persistent_segment_tree{
	private:
		persistent_node <cactus> tr[MAXN];
		int n;
		int root[MAXNUM];
		int len;
		cactus a[MAXNUM];
		int num;
		const int new_node(void);
		const int new_node(const cactus val);
		const int new_node(const int l,const int r,const int val);
		void build_in_a(const int l,const int r,const int p);
		void build_by_a(void);
		void build_in_empty(const int l,const int r,const int p);
		void build_empty(void);
		void init_empty(const int sz);
		void init(cactus *p1,cactus *p2);
		void add_linear_in(const int pre,const int k,const int l,const int r,const int p,const cactus val);
		void add_linear(const int pre_root,const int p,const cactus val);
		const cactus point_query_in(const int rootx,const int l,const int r,const int p);
		const cactus range_query_in(const int rootx,const int l,const int r,const int pl,const int pr);
		void add_in(const int p,const cactus val,const int version);
		void simple_add_in(const int p,const cactus val);
		const cactus find_in(const int p,const int version);
		const cactus simple_find_in(const int p);
		const cactus sum_in(const int pl,const int pr,const int version);
		const cactus simple_sum_in(const int pl,const int pr);
	public:
		sum_persistent_segment_tree(void);
		sum_persistent_segment_tree(const int size);
		sum_persistent_segment_tree(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		const SIZE_C versions(void);
		void add(const int p,const cactus value,const int version);
		void simple_add(const int p,const cactus value);
		void replace(const int p,const cactus val,const int version);
		void simple_replace(const int p,const cactus val);
		const cactus find(const int p,const int version);
		const cactus simple_find(const int p);
		const cactus sum(const int pl,const int pr,const int version);
		const cactus simple_sum(const int pl,const int pr);
		void version_copy(const int version);
		void simple_version_copy(void);
};

template <typename cactus>
const int sum_persistent_segment_tree<cactus>::new_node(void){
	n++;
	return n-1;
}

template <typename cactus>
const int sum_persistent_segment_tree<cactus>::new_node(const cactus val){
	tr[n]=persistent_node <cactus> (-1,-1,val);
	n++;
	return n-1;
}

template <typename cactus>
const int sum_persistent_segment_tree<cactus>::new_node(const int l,const int r,const int val){
	tr[n]=persistent_node <cactus> (l,r,val);
	n++;
	return n-1;
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::build_in_a(const int l,const int r,const int p){
	if(l==r){
		tr[p].v=a[l];
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	build_in_a(l,mid,tr[p].left);
	build_in_a(mid+1,r,tr[p].right);
	tr[p].v=tr[tr[p].left].v+tr[tr[p].right].v;
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::build_by_a(void){
	n=1;
	len=1;
	root[0]=0;
	build_in_a(1,num,0);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::build_in_empty(const int l,const int r,const int p){
	if(l==r){
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	build_in_empty(l,mid,tr[p].left);
	build_in_empty(mid+1,r,tr[p].right);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::build_empty(void){
	n=1;
	len=1;
	root[0]=0;
	build_in_empty(1,num,0);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::init_empty(const int sz){
	num=sz;
	build_empty();
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::init(cactus *p1,cactus *p2){
	num=p2-p1;
	for(int i=1;i<=num;i++){
		a[i]=*p1;
		p1++;
	}
	build_by_a();
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::add_linear_in(const int pre,const int k,const int l,const int r,const int p,const cactus val){
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		tr[k].left=tr[pre].left;
		tr[k].right=new_node(tr[tr[pre].right].v+val);
		add_linear_in(tr[pre].right,tr[k].right,mid+1,r,p,val);
	}else{
		tr[k].right=tr[pre].right;
		tr[k].left=new_node(tr[tr[pre].left].v+val);
		add_linear_in(tr[pre].left,tr[k].left,l,mid,p,val);
	}
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::add_linear(const int pre_root,const int p,const cactus val){
	root[len]=new_node(tr[pre_root].v+val);
	add_linear_in(pre_root,root[len],1,num,p,val);
	len++;
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::point_query_in(const int rootx,const int l,const int r,const int p){
	if(l==r){
		return tr[rootx].v;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		return point_query_in(tr[rootx].right,mid+1,r,p);
	}else{
		return point_query_in(tr[rootx].left,l,mid,p);
	}
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::range_query_in(const int rootx,const int l,const int r,const int pl,const int pr){
	if(inrange(pl,pr,l,r)){
		return tr[rootx].v;
	}
	if(outofrange(pl,pr,l,r)){
		return 0;
	}
	int mid=(l+r)>>1;
	return range_query_in(tr[rootx].left,l,mid,pl,pr)+range_query_in(tr[rootx].right,mid+1,r,pl,pr);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::add_in(const int p,const cactus val,const int version){
	add_linear(root[version],p,val);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::simple_add_in(const int p,const cactus val){
	add_linear(root[len-1],p,val);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::find_in(const int p,const int version){
	return point_query_in(root[version],1,num,p);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::simple_find_in(const int p){
	return point_query_in(root[len-1],1,num,p);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::sum_in(const int pl,const int pr,const int version){
	return range_query_in(root[version],1,num,pl,pr);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::simple_sum_in(const int pl,const int pr){
	return range_query_in(root[len-1],1,num,pl,pr);
}

template <typename cactus>
sum_persistent_segment_tree<cactus>::sum_persistent_segment_tree(void){
	init_empty(MAXNUM);
}

template <typename cactus>
sum_persistent_segment_tree<cactus>::sum_persistent_segment_tree(const int size){
	init_empty(size);
}

template <typename cactus>
sum_persistent_segment_tree<cactus>::sum_persistent_segment_tree(cactus *p1,cactus *p2){
	init(p1,p2);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::add(const int p,const cactus value,const int version){
	add_in(p,value,version);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::simple_add(const int p,const cactus value){
	simple_add_in(p,value);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::replace(const int p,const cactus val,const int version){
	add_in(p,val-find_in(p,version),version);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::simple_replace(const int p,const cactus val){
	simpe_add_in(p,val-simple_find_in(p));
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::find(const int p,const int version){
	return find_in(p,version);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::simple_find(const int p){
	return simple_find_in(p);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::sum(const int pl,const int pr,const int version){
	return sum_in(pl,pr,version);
}

template <typename cactus>
const cactus sum_persistent_segment_tree<cactus>::simple_sum(const int pl,const int pr){
	return simple_sum_in(pl,pr);
}

template <typename cactus>
const SIZE_C sum_persistent_segment_tree<cactus>::size(void){
	return num;
}

template <typename cactus>
const SIZE_C sum_persistent_segment_tree<cactus>::versions(void){
	return len;
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::version_copy(const int version){
	add_in(1,0,version);
}

template <typename cactus>
void sum_persistent_segment_tree<cactus>::simple_version_copy(void){
	add_in(1,0,len-1);
}

/**********************************************************************************/

class union_node{
	private:
		int left,right;
		int f,h;
		union_node(void);
		union_node(int l,int r,int fa,int ht);
		friend class persistent_union_set;
};

union_node::union_node(void){
	h=1;
}

union_node::union_node(int l,int r,int fa,int ht){
	left=l;
	right=r;
	f=fa;
	h=ht;
}



class persistent_union_set{
	private:
		union_node u[MAXN];
		int n;
		int root[MAXNUM*2];
		int r;
		int num;
		int new_node(void);
		int new_node(int l,int r,int fa,int ht);
		int find_r(int k,int a);
		void build_in(int k,int l,int r);
		void new_line(int pre,int k,int l,int r,int p,int fa,int d_ht);
		int build_new(int p_root,int p,int fa,int d_ht);
		int get_pos(int k,int l,int r,int p);;
	public:	
		explicit persistent_union_set(const int range);
		void merge(const int version,int a,int b);
		void simple_merge(const int a,const int b);
		const bool relate(const int version,int a,int b);
		const bool simple_relate(const int a,const int b);
		void copy(const int version);
		void simple_copy(void);
};

int persistent_union_set::new_node(void){
	n++;
	return n-1;
}

int persistent_union_set::new_node(int l,int r,int fa,int ht){
	u[n]=union_node(l,r,fa,ht);
	n++;
	return n-1;
}

void persistent_union_set::build_in(int k,int l,int r){
	if(l==r){
		u[k].f=l;
		return;
	}
	u[k].left=new_node();
	u[k].right=new_node();
	int mid=(l+r)>>1;
	build_in(u[k].left,l,mid);
	build_in(u[k].right,mid+1,r);
}

void persistent_union_set::new_line(int pre,int k,int l,int r,int p,int fa,int d_ht){
	if(l==r){
		u[k]=u[pre];
		u[k].f=fa;
		u[k].h+=d_ht;
		return;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		u[k]=u[pre];
		u[k].right=new_node();
		new_line(u[pre].right,u[k].right,mid+1,r,p,fa,d_ht);
	}else{
		u[k]=u[pre];
		u[k].left=new_node();
		new_line(u[pre].left,u[k].left,l,mid,p,fa,d_ht);
	}
}

int persistent_union_set::build_new(int p_root,int p,int fa,int d_ht){
	int ret=new_node();
	new_line(p_root,ret,1,num,p,fa,d_ht);
	return ret;
}

int persistent_union_set::get_pos(int k,int l,int r,int p){
	if(l==r){
		return k;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		return get_pos(u[k].right,mid+1,r,p);
	}else{
		return get_pos(u[k].left,l,mid,p);
	}
}

int persistent_union_set::find_r(int k,int a){
	int b=get_pos(k,1,num,a);
	if(u[b].f==a){
		return a;
	}
	return find_r(k,u[b].f);
}

persistent_union_set::persistent_union_set(const int range){
	num=range;
	n=1;
	build_in(0,1,num);
	root[0]=0;
	r=1;
}

void persistent_union_set::merge(const int version,int a,int b){
	a=find_r(root[version],a);
	b=find_r(root[version],b);
	int pa=get_pos(root[version],1,num,a);
	int pb=get_pos(root[version],1,num,b);
	if(pa==pb){
		root[r]=root[version];
		r++;
		return;
	}
	if(u[pa].h>u[pb].h){
		root[r]=build_new(root[version],b,a,0);
		r++;
	}else{
		if(u[pa].h==u[pb].h){
			root[r]=build_new(build_new(root[version],b,a,0),a,a,1);
			r++;
		}else{
			root[r]=build_new(root[version],a,b,0);
			r++;
		}
	}
}

void persistent_union_set::simple_merge(const int a,const int b){
	merge(r-1,a,b);
}

const bool persistent_union_set::relate(const int version,int a,int b){
	a=find_r(root[version],a);
	b=find_r(root[version],b);
	return a==b;
}

const bool persistent_union_set::simple_relate(const int a,const int b){
	return relate(r-1,a,b);
}

void persistent_union_set::copy(const int version){
	root[r]=root[version];
	r++;
}

void persistent_union_set::simple_copy(void){
	copy(r-1);
}

/**********************************************************************************/

template <typename cactus>
class reverse_splay_node{
	friend class reverse_splay<cactus>;
	private:
		int left;
		int right;
		int p;
		int v;
		bool tag;
		int size;
		reverse_splay_node(void);
		reverse_splay_node(int l,int r,int pa,int val,bool tags);
};

template <typename cactus>
reverse_splay_node<cactus>::reverse_splay_node(void){
	left=-1;
	right=-1;
	p=-1;
	v=0;
	tag=0;
	size=1;
}

template <typename cactus>
reverse_splay_node<cactus>::reverse_splay_node(int l,int r,int pa,int val,bool tags){
	left=l;
	right=r;
	p=pa;
	v=val;
	tag=tags;
	size=1;
}



template <typename cactus>
class reverse_splay{
	private:
		reverse_splay_node<cactus> tr[MAXNUM*2];
		int n;
		int root;
		cactus a[MAXNUM];
		cactus r[MAXNUM];
		int pt;
		int num;
		void resize(int p);
		bool lrson(int p);
		int new_node(void);	
		int new_node(int l,int r,int pa,int val,bool tags);
		void built_in(int p,int l,int r);
		void build_a(void);
		void init(cactus *p1,cactus *p2);
		void left_rotate(int p);
		void right_rotate(int p);
		void rotate_to(int p,int dtn);
		void get_node(int p,int v,int dtn);
		void make_tag(int p);
		void pushdown(int p);
		void reverse_in(int pl,int pr);
		void print_x_root(int rx);
		void renew_x_root(int rx);
	public:
		explicit reverse_splay(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		void reverse(const int pl,const int pr);
		void print(void);
		const cactus* get(void);
};

template <typename cactus>
void reverse_splay<cactus>::resize(int p){
	tr[p].size=1;
	if(tr[p].left!=-1){
		tr[p].size+=tr[tr[p].left].size;
	}
	if(tr[p].right!=-1){
		tr[p].size+=tr[tr[p].right].size;
	}
}

template <typename cactus>
bool reverse_splay<cactus>::lrson(int p){
	return p==tr[tr[p].p].right;
}

template <typename cactus>
int reverse_splay<cactus>::new_node(int l,int r,int pa,int val,bool tags){
	tr[n]=reverse_splay_node<cactus>(l,r,pa,val,tags);
	n++;
	return n-1;
}

template <typename cactus>
int reverse_splay<cactus>::new_node(void){
	n++;
	return n-1;
}

template <typename cactus>
void reverse_splay<cactus>::built_in(int p,int l,int r){
	if(l==r){
		tr[p].v=l;
		return;
	}
	int mid=(l+r)>>1;
	tr[p].v=mid;
	if(l<mid){
		tr[p].left=new_node(-1,-1,p,0,0);
		built_in(tr[p].left,l,mid-1);
	}
	if(r>mid){
		tr[p].right=new_node(-1,-1,p,0,0);
		built_in(tr[p].right,mid+1,r);
	}
	resize(p);
}


template <typename cactus>
void reverse_splay<cactus>::build_a(void){
	n=1;
	root=0;
	built_in(0,0,num+1);
}

template <typename cactus>
void reverse_splay<cactus>::init(cactus *p1,cactus *p2){
	num=p2-p1;
	for(int i=1;i<=num;i++){
		a[i]=*p1;
		p1++;
	}
	build_a();
}

template <typename cactus>
void reverse_splay<cactus>::left_rotate(int p){
	int pa=tr[p].p;
	int rght=tr[p].right;
	int rl=tr[rght].left;
	
	if(p==root){
		root=rght;
		tr[rght].p=-1;
	}else{
		if(lrson(p)){
			tr[pa].right=rght;
			tr[rght].p=pa;
		}else{
			tr[pa].left=rght;
			tr[rght].p=pa;
		}
	}
	
	tr[p].right=rl;
	tr[rl].p=p;
	
	tr[rght].left=p;
	tr[p].p=rght;
	
	resize(p);
	resize(rght);
}

template <typename cactus>
void reverse_splay<cactus>::right_rotate(int p){
	int pa=tr[p].p;
	int lft=tr[p].left;
	int lr=tr[lft].right;
	
	if(p==root){
		tr[lft].p=-1;
		root=lft;
	}else{
		if(lrson(p)){
			tr[pa].right=lft;
			tr[lft].p=pa;
		}else{
			tr[pa].left=lft;
			tr[lft].p=pa;
		}
	}
	
	tr[p].left=lr;
	tr[lr].p=p;
	
	tr[lft].right=p;
	tr[p].p=lft;
	
	resize(p);
	resize(lft);
}

template <typename cactus>
void reverse_splay<cactus>::rotate_to(int p,int dtn){
	while(tr[p].p!=dtn){
		pushdown(tr[p].p);
		pushdown(p);
		if(lrson(p)){
			left_rotate(tr[p].p);
		}else{
			right_rotate(tr[p].p);
		}
	}
}

template <typename cactus>
void reverse_splay<cactus>::get_node(int p,int v,int dtn){
	v++;
	while(1){
		pushdown(p);
		if(tr[p].left==-1){
			if(v==1){
				break;
			}else{
				v--;
				p=tr[p].right;
			}
		}else{
			if(v==tr[tr[p].left].size+1){
				break;
			}else{
				if(v<=tr[tr[p].left].size){
					p=tr[p].left;
				}else{
					v-=(tr[tr[p].left].size+1);
					p=tr[p].right;
				}
			}
		}
	}
	rotate_to(p,dtn);
}

template <typename cactus>
void reverse_splay<cactus>::make_tag(int p){
	if(p==-1){
		return;
	}
	tr[p].tag^=1;
}

template <typename cactus>
void reverse_splay<cactus>::pushdown(int p){
	if(tr[p].tag){
		swap_c(tr[p].left,tr[p].right);
		tr[p].tag=0;
		make_tag(tr[p].left);
		make_tag(tr[p].right);
	}
}

template <typename cactus>
void reverse_splay<cactus>::reverse_in(int pl,int pr){
	get_node(root,pl-1,-1);
	get_node(root,pr+1,root);
	make_tag(tr[tr[root].right].left);
}

template <typename cactus>
void reverse_splay<cactus>::print_x_root(int rx){
	if(rx==-1){
		return;
	}
	pushdown(rx);
	print_x_root(tr[rx].left);
	if(tr[rx].v>0&&tr[rx].v<=num){
		cactusout<<a[tr[rx].v]<<space;
	}
	print_x_root(tr[rx].right);
}

template <typename cactus>
void reverse_splay<cactus>::renew_x_root(int rx){
	if(rx==-1){
		return;
	}
	pushdown(rx);
	renew_x_root(tr[rx].left);
	if(tr[rx].v>0&&tr[rx].v<=num){
		r[pt]=a[tr[rx].v];
	}
	pt++;
	renew_x_root(tr[rx].right);
}

template <typename cactus>
reverse_splay<cactus>::reverse_splay(cactus *p1,cactus *p2){
	init(p1,p2);
}

template <typename cactus>
const SIZE_C reverse_splay<cactus>::size(void){
	return num;
}

template <typename cactus>
void reverse_splay<cactus>::reverse(const int pl,const int pr){
	reverse_in(pl,pr);
}

template <typename cactus>
void reverse_splay<cactus>::print(void){
	print_x_root(root);
}

template <typename cactus>
const cactus* reverse_splay<cactus>::get(void){
	pt=1;
	renew_x_root(root);
	return r+1;
}

/*******************************************************************************/

template <typename cactus>
class reverse_fhq_node{
	friend class reverse_fhq_treap<cactus>;
	private:
		int left;
		int right;
		int v;
		int size;
		int prio;
		bool tag;
		reverse_fhq_node(void);
		reverse_fhq_node(int l,int r,int val,int sz,int pr,bool tags);
};

template <typename cactus>
reverse_fhq_node<cactus>::reverse_fhq_node(void){
	left=0;
	right=0;
	size=1;
	prio=0;
	tag=0;
}

template <typename cactus>
reverse_fhq_node<cactus>::reverse_fhq_node(int l,int r,int val,int sz,int pr,bool tags){
	left=l;
	right=r;
	v=val;
	size=sz;
	prio=pr;
	tag=tags;
}


template <typename cactus>
class reverse_fhq_treap{
	private:
		reverse_fhq_node<cactus> tr[MAXNUM];
		int n;
		int root;
		cactus a[MAXNUM];
		cactus r[MAXNUM];
		int num;
		int pt;
		int sk[MAXNUM];
		int skn;
		void resize(int p);
		int new_node(void);
		int new_node(int v,int prio);
		void build_in(int p,int l,int r);
		void build_a(void);
		void init(cactus *p1,cactus *p2);
		void split_by_size(int p,int sz,int &r1,int &r2);
		void merge_in(int &rt,int p1,int p2);
		void make_tag(int p);
		void pushdown(int p);
		void reverse_in(int pl,int pr);
		void printxroot(int p);
		void renewxroot(int p);
	public:
		explicit reverse_fhq_treap(cactus *p1,cactus *p2);
		const SIZE_C size(void);
		void reverse(const int pl,const int pr);
		void print(void);
		const cactus* get(void);
};

template <typename cactus>
const SIZE_C reverse_fhq_treap<cactus>::size(void){
	return num;
}

template <typename cactus>
void reverse_fhq_treap<cactus>::resize(int p){
	tr[0].size=0;
	tr[p].size=1+tr[tr[p].left].size+tr[tr[p].right].size;
}

template <typename cactus>
int reverse_fhq_treap<cactus>::new_node(void){
	n++;
	return n;
}

template <typename cactus>
int reverse_fhq_treap<cactus>::new_node(int v,int prio){
	n++;
	tr[n]=reverse_fhq_node<cactus>(0,0,v,1,prio,0);
	return n;
}

template <typename cactus>
void reverse_fhq_treap<cactus>::build_in(int p,int l,int r){
	if(l==r){
		tr[p].v=l;
		tr[p].prio=pt;
		pt++;
		return;
	}
	int mid=(l+r)>>1;
	tr[p].v=mid;
	tr[p].prio=pt;
	pt++;
	if(l<mid){
		tr[p].left=new_node();
		build_in(tr[p].left,l,mid-1);
	}
	if(r>mid){
		tr[p].right=new_node();
		build_in(tr[p].right,mid+1,r);
	}
	resize(p);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::build_a(void){
	n=1;
	pt=0;
	root=1;
	build_in(1,0,num+1);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::init(cactus *p1,cactus *p2){
	num=p2-p1;
	for(int i=1;i<=num;i++){
		a[i]=*p1;
		p1++;
	}
	build_a();
}

template <typename cactus>
void reverse_fhq_treap<cactus>::split_by_size(int p,int sz,int &r1,int &r2){
	if(p==0){
		r1=0;
		r2=0;
		return;
	}
	pushdown(p);
	if(tr[tr[p].left].size<sz){
		r1=p;
		split_by_size(tr[p].right,sz-tr[tr[p].left].size-1,tr[p].right,r2);
	}else{
		r2=p;
		split_by_size(tr[p].left,sz,r1,tr[p].left);
	}
	resize(p);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::merge_in(int &rt,int p1,int p2){
	pushdown(p1);
	pushdown(p2);
	if(p1==0||p2==0){
		rt=p1+p2;
		return;
	}
	if(tr[p1].prio<tr[p2].prio){
		rt=p1;
		merge_in(tr[rt].right,tr[p1].right,p2);
	}else{
		rt=p2;
		merge_in(tr[rt].left,p1,tr[p2].left);
	}
	resize(rt);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::make_tag(int p){
	if(p==0){
		return;
	}
	tr[p].tag^=1;
}

template <typename cactus>
void reverse_fhq_treap<cactus>::pushdown(int p){
	if(tr[p].tag){
		swap_c(tr[p].left,tr[p].right);
		make_tag(tr[p].left);
		make_tag(tr[p].right);
		tr[p].tag=0;
	}
}

template <typename cactus>
void reverse_fhq_treap<cactus>::reverse_in(int pl,int pr){
	int r1,r2,r3;
	split_by_size(root,pl,r1,r2);
	split_by_size(r2,pr-pl+1,r2,r3);
	make_tag(r2);
	merge_in(r2,r2,r3);
	merge_in(root,r1,r2);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	pushdown(p);
	printxroot(tr[p].left);
	if(tr[p].v>0&&tr[p].v<=num){
		cactusout<<a[tr[p].v]<<space;
	}
	printxroot(tr[p].right);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::renewxroot(int p){
	if(p==0){
		return;
	}
	pushdown(p);
	renew_x_root(tr[p].left);
	if(tr[p].v>0&&tr[p].v<=num){
		r[pt]=a[tr[p].v];
	}
	pt++;
	renew_x_root(tr[p].right);
}

template <typename cactus>
reverse_fhq_treap<cactus>::reverse_fhq_treap(cactus *p1,cactus *p2){
	init(p1,p2);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::reverse(const int pl,const int pr){
	reverse_in(pl,pr);
}

template <typename cactus>
void reverse_fhq_treap<cactus>::print(void){
	printxroot(root);
}

template <typename cactus>
const cactus* reverse_fhq_treap<cactus>::get(void){
	pt=1;
	renewxroot(root);
	return r+1;
}

/*******************************************************************************/

class complex_c{
	public:
		double a;
		double b;
		complex_c(void);
		complex_c(double a_,double bi_);
		const complex_c conjugate(void);
		void operator=(const double a_);
		const complex_c operator+(const complex_c cplx)const;
		const complex_c operator-(const complex_c cplx)const;
		const complex_c operator*(const complex_c cplx)const;
		const complex_c operator/(const complex_c cplx)const;
		void operator+=(const complex_c cplx);
		void operator-=(const complex_c cplx);
		void operator*=(const complex_c cplx);
		void operator/=(const complex_c cplx);
		const double mod(void);
};

const complex_c operator-(const complex_c cplx){
	return complex_c(-cplx.a,-cplx.b);
}

complex_c::complex_c(void){
	a=0.0;
	b=0.0;
}

complex_c::complex_c(double a_,double bi_){
	a=a_;
	b=bi_;
}

const complex_c complex_c::conjugate(void){
	return complex_c(a,-b);
}

void complex_c::operator=(const double a_){
	a=a_;
	b=0.0;
}

const complex_c complex_c::operator+(const complex_c cplx)const{
	return complex_c(a+cplx.a,b+cplx.b);
}

const complex_c complex_c::operator-(const complex_c cplx)const{
	return complex_c(a-cplx.a,b-cplx.b);
}

const complex_c complex_c::operator*(const complex_c cplx)const{
	return complex_c(a*cplx.a-b*cplx.b,a*cplx.b+b*cplx.a);
}

const complex_c complex_c::operator/(const complex_c cplx)const{
	double cd=cplx.a*cplx.a+cplx.b*cplx.b;
	return complex_c((a*cplx.a+b*cplx.b)/cd,(b*cplx.a-a*cplx.b)/cd);
}

void complex_c::operator+=(const complex_c cplx){
	a+=cplx.a;
	b+=cplx.b;
}

void complex_c::operator-=(const complex_c cplx){
	a-=cplx.a;
	b-=cplx.b;
}

void complex_c::operator*=(const complex_c cplx){
	*this=(*this)*cplx;
}

void complex_c::operator/=(const complex_c cplx){
	*this=(*this)/cplx;
}

const double complex_c::mod(void){
	return sqrt(a*a+b*b);
}

/*******************************************************************************/

template <typename cactus>
class persistent_fhq_node{
	friend class persistent_fhq_treap<cactus>;
	private:
		int left;
		int right;
		cactus v;
		int size;
		int prio;
		persistent_fhq_node(void);
		persistent_fhq_node(int l,int r,int sz,int pr);
};

template <typename cactus>
persistent_fhq_node<cactus>::persistent_fhq_node(void){
	left=0;
	right=0;
	size=1;
	prio=0;
}

template <typename cactus>
persistent_fhq_node<cactus>::persistent_fhq_node(int l,int r,int sz,int pr){
	left=l;
	right=r;
	size=sz;
	prio=pr;
}

template <typename cactus>
class persistent_fhq_treap{
	private:
		persistent_fhq_node <cactus> tr[MAXN];
		int n;
		int root[MAXN];
		int num;
		int seed=114514;
		int sk[MAXN];
		int skn;
		int rand_c(void);
		int new_node(void);
		int new_node(int l,int r,cactus val,int sz,int pr);
		int copy_node(int p);
		void resize(int p);
		void release_empty(int p);
		void init(void);
		void merge_in(int &rt,int p1,int p2);
		void split_by_value(int r,cactus val,int &p1,int &p2);
		void split_by_size(int r,int sz,int &p1,int &p2);
		cactus get_max_in(int p);
		cactus get_min_in(int p);
		void insert_in(cactus v,int version);
		void del_in(cactus v,int version);
		cactus kth_in(int k,int version);
		int rankin(cactus v,int version);
		cactus suc_in(cactus v,int version);
		cactus pre_in(cactus v,int version);
		void printxroot(int p);
	public:
		persistent_fhq_treap(void);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		void insert(const int version,const cactus v);
		void simple_insert(const cactus v);
		void del(const int version,const cactus v);
		void simple_del(const cactus v);
		const cactus kth(const int version,const int k);
		const cactus simple_kth(const int k);
		const int rank(const int version,const cactus v);
		const int simple_rank(const cactus v);
		const cactus pre(const int version,const cactus v);
		const cactus simple_pre(const cactus v);
		const cactus suc(const int version,const cactus v);
		const cactus simple_suc(const cactus v);
		const cactus max(const int version);
		const cactus simple_max(void);
		const cactus min(const int version);
		const cactus simple_min(void);
		void print(const int version);
		void simple_print(void);
};

template <typename cactus>
const SIZE_C persistent_fhq_treap<cactus>::size(const int version){
	return tr[root[version]].size;
}

template <typename cactus>
const SIZE_C persistent_fhq_treap<cactus>::simple_size(void){
	return tr[root[num-1]].size;
}

template <typename cactus>
int persistent_fhq_treap<cactus>::rand_c(void){
	return seed=(int)(seed*4827153LL%2147483647);
}

template <typename cactus>
int persistent_fhq_treap<cactus>::new_node(void){
	if(skn){
		skn--;
		tr[sk[skn]]=persistent_fhq_node<cactus>();
		return sk[skn];
	}else{
		n++;
		tr[n]=persistent_fhq_node<cactus>();
		return n;
	}
}

template <typename cactus>
int persistent_fhq_treap<cactus>::new_node(int l,int r,cactus val,int sz,int pr){
	if(skn){
		skn--;
		tr[sk[skn]]=persistent_fhq_node<cactus>(l,r,val,sz,pr);
		return sk[skn];
	}else{
		n++;
		tr[n]=persistent_fhq_node<cactus>(l,r,val,sz,pr);
		return n;
	}
}

template <typename cactus>
int persistent_fhq_treap<cactus>::copy_node(int p){
	if(skn){
		skn--;
		tr[sk[skn]]=tr[p];
		return sk[skn];
	}else{
		n++;
		tr[n]=tr[p];
		return n;
	}
}

template <typename cactus>
void persistent_fhq_treap<cactus>::resize(int p){
	tr[0].size=0;
	tr[p].size=tr[tr[p].left].size+tr[tr[p].right].size+1;
}

template <typename cactus>
void persistent_fhq_treap<cactus>::release_empty(int p){
	sk[skn]=p;
	skn++;
}

template <typename cactus>
void persistent_fhq_treap<cactus>::init(void){
	tr[0]=persistent_fhq_node<cactus>(0,0,0,0);
	n=0;
	skn=0;
	root[0]=0;
	num=1;
}

template <typename cactus>
void persistent_fhq_treap<cactus>::merge_in(int &rt,int p1,int p2){//r1.v<r2.v
	if(p1==0||p2==0){
		rt=copy_node(p1+p2);
		return;
	}
	if(tr[p1].prio<tr[p2].prio){
		rt=copy_node(p1);
		merge_in(tr[rt].right,tr[p1].right,p2);
	}else{
		rt=copy_node(p2);
		merge_in(tr[rt].left,p1,tr[p2].left);
	}
	resize(rt);
}

template <typename cactus>
void persistent_fhq_treap<cactus>::split_by_value(int r,cactus val,int &p1,int &p2){//tree of p1 includes val
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(tr[r].v<=val){
		p1=copy_node(r);
		split_by_value(tr[r].right,val,tr[p1].right,p2);
		resize(p1);
	}else{
		p2=copy_node(r);
		split_by_value(tr[r].left,val,p1,tr[p2].left);
		resize(p2);
	}
}

template <typename cactus>
void persistent_fhq_treap<cactus>::split_by_size(int r,int sz,int &p1,int &p2){//tree of p1 includes val
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(tr[tr[r].left].size+1<=sz){
		p1=copy_node(r);
		split_by_size(tr[r].right,sz-tr[tr[r].left].size-1,tr[p1].right,p2);
		resize(p1);
	}else{
		p2=copy_node(r);
		split_by_size(tr[r].left,sz,p1,tr[p2].left);
		resize(p2);
	}
}

template <typename cactus>
cactus persistent_fhq_treap<cactus>::get_max_in(int p){
	if(tr[p].right==0){
		return tr[p].v;
	}else{
		return get_max_in(tr[p].right);
	}
}

template <typename cactus>
cactus persistent_fhq_treap<cactus>::get_min_in(int p){
	if(tr[p].left==0){
		return tr[p].v;
	}else{
		return get_min_in(tr[p].left);
	}
}

template <typename cactus>
void persistent_fhq_treap<cactus>::insert_in(cactus v,int version){
	if(root[version]==0){
		root[num]=new_node(0,0,v,1,rand_c());
		num++;
		return;
	}
	int r1,r2,r3;
	split_by_value(root[version],v-1,r1,r2);
	split_by_value(r2,v,r2,r3);
	if(r2==0){
		merge_in(r2,new_node(0,0,v,1,rand_c()),r3);
		merge_in(root[num],r1,r2);
		num++;
	}else{
		merge_in(r2,r2,r3);
		merge_in(root[num],r1,r2);
		num++;
	}
}

template <typename cactus>
void persistent_fhq_treap<cactus>::del_in(cactus v,int version){
	if(root[version]==0||tr[root[version]].size==1){
		root[num]=0;
		num++;
		return;
	}
	int r1,r2,r3;
	split_by_value(root[version],v-1,r1,r2);
	split_by_value(r2,v,r2,r3);
	if(r2==0){
		merge_in(root[num],r1,r3);
		num++;
	}else{
		release_empty(r2);
		merge_in(root[num],r1,r3);
		num++;
	}
}

template <typename cactus>
cactus persistent_fhq_treap<cactus>::kth_in(int k,int version){
	int r1,r2,r3;
	split_by_size(root[version],k-1,r1,r2);
	split_by_size(r2,1,r2,r3);
	int rt=r2;
	merge_in(r2,r2,r3);
	merge_in(root[num],r1,r2);
	num++;
	return tr[rt].v;
}

template <typename cactus>
int persistent_fhq_treap<cactus>::rankin(cactus v,int version){
	int r1,r2;
	split_by_value(root[version],v-1,r1,r2);
	if(r2==0){
		merge_in(root[num],r1,r2);
		num++;
		return INF;
	}else{
		int rt=tr[r1].size;
		merge_in(root[num],r1,r2);
		num++;
		return rt+1;
	}
}

template <typename cactus>
cactus persistent_fhq_treap<cactus>::suc_in(cactus v,int version){
	int r1,r2;
	split_by_value(root[version],v,r1,r2);
	int vr;
	if(r2==0){
		vr=INF;
	}else{
		vr=get_min_in(r2);
	}
	merge_in(root[num],r1,r2);
	return vr;
}

template <typename cactus>
void persistent_fhq_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
cactus persistent_fhq_treap<cactus>::pre_in(cactus v,int version){
	int r1,r2;
	split_by_value(root[version],v-1,r1,r2);
	int vr;
	if(r1==0){
		vr=-INF;
	}else{
		vr=get_max_in(r1);
	}
	merge_in(root[num],r1,r2);
	return vr;
}

template <typename cactus>
persistent_fhq_treap<cactus>::persistent_fhq_treap(void){
	init();
}

template <typename cactus>
void persistent_fhq_treap<cactus>::insert(const int version,const cactus v){
	insert_in(v,version);
}

template <typename cactus>
void persistent_fhq_treap<cactus>::simple_insert(const cactus v){
	insert_in(v,num-1);
}

template <typename cactus>
void persistent_fhq_treap<cactus>::del(const int version,const cactus v){
	del_in(v,version);
}

template <typename cactus>
void persistent_fhq_treap<cactus>::simple_del(const cactus v){
	del_in(v,num-1);
}

template <typename cactus>
const cactus persistent_fhq_treap<cactus>::kth(const int version,const int k){
	return kth_in(k,version);
}

template <typename cactus>
const cactus persistent_fhq_treap<cactus>::simple_kth(const int k){
	return kth_in(k,num-1);
}

template <typename cactus>
const int persistent_fhq_treap<cactus>::rank(const int version,const cactus v){
	return rankin(v,version);
}

template <typename cactus>
const int persistent_fhq_treap<cactus>::simple_rank(const cactus v){
	return rankin(v,num-1);
}

template <typename cactus>
const cactus persistent_fhq_treap<cactus>::pre(const int version,const cactus v){
	return pre_in(v,version);
}

template <typename cactus>
const cactus persistent_fhq_treap<cactus>::simple_pre(const cactus v){
	return pre_in(v,num-1);
}

template <typename cactus>
const cactus persistent_fhq_treap<cactus>::suc(const int version,const cactus v){
	return suc_in(v,version);
}

template <typename cactus>
const cactus persistent_fhq_treap<cactus>::simple_suc(const cactus v){
	return suc_in(v,num-1);
}

template <typename cactus>
void persistent_fhq_treap<cactus>::print(const int version){
	printxroot(root[version]);
}

template <typename cactus>
void persistent_fhq_treap<cactus>::simple_print(void){
	printxroot(root[num-1]);
}



template <typename cactus>
class persistent_multi_fhq_node{
	friend class persistent_multi_fhq_treap<cactus>;
	private:
		int left;
		int right;
		cactus v;
		int size;
		int cnt;
		int prio;
		persistent_multi_fhq_node(void);
		persistent_multi_fhq_node(int l,int r,int sz,int c,int pr);
};

template <typename cactus>
persistent_multi_fhq_node<cactus>::persistent_multi_fhq_node(void){
	left=0;
	right=0;
	size=1;
	prio=0;
	cnt=1;
}

template <typename cactus>
persistent_multi_fhq_node<cactus>::persistent_multi_fhq_node(int l,int r,int sz,int c,int pr){
	left=l;
	right=r;
	size=sz;
	cnt=c;
	prio=pr;
}

template <typename cactus>
class persistent_multi_fhq_treap{
	private:
		persistent_multi_fhq_node <cactus> tr[MAXN];
		int n;
		int root[MAXN];
		int num;
		int seed=114514;
		int sk[MAXN];
		int skn;
		int rand_c(void);
		int new_node(void);
		int new_node(int l,int r,cactus val,int sz,int pr);
		int copy_node(int p);
		void resize(int p);
		void release_empty(int p);
		void init(void);
		void merge_in(int &rt,int p1,int p2);
		void split_by_value(int r,cactus val,int &p1,int &p2);
		void split_by_size(int r,int sz,int &p1,int &p2);
		cactus get_max_in(int p);
		cactus get_min_in(int p);
		void insert_in(cactus v,int version);
		void del_in(cactus v,int version);
		cactus kthinroot(int r,int k);
		cactus kth_in(int k,int version);
		int rankin(cactus v,int version);
		cactus suc_in(cactus v,int version);
		cactus pre_in(cactus v,int version);
		void printxroot(int p);
	public:
		persistent_multi_fhq_treap(void);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		void insert(const int version,const cactus v);
		void simple_insert(const cactus v);
		void del(const int version,const cactus v);
		void simple_del(const cactus v);
		const cactus kth(const int version,const int k);
		const cactus simple_kth(const int k);
		const int rank(const int version,const cactus v);
		const int simple_rank(const cactus v);
		const cactus pre(const int version,const cactus v);
		const cactus simple_pre(const cactus v);
		const cactus suc(const int version,const cactus v);
		const cactus simple_suc(const cactus v);
		const cactus max(const int version);
		const cactus simple_max(void);
		const cactus min(const int version);
		const cactus simple_min(void);
		void print(const int version);
		void simple_print(void);
};

template <typename cactus>
const SIZE_C persistent_multi_fhq_treap<cactus>::size(const int version){
	return tr[root[version]].size;
}

template <typename cactus>
const SIZE_C persistent_multi_fhq_treap<cactus>::simple_size(void){
	return tr[root[num-1]].size;
}

template <typename cactus>
int persistent_multi_fhq_treap<cactus>::rand_c(void){
	return seed=(int)(seed*4827153LL%2147483647);
}

template <typename cactus>
int persistent_multi_fhq_treap<cactus>::new_node(void){
	if(skn){
		skn--;
		tr[sk[skn]]=persistent_multi_fhq_node<cactus>();
		return sk[skn];
	}else{
		n++;
		tr[n]=persistent_multi_fhq_node<cactus>();
		return n;
	}
}

template <typename cactus>
int persistent_multi_fhq_treap<cactus>::new_node(int l,int r,cactus val,int sz,int pr){
	if(skn){
		skn--;
		tr[sk[skn]]=persistent_multi_fhq_node<cactus>(l,r,val,sz,1,pr);
		return sk[skn];
	}else{
		n++;
		tr[n]=persistent_multi_fhq_node<cactus>(l,r,val,sz,1,pr);
		return n;
	}
}

template <typename cactus>
int persistent_multi_fhq_treap<cactus>::copy_node(int p){
	if(skn){
		skn--;
		tr[sk[skn]]=tr[p];
		return sk[skn];
	}else{
		n++;
		tr[n]=tr[p];
		return n;
	}
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::resize(int p){
	tr[0].size=0;
	tr[p].size=tr[tr[p].left].size+tr[tr[p].right].size+tr[p].cnt;
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::release_empty(int p){
	sk[skn]=p;
	skn++;
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::init(void){
	tr[0]=persistent_multi_fhq_node<cactus>(0,0,0,0,0);
	n=0;
	skn=0;
	root[0]=0;
	num=1;
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::merge_in(int &rt,int p1,int p2){//r1.v<r2.v
	if(p1==0||p2==0){
		rt=copy_node(p1+p2);
		return;
	}
	if(tr[p1].prio<tr[p2].prio){
		rt=copy_node(p1);
		merge_in(tr[rt].right,tr[p1].right,p2);
	}else{
		rt=copy_node(p2);
		merge_in(tr[rt].left,p1,tr[p2].left);
	}
	resize(rt);
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::split_by_value(int r,cactus val,int &p1,int &p2){//tree of p1 includes val
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(tr[r].v<=val){
		p1=copy_node(r);
		split_by_value(tr[r].right,val,tr[p1].right,p2);
		resize(p1);
	}else{
		p2=copy_node(r);
		split_by_value(tr[r].left,val,p1,tr[p2].left);
		resize(p2);
	}
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::split_by_size(int r,int sz,int &p1,int &p2){//tree of p1 includes val
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(tr[tr[r].left].size+1<=sz){
		p1=copy_node(r);
		split_by_size(tr[r].right,sz-tr[tr[r].left].size-tr[r].cnt,tr[p1].right,p2);
		resize(p1);
	}else{
		p2=copy_node(r);
		split_by_size(tr[r].left,sz,p1,tr[p2].left);
		resize(p2);
	}
}

template <typename cactus>
cactus persistent_multi_fhq_treap<cactus>::get_max_in(int p){
	if(tr[p].right==0){
		return tr[p].v;
	}else{
		return get_max_in(tr[p].right);
	}
}

template <typename cactus>
cactus persistent_multi_fhq_treap<cactus>::get_min_in(int p){
	if(tr[p].left==0){
		return tr[p].v;
	}else{
		return get_min_in(tr[p].left);
	}
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::insert_in(cactus v,int version){
	if(root[version]==0){
		root[num]=new_node(0,0,v,1,rand_c());
		num++;
		return;
	}
	int r1,r2,r3;
	split_by_value(root[version],v-1,r1,r2);
	split_by_value(r2,v,r2,r3);
	if(r2==0){
		merge_in(r2,new_node(0,0,v,1,rand_c()),r3);
		merge_in(root[num],r1,r2);
		num++;
	}else{
		tr[r2].cnt++;
		tr[r2].size++;
		merge_in(r2,r2,r3);
		merge_in(root[num],r1,r2);
		num++;
	}
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::del_in(cactus v,int version){
	if(root[version]==0||tr[root[version]].size==1){
		root[num]=0;
		num++;
		return;
	}
	int r1,r2,r3;
	split_by_value(root[version],v-1,r1,r2);
	split_by_value(r2,v,r2,r3);
	if(r2==0){
		merge_in(root[num],r1,r3);
		num++;
	}else{
		if(tr[r2].cnt>1){
			tr[r2].cnt--;
			merge_in(r2,r2,r3);
			merge_in(root[num],r1,r2);
			num++;
		}else{
			release_empty(r2);
			merge_in(root[num],r1,r3);
			num++;
		}
		
	}
}

template <typename cactus>
cactus persistent_multi_fhq_treap<cactus>::kthinroot(int r,int k){
	if(tr[r].left==0){
		if(k<=tr[r].cnt){
			return tr[r].v;
		}else{
			return kthinroot(tr[r].right,k-tr[r].cnt);
		}
	}else{
		if(k<=tr[tr[r].left].size){
			return kthinroot(tr[r].left,k);
		}else{
			if(k>tr[tr[r].left].size+tr[r].cnt){
				return kthinroot(tr[r].right,k-tr[r].cnt-tr[tr[r].left].size);
			}else{
				return tr[r].v;
			}
		}
	}
}

template <typename cactus>
cactus persistent_multi_fhq_treap<cactus>::kth_in(int k,int version){
	root[num]=root[version];
	num++;
	return kthinroot(root[version],k);
}

template <typename cactus>
int persistent_multi_fhq_treap<cactus>::rankin(cactus v,int version){
	int r1,r2;
	split_by_value(root[version],v-1,r1,r2);
	int rt=tr[r1].size+1;
	merge_in(root[num],r1,r2);
	num++;
	return rt;
}

template <typename cactus>
cactus persistent_multi_fhq_treap<cactus>::suc_in(cactus v,int version){
	int r1,r2;
	split_by_value(root[version],v,r1,r2);
	int vr;
	if(r2==0){
		vr=INF;
	}else{
		vr=get_min_in(r2);
	}
	merge_in(root[num],r1,r2);
	num++;
	return vr;
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	printxroot(tr[p].left);
	cactusout<<tr[p].v<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
cactus persistent_multi_fhq_treap<cactus>::pre_in(cactus v,int version){
	int r1,r2;
	split_by_value(root[version],v-1,r1,r2);
	int vr;
	if(r1==0){
		vr=-INF;
	}else{
		vr=get_max_in(r1);
	}
	merge_in(root[num],r1,r2);
	num++;
	return vr;
}

template <typename cactus>
persistent_multi_fhq_treap<cactus>::persistent_multi_fhq_treap(void){
	init();
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::insert(const int version,const cactus v){
	insert_in(v,version);
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::simple_insert(const cactus v){
	insert_in(v,num-1);
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::del(const int version,const cactus v){
	del_in(v,version);
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::simple_del(const cactus v){
	del_in(v,num-1);
}

template <typename cactus>
const cactus persistent_multi_fhq_treap<cactus>::kth(const int version,const int k){
	return kth_in(k,version);
}

template <typename cactus>
const cactus persistent_multi_fhq_treap<cactus>::simple_kth(const int k){
	return kth_in(k,num-1);
}

template <typename cactus>
const int persistent_multi_fhq_treap<cactus>::rank(const int version,const cactus v){
	return rankin(v,version);
}

template <typename cactus>
const int persistent_multi_fhq_treap<cactus>::simple_rank(const cactus v){
	return rankin(v,num-1);
}

template <typename cactus>
const cactus persistent_multi_fhq_treap<cactus>::pre(const int version,const cactus v){
	return pre_in(v,version);
}

template <typename cactus>
const cactus persistent_multi_fhq_treap<cactus>::simple_pre(const cactus v){
	return pre_in(v,num-1);
}

template <typename cactus>
const cactus persistent_multi_fhq_treap<cactus>::suc(const int version,const cactus v){
	return suc_in(v,version);
}

template <typename cactus>
const cactus persistent_multi_fhq_treap<cactus>::simple_suc(const cactus v){
	return suc_in(v,num-1);
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::print(const int version){
	printxroot(root[version]);
}

template <typename cactus>
void persistent_multi_fhq_treap<cactus>::simple_print(void){
	printxroot(root[num-1]);
}

/*******************************************************************************/

template <typename cactus>
class persistent_reverse_fhq_node{
	friend class persistent_reverse_fhq_treap<cactus>;
	private:
		int left;
		int right;
		int v;
		bool tag;
		int prio;
		int size;
		persistent_reverse_fhq_node(void);
		persistent_reverse_fhq_node(int l,int r,int val,bool tags,int pr,int sz);
};

template <typename cactus>
persistent_reverse_fhq_node<cactus>::persistent_reverse_fhq_node(void){
	left=0;
	right=0;
	v=0;
	tag=0;
	prio=0;
}

template <typename cactus>
persistent_reverse_fhq_node<cactus>::persistent_reverse_fhq_node(int l,int r,int val,bool tags,int pr,int sz){
	left=l;
	right=r;
	v=val;
	tag=tags;
	prio=pr;
	size=sz;
}



template <typename cactus>
class persistent_reverse_fhq_treap{
	private:
		persistent_reverse_fhq_node<cactus> tr[MAXN];
		int n;
		int root[MAXNUM];
		int rn;
		int pt;
		cactus a[MAXNUM];
		cactus r[MAXNUM];
		int num;
		int new_node(void);
		int new_node(int v,int pr);
		int copy_node(int p);
		void build0(int p,int l,int r);
		void build_in(void);
		void resize(int p);
		void maketag(int p);
		void pushdown(int p);
		void split_by_size(int r,int sz,int &p1,int &p2);
		void merge_in(int &r,int p1,int p2);
		void reverse_in(int version,int pl,int pr);
		void printxroot(int p);
		void getxroot(int p);
		void print_in(int version);
		cactus* get_in(int version);
	public:
		explicit persistent_reverse_fhq_treap(cactus *a1,cactus *a2);
		const SIZE_C size(void);
		void reverse(const int version,const int pl,const int pr);
		void simple_reverse(const int pl,const int pr);
		void print(const int version);
		void simple_print(void);
		cactus* get(const int version);
		cactus* simple_get(void);
};

template <typename cactus>
const SIZE_C persistent_reverse_fhq_treap<cactus>::size(void){
	return num;
}

template <typename cactus>
int persistent_reverse_fhq_treap<cactus>::new_node(void){
	n++;
	return n;
}

template <typename cactus>
int persistent_reverse_fhq_treap<cactus>::new_node(int v,int pr){
	n++;
	tr[n]=persistent_reverse_fhq_node<cactus> (0,0,v,0,pr,1);
	return n;
}

template <typename cactus>
int persistent_reverse_fhq_treap<cactus>::copy_node(int p){
	if(p==0){
		return 0;
	}
	n++;
	tr[n]=tr[p];
	return n;
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::resize(int p){
	tr[p].size=tr[tr[p].left].size+tr[tr[p].right].size+1;
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::maketag(int p){
	if(p==0){
		return;
	}
	tr[p].tag^=1;
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::pushdown(int p){
	if(tr[p].tag){
		tr[p].tag=0;
		if(tr[p].left){
			tr[p].left=copy_node(tr[p].left);
		}
		if(tr[p].right){
			tr[p].right=copy_node(tr[p].right);
		}
		swap_c(tr[p].left,tr[p].right);
		maketag(tr[p].left);
		maketag(tr[p].right);
	}
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::build0(int p,int l,int r){
	if(l==r){
		tr[p].v=l;
		tr[p].prio=pt;
		pt++;
		return;
	}
	tr[p].prio=pt;
	pt++;
	int mid=(l+r)>>1;
	tr[p].v=mid;
	if(l<mid){
		tr[p].left=new_node();
		build0(tr[p].left,l,mid-1);
	}
	if(r>mid){
		tr[p].right=new_node();
		build0(tr[p].right,mid+1,r);
	}
	resize(p);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::build_in(void){
	n=1;
	build0(1,0,num+1);
	rn=1;
	root[0]=1;
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::split_by_size(int r,int sz,int &p1,int &p2){
	pushdown(r);
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(sz<=tr[tr[r].left].size){
		p2=copy_node(r);
		split_by_size(tr[r].left,sz,p1,tr[p2].left);
		resize(p2);
	}else{
		p1=copy_node(r);
		split_by_size(tr[r].right,sz-tr[tr[r].left].size-1,tr[p1].right,p2);
		resize(p1);
	}
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::merge_in(int &r,int p1,int p2){
	pushdown(p1);
	pushdown(p2);
	if(p1==0||p2==0){
		r=copy_node(p1+p2);
		return;
	}
	if(tr[p1].prio<tr[p2].prio){
		r=copy_node(p1);
		merge_in(tr[r].right,tr[p1].right,p2);
	}else{
		r=copy_node(p2);
		merge_in(tr[r].left,p1,tr[p2].left);
	}
	resize(r);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::reverse_in(int version,int pl,int pr){
	int r1,r2,r3;
	split_by_size(root[version],pl,r1,r2);
	split_by_size(r2,pr-pl+1,r2,r3);
	maketag(r2);
	merge_in(r2,r2,r3);
	merge_in(root[rn],r1,r2);
	rn++;
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::printxroot(int p){
	if(p==0){
		return;
	}
	pushdown(p);
	printxroot(tr[p].left);
	cactusout<<a[tr[p].v]<<space;
	printxroot(tr[p].right);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::getxroot(int p){
	if(p==0){
		return;
	}
	pushdown(p);
	getxroot(tr[p].left);
	r[pt]=a[tr[p].v];
	pt++;
	getxroot(tr[p].right);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::print_in(int version){
	printxroot(root[version]);
	cactusout<<enter;
}

template <typename cactus>
cactus* persistent_reverse_fhq_treap<cactus>::get_in(int version){
	pt=1;
	getxroot(root[version]);
	return r+1;
}

template <typename cactus>
persistent_reverse_fhq_treap<cactus>::persistent_reverse_fhq_treap(cactus *a1,cactus *a2){
	n=0;
	tr[0]=persistent_reverse_fhq_node<cactus> (0,0,0,0,0,0);
	num=a2-a1;
	for(int i=1;i<=num;i++){
		a[i]=*a1;
		a1++;
	}
	pt=0;
	build_in();
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::reverse(const int version,const int pl,const int pr){
	reverse_in(version,pl,pr);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::simple_reverse(const int pl,const int pr){
	reverse_in(rn-1,pl,pr);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::print(const int version){
	print_in(version);
}

template <typename cactus>
void persistent_reverse_fhq_treap<cactus>::simple_print(void){
	print_in(rn-1);
}

template <typename cactus>
cactus* persistent_reverse_fhq_treap<cactus>::get(const int version){
	return get_in(version);
}

template <typename cactus>
cactus* persistent_reverse_fhq_treap<cactus>::simple_get(void){
	return get_in(rn-1);
}

/*******************************************************************************/

class ascii_trie{
	private:
		int n;
		int tr[MAXN][128];
		int Size[MAXN];
		int num[MAXN];
		int new_node(void);
		void insert_in(char *c);
		void insert_in(string str);
		void del_in(char *c);
		void del_in(string str);
		const int query(char *c);
		const int query(string str);
		const bool find_in(char *c);
		const bool find_in(string str);
		const int prefix_in(char *c);
		const int prefix_in(string str);
	public:
		ascii_trie(void);
		const SIZE_C size(void);
		void insert(char *c);
		void insert(string str);
		void del(char *c);
		void del(string str);
		const int count(char *c);
		const int count(string str);
		const bool find(char *c);
		const bool find(string str);
		const int prefix(char *c);
		const int prefix(string str);
};
		
const SIZE_C ascii_trie::size(void){
	return Size[1];
}

int ascii_trie::new_node(void){
	n++;
	num[n]=0;
	Size[n]=0;
	return n;
}

void ascii_trie::insert_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][(int)*c]==0){
			tr[pt][(int)*c]=new_node();
		}
		pt=tr[pt][(int)*c];
		i++;
		c++;
	}
	num[pt]++;
	Size[pt]++;
}

void ascii_trie::insert_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][(int)str[i]]==0){
			tr[pt][(int)str[i]]=new_node();
		}
		pt=tr[pt][(int)str[i]];
		i++;
	}
	num[pt]++;
	Size[pt]++;
}

void ascii_trie::del_in(char *c){
	if(find_in(c)){
		int len=strlen(c);
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][(int)*c]==0){
				tr[pt][(int)*c]=new_node();
			}
			pt=tr[pt][(int)*c];
			i++;
			c++;
		}
		num[pt]--;
		Size[pt]--;
	}
}

void ascii_trie::del_in(string str){
	if(find_in(str)){
		int len=str.length();
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][(int)str[i]]==0){
				tr[pt][(int)str[i]]=new_node();
			}
			pt=tr[pt][(int)str[i]];
			i++;
		}
		num[pt]--;
		Size[pt]--;	
	}
}

const int ascii_trie::query(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][(int)*c]==0){
			tr[pt][(int)*c]=new_node();
		}
		pt=tr[pt][(int)*c];
		i++;
		c++;
	}
	return num[pt];
}

const int ascii_trie::query(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][(int)str[i]]==0){
			tr[pt][(int)str[i]]=new_node();
		}
		pt=tr[pt][(int)str[i]];
		i++;
	}
	return num[pt];
}

const bool ascii_trie::find_in(char *c){
	return (bool)query(c);
}

const bool ascii_trie::find_in(string str){
	return (bool)query(str);
}

const int ascii_trie::prefix_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][(int)*c]==0){
			tr[pt][(int)*c]=new_node();
		}
		pt=tr[pt][(int)*c];
		i++;
		c++;
	}
	return Size[pt];
}

const int ascii_trie::prefix_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][(int)str[i]]==0){
			tr[pt][(int)str[i]]=new_node();
		}
		pt=tr[pt][(int)str[i]];
		i++;
	}
	return Size[pt];
}

ascii_trie::ascii_trie(void){
	n=1;
}

void ascii_trie::insert(char *c){
	insert_in(c);
}

void ascii_trie::insert(string str){
	insert_in(str);
}

void ascii_trie::del(char *c){
	del_in(c);
}

void ascii_trie::del(string str){
	del_in(str);
}

const int ascii_trie::count(char *c){
	return query(c);
}

const int ascii_trie::count(string str){
	return query(str);
}

const bool ascii_trie::find(char *c){
	return find_in(c);
}

const bool ascii_trie::find(string str){
	return find_in(str);
}

const int ascii_trie::prefix(char *c){
	return prefix_in(c);
}

const int ascii_trie::prefix(string str){
	return prefix_in(str);
}

/*******************************************************************************/

class trie{
	private:
		int n;
		int tr[MAXN][63];
		int Size[MAXN];
		int num[MAXN];
		int getnum(char x);
		int new_node(void);
		void insert_in(char *c);
		void insert_in(string str);
		void del_in(char *c);
		void del_in(string str);
		const int query(char *c);
		const int query(string str);
		const bool find_in(char *c);
		const bool find_in(string str);
		const int prefix_in(char *c);
		const int prefix_in(string str);
	public:
		trie(void);
		const SIZE_C size(void);
		void insert(char *c);
		void insert(string str);
		void del(char *c);
		void del(string str);
		const int count(char *c);
		const int count(string str);
		const bool find(char *c);
		const bool find(string str);
		const int prefix(char *c);
		const int prefix(string str);
};
		
const SIZE_C trie::size(void){
	return Size[1];
}

int trie::new_node(void){
	n++;
	num[n]=0;
	Size[n]=0;
	return n;
}

void trie::insert_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	num[pt]++;
	Size[pt]++;
}

void trie::insert_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	num[pt]++;
	Size[pt]++;
}

void trie::del_in(char *c){
	if(find_in(c)){
		int len=strlen(c);
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(*c)]==0){
				tr[pt][getnum(*c)]=new_node();
			}
			pt=tr[pt][getnum(*c)];
			i++;
			c++;
		}
		num[pt]--;
		Size[pt]--;
	}
}

void trie::del_in(string str){
	if(find_in(str)){
		int len=str.length();
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(str[i])]==0){
				tr[pt][getnum(str[i])]=new_node();
			}
			pt=tr[pt][getnum(str[i])];
			i++;
		}
		num[pt]--;
		Size[pt]--;	
	}
}

const int trie::query(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return num[pt];
}

const int trie::query(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return num[pt];
}

const bool trie::find_in(char *c){
	return (bool)query(c);
}

const bool trie::find_in(string str){
	return (bool)query(str);
}

const int trie::prefix_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return Size[pt];
}

const int trie::prefix_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return Size[pt];
}

trie::trie(void){
	n=1;
}

void trie::insert(char *c){
	insert_in(c);
}

void trie::insert(string str){
	insert_in(str);
}

void trie::del(char *c){
	del_in(c);
}

void trie::del(string str){
	del_in(str);
}

const int trie::count(char *c){
	return query(c);
}

const int trie::count(string str){
	return query(str);
}

const bool trie::find(char *c){
	return find_in(c);
}

const bool trie::find(string str){
	return find_in(str);
}

const int trie::prefix(char *c){
	return prefix_in(c);
}

const int trie::prefix(string str){
	return prefix_in(str);
}

int trie::getnum(char x){
	if(x>='A'&&x<='Z'){
		return x-'A';
	}else{
		if(x>='a'&&x<='z'){
			return x-'a'+26;
		}else{
			return x-'0'+52;
		}
	} 
}

/*******************************************************************************/

class alphabet_trie{
	private:
		int n;
		int tr[MAXN][53];
		int Size[MAXN];
		int num[MAXN];
		int getnum(char x);
		int new_node(void);
		void insert_in(char *c);
		void insert_in(string str);
		void del_in(char *c);
		void del_in(string str);
		const int query(char *c);
		const int query(string str);
		const bool find_in(char *c);
		const bool find_in(string str);
		const int prefix_in(char *c);
		const int prefix_in(string str);
	public:
		alphabet_trie(void);
		const SIZE_C size(void);
		void insert(char *c);
		void insert(string str);
		void del(char *c);
		void del(string str);
		const int count(char *c);
		const int count(string str);
		const bool find(char *c);
		const bool find(string str);
		const int prefix(char *c);
		const int prefix(string str);
};
		
const SIZE_C alphabet_trie::size(void){
	return Size[1];
}

int alphabet_trie::new_node(void){
	n++;
	num[n]=0;
	Size[n]=0;
	return n;
}

void alphabet_trie::insert_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	num[pt]++;
	Size[pt]++;
}

void alphabet_trie::insert_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	num[pt]++;
	Size[pt]++;
}

void alphabet_trie::del_in(char *c){
	if(find_in(c)){
		int len=strlen(c);
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(*c)]==0){
				tr[pt][getnum(*c)]=new_node();
			}
			pt=tr[pt][getnum(*c)];
			i++;
			c++;
		}
		num[pt]--;
		Size[pt]--;
	}
}

void alphabet_trie::del_in(string str){
	if(find_in(str)){
		int len=str.length();
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(str[i])]==0){
				tr[pt][getnum(str[i])]=new_node();
			}
			pt=tr[pt][getnum(str[i])];
			i++;
		}
		num[pt]--;
		Size[pt]--;	
	}
}

const int alphabet_trie::query(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return num[pt];
}

const int alphabet_trie::query(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return num[pt];
}

const bool alphabet_trie::find_in(char *c){
	return (bool)query(c);
}

const bool alphabet_trie::find_in(string str){
	return (bool)query(str);
}

const int alphabet_trie::prefix_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return Size[pt];
}

const int alphabet_trie::prefix_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return Size[pt];
}

alphabet_trie::alphabet_trie(void){
	n=1;
}

void alphabet_trie::insert(char *c){
	insert_in(c);
}

void alphabet_trie::insert(string str){
	insert_in(str);
}

void alphabet_trie::del(char *c){
	del_in(c);
}

void alphabet_trie::del(string str){
	del_in(str);
}

const int alphabet_trie::count(char *c){
	return query(c);
}

const int alphabet_trie::count(string str){
	return query(str);
}

const bool alphabet_trie::find(char *c){
	return find_in(c);
}

const bool alphabet_trie::find(string str){
	return find_in(str);
}

const int alphabet_trie::prefix(char *c){
	return prefix_in(c);
}

const int alphabet_trie::prefix(string str){
	return prefix_in(str);
}

int alphabet_trie::getnum(char x){
	if(x>='A'&&x<='Z'){
		return x-'A';
	}else{
		return x-'a'+26;
	}
}

/*******************************************************************************/

class lowercase_trie{
	private:
		int n;
		int tr[MAXN][26];
		int Size[MAXN];
		int num[MAXN];
		int getnum(char x);
		int new_node(void);
		void insert_in(char *c);
		void insert_in(string str);
		void del_in(char *c);
		void del_in(string str);
		const int query(char *c);
		const int query(string str);
		const bool find_in(char *c);
		const bool find_in(string str);
		const int prefix_in(char *c);
		const int prefix_in(string str);
	public:
		lowercase_trie(void);
		const SIZE_C size(void);
		void insert(char *c);
		void insert(string str);
		void del(char *c);
		void del(string str);
		const int count(char *c);
		const int count(string str);
		const bool find(char *c);
		const bool find(string str);
		const int prefix(char *c);
		const int prefix(string str);
};
		
const SIZE_C lowercase_trie::size(void){
	return Size[1];
}

int lowercase_trie::new_node(void){
	n++;
	num[n]=0;
	Size[n]=0;
	return n;
}

void lowercase_trie::insert_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	num[pt]++;
	Size[pt]++;
}

void lowercase_trie::insert_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	num[pt]++;
	Size[pt]++;
}

void lowercase_trie::del_in(char *c){
	if(find_in(c)){
		int len=strlen(c);
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(*c)]==0){
				tr[pt][getnum(*c)]=new_node();
			}
			pt=tr[pt][getnum(*c)];
			i++;
			c++;
		}
		num[pt]--;
		Size[pt]--;
	}
}

void lowercase_trie::del_in(string str){
	if(find_in(str)){
		int len=str.length();
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(str[i])]==0){
				tr[pt][getnum(str[i])]=new_node();
			}
			pt=tr[pt][getnum(str[i])];
			i++;
		}
		num[pt]--;
		Size[pt]--;	
	}
}

const int lowercase_trie::query(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return num[pt];
}

const int lowercase_trie::query(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return num[pt];
}

const bool lowercase_trie::find_in(char *c){
	return (bool)query(c);
}

const bool lowercase_trie::find_in(string str){
	return (bool)query(str);
}

const int lowercase_trie::prefix_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return Size[pt];
}

const int lowercase_trie::prefix_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return Size[pt];
}

lowercase_trie::lowercase_trie(void){
	n=1;
}

void lowercase_trie::insert(char *c){
	insert_in(c);
}

void lowercase_trie::insert(string str){
	insert_in(str);
}

void lowercase_trie::del(char *c){
	del_in(c);
}

void lowercase_trie::del(string str){
	del_in(str);
}

const int lowercase_trie::count(char *c){
	return query(c);
}

const int lowercase_trie::count(string str){
	return query(str);
}

const bool lowercase_trie::find(char *c){
	return find_in(c);
}

const bool lowercase_trie::find(string str){
	return find_in(str);
}

const int lowercase_trie::prefix(char *c){
	return prefix_in(c);
}

const int lowercase_trie::prefix(string str){
	return prefix_in(str);
}

int lowercase_trie::getnum(char x){
	return x-'a';
}

/*******************************************************************************/

class uppercase_trie{
	private:
		int n;
		int tr[MAXN][26];
		int Size[MAXN];
		int num[MAXN];
		int getnum(char x);
		int new_node(void);
		void insert_in(char *c);
		void insert_in(string str);
		void del_in(char *c);
		void del_in(string str);
		const int query(char *c);
		const int query(string str);
		const bool find_in(char *c);
		const bool find_in(string str);
		const int prefix_in(char *c);
		const int prefix_in(string str);
	public:
		uppercase_trie(void);
		const SIZE_C size(void);
		void insert(char *c);
		void insert(string str);
		void del(char *c);
		void del(string str);
		const int count(char *c);
		const int count(string str);
		const bool find(char *c);
		const bool find(string str);
		const int prefix(char *c);
		const int prefix(string str);
};
		
const SIZE_C uppercase_trie::size(void){
	return Size[1];
}

int uppercase_trie::new_node(void){
	n++;
	num[n]=0;
	Size[n]=0;
	return n;
}

void uppercase_trie::insert_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	num[pt]++;
	Size[pt]++;
}

void uppercase_trie::insert_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		Size[pt]++;
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	num[pt]++;
	Size[pt]++;
}

void uppercase_trie::del_in(char *c){
	if(find_in(c)){
		int len=strlen(c);
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(*c)]==0){
				tr[pt][getnum(*c)]=new_node();
			}
			pt=tr[pt][getnum(*c)];
			i++;
			c++;
		}
		num[pt]--;
		Size[pt]--;
	}
}

void uppercase_trie::del_in(string str){
	if(find_in(str)){
		int len=str.length();
		int pt=1,i=0;
		while(i<len){
			Size[pt]--;
			if(tr[pt][getnum(str[i])]==0){
				tr[pt][getnum(str[i])]=new_node();
			}
			pt=tr[pt][getnum(str[i])];
			i++;
		}
		num[pt]--;
		Size[pt]--;	
	}
}

const int uppercase_trie::query(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return num[pt];
}

const int uppercase_trie::query(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return num[pt];
}

const bool uppercase_trie::find_in(char *c){
	return (bool)query(c);
}

const bool uppercase_trie::find_in(string str){
	return (bool)query(str);
}

const int uppercase_trie::prefix_in(char *c){
	int len=strlen(c);
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(*c)]==0){
			tr[pt][getnum(*c)]=new_node();
		}
		pt=tr[pt][getnum(*c)];
		i++;
		c++;
	}
	return Size[pt];
}

const int uppercase_trie::prefix_in(string str){
	int len=str.length();
	int pt=1,i=0;
	while(i<len){
		if(tr[pt][getnum(str[i])]==0){
			tr[pt][getnum(str[i])]=new_node();
		}
		pt=tr[pt][getnum(str[i])];
		i++;
	}
	return Size[pt];
}

uppercase_trie::uppercase_trie(void){
	n=1;
}

void uppercase_trie::insert(char *c){
	insert_in(c);
}

void uppercase_trie::insert(string str){
	insert_in(str);
}

void uppercase_trie::del(char *c){
	del_in(c);
}

void uppercase_trie::del(string str){
	del_in(str);
}

const int uppercase_trie::count(char *c){
	return query(c);
}

const int uppercase_trie::count(string str){
	return query(str);
}

const bool uppercase_trie::find(char *c){
	return find_in(c);
}

const bool uppercase_trie::find(string str){
	return find_in(str);
}

const int uppercase_trie::prefix(char *c){
	return prefix_in(c);
}

const int uppercase_trie::prefix(string str){
	return prefix_in(str);
}

int uppercase_trie::getnum(char x){
	return x-'A';
}

/*******************************************************************************/

class range_node{
	private:
		int left;
		int right;
		int v;
		range_node(void);
		range_node(int l,int r,int val);
		friend class range_weighed_tree;
};

range_node::range_node(void){
	left=0;
	right=0;
	v=0;
}

range_node::range_node(int l,int r,int val){
	left=l;
	right=r;
	v=val;
}



class range_weighed_tree{
	private:
		int n;
		range_node tr[MAXN];
		int num;
		int root[MAXNUM];
		int value_range;
		int a[MAXNUM];
		int c[MAXNUM];
		int teml[MAXNUM];
		int temln;
		int temr[MAXNUM];
		int temrn;
		int new_node(void);
		int new_node(int v);
		void buildin_empty(int p,int l,int r);
		void build_empty(void);
		void buildin_a(int p,int l,int r,int v);
		void build_a(void);
		void add_single(int k,int l,int r,int p,int v);
		int query_single(int k,int l,int r,int p);
		int range_query_single(int k,int l,int r,int pl,int pr);
		int kthonpos(int p,int l,int r,int k);
		void add_in(const int delta,const int p);
		void minus_in(const int delta,const int p);
		void replace_in(const int value,const int p);
		int find_in(const int value,const int pl,const int pr);
		int rank_in(const int v,const int pl,const int pr);
		int kth_in(int k,const int pl,const int pr);
		int pre_in(const int v,const int pl,const int pr);
		int suc_in(const int v,const int pl,const int pr);
	public:
		range_weighed_tree(void);
		range_weighed_tree(const int valuerange,const int length);
		range_weighed_tree(int *a1,int *a2);
		range_weighed_tree(int *a1,int *a2,const int valuerange);
		const SIZE_C size(void);
		const SIZE_C size(const int pl,const int pr);
		const SIZE_C valuerange(void);
		void add(const int delta,const int p);
		void minus(const int delta,const int p);
		void replace(const int val,const int p);
		const int find(const int value,const int pl,const int pr);
		const int rank(const int v,const int pl,const int pr);
		const int kth(const int k,const int pl,const int pr);
		const int pre(const int v,const int pl,const int pr);
		const int suc(const int v,const int pl,const int pr);
};
		
const SIZE_C range_weighed_tree::size(void){
	return num;
}
		
const SIZE_C range_weighed_tree::size(const int pl,const int pr){
	int rl=0,rr=0;
	int plx=pl,prx=pr;
	plx--;
	while(plx){
		rl+=tr[root[plx]].v;
		plx-=lowbit(plx);
	}
	while(prx){
		rr+=tr[root[prx]].v;
		prx-=lowbit(prx);
	}
	return rr-rl;
}
		
const SIZE_C range_weighed_tree::valuerange(void){
	return value_range;
}

int range_weighed_tree::new_node(void){
	n++;
	return n;
}

int range_weighed_tree::new_node(int v){
	n++;
	tr[n].v=v;
	return n;
}

void range_weighed_tree::buildin_empty(int p,int l,int r){
	if(l==r){
		return;
	}
	tr[p].left=new_node();
	tr[p].right=new_node();
	int mid=(l+r)>>1;
	buildin_empty(tr[p].left,l,mid);
	buildin_empty(tr[p].right,mid+1,r);
}

void range_weighed_tree::build_empty(void){
	for(int i=1;i<=num;i++){
		root[i]=new_node();
		buildin_empty(root[i],1,value_range);
	}
}

void range_weighed_tree::buildin_a(int p,int l,int r,int v){
	tr[p].v++;
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	if(v>mid){
		buildin_a(tr[p].right,mid+1,r,v);
	}else{
		buildin_a(tr[p].left,l,mid,v);
	}
}

void range_weighed_tree::build_a(void){
	build_empty();
	int p;
	for(int i=1;i<=num;i++){
		p=i;
		while(p<=num){
			buildin_a(root[p],1,value_range,a[i]);
			p+=lowbit(p);
		}
	}
}

void range_weighed_tree::add_single(int k,int l,int r,int p,int v){
	if(l==r){
		tr[k].v+=v;
		return;
	}
	int mid=(l+r)>>1;
	tr[k].v+=v;
	if(p>mid){
		add_single(tr[k].right,mid+1,r,p,v);
	}else{
		add_single(tr[k].left,l,mid,p,v);
	}
}

int range_weighed_tree::query_single(int k,int l,int r,int p){
	if(l==r){
		return tr[k].v;
	}
	int mid=(l+r)>>1;
	if(p>mid){
		return query_single(tr[k].right,mid+1,r,p);
	}else{
		return query_single(tr[k].left,l,mid,p);
	}
}

int range_weighed_tree::range_query_single(int k,int l,int r,int pl,int pr){
	if(inrange(l,r,pl,pr)){
		return tr[k].v;
	}
	if(outofrange(l,r,pl,pr)){
		return 0;
	}
	int mid=(l+r)>>1;
	return range_query_single(tr[k].left,l,mid,pl,pr)+range_query_single(tr[k].right,mid+1,r,pl,pr);
}

int range_weighed_tree::kthonpos(int p,int l,int r,int k){
	if(l==r){
		return l;
	}
	int mid=(l+r)>>1;
	if(k<=tr[tr[p].left].v){
		return kthonpos(tr[p].left,l,mid,k);
	}else{
		return kthonpos(tr[p].right,mid+1,r,k-tr[tr[p].left].v);
	}
}

void range_weighed_tree::add_in(const int delta,const int p){
	int px=p;
	while(px<=num){
		add_single(root[px],1,value_range,a[p],-1);
		px+=lowbit(px);
	}
	px=p;
	a[p]+=delta;
	while(px<=num){
		add_single(root[px],1,value_range,a[p],1);
		px+=lowbit(px);
	}
}

void range_weighed_tree::minus_in(const int delta,const int p){
	int px=p;
	while(px<=num){
		add_single(root[px],1,value_range,a[p],-1);
		px+=lowbit(px);
	}
	px=p;
	a[p]-=delta;
	while(px<=num){
		add_single(root[px],1,value_range,a[p],1);
		px+=lowbit(px);
	}
}

void range_weighed_tree::replace_in(const int value,const int p){
	int px=p;
	while(px<=num){
		add_single(root[px],1,value_range,a[p],-1);
		px+=lowbit(px);
	}
	px=p;
	a[p]=value;
	while(px<=num){
		add_single(root[px],1,value_range,a[p],1);
		px+=lowbit(px);
	}
}

int range_weighed_tree::find_in(const int value,const int pl,const int pr){
	int s1=0,s2=0;
	int plx=pl-1,prx=pr;
	while(plx){
		s1+=query_single(root[plx],1,value_range,value);
		plx-=lowbit(plx);
	}
	while(prx){
		s2+=query_single(root[prx],1,value_range,value);
		prx-=lowbit(prx);
	}
	return s2-s1;
}

int range_weighed_tree::rank_in(const int v,const int pl,const int pr){
	if(v==1){
		return 1;
	}
	int r1=0,r2=0;
	int plx=pl-1,prx=pr;
	while(plx){
		r1+=range_query_single(root[plx],1,value_range,1,v-1);
		plx-=lowbit(plx);
	}
	while(prx){
		r2+=range_query_single(root[prx],1,value_range,1,v-1);
		prx-=lowbit(prx);
	}
	return r2-r1+1;
}

int range_weighed_tree::kth_in(int k,const int pl,const int pr){
	temln=0;
	temrn=0;
	int plx=pl-1;
	int prx=pr;
	while(plx){
		teml[temln]=root[plx];
		temln++;
		plx-=lowbit(plx);
	}
	while(prx){
		temr[temrn]=root[prx];
		temrn++;
		prx-=lowbit(prx);
	}
	int l,r,mid,s=0;
	l=1;
	r=value_range;
	while(1){
		if(l==r){
			return l;
		}
		s=0;
		mid=(l+r)>>1;
		for(int i=0;i<temrn;i++){
			s+=tr[tr[temr[i]].left].v;
		}
		for(int i=0;i<temln;i++){
			s-=tr[tr[teml[i]].left].v;
		}
		if(k<=s){
			for(int i=0;i<temrn;i++){
				temr[i]=tr[temr[i]].left;
			}
			for(int i=0;i<temln;i++){
				teml[i]=tr[teml[i]].left;
			}
			r=mid;
		}else{
			for(int i=0;i<temrn;i++){
				temr[i]=tr[temr[i]].right;
			}
			for(int i=0;i<temln;i++){
				teml[i]=tr[teml[i]].right;
			}
			l=mid+1;
			k-=s;
		}
	}
}

int range_weighed_tree::pre_in(const int v,const int pl,const int pr){
	int rk=rank_in(v,pl,pr);
	if(rk==1){
		return -INF;
	}
	else{
		return kth_in(rk-1,pl,pr);
	}
}

int range_weighed_tree::suc_in(const int v,const int pl,const int pr){
	int rk=rank_in(v,pl,pr);
	int tot=find_in(v,pl,pr);
	if(rk==pr-pl+1||rk+tot-1>=pr-pl+1){
		return INF;
	}
	else{
		return kth_in(rk+tot,pl,pr);
	}
}

range_weighed_tree::range_weighed_tree(void){
	n=0;
	value_range=MAXNUM;
	num=MAXNUM;
	build_empty();
}

range_weighed_tree::range_weighed_tree(const int valuerange,const int length){
	n=0;
	value_range=valuerange;
	num=length;
	build_empty();
}

range_weighed_tree::range_weighed_tree(int *a1,int *a2){
	n=0;
	num=a2-a1;
	value_range=0;
	for(int i=1;i<=num;i++){
		a[i]=*a1;
		a1++;
		if(a[i]>value_range){
			value_range=a[i];
		}
	}
	build_a();
}

range_weighed_tree::range_weighed_tree(int *a1,int *a2,const int valuerange){
	n=0;
	num=a2-a1;
	value_range=valuerange;
	for(int i=1;i<=num;i++){
		a[i]=*a1;
		a1++;
		if(a[i]>value_range){
			value_range=a[i];
		}
	}
	build_a();
}

void range_weighed_tree::add(const int delta,const int p){
	add_in(delta,p);
}

void range_weighed_tree::replace(const int val,const int p){
	replace_in(val,p);
}

void range_weighed_tree::minus(const int delta,const int p){
	minus_in(delta,p);
}

const int range_weighed_tree::rank(const int v,const int pl,const int pr){
	return rank_in(v,pl,pr);
}

const int range_weighed_tree::find(const int value,const int pl,const int pr){
	return find_in(value,pl,pr);
}

const int range_weighed_tree::kth(const int k,const int pl,const int pr){
	return kth_in(k,pl,pr);
}

const int range_weighed_tree::pre(const int v,const int pl,const int pr){
	return pre_in(v,pl,pr);
}

const int range_weighed_tree::suc(const int v,const int pl,const int pr){
	return suc_in(v,pl,pr);
}

/*******************************************************************************/


template <typename cactus>
class range_fhq_node{
	friend class range_fhq_treap<cactus>;
	private:
		int left;
		int right;
		cactus v;
		int cnt;
		int size;
		int priority;
		range_fhq_node(void);
		range_fhq_node(const cactus val);
		range_fhq_node(int l,int r,cactus val,int num,int sz,int prio);
};

template <typename cactus>
range_fhq_node<cactus>::range_fhq_node(void){
	left=0;
	right=0;
	cnt=0;
	size=0;
	priority=0;
}

template <typename cactus>
range_fhq_node<cactus>::range_fhq_node(const cactus val){
	left=0;
	right=0;
	cnt=1;
	size=1;
	v=val;
	priority=0;
}

template <typename cactus>
range_fhq_node<cactus>::range_fhq_node(int l,int r,cactus val,int num,int sz,int prio){
	left=l;
	right=r;
	cnt=num;
	size=1;
	v=val;
	priority=prio;
}



template <typename cactus>
class range_fhq_treap{
	private:
		int n;
		range_fhq_node<cactus> tr[MAXN];
		int a[MAXNUM];
		int num;
		int root[MAXNUM];
		int em[MAXN];
		int emn;
		int seed=311519;
		cactus maxx=-INF;
		cactus minx=INF;
		inline const int rand_c(void){return seed=(int)((seed*4827153LL+114514)%2147483647);}
		int new_node(void);
		int new_node(cactus v);
		void resize(int p);
		void merge_in(int &r,int p1,int p2);
		void split_by_size(int r,int sz,int &p1,int &p2);
		void split_by_value(int r,cactus v,int &p1,int &p2);
		cactus max_single(int p);
		cactus min_single(int p);
		int rank_single(int nx,cactus v);
		int single_tot(int nx,cactus v);
		int query_tot(int pl,int pr,cactus v);
		void replace_single(int nx,int v1,int v2);
		void build_single(int p,cactus v);
		void build_in(void);
		void init(cactus *a1,cactus *a2);
		void replace_in(int p,cactus value);
		void add_in(int p,cactus delta);
		void minus_in(int p,cactus delta);
		int rank_in(int pl,int pr,cactus value);
		cactus kth_in(int pl,int pr,int k);
		cactus pre_in(int pl,int pr,cactus val);
		cactus suc_in(int pl,int pr,cactus val);
		cactus max_in(int pl,int pr);
		cactus min_in(int pl,int pr);
	public:
		explicit range_fhq_treap(cactus *a1,cactus *a2);
		const SIZE_C size(void);
		const SIZE_C size(const int pl,const int pr);
		void replace(const int p,const cactus value);
		void add(const int p,const cactus delta);
		void minus(const int p,const cactus delta);
		const int rank(const int pl,const int pr,const cactus value);
		const cactus kth(const int pl,const int pr,const int k);
		const cactus pre(const int pl,const int pr,const cactus value);
		const cactus suc(const int pl,const int pr,const cactus value);
		const cactus max(const int pl,const int pr);
		const cactus min(const int pl,const int pr);
};
			
template <typename cactus>
const SIZE_C range_fhq_treap<cactus>::size(void){
	return num;
}
		
template <typename cactus>
const SIZE_C range_fhq_treap<cactus>::size(const int pl,const int pr){
	int rl=0,rr=0;
	int plx=pl,prx=pr;
	plx--;
	while(plx){
		rl+=tr[root[plx]].size;
		plx-=lowbit(plx);
	}
	while(prx){
		rr+=tr[root[prx]].size;
		prx-=lowbit(prx);
	}
	return rr-rl;
}

template <typename cactus>
int range_fhq_treap<cactus>::new_node(void){
	if(emn){
		tr[em[emn-1]]=range_fhq_node<cactus>();
		emn--;
		return em[emn];
	}else{
		n++;
		return n;
	}
}

template <typename cactus>
int range_fhq_treap<cactus>::new_node(cactus v){
	if(emn){
		tr[em[emn-1]]=range_fhq_node<cactus>(0,0,v,1,1,rand_c());
		emn--;
		return em[emn];
	}else{
		n++;
		tr[n]=range_fhq_node<cactus>(0,0,v,1,1,rand_c());
		return n;
	}
}

template <typename cactus>
void range_fhq_treap<cactus>::resize(int p){
	tr[p].size=tr[p].cnt+tr[tr[p].left].size+tr[tr[p].right].size;
}

template <typename cactus>
void range_fhq_treap<cactus>::merge_in(int &r,int p1,int p2){
	if(p1==0||p2==0){
		r=p1+p2;
		return;
	}
	if(tr[p1].priority<tr[p2].priority){
		r=p1;
		merge_in(tr[r].right,tr[p1].right,p2);
	}else{
		r=p2;
		merge_in(tr[r].left,p1,tr[p2].left);
	}
	resize(r);
}

template <typename cactus>
void range_fhq_treap<cactus>::split_by_size(int r,int sz,int &p1,int &p2){
	//the algorithm makes sure that the sz_th element falls in p1
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(tr[tr[r].left].size+tr[r].cnt>=sz){
		p1=r;
		split_by_size(tr[r].right,sz-tr[tr[r].left].size-tr[r].cnt,tr[p1].right,p2);
		resize(p1);
	}else{
		p2=r;
		split_by_size(tr[r].left,sz,p1,tr[p2].left);
		resize(p2);
	}
}

template <typename cactus>
void range_fhq_treap<cactus>::split_by_value(int r,cactus v,int &p1,int &p2){
	if(r==0){
		p1=0;
		p2=0;
		return;
	}
	if(tr[r].v<=v){
		p1=r;
		split_by_value(tr[r].right,v,tr[p1].right,p2);
		resize(p1);
	}else{
		p2=r;
		split_by_value(tr[r].left,v,p1,tr[p2].left);
		resize(p2);
	}
}

template <typename cactus>
cactus range_fhq_treap<cactus>::max_single(int p){
	if(tr[p].right==0){
		return tr[p].v;
	}
	return max_single(tr[p].right);
}

template <typename cactus>
cactus range_fhq_treap<cactus>::min_single(int p){
	if(tr[p].left==0){
		return tr[p].v;
	}
	return max_single(tr[p].left);
}

template <typename cactus>
int range_fhq_treap<cactus>::rank_single(int nx,cactus v){//minused by 1
	int r1=0,r2=0;
	split_by_value(root[nx],v-1,r1,r2);
	int ret=tr[r1].size;
	merge_in(root[nx],r1,r2);
	return ret;
}

template <typename cactus>
int range_fhq_treap<cactus>::single_tot(int nx,cactus v){
	int r1,r2,r3;
	split_by_value(root[nx],v-1,r1,r2);
	split_by_value(r2,v,r2,r3);
	int rt=0;
	if(r2){
		rt=tr[r2].size;
		merge_in(r2,r2,r3);
		merge_in(root[nx],r1,r2);
	}else{
		merge_in(root[nx],r1,r3);
	}
	return rt;
}

template <typename cactus>
int range_fhq_treap<cactus>::query_tot(int pl,int pr,cactus v){
	int v1=0,v2=0;
	pl--;
	while(pl){
		v1+=single_tot(pl,v);
		pl-=lowbit(pl);
	}
	while(pr){
		v2+=single_tot(pr,v);
		pr-=lowbit(pr);
	}
	return v2-v1;
}

template <typename cactus>
void range_fhq_treap<cactus>::replace_single(int nx,int v1,int v2){
	int r1=0,r2=0,r3=0;
	split_by_value(root[nx],v1-1,r1,r2);
	split_by_value(r2,v1,r2,r3);
	if(r2==0){
		merge_in(root[nx],r1,r3);
		return;
	}else{
		if(tr[r2].cnt>1){
			tr[r2].cnt--;
			tr[r2].size--;
			merge_in(r2,r2,r3);
			merge_in(root[nx],r1,r2);
		}else{
			em[emn]=r2;
			emn++;
			merge_in(root[nx],r1,r3);
		}
	}
	r1=0,r2=0,r3=0;
	split_by_value(root[nx],v2-1,r1,r2);
	split_by_value(r2,v2,r2,r3);
	if(r2==0){
		r2=new_node(v2);
		merge_in(r2,r2,r3);
		merge_in(root[nx],r1,r2);
		return;
	}else{
		tr[r2].cnt++;
		tr[r2].size++;
		merge_in(r2,r2,r3);
		merge_in(root[nx],r1,r2);
		return;
	}
}

template <typename cactus>
void range_fhq_treap<cactus>::build_single(int p,cactus v){
	if(root[p]==0){
		root[p]=new_node(v);
		return;
	}
	int r1=0,r2=0,r3=0;
	split_by_value(root[p],v-1,r1,r2);
	split_by_value(r2,v,r2,r3);
	if(r2==0){
		r2=new_node(v);
		merge_in(r2,r2,r3);
		merge_in(root[p],r1,r2);
	}else{
		tr[r2].cnt++;
		tr[r2].size++;
		merge_in(r2,r2,r3);
		merge_in(root[p],r1,r2);
	}
}

template <typename cactus>
void range_fhq_treap<cactus>::build_in(void){
	int px;
	for(int i=1;i<=num;i++){
		px=i;
		while(px<=num){
			build_single(px,a[i]);
			px+=lowbit(px);
		}
	}
}

template <typename cactus>
void range_fhq_treap<cactus>::init(cactus *a1,cactus *a2){
	tr[0].cnt=0;
	tr[0].size=0;
	num=a2-a1;
	emn=0;
	for(int i=1;i<=num;i++){
		a[i]=*a1;
		if(maxx<a[i]){
			maxx=a[i];
		}
		if(minx>a[i]){
			minx=a[i];
		}
		a1++;
		root[i]=0;
	}
	build_in();
}

template <typename cactus>
void range_fhq_treap<cactus>::replace_in(int p,cactus value){
	if(maxx<value){
		maxx=value;
	}
	if(minx>value){
		minx=value;
	}
	int px=p;
	while(px<=num){
		replace_single(px,a[p],value);
		px+=lowbit(px);
	}
	a[p]=value;
}

template <typename cactus>
void range_fhq_treap<cactus>::add_in(int p,cactus delta){
	replace_in(p,a[p]+delta);
}

template <typename cactus>
void range_fhq_treap<cactus>::minus_in(int p,cactus delta){
	replace_in(p,a[p]-delta);
}

template <typename cactus>
int range_fhq_treap<cactus>::rank_in(int pl,int pr,cactus value){
	int rl=0,rr=0;
	pl--;
	while(pl){
		rl+=rank_single(pl,value);
		pl-=lowbit(pl);
	}
	while(pr){
		rr+=rank_single(pr,value);
		pr-=lowbit(pr);
	}
	return rr-rl+1;
}

template <typename cactus>
cactus range_fhq_treap<cactus>::kth_in(int pl,int pr,int k){
	if(k<1){
		return -INF;
	}
	if(k>(pr-pl+1)){
		return INF;
	}
	cactus l=minx,r=maxx;
	while(l<r){
		int mid=(l+r+1)>>1;
		if(rank_in(pl,pr,mid)>k){
			r=mid-1;
		}else{
			l=mid;
		}
	}
	return r;
}

template <typename cactus>
cactus range_fhq_treap<cactus>::pre_in(int pl,int pr,cactus val){
	return kth_in(pl,pr,rank_in(pl,pr,val)-1);
}

template <typename cactus>
cactus range_fhq_treap<cactus>::suc_in(int pl,int pr,cactus val){
	return kth_in(pl,pr,rank_in(pl,pr,val)+query_tot(pl,pr,val));
}

template <typename cactus>
cactus range_fhq_treap<cactus>::max_in(int pl,int pr){
	return kth_in(pl,pr,pr-pl+1);
}

template <typename cactus>
cactus range_fhq_treap<cactus>::min_in(int pl,int pr){
	return kth_in(pl,pr,pr-pl+1);
}

template <typename cactus>
range_fhq_treap<cactus>::range_fhq_treap(cactus *a1,cactus *a2){
	init(a1,a2);
}

template <typename cactus>
void range_fhq_treap<cactus>::replace(const int p,const cactus value){
	replace_in(p,value);
}

template <typename cactus>
void range_fhq_treap<cactus>::add(const int p,const cactus delta){
	add_in(p,delta);
}

template <typename cactus>
void range_fhq_treap<cactus>::minus(const int p,const cactus delta){
	minus_in(p,delta);
}

template <typename cactus>
const int range_fhq_treap<cactus>::rank(const int pl,const int pr,const cactus value){
	return rank_in(pl,pr,value);
}

template <typename cactus>
const cactus range_fhq_treap<cactus>::kth(const int pl,const int pr,const int k){
	return kth_in(pl,pr,k);
}

template <typename cactus>
const cactus range_fhq_treap<cactus>::pre(const int pl,const int pr,const cactus value){
	return pre_in(pl,pr,value);
}

template <typename cactus>
const cactus range_fhq_treap<cactus>::suc(const int pl,const int pr,const cactus value){
	return suc_in(pl,pr,value);
}

template <typename cactus>
const cactus range_fhq_treap<cactus>::max(const int pl,const int pr){
	return max_in(pl,pr);
}

template <typename cactus>
const cactus range_fhq_treap<cactus>::min(const int pl,const int pr){
	return min_in(pl,pr);
}

/*******************************************************************************/

template <typename cactus>
class leftist_node{
	friend class min_leftist_tree <cactus>;
	friend class max_leftist_tree <cactus>;
	private:
		int left;
		int right;
		int rt;
		int dist;
		int id;
		cactus v;
		leftist_node(void);
		leftist_node(int l,int r,int root,int dis,int id_,cactus value);
		const bool operator>(leftist_node b);
		const bool operator<(leftist_node b);
};

template <typename cactus>
leftist_node<cactus>::leftist_node(void){
	left=0;
	right=0;
	rt=0;
	dist=-1;
	id=0;
}

template <typename cactus>
leftist_node<cactus>::leftist_node(int l,int r,int root,int dis,int id_,cactus value){
	left=l;
	right=r;
	rt=root;
	dist=dis;
	id=id_;
	v=value;
}

template <typename cactus>
const bool leftist_node<cactus>::operator>(leftist_node b){
	if(v==b.v){
		return id>b.id;
	}else{
		return v>b.v;
	}
}

template <typename cactus>
const bool leftist_node<cactus>::operator<(leftist_node b){
	if(v==b.v){
		return id<b.id;
	}else{
		return v<b.v;
	}
}



template <typename cactus>
class min_leftist_tree{
	private:
		int n;
		int timer;
		leftist_node <cactus> tr[MAXNUM];
		int new_node(int l,int r,int root,int dis,int id_,cactus value);
		void init(cactus *a1,cactus *a2);
		int get_root(int p);
		void merge_inline(int &r,int p1,int p2);
		void re_dis(int p);
		bool merge_in(int p1,int p2);
		int insert_in(cactus v,int p);
		void del_in(int p);
		cactus min_in(int p);
	public:
		explicit min_leftist_tree(cactus *a1,cactus *a2);
		const SIZE_C size(void);
		const bool merge(const int p1,const int p2);
		const int insert(const cactus v,const int p);
		const int root(const int p);
		void del(const int p);
		const cactus value(const int p);
		const cactus min(const int p);
};

template <typename cactus>
int min_leftist_tree<cactus>::new_node(int l,int r,int root,int dis,int id_,cactus value){
	n++;
	tr[n]=leftist_node <cactus> (l,r,root,dis,id_,value);
	return n;
}

template <typename cactus>
void min_leftist_tree<cactus>::init(cactus *a1,cactus *a2){
	n=0;
	int num=a2-a1;
	for(int i=1;i<=num;i++){
		new_node(0,0,i,-1,i,*a1);
		a1++;
	}
	timer=num+1;
}

template <typename cactus>
int min_leftist_tree<cactus>::get_root(int p){
	if(tr[p].rt==p){
		return p;
	}else{
		return (tr[p].rt=get_root(tr[p].rt));
	}
}

template <typename cactus>
void min_leftist_tree<cactus>::merge_inline(int &r,int p1,int p2){
	if(p1==0||p2==0){
		if(p1){
			tr[p1].rt=p1;
		}
		if(p2){
			tr[p2].rt=p2;
		}
		r=p1+p2;
		re_dis(r);
		return;
	}
	if(tr[p1]>tr[p2]){
		swap_c(p1,p2);
	}
	tr[p2].rt=p1;
	r=p1;
	merge_inline(tr[r].right,tr[p1].right,p2);
	tr[tr[p1].right].rt=p1;
	re_dis(r);
}

template <typename cactus>
void min_leftist_tree<cactus>::re_dis(int p){
	if(p<1){
		return;
	}
	int disl,disr;
	if(tr[p].left==0){
		disl=-1;
	}else{
		disl=tr[tr[p].left].dist+1;
	}
	if(tr[p].right==0){
		disr=-1;
	}else{
		disr=tr[tr[p].right].dist+1;
	}
	if(disl<disr){
		swap_c(tr[p].left,tr[p].right);
		tr[p].dist=disl;
	}else{
		tr[p].dist=disr;
	}
}

template <typename cactus>
bool min_leftist_tree<cactus>::merge_in(int p1,int p2){
	int r;
	p1=get_root(p1);
	p2=get_root(p2);
	if(p1==p2){
		return 0;
	}
	merge_inline(r,p1,p2);
	return 1;
}

template <typename cactus>
int min_leftist_tree<cactus>::insert_in(cactus v,int p){
	int ret=new_node(0,0,0,-1,timer,v);
	tr[ret].rt=ret;
	merge_in(ret,p);
	return ret;
}

template <typename cactus>
void min_leftist_tree<cactus>::del_in(int p){
	p=get_root(p);
	tr[tr[p].right].rt=tr[p].right;
	tr[tr[p].left].rt=tr[p].left;
	merge_inline(tr[p].rt,tr[p].left,tr[p].right);
}

template <typename cactus>
cactus min_leftist_tree<cactus>::min_in(int p){
	p=get_root(p);
	return tr[p].v;
}

template <typename cactus>
min_leftist_tree<cactus>::min_leftist_tree(cactus *a1,cactus *a2){
	init(a1,a2);
}

template <typename cactus>
const SIZE_C min_leftist_tree<cactus>::size(void){
	return timer-1;
}

template <typename cactus>
const bool min_leftist_tree<cactus>::merge(const int p1,const int p2){
	return merge_in(p1,p2);
}

template <typename cactus>
const int min_leftist_tree<cactus>::insert(const cactus v,const int p){
	return insert_in(v,p);
}

template <typename cactus>
const int min_leftist_tree<cactus>::root(const int p){
	return get_root(p);
}

template <typename cactus>
void min_leftist_tree<cactus>::del(const int p){
	del_in(p);
}

template <typename cactus>
const cactus min_leftist_tree<cactus>::value(const int p){
	return tr[p].v;
}

template <typename cactus>
const cactus min_leftist_tree<cactus>::min(const int p){
	return min_in(p);
}



template <typename cactus>
class max_leftist_tree{
	private:
		int n;
		int timer;
		leftist_node <cactus> tr[MAXNUM];
		int new_node(int l,int r,int root,int dis,int id_,cactus value);
		void init(cactus *a1,cactus *a2);
		int get_root(int p);
		void merge_inline(int &r,int p1,int p2);
		void re_dis(int p);
		bool merge_in(int p1,int p2);
		int insert_in(cactus v,int p);
		void del_in(int p);
		cactus max_in(int p);
	public:
		explicit max_leftist_tree(cactus *a1,cactus *a2);
		const SIZE_C size(void);
		const bool merge(const int p1,const int p2);
		const int insert(const cactus v,const int p);
		const int root(const int p);
		void del(const int p);
		const cactus value(const int p);
		const cactus max(const int p);
};

template <typename cactus>
int max_leftist_tree<cactus>::new_node(int l,int r,int root,int dis,int id_,cactus value){
	n++;
	tr[n]=leftist_node <cactus> (l,r,root,dis,id_,value);
	return n;
}

template <typename cactus>
void max_leftist_tree<cactus>::init(cactus *a1,cactus *a2){
	n=0;
	int num=a2-a1;
	for(int i=1;i<=num;i++){
		new_node(0,0,i,-1,i,*a1);
		a1++;
	}
	timer=num+1;
}

template <typename cactus>
int max_leftist_tree<cactus>::get_root(int p){
	if(tr[p].rt==p){
		return p;
	}else{
		return (tr[p].rt=get_root(tr[p].rt));
	}
}

template <typename cactus>
void max_leftist_tree<cactus>::merge_inline(int &r,int p1,int p2){
	if(p1==0||p2==0){
		if(p1){
			tr[p1].rt=p1;
		}
		if(p2){
			tr[p2].rt=p2;
		}
		r=p1+p2;
		re_dis(r);
		return;
	}
	if(tr[p1]<tr[p2]){
		swap_c(p1,p2);
	}
	tr[p2].rt=p1;
	r=p1;
	merge_inline(tr[r].right,tr[p1].right,p2);
	tr[tr[p1].right].rt=p1;
	re_dis(r);
}

template <typename cactus>
void max_leftist_tree<cactus>::re_dis(int p){
	if(p<1){
		return;
	}
	int disl,disr;
	if(tr[p].left==0){
		disl=-1;
	}else{
		disl=tr[tr[p].left].dist+1;
	}
	if(tr[p].right==0){
		disr=-1;
	}else{
		disr=tr[tr[p].right].dist+1;
	}
	if(disl<disr){
		swap_c(tr[p].left,tr[p].right);
		tr[p].dist=disl;
	}else{
		tr[p].dist=disr;
	}
}

template <typename cactus>
bool max_leftist_tree<cactus>::merge_in(int p1,int p2){
	int r;
	p1=get_root(p1);
	p2=get_root(p2);
	if(p1==p2){
		return 0;
	}
	merge_inline(r,p1,p2);
	return 1;
}

template <typename cactus>
int max_leftist_tree<cactus>::insert_in(cactus v,int p){
	int ret=new_node(0,0,0,-1,timer,v);
	tr[ret].rt=ret;
	merge_in(ret,p);
	return ret;
}

template <typename cactus>
void max_leftist_tree<cactus>::del_in(int p){
	p=get_root(p);
	tr[tr[p].right].rt=tr[p].right;
	tr[tr[p].left].rt=tr[p].left;
	merge_inline(tr[p].rt,tr[p].left,tr[p].right);
}

template <typename cactus>
cactus max_leftist_tree<cactus>::max_in(int p){
	p=get_root(p);
	return tr[p].v;
}

template <typename cactus>
max_leftist_tree<cactus>::max_leftist_tree(cactus *a1,cactus *a2){
	init(a1,a2);
}

template <typename cactus>
const SIZE_C max_leftist_tree<cactus>::size(void){
	return timer-1;
}

template <typename cactus>
const bool max_leftist_tree<cactus>::merge(const int p1,const int p2){
	return merge_in(p1,p2);
}

template <typename cactus>
const int max_leftist_tree<cactus>::insert(const cactus v,const int p){
	return insert_in(v,p);
}

template <typename cactus>
const int max_leftist_tree<cactus>::root(const int p){
	return get_root(p);
}

template <typename cactus>
void max_leftist_tree<cactus>::del(const int p){
	del_in(p);
}

template <typename cactus>
const cactus max_leftist_tree<cactus>::value(const int p){
	return tr[p].v;
}

template <typename cactus>
const cactus max_leftist_tree<cactus>::max(const int p){
	return max_in(p);
}

/*******************************************************************************/

class inverse_element{
	private:
		int MOD_P;
		int ie[MAXN+3];
		void init(const int range);
		const int query_in(const int a);
	public:
		explicit inverse_element(const int P);
		explicit inverse_element(const int P,const int range);
		const int query(const int a);
		const int operator[](const int a);
};

void inverse_element::init(const int range){
	ie[0]=1;
	ie[1]=1;
	for(int i=2;i<=range;i++){
		ie[i]=((MOD_P-MOD_P/i)*ie[(MOD_P%i)])%MOD_P;
	}
}

const int inverse_element::query_in(const int a){
	return ie[a];
}

inverse_element::inverse_element(const int P){
	MOD_P=P;
	init(MOD_P-1);
}

inverse_element::inverse_element(const int P,const int range){
	MOD_P=P;
	init(range);
}

const int inverse_element::query(const int a){
	return ie[a];
}

const int inverse_element::operator[](const int a){
	return ie[a];
}

/*******************************************************************************/

template <typename cactus>
class discrete_array{//address starts from 1
	private:
		int n;
		int ax[MAXN];
		cactus d[MAXN];
		void init(cactus *a1,cactus *a2);
	public:
		explicit discrete_array(cactus *a1,cactus *a2);
		const SIZE_C size(void){return n;}
		int* operator()(const int addr);//points to the discreted array
		const cactus operator[](const int addr);//returns the original value
		int* operator+(const int addr);
};

template <typename cactus>
void discrete_array<cactus>::init(cactus *a1,cactus *a2){
	pair_c <cactus,int> a[MAXN];
	n=a2-a1;
	for(int i=1;i<=n;i++){
		a[i].x1=*a1;
		a[i].x2=i;
		a1++;
	}
	sort(a+1,a+n+1);
	int pt=1;
	d[1]=a[1].x1;
	ax[a[1].x2]=1;
	for(int i=2;i<=n;i++){
		if(a[i].x1==a[i-1].x1){
			ax[a[i].x2]=pt;
		}else{
			pt++;
			d[pt]=a[i].x1;
			ax[a[i].x2]=pt;
		}
	}
}

template <typename cactus>
discrete_array<cactus>::discrete_array(cactus *a1,cactus *a2){
	init(a1,a2);
}

template <typename cactus>
int* discrete_array<cactus>::operator()(const int addr){
	return ax+addr;
}

template <typename cactus>
int* discrete_array<cactus>::operator+(const int addr){
	return ax+addr;
}

template <typename cactus>
const cactus discrete_array<cactus>::operator[](const int addr){
	return d[addr];
}

/*******************************************************************************/

class t01_node{
	friend class trie01;
	private:
		int left;
		int right;
		int cnt;
		int size;
		t01_node(void);
		t01_node(int l,int r,int cnt_,int sz);
};

t01_node::t01_node(void){
	left=0;
	right=0;
	cnt=0;
	size=0;
}
		
t01_node::t01_node(int l,int r,int cnt_,int sz){
	left=l;
	right=r;
	cnt=cnt_;
	size=sz;
}



class trie01{
	private:
		int n;
		t01_node tr[MAXN];
		int szn;
		int new_node(void);
		int new_node(bool v,int pa,int l,int r);
		int find_p(int v);
		void insert_in(int v);
		bool del_in(int v);
		void self_add_in(void);
		int find_in(int v);
		int kth_in(int k);
		int rank_in(int v);
		int pre_in(int v);
		int suc_in(int v);
	public:
		trie01(void);
		const SIZE_C size(void);
		void insert(const int v);
		const bool del(const int v);
		void add(void);
		void operator++(void);
		const int find(const int v);
		const int kth(const int k);
		const int rank(const int v);
		const int pre(const int v);
		const int suc(const int v);
};

int trie01::new_node(void){
	n++;
	return n;
}

int trie01::new_node(bool v,int pa,int l,int r){
	n++;
	if(v){
		tr[pa].right=n;
	}else{
		tr[pa].left=n;
	}
	tr[n]=t01_node(l,r,0,0);
	return n;
}

int trie01::find_p(int v){
	int p=1;
	for(int i=MAXH;i>=0;i--){
		if(kth_bool(v,i)){
			p=tr[p].right;
		}else{
			p=tr[p].left;
		}
		if(p==0){
			return 0;
		}
	}
	return p;
}

void trie01::insert_in(int v){
	szn++;
	int p=1;
	int from;
	for(int i=MAXH;i>=0;i--){
		tr[p].size++;
		from=p;
		if(kth_bool(v,i)){
			p=tr[p].right;
		}else{
			p=tr[p].left;
		}
		if(p==0){
			p=new_node(kth_bool(v,i),from,0,0);
		}
	}
	tr[p].size++;
	tr[p].cnt++;
}

bool trie01::del_in(int v){
	int px=find_p(v);
	if(px){
		if(tr[px].cnt<1){
			return 0;
		}
		tr[px].cnt--;
		tr[px].size--;
		int p=1;
		for(int i=MAXH;i>=0;i--){
			tr[p].size--;
			if(kth_bool(v,i)){
				p=tr[p].right;
			}else{
				p=tr[p].left;
			}
		}
		szn--;
		return 1;
	}else{
		return 0;
	}
}

void trie01::self_add_in(void){
	int p=1;
	while(p){
		swap_c(tr[p].left,tr[p].right);
		p=tr[p].right;
	}
}

int trie01::find_in(int v){
	int px=find_p(v);
	if(px==0){
		return 0;
	}else{
		return tr[px].cnt;
	}
}

int trie01::kth_in(int k){
	int p=1;
	int rr=0;
	for(int i=MAXH;i>=0;i--){
		if(tr[tr[p].left].size<k){
			k-=tr[tr[p].left].size;
			p=tr[p].right;
			rr+=(1<<i);
		}else{
			p=tr[p].left;
		}
	}
	return rr;
}

int trie01::rank_in(int v){
	int ret=0;
	int p=1;
	for(int i=MAXH;i>=0;i--){
		if(kth_bool(v,i)){
			ret+=tr[tr[p].left].size;
			p=tr[p].right;
		}else{
			p=tr[p].left;
		}
		if(p==0){
			return 0;
		}
	}
	return ret+1;
}

int trie01::pre_in(int v){
	int xx=rank_in(v);
	if(xx==1||xx==0){
		return -INF;
	}
	return kth_in(xx-1);
}

int trie01::suc_in(int v){
	int xx=rank_in(v+1);
	if(xx){
		return kth_in(xx);
	}
	return INF;
}

trie01::trie01(void){
	n=1;
	tr[1]=t01_node(0,0,0,0);
}

const SIZE_C trie01::size(void){
	return szn;
}

void trie01::insert(const int v){
	insert_in(v);
}

const bool trie01::del(const int v){
	return del_in(v);
}

void trie01::add(void){
	self_add_in();
}

void trie01::operator++(void){
	self_add_in();
}

const int trie01::find(const int v){
	return find_in(v);
}

const int trie01::kth(const int k){
	return kth_in(k);
}

const int trie01::rank(const int v){
	return rank_in(v);
}

const int trie01::pre(const int v){
	return pre_in(v);
}

const int trie01::suc(const int v){
	return suc_in(v);
}

void operator++(trie01 t){
	t.add();
}

/*******************************************************************************/

template <typename cactus>
class exGCD{
	private:
		cactus a;
		cactus b;
		cactus gcdx;
		cactus d;//c=d*gcdx
		cactus c;
		cactus t_x;
		cactus t_y;
		cactus dx;
		cactus dy;
		void works(cactus t_a,cactus t_b);
		void pre_pair(void);
		void suc_pair(void);
		cactus find_x(cactus y);
		cactus find_y(cactus x);
	public:
		explicit exGCD(const cactus a_,const cactus b_,const cactus d_);
		const pair_c <cactus,cactus> solution(void);
		void previous(void);
		void next(void);
		const pair_c <cactus,cactus> operator()(void);
		const cactus x(const cactus y);
		const cactus y(const cactus x);
		const cactus x(void);
		const cactus y(void);
		void operator++(void);
		void operator--(void);
		void operator++(int);
		void operator--(int);
};

template <typename cactus>
void exGCD<cactus>::works(cactus t_a,cactus t_b){
	if(t_b==0){
		t_x=d;
		t_y=0;
		return;
	}
	works(t_b,t_a%t_b);
	cactus t;
	t=t_y;
	t_y=t_x-t_a/t_b*t_y;
	t_x=t;
}

template <typename cactus>
void exGCD<cactus>::pre_pair(void){
	t_x-=dx;
	t_y-=dy;
}

template <typename cactus>
void exGCD<cactus>::suc_pair(void){
	t_x+=dx;
	t_y+=dy;
}

template <typename cactus>
cactus exGCD<cactus>::find_x(cactus y){
	return (c-y*b)/a;
}

template <typename cactus>
cactus exGCD<cactus>::find_y(cactus x){
	return (c-x*a)/b;
}

template <typename cactus>
exGCD<cactus>::exGCD(const cactus a_,const cactus b_,const cactus d_){
	a=a_;
	b=b_;
	gcdx=gcd_c(a,b);
	d=d_/gcdx;
	c=d*gcdx;
	works(a,b);
	cactus d=lcm_c(a,b);
	dx=d/a;
	dy=-d/b;
}

template <typename cactus>
const pair_c <cactus,cactus> exGCD<cactus>::solution(void){
	return pair_c<cactus,cactus>(t_x,t_y);
}

template <typename cactus>
void exGCD<cactus>::previous(void){
	pre_pair();
}

template <typename cactus>
void exGCD<cactus>::next(void){
	suc_pair();
}

template <typename cactus>
const pair_c <cactus,cactus> exGCD<cactus>::operator()(void){
	return solution();
}

template <typename cactus>
const cactus exGCD<cactus>::x(const cactus y){
	return find_x(y);
}

template <typename cactus>
const cactus exGCD<cactus>::y(const cactus x){
	return find_y(x);
}

template <typename cactus>
const cactus exGCD<cactus>::x(void){
	return t_x;
}

template <typename cactus>
const cactus exGCD<cactus>::y(void){
	return t_y;
}

template <typename cactus>
void exGCD<cactus>::operator++(void){
	suc_pair();
}

template <typename cactus>
void exGCD<cactus>::operator--(void){
	pre_pair();
}


template <typename cactus>
void exGCD<cactus>::operator++(int){
	suc_pair();
}

template <typename cactus>
void exGCD<cactus>::operator--(int){
	pre_pair();
}

/*******************************************************************************/

template <typename cactus>
class area_sum_node{
	friend class area_sum_calc<cactus>;
	friend class area_sum<cactus>;
	private:
		cactus xl;
		cactus xr;
		cactus y;
		int ix;
		bool sgn;
		area_sum_node(cactus xl_,cactus xr_,cactus y_,int ix_,bool sgn_);
	public:
		area_sum_node(void);
		bool operator<(area_sum_node a);
};

template <typename cactus>
area_sum_node<cactus>::area_sum_node(void){
	return;
}

template <typename cactus>
area_sum_node<cactus>::area_sum_node(cactus xl_,cactus xr_,cactus y_,int ix_,bool sgn_){
	xl=xl_;
	xr=xr_;
	y=y_;
	ix=ix_;
	sgn=sgn_;
}

template <typename cactus>
bool area_sum_node<cactus>::operator<(area_sum_node a){
	return y<a.y;
}



template <typename cactus>
class area_sum_ndtr{
	friend class area_sum_calc<cactus>;
	friend class area_sum<cactus>;
	private:
		cactus sum;//current
		cactus s;
		int cnt;
		area_sum_ndtr(void);
		area_sum_ndtr(cactus sum_,cactus s_,int cnt_);
};

template <typename cactus>
area_sum_ndtr<cactus>::area_sum_ndtr(void){
	return;
}

template <typename cactus>
area_sum_ndtr<cactus>::area_sum_ndtr(cactus sum_,cactus s_,int cnt_){
	sum=sum_;
	s=s_;
	cnt=cnt_;
}



template <typename cactus>
class area_sum_calc{
	friend class area_sum<cactus>;
	private:
		int n;
		int nx;
		int pt;
		area_sum_node<cactus> nd[MAXN];
		pair_c<cactus,int> x_st[MAXN];
		int dn[MAXN];
		cactus px[MAXN];
		int num;
		area_sum_ndtr<cactus> tr[MAXN];
		cactus ret;
		void build(int l,int r,int p);
		void add_e(int p,int l,int r);
		void mns_e(int p,int l,int r);
		void ins_x(int l,int r,int lx,int rx,int p);
		void del_x(int l,int r,int lx,int rx,int p);
		cactus sum_(void);
		void init(array_c<area_sum_node<cactus>,MAXN>& arr);
		void discrete(void);
		void moveline(void);
		cactus sum_in(void);
		explicit area_sum_calc(array_c<area_sum_node<cactus>,MAXN>& arr,int n_);
		cactus sum(void);
};

template <typename cactus>
void area_sum_calc<cactus>::build(int l,int r,int p){
	if(l==r){
		tr[p].s=px[l+1]-px[l];
		return;
	}
	int mid=(l+r)>>1;
	build(l,mid,p<<1);
	build(mid+1,r,(p<<1)+1);
	tr[p].s=tr[p<<1].s+tr[(p<<1)+1].s;
}

template <typename cactus>
void area_sum_calc<cactus>::add_e(int p,int l,int r){
	if(tr[p].cnt==0){
		tr[p].cnt++;
		tr[p].sum=tr[p].s;
	}else{
		tr[p].cnt++;
		return;
	}
}

template <typename cactus>
void area_sum_calc<cactus>::mns_e(int p,int l,int r){
	if(tr[p].cnt==1){
		tr[p].cnt--;
		if(l!=r){
			tr[p].sum=tr[p<<1].sum+tr[(p<<1)+1].sum;
		}else{
			tr[p].sum=0;
		}
	}else{
		tr[p].cnt--;
		return;
	}
}

template <typename cactus>
void area_sum_calc<cactus>::ins_x(int l,int r,int lx,int rx,int p){
	if(inrange(l,r,lx,rx)){
		add_e(p,l,r);
		return;
	}
	if(outofrange(l,r,lx,rx)){
		return;
	}
	int mid=(l+r)>>1;
	ins_x(l,mid,lx,rx,p<<1);
	ins_x(mid+1,r,lx,rx,(p<<1)+1);
	if(tr[p].cnt==0){
		tr[p].sum=tr[p<<1].sum+tr[(p<<1)+1].sum;
	}
}

template <typename cactus>
void area_sum_calc<cactus>::del_x(int l,int r,int lx,int rx,int p){
	if(inrange(l,r,lx,rx)){
		mns_e(p,l,r);
		return;
	}
	if(outofrange(l,r,lx,rx)){
		return;
	}
	int mid=(l+r)>>1;
	del_x(l,mid,lx,rx,p<<1);
	del_x(mid+1,r,lx,rx,(p<<1)+1);
	if(tr[p].cnt==0){
		tr[p].sum=tr[p<<1].sum+tr[(p<<1)+1].sum;
	}
}

template <typename cactus>
cactus area_sum_calc<cactus>::sum_(void){
	return tr[1].sum;
}

template <typename cactus>
void area_sum_calc<cactus>::init(array_c<area_sum_node<cactus>,MAXN>& arr){
	nx=n*2;
	for(int i=1;i<=nx;i++){
		nd[i]=arr[i];
		if(i&1){
			x_st[i].x1=nd[i].xl;
			x_st[i].x2=i;
			x_st[i+1].x1=nd[i].xr;
			x_st[i+1].x2=i+1;
		}
	}
	discrete();
	build(1,num,1);
}

template <typename cactus>
void area_sum_calc<cactus>::discrete(void){
	sort(x_st+1,x_st+nx+1);
	sort(nd+1,nd+nx+1);
	pt=1;
	dn[x_st[1].x2]=1;
	px[1]=x_st[1].x1;
	for(int i=2;i<=nx;i++){
		if(x_st[i].x1!=x_st[i-1].x1){
			pt++;
			px[pt]=x_st[pt].x1;
		}
		dn[x_st[pt].x2]=pt;
	}
	num=pt-1;
}

template <typename cactus>
void area_sum_calc<cactus>::moveline(void){
	ins_x(1,num,dn[nd[1].ix*2-1],dn[nd[1].ix*2]-1,1);
	for(int i=2;i<nx;i++){
		if(nd[i].sgn){
			ins_x(1,num,dn[nd[i].ix*2-1],dn[nd[i].ix*2]-1,1);
		}else{
			del_x(1,num,dn[nd[i].ix*2-1],dn[nd[i].ix*2]-1,1);
		}
		if(nd[i].y!=nd[i-1].y){
			ret+=sum_()*(nd[i].y-nd[i-1].y);
		}
	}
	ret+=sum_()*(nd[nx].y-nd[nx-1].y);
}

template <typename cactus>
cactus area_sum_calc<cactus>::sum_in(void){
	moveline();
	return ret;
}

template <typename cactus>
area_sum_calc<cactus>::area_sum_calc(array_c<area_sum_node<cactus>,MAXN>& arr,int n_){
	n=n_;
	ret=0;
	init(arr);
}

template <typename cactus>
cactus area_sum_calc<cactus>::sum(void){
	return sum_in();
}



template <typename cactus>
class area_sum{
	private:
		int n;
		array_c<area_sum_node<cactus>,MAXN> arr;
		void insert_in(cactus xl__,cactus yl__,cactus xr__,cactus yr__);
		const cactus sum_in(void);
	public:
		area_sum(void);
		const SIZE_C size(void){return n;}
		void insert(const cactus xl,const cactus yl,const cactus xr,const cactus yr);
		const cactus sum(void);
};

template <typename cactus>
void area_sum<cactus>::insert_in(cactus xl__,cactus yl__,cactus xr__,cactus yr__){
	n++;
	arr.insert(area_sum_node<cactus>(xl__,xr__,yl__,n,1));
	arr.insert(area_sum_node<cactus>(xl__,xr__,yr__,n,0));
}

template <typename cactus>
const cactus area_sum<cactus>::sum_in(void){
	area_sum_calc<cactus> asc(arr,n);
	return asc.sum();
}

template <typename cactus>
area_sum<cactus>::area_sum(void){
	n=0;
	return;
}

template <typename cactus>
void area_sum<cactus>::insert(const cactus xl,const cactus yl,const cactus xr,const cactus yr){
	insert_in(xl,yl,xr,yr);
}

template <typename cactus>
const cactus area_sum<cactus>::sum(void){
	return sum_in();
}

/*******************************************************************************/

class AC_automaton_node{
	friend class AC_automaton;
	private:
		int ch[52];
		int fail;
		int cnt;
		int in;
		int vis;
		int ans;
		AC_automaton_node(void){}
		int& operator[](int addr){return ch[addr];}
};

class AC_automaton{
	private:
		const int MAXCHSZ=52;
		int n;
		int num;
		bool flag;
		int ptx[MAXN];
		array_c<> ret;
		AC_automaton_node tr[MAXN];
		queue_c <int> q;
		int transxc(char c);
		int new_node(void);
		bool ins(string s);
		bool ins(char* s);
		void buildin(void);
		void query(string s);
		void query(char *s);
		void topo(void);
	public:
		AC_automaton(void);
		const SIZE_C size(void);
		const SIZE_C editable(void);
		const bool insert(const string s);
		const bool insert(const char* s);
		const array_c<>& match(const string s);
		const array_c<>& match(const char* s);
};

int AC_automaton::transxc(char c){
	if(c>='a'){
		return c-'a';
	}else{
		return c-'A'+26;
	}
}

int AC_automaton::new_node(void){
	n++;
	return n;
}

bool AC_automaton::ins(string s){
	if(flag){
		return 0;
	}
	int p=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		if(tr[p][transxc(s[i])]){
			p=tr[p][transxc(s[i])];
		}else{
			tr[p][transxc(s[i])]=new_node();
			p=tr[p][transxc(s[i])];
		}
	}
	tr[p].cnt++;
	num++;
	ptx[num]=p;
	return 1;
}

bool AC_automaton::ins(char* s){
	if(flag){
		return 0;
	}
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		if(tr[pt][transxc(*s)]){
			pt=tr[pt][transxc(*s)];
		}else{
			tr[pt][transxc(*s)]=new_node();
			pt=tr[pt][transxc(*s)];
		}
		s++;
	}
	tr[pt].cnt++;
	num++;
	ptx[num]=pt;
	return 1;
}

void AC_automaton::buildin(void){
	ret.n=num;
	flag=1;
	q.clear();
	for(int i=0;i<MAXCHSZ;i++){
		if(tr[0][i]){
			q.insert(tr[0][i]);
		}
	}
	int t;
	while(!q.empty()){
		t=q.front();
		q.pop();
		for(int i=0;i<MAXCHSZ;i++){
			if(tr[t][i]){
				tr[tr[t][i]].fail=tr[tr[t].fail][i];
				tr[tr[tr[t].fail][i]].in++;
				q.insert(tr[t][i]);
			}else{
				tr[t][i]=tr[tr[t].fail][i];
			}
		}
	}
}

void AC_automaton::query(string s){
	int pt=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(s[i])];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
	}
}

void AC_automaton::query(char *s){
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(*s)];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
		s++;
	}
}

void AC_automaton::topo(void){
	q.clear();
	int inx[MAXN];
	for(int i=1;i<=n;i++){
		inx[i]=tr[i].in;
		if(!tr[i].in){
			q.insert(i);
		}
	}
	int j,f;
	while(!q.empty()){
		j=q.front();
		q.pop();
		f=tr[j].fail;
		if(tr[f].cnt){
			tr[f].vis+=tr[j].ans;
		}
		tr[f].ans+=tr[j].ans;
		inx[f]--;
		if(!inx[f]){
			q.insert(f);
		}
	}
	for(int i=1;i<=num;i++){
		ret[i]=tr[ptx[i]].vis;
	}
}

AC_automaton::AC_automaton(void){
	n=0;
	flag=0;
	num=0;
}

const SIZE_C AC_automaton::size(void){
	return num;
}

const SIZE_C AC_automaton::editable(void){
	return flag;
}

const bool AC_automaton::insert(const string s){
	return ins(s);
}

const bool AC_automaton::insert(const char* s){
	return ins(s);
}

const array_c<>& AC_automaton::match(const string s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}

const array_c<>& AC_automaton::match(const char* s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}



class upper_AC_automaton_node{
	friend class upper_AC_automaton;
	private:
		int ch[26];
		int fail;
		int cnt;
		int in;
		int vis;
		int ans;
		upper_AC_automaton_node(void){}
		int& operator[](int addr){return ch[addr];}
};

class upper_AC_automaton{
	private:
		const int MAXCHSZ=26;
		int n;
		int num;
		bool flag;
		int ptx[MAXN];
		array_c<> ret;
		upper_AC_automaton_node tr[MAXN];
		queue_c <int> q;
		int transxc(char c);
		int new_node(void);
		bool ins(string s);
		bool ins(char* s);
		void buildin(void);
		void query(string s);
		void query(char *s);
		void topo(void);
	public:
		upper_AC_automaton(void);
		const SIZE_C size(void);
		const SIZE_C editable(void);
		const bool insert(const string s);
		const bool insert(const char* s);
		const array_c<>& match(const string s);
		const array_c<>& match(const char* s);
};

int upper_AC_automaton::transxc(char c){
	return c-'A';
}

int upper_AC_automaton::new_node(void){
	n++;
	return n;
}

bool upper_AC_automaton::ins(string s){
	if(flag){
		return 0;
	}
	int p=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		if(tr[p][transxc(s[i])]){
			p=tr[p][transxc(s[i])];
		}else{
			tr[p][transxc(s[i])]=new_node();
			p=tr[p][transxc(s[i])];
		}
	}
	tr[p].cnt++;
	num++;
	ptx[num]=p;
	return 1;
}

bool upper_AC_automaton::ins(char* s){
	if(flag){
		return 0;
	}
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		if(tr[pt][transxc(*s)]){
			pt=tr[pt][transxc(*s)];
		}else{
			tr[pt][transxc(*s)]=new_node();
			pt=tr[pt][transxc(*s)];
		}
		s++;
	}
	tr[pt].cnt++;
	num++;
	ptx[num]=pt;
	return 1;
}

void upper_AC_automaton::buildin(void){
	ret.n=num;
	flag=1;
	q.clear();
	for(int i=0;i<MAXCHSZ;i++){
		if(tr[0][i]){
			q.insert(tr[0][i]);
		}
	}
	int t;
	while(!q.empty()){
		t=q.front();
		q.pop();
		for(int i=0;i<MAXCHSZ;i++){
			if(tr[t][i]){
				tr[tr[t][i]].fail=tr[tr[t].fail][i];
				tr[tr[tr[t].fail][i]].in++;
				q.insert(tr[t][i]);
			}else{
				tr[t][i]=tr[tr[t].fail][i];
			}
		}
	}
}

void upper_AC_automaton::query(string s){
	int pt=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(s[i])];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
	}
}

void upper_AC_automaton::query(char *s){
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(*s)];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
		s++;
	}
}

void upper_AC_automaton::topo(void){
	q.clear();
	int inx[MAXN];
	for(int i=1;i<=n;i++){
		inx[i]=tr[i].in;
		if(!tr[i].in){
			q.insert(i);
		}
	}
	int j,f;
	while(!q.empty()){
		j=q.front();
		q.pop();
		f=tr[j].fail;
		if(tr[f].cnt){
			tr[f].vis+=tr[j].ans;
		}
		tr[f].ans+=tr[j].ans;
		inx[f]--;
		if(!inx[f]){
			q.insert(f);
		}
	}
	for(int i=1;i<=num;i++){
		ret[i]=tr[ptx[i]].vis;
	}
}

upper_AC_automaton::upper_AC_automaton(void){
	n=0;
	flag=0;
	num=0;
}

const SIZE_C upper_AC_automaton::size(void){
	return num;
}

const SIZE_C upper_AC_automaton::editable(void){
	return flag;
}

const bool upper_AC_automaton::insert(const string s){
	return ins(s);
}

const bool upper_AC_automaton::insert(const char* s){
	return ins(s);
}

const array_c<>& upper_AC_automaton::match(const string s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}

const array_c<>& upper_AC_automaton::match(const char* s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}



class lower_AC_automaton_node{
	friend class lower_AC_automaton;
	private:
		int ch[26];
		int fail;
		int cnt;
		int in;
		int vis;
		int ans;
		lower_AC_automaton_node(void){}
		int& operator[](int addr){return ch[addr];}
};

class lower_AC_automaton{
	private:
		const int MAXCHSZ=26;
		int n;
		int num;
		bool flag;
		int ptx[MAXN];
		array_c<> ret;
		lower_AC_automaton_node tr[MAXN];
		queue_c <int> q;
		int transxc(char c);
		int new_node(void);
		bool ins(string s);
		bool ins(char* s);
		void buildin(void);
		void query(string s);
		void query(char *s);
		void topo(void);
	public:
		lower_AC_automaton(void);
		const SIZE_C size(void);
		const SIZE_C editable(void);
		const bool insert(const string s);
		const bool insert(const char* s);
		const array_c<>& match(const string s);
		const array_c<>& match(const char* s);
};

int lower_AC_automaton::transxc(char c){
	return c-'a';
}

int lower_AC_automaton::new_node(void){
	n++;
	return n;
}

bool lower_AC_automaton::ins(string s){
	if(flag){
		return 0;
	}
	int p=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		if(tr[p][transxc(s[i])]){
			p=tr[p][transxc(s[i])];
		}else{
			tr[p][transxc(s[i])]=new_node();
			p=tr[p][transxc(s[i])];
		}
	}
	tr[p].cnt++;
	num++;
	ptx[num]=p;
	return 1;
}

bool lower_AC_automaton::ins(char* s){
	if(flag){
		return 0;
	}
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		if(tr[pt][transxc(*s)]){
			pt=tr[pt][transxc(*s)];
		}else{
			tr[pt][transxc(*s)]=new_node();
			pt=tr[pt][transxc(*s)];
		}
		s++;
	}
	tr[pt].cnt++;
	num++;
	ptx[num]=pt;
	return 1;
}

void lower_AC_automaton::buildin(void){
	ret.n=num;
	flag=1;
	q.clear();
	for(int i=0;i<MAXCHSZ;i++){
		if(tr[0][i]){
			q.insert(tr[0][i]);
		}
	}
	int t;
	while(!q.empty()){
		t=q.front();
		q.pop();
		for(int i=0;i<MAXCHSZ;i++){
			if(tr[t][i]){
				tr[tr[t][i]].fail=tr[tr[t].fail][i];
				tr[tr[tr[t].fail][i]].in++;
				q.insert(tr[t][i]);
			}else{
				tr[t][i]=tr[tr[t].fail][i];
			}
		}
	}
}

void lower_AC_automaton::query(string s){
	int pt=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(s[i])];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
	}
}

void lower_AC_automaton::query(char *s){
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(*s)];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
		s++;
	}
}

void lower_AC_automaton::topo(void){
	q.clear();
	int inx[MAXN];
	for(int i=1;i<=n;i++){
		inx[i]=tr[i].in;
		if(!tr[i].in){
			q.insert(i);
		}
	}
	int j,f;
	while(!q.empty()){
		j=q.front();
		q.pop();
		f=tr[j].fail;
		if(tr[f].cnt){
			tr[f].vis+=tr[j].ans;
		}
		tr[f].ans+=tr[j].ans;
		inx[f]--;
		if(!inx[f]){
			q.insert(f);
		}
	}
	for(int i=1;i<=num;i++){
		ret[i]=tr[ptx[i]].vis;
	}
}

lower_AC_automaton::lower_AC_automaton(void){
	n=0;
	flag=0;
	num=0;
}

const SIZE_C lower_AC_automaton::size(void){
	return num;
}

const SIZE_C lower_AC_automaton::editable(void){
	return flag;
}

const bool lower_AC_automaton::insert(const string s){
	return ins(s);
}

const bool lower_AC_automaton::insert(const char* s){
	return ins(s);
}

const array_c<>& lower_AC_automaton::match(const string s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}

const array_c<>& lower_AC_automaton::match(const char* s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}



class ascii_AC_automaton_node{
	friend class ascii_AC_automaton;
	private:
		int ch[26];
		int fail;
		int cnt;
		int in;
		int vis;
		int ans;
		ascii_AC_automaton_node(void){}
		int& operator[](int addr){return ch[addr];}
};

class ascii_AC_automaton{
	private:
		const int MAXCHSZ=128;
		int n;
		int num;
		bool flag;
		int ptx[MAXN];
		array_c<> ret;
		ascii_AC_automaton_node tr[MAXN];
		queue_c <int> q;
		int transxc(char c);
		int new_node(void);
		bool ins(string s);
		bool ins(char* s);
		void buildin(void);
		void query(string s);
		void query(char *s);
		void topo(void);
	public:
		ascii_AC_automaton(void);
		const SIZE_C size(void);
		const SIZE_C editable(void);
		const bool insert(const string s);
		const bool insert(const char* s);
		const array_c<>& match(const string s);
		const array_c<>& match(const char* s);
};

int ascii_AC_automaton::transxc(char c){
	return (int)c;
}

int ascii_AC_automaton::new_node(void){
	n++;
	return n;
}

bool ascii_AC_automaton::ins(string s){
	if(flag){
		return 0;
	}
	int p=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		if(tr[p][transxc(s[i])]){
			p=tr[p][transxc(s[i])];
		}else{
			tr[p][transxc(s[i])]=new_node();
			p=tr[p][transxc(s[i])];
		}
	}
	tr[p].cnt++;
	num++;
	ptx[num]=p;
	return 1;
}

bool ascii_AC_automaton::ins(char* s){
	if(flag){
		return 0;
	}
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		if(tr[pt][transxc(*s)]){
			pt=tr[pt][transxc(*s)];
		}else{
			tr[pt][transxc(*s)]=new_node();
			pt=tr[pt][transxc(*s)];
		}
		s++;
	}
	tr[pt].cnt++;
	num++;
	ptx[num]=pt;
	return 1;
}

void ascii_AC_automaton::buildin(void){
	ret.n=num;
	flag=1;
	q.clear();
	for(int i=0;i<MAXCHSZ;i++){
		if(tr[0][i]){
			q.insert(tr[0][i]);
		}
	}
	int t;
	while(!q.empty()){
		t=q.front();
		q.pop();
		for(int i=0;i<MAXCHSZ;i++){
			if(tr[t][i]){
				tr[tr[t][i]].fail=tr[tr[t].fail][i];
				tr[tr[tr[t].fail][i]].in++;
				q.insert(tr[t][i]);
			}else{
				tr[t][i]=tr[tr[t].fail][i];
			}
		}
	}
}

void ascii_AC_automaton::query(string s){
	int pt=0;
	int len=s.length();
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(s[i])];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
	}
}

void ascii_AC_automaton::query(char *s){
	int pt=0;
	int len=strlen(s);
	for(int i=0;i<len;i++){
		pt=tr[pt][transxc(*s)];
		tr[pt].vis+=(bool)tr[pt].cnt;
		tr[pt].ans++;
		s++;
	}
}

void ascii_AC_automaton::topo(void){
	q.clear();
	int inx[MAXN];
	for(int i=1;i<=n;i++){
		inx[i]=tr[i].in;
		if(!tr[i].in){
			q.insert(i);
		}
	}
	int j,f;
	while(!q.empty()){
		j=q.front();
		q.pop();
		f=tr[j].fail;
		if(tr[f].cnt){
			tr[f].vis+=tr[j].ans;
		}
		tr[f].ans+=tr[j].ans;
		inx[f]--;
		if(!inx[f]){
			q.insert(f);
		}
	}
	for(int i=1;i<=num;i++){
		ret[i]=tr[ptx[i]].vis;
	}
}

ascii_AC_automaton::ascii_AC_automaton(void){
	n=0;
	flag=0;
	num=0;
}

const SIZE_C ascii_AC_automaton::size(void){
	return num;
}

const SIZE_C ascii_AC_automaton::editable(void){
	return flag;
}

const bool ascii_AC_automaton::insert(const string s){
	return ins(s);
}

const bool ascii_AC_automaton::insert(const char* s){
	return ins(s);
}

const array_c<>& ascii_AC_automaton::match(const string s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}

const array_c<>& ascii_AC_automaton::match(const char* s){
	if(!flag){
		buildin();
		flag=1;
	}
	query(s);
	topo();
	return ret;
}

/*******************************************************************************/

#define LCT link_cut_trees
template <typename cactus,cactus (*fx)(cactus,cactus)>
class lct_node{
	friend class link_cut_trees<cactus,fx>;
	private:
		int left;
		int right;
		int p;
		cactus v;
		bool tag;//reverse
		int sz;
		lct_node(void);
		lct_node(int l,int r,int pa,cactus val,bool rtag,int size);
};

template <typename cactus,cactus (*fx)(cactus,cactus)>
lct_node<cactus,fx>::lct_node(void){
	left=0;
	right=0;
	p=0;
	tag=0;
	sz=0;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
lct_node<cactus,fx>::lct_node(int l,int r,int pa,cactus val,bool rtag,int size){
	left=l;
	right=r;
	p=pa;
	v=val;
	tag=rtag;
	sz=size;
}



template <typename cactus,cactus (*fx)(cactus,cactus)>
class link_cut_trees{
	private:
		int n;
		cactus a[MAXN];
		lct_node<cactus,fx> tr[MAXN];
		bool lrson(int p);
		bool isroot(int p);
		void pushdown(int p);
		void pushup(int p);
		void update(int p);
		void downdate(int p);
		void lr_rotate(int p);
		void splay(int p);
		int access(int p);
		int find_root_p(int p);
		void make_root(int p);
		void split(int p1,int p2);
		int root_in(int p);
		bool find_in(int p1,int p2);
		void cut_unlocked_in(int p1,int p2);
		bool cut_in(int p1,int p2);
		void link_unlocked_in(int p1,int p2);
		bool link_in(int p1,int p2);
		cactus sum_unlocked_in(int p1,int p2);
		cactus sum_in(int p1,int p2);
		void replace_in(int p,cactus v);
		void add_in(int p,cactus v);
		void minus_in(int p,cactus v);
		void renew_in(int p);
	public:
		explicit link_cut_trees(const int num);
		explicit link_cut_trees(cactus* a1,cactus* a2);
		const SIZE_C size(void);
		const int operator()(const int p);
		const int root(const int p);
		const bool find(const int p1,const int p2);
		void cut_unlocked(const int p1,const int p2);
		const bool cut(const int p1,const int p2);
		void link_unlocked(const int p1,const int p2);
		const bool link(const int p1,const int p2);
		const cactus sum_unlocked(const int p1,const int p2);
		const cactus sum(const int p1,const int p2);
		void replace(const int p,const cactus v);
		void add(const int p,const cactus v);
		void minus(const int p,const cactus v);
		cactus& operator[](const int addr);
		cactus& value(const int p);
		void renew(const int p);
};

template <typename cactus,cactus (*fx)(cactus,cactus)>
bool link_cut_trees<cactus,fx>::lrson(int p){
	return p==tr[tr[p].p].right;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
bool link_cut_trees<cactus,fx>::isroot(int p){
	return (p!=tr[tr[p].p].left)&&(p!=tr[tr[p].p].right)&&p;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::pushdown(int p){
	if(tr[p].tag){
		tr[p].tag=0;
		if(tr[p].left){
			swap_c(tr[tr[p].left].left,tr[tr[p].left].right);
			tr[tr[p].left].tag^=1;
		}
		if(tr[p].right){
			swap_c(tr[tr[p].right].left,tr[tr[p].right].right);
			tr[tr[p].right].tag^=1;
		}
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::pushup(int p){
	tr[0].sz=tr[0].v=0;
	tr[p].v=fx(tr[tr[p].left].v,fx(tr[tr[p].right].v,a[p]));
	tr[p].sz=tr[tr[p].left].sz+tr[tr[p].right].sz+1;
	tr[0].sz=tr[0].v=0;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::update(int p){
	if(!isroot(p)){
		update(tr[p].p);
	}
	pushdown(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::downdate(int p){
	pushup(p);
	if(!isroot(p)){
		downdate(tr[p].p);
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::lr_rotate(int p){
	int pt=tr[p].p;
	int f=tr[pt].p;
	if(lrson(p)){
		if(!isroot(pt)){
			if(lrson(pt)){
				tr[f].right=p;
			}else{
				tr[f].left=p;
			}
		}
		tr[p].p=f;
		tr[pt].p=p;
		tr[pt].right=tr[p].left;
		if(tr[p].left){
			tr[tr[p].left].p=pt;
		}
		tr[p].left=pt;
		pushup(pt);
		pushup(p);
	}else{
		if(!isroot(pt)){
			if(lrson(pt)){
				tr[f].right=p;
			}else{
				tr[f].left=p;
			}
		}
		tr[p].p=f;
		tr[pt].p=p;
		tr[pt].left=tr[p].right;
		if(tr[p].right){
			tr[tr[p].right].p=pt;
		}
		tr[p].right=pt;
		pushup(pt);
		pushup(p);
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::splay(int p){
	update(p);
	pushdown(tr[p].left);
	pushdown(tr[p].right);
	int f;
	while(!isroot(p)){
		f=tr[p].p;
		if(f&&!isroot(f)){
			lr_rotate(lrson(p)==lrson(f)?f:p);
		}
		if(!isroot(p)){
			lr_rotate(p);
		}
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
int link_cut_trees<cactus,fx>::access(int p){
	int f=0;
	while(p){
		splay(p);
		tr[p].right=f;
		pushup(p);
		f=p;
		p=tr[p].p;
	}
	return f;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
int link_cut_trees<cactus,fx>::find_root_p(int p){
	access(p);
	splay(p);
	pushdown(p);
	while(tr[p].left){
		p=tr[p].left;
		pushdown(p);
	}
	splay(p);
	return p;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::make_root(int p){
	p=access(p);
	tr[p].tag^=1;
	swap_c(tr[p].left,tr[p].right);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::split(int p1,int p2){
	make_root(p1);
	access(p2);
	splay(p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
int link_cut_trees<cactus,fx>::root_in(int p){
	return find_root_p(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
bool link_cut_trees<cactus,fx>::find_in(int p1,int p2){
	return find_root_p(p1)==find_root_p(p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::cut_unlocked_in(int p1,int p2){
	make_root(p1);
	find_root_p(p2);
	tr[p2].p=0;
	tr[p1].right=0;
	pushup(p1);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
bool link_cut_trees<cactus,fx>::cut_in(int p1,int p2){
	make_root(p1);
	if(find_root_p(p2)!=p1||tr[p1].sz>2){
		return 0;
	}else{
		tr[p2].p=0;
		tr[p1].right=0;
		pushup(p1);
		return 1;
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::link_unlocked_in(int p1,int p2){
	make_root(p1);
	splay(p1);
	tr[p1].p=p2;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
bool link_cut_trees<cactus,fx>::link_in(int p1,int p2){
	if(find_root_p(p1)!=find_root_p(p2)){
		make_root(p1);
		splay(p1);
		tr[p1].p=p2;
		return 1;
	}else{
		return 0;
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
cactus link_cut_trees<cactus,fx>::sum_unlocked_in(int p1,int p2){
	split(p1,p2);
	return tr[p2].v;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
cactus link_cut_trees<cactus,fx>::sum_in(int p1,int p2){
	if(p1==p2){
		return a[p1];
	}else{
		if(find_root_p(p1)==find_root_p(p2)){
			split(p1,p2);
			return tr[p2].v;
		}else{
			return 0;
		}
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::replace_in(int p,cactus v){
	splay(p);
	a[p]=v;
	pushup(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::add_in(int p,cactus v){
	splay(p);
	a[p]+=v;
	pushup(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::minus_in(int p,cactus v){
	splay(p);
	a[p]-=v;
	pushup(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::renew_in(int p){
	splay(p);
	pushup(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
link_cut_trees<cactus,fx>::link_cut_trees(const int num){
	n=num;
	for(int i=1;i<=n;i++){
		tr[i]=lct_node<cactus,fx>(0,0,0,0,0,1);
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
link_cut_trees<cactus,fx>::link_cut_trees(cactus* a1,cactus* a2){
	n=a2-a1;
	cactus *ax=a1;
	for(int i=1;i<=n;i++){
		a[i]=*ax;
		ax++;
	}
	for(int i=1;i<=n;i++){
		tr[i]=lct_node<cactus,fx>(0,0,0,a[i],0,1);
	}
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const SIZE_C link_cut_trees<cactus,fx>::size(void){
	return n;
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const int link_cut_trees<cactus,fx>::operator()(const int p){
	return root_in(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const int link_cut_trees<cactus,fx>::root(const int p){
	return root_in(p);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const bool link_cut_trees<cactus,fx>::find(const int p1,const int p2){
	return find_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::cut_unlocked(const int p1,const int p2){
	cut_unlocked_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const bool link_cut_trees<cactus,fx>::cut(const int p1,const int p2){
	return cut_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::link_unlocked(const int p1,const int p2){
	link_unlocked_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const bool link_cut_trees<cactus,fx>::link(const int p1,const int p2){
	return link_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const cactus link_cut_trees<cactus,fx>::sum_unlocked(const int p1,const int p2){
	return sum_unlocked_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
const cactus link_cut_trees<cactus,fx>::sum(const int p1,const int p2){
	return sum_in(p1,p2);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::replace(const int p,const cactus v){
	replace_in(p,v);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::add(const int p,const cactus v){
	add_in(p,v);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::minus(const int p,const cactus v){
	minus_in(p,v);
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
cactus& link_cut_trees<cactus,fx>::operator[](const int addr){
	return a[addr];
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
cactus& link_cut_trees<cactus,fx>::value(const int p){
	return a[p];
}

template <typename cactus,cactus (*fx)(cactus,cactus)>
void link_cut_trees<cactus,fx>::renew(const int p){
	renew_in(p);
}



#define sum_LCT sum_link_cut_trees
template <typename cactus>
class sum_lct_node{
	friend class sum_link_cut_trees<cactus>;
	private:
		int left;
		int right;
		int p;
		cactus v;
		bool tag;//reverse
		int sz;
		sum_lct_node(void);
		sum_lct_node(int l,int r,int pa,cactus val,bool rtag,int size);
};

template <typename cactus>
sum_lct_node<cactus>::sum_lct_node(void){
	left=0;
	right=0;
	p=0;
	tag=0;
	sz=0;
}

template <typename cactus>
sum_lct_node<cactus>::sum_lct_node(int l,int r,int pa,cactus val,bool rtag,int size){
	left=l;
	right=r;
	p=pa;
	v=val;
	tag=rtag;
	sz=size;
}



template <typename cactus>
class sum_link_cut_trees{
	private:
		int n;
		cactus a[MAXN];
		sum_lct_node<cactus> tr[MAXN];
		bool lrson(int p);
		bool isroot(int p);
		void pushdown(int p);
		void pushup(int p);
		void update(int p);
		void downdate(int p);
		void lr_rotate(int p);
		void splay(int p);
		int access(int p);
		int find_root_p(int p);
		void make_root(int p);
		void split(int p1,int p2);
		int root_in(int p);
		bool find_in(int p1,int p2);
		void cut_unlocked_in(int p1,int p2);
		bool cut_in(int p1,int p2);
		void link_unlocked_in(int p1,int p2);
		bool link_in(int p1,int p2);
		cactus sum_unlocked_in(int p1,int p2);
		cactus sum_in(int p1,int p2);
		void replace_in(int p,cactus v);
		void add_in(int p,cactus v);
		void minus_in(int p,cactus v);
		void renew_in(int p);
	public:
		explicit sum_link_cut_trees(const int num);
		explicit sum_link_cut_trees(cactus* a1,cactus* a2);
		const SIZE_C size(void);
		const int operator()(const int p);
		const int root(const int p);
		const bool find(const int p1,const int p2);
		void cut_unlocked(const int p1,const int p2);
		const bool cut(const int p1,const int p2);
		void link_unlocked(const int p1,const int p2);
		const bool link(const int p1,const int p2);
		const cactus sum_unlocked(const int p1,const int p2);
		const cactus sum(const int p1,const int p2);
		void replace(const int p,const cactus v);
		void add(const int p,const cactus v);
		void minus(const int p,const cactus v);
		cactus& operator[](const int addr);
		cactus& value(const int p);
		void renew(const int p);
};

template <typename cactus>
bool sum_link_cut_trees<cactus>::lrson(int p){
	return p==tr[tr[p].p].right;
}

template <typename cactus>
bool sum_link_cut_trees<cactus>::isroot(int p){
	return (p!=tr[tr[p].p].left)&&(p!=tr[tr[p].p].right)&&p;
}

template <typename cactus>
void sum_link_cut_trees<cactus>::pushdown(int p){
	if(tr[p].tag){
		tr[p].tag=0;
		if(tr[p].left){
			swap_c(tr[tr[p].left].left,tr[tr[p].left].right);
			tr[tr[p].left].tag^=1;
		}
		if(tr[p].right){
			swap_c(tr[tr[p].right].left,tr[tr[p].right].right);
			tr[tr[p].right].tag^=1;
		}
	}
}

template <typename cactus>
void sum_link_cut_trees<cactus>::pushup(int p){
	tr[0].sz=tr[0].v=0;
	tr[p].v=tr[tr[p].left].v+tr[tr[p].right].v+a[p];
	tr[p].sz=tr[tr[p].left].sz+tr[tr[p].right].sz+1;
	tr[0].sz=tr[0].v=0;
}

template <typename cactus>
void sum_link_cut_trees<cactus>::update(int p){
	if(!isroot(p)){
		update(tr[p].p);
	}
	pushdown(p);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::downdate(int p){
	pushup(p);
	if(!isroot(p)){
		downdate(tr[p].p);
	}
}

template <typename cactus>
void sum_link_cut_trees<cactus>::lr_rotate(int p){
	int pt=tr[p].p;
	int f=tr[pt].p;
	if(lrson(p)){
		if(!isroot(pt)){
			if(lrson(pt)){
				tr[f].right=p;
			}else{
				tr[f].left=p;
			}
		}
		tr[p].p=f;
		tr[pt].p=p;
		tr[pt].right=tr[p].left;
		if(tr[p].left){
			tr[tr[p].left].p=pt;
		}
		tr[p].left=pt;
		pushup(pt);
		pushup(p);
	}else{
		if(!isroot(pt)){
			if(lrson(pt)){
				tr[f].right=p;
			}else{
				tr[f].left=p;
			}
		}
		tr[p].p=f;
		tr[pt].p=p;
		tr[pt].left=tr[p].right;
		if(tr[p].right){
			tr[tr[p].right].p=pt;
		}
		tr[p].right=pt;
		pushup(pt);
		pushup(p);
	}
}

template <typename cactus>
void sum_link_cut_trees<cactus>::splay(int p){
	update(p);
	pushdown(tr[p].left);
	pushdown(tr[p].right);
	int f;
	while(!isroot(p)){
		f=tr[p].p;
		if(f&&!isroot(f)){
			lr_rotate(lrson(p)==lrson(f)?f:p);
		}
		if(!isroot(p)){
			lr_rotate(p);
		}
	}
}

template <typename cactus>
int sum_link_cut_trees<cactus>::access(int p){
	int f=0;
	while(p){
		splay(p);
		tr[p].right=f;
		pushup(p);
		f=p;
		p=tr[p].p;
	}
	return f;
}

template <typename cactus>
int sum_link_cut_trees<cactus>::find_root_p(int p){
	access(p);
	splay(p);
	pushdown(p);
	while(tr[p].left){
		p=tr[p].left;
		pushdown(p);
	}
	splay(p);
	return p;
}

template <typename cactus>
void sum_link_cut_trees<cactus>::make_root(int p){
	p=access(p);
	tr[p].tag^=1;
	swap_c(tr[p].left,tr[p].right);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::split(int p1,int p2){
	make_root(p1);
	access(p2);
	splay(p2);
}

template <typename cactus>
int sum_link_cut_trees<cactus>::root_in(int p){
	return find_root_p(p);
}

template <typename cactus>
bool sum_link_cut_trees<cactus>::find_in(int p1,int p2){
	return find_root_p(p1)==find_root_p(p2);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::cut_unlocked_in(int p1,int p2){
	make_root(p1);
	find_root_p(p2);
	tr[p2].p=0;
	tr[p1].right=0;
	pushup(p1);
}

template <typename cactus>
bool sum_link_cut_trees<cactus>::cut_in(int p1,int p2){
	make_root(p1);
	if(find_root_p(p2)!=p1||tr[p1].sz>2){
		return 0;
	}else{
		tr[p2].p=0;
		tr[p1].right=0;
		pushup(p1);
		return 1;
	}
}

template <typename cactus>
void sum_link_cut_trees<cactus>::link_unlocked_in(int p1,int p2){
	make_root(p1);
	splay(p1);
	tr[p1].p=p2;
}

template <typename cactus>
bool sum_link_cut_trees<cactus>::link_in(int p1,int p2){
	if(find_root_p(p1)!=find_root_p(p2)){
		make_root(p1);
		splay(p1);
		tr[p1].p=p2;
		return 1;
	}else{
		return 0;
	}
}

template <typename cactus>
cactus sum_link_cut_trees<cactus>::sum_unlocked_in(int p1,int p2){
	split(p1,p2);
	return tr[p2].v;
}

template <typename cactus>
cactus sum_link_cut_trees<cactus>::sum_in(int p1,int p2){
	if(p1==p2){
		return a[p1];
	}else{
		if(find_root_p(p1)==find_root_p(p2)){
			split(p1,p2);
			return tr[p2].v;
		}else{
			return 0;
		}
	}
}

template <typename cactus>
void sum_link_cut_trees<cactus>::replace_in(int p,cactus v){
	splay(p);
	a[p]=v;
	pushup(p);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::add_in(int p,cactus v){
	splay(p);
	a[p]+=v;
	pushup(p);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::minus_in(int p,cactus v){
	splay(p);
	a[p]-=v;
	pushup(p);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::renew_in(int p){
	splay(p);
	pushup(p);
}

template <typename cactus>
sum_link_cut_trees<cactus>::sum_link_cut_trees(const int num){
	n=num;
	for(int i=1;i<=n;i++){
		tr[i]=sum_lct_node<cactus>(0,0,0,0,0,1);
	}
}

template <typename cactus>
sum_link_cut_trees<cactus>::sum_link_cut_trees(cactus* a1,cactus* a2){
	n=a2-a1;
	cactus *ax=a1;
	for(int i=1;i<=n;i++){
		a[i]=*ax;
		ax++;
	}
	for(int i=1;i<=n;i++){
		tr[i]=sum_lct_node<cactus>(0,0,0,a[i],0,1);
	}
}

template <typename cactus>
const SIZE_C sum_link_cut_trees<cactus>::size(void){
	return n;
}

template <typename cactus>
const int sum_link_cut_trees<cactus>::operator()(const int p){
	return root_in(p);
}

template <typename cactus>
const int sum_link_cut_trees<cactus>::root(const int p){
	return root_in(p);
}

template <typename cactus>
const bool sum_link_cut_trees<cactus>::find(const int p1,const int p2){
	return find_in(p1,p2);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::cut_unlocked(const int p1,const int p2){
	cut_unlocked_in(p1,p2);
}

template <typename cactus>
const bool sum_link_cut_trees<cactus>::cut(const int p1,const int p2){
	return cut_in(p1,p2);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::link_unlocked(const int p1,const int p2){
	link_unlocked_in(p1,p2);
}

template <typename cactus>
const bool sum_link_cut_trees<cactus>::link(const int p1,const int p2){
	return link_in(p1,p2);
}

template <typename cactus>
const cactus sum_link_cut_trees<cactus>::sum_unlocked(const int p1,const int p2){
	return sum_unlocked_in(p1,p2);
}

template <typename cactus>
const cactus sum_link_cut_trees<cactus>::sum(const int p1,const int p2){
	return sum_in(p1,p2);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::replace(const int p,const cactus v){
	replace_in(p,v);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::add(const int p,const cactus v){
	add_in(p,v);
}

template <typename cactus>
void sum_link_cut_trees<cactus>::minus(const int p,const cactus v){
	minus_in(p,v);
}

template <typename cactus>
cactus& sum_link_cut_trees<cactus>::operator[](const int addr){
	return a[addr];
}

template <typename cactus>
cactus& sum_link_cut_trees<cactus>::value(const int p){
	return a[p];
}

template <typename cactus>
void sum_link_cut_trees<cactus>::renew(const int p){
	renew_in(p);
}

/*******************************************************************************/

class map_node{
	friend class directed_graph;
	friend class undirected_graph;
	private:
		int from;
		int to;
		int val;
		int nex;
		map_node(void);
		map_node(const int u,const int v,const int w,const int next);
	public:
		const bool operator>(const map_node mn)const;
		const bool operator<(const map_node mn)const;
};
	
map_node::map_node(void){
	from=0;
	to=0;
	val=0;
	nex=-1;
}

map_node::map_node(const int u,const int v,const int w,const int next){
	from=u;
	to=v;
	val=w;
	nex=next;
}

const bool map_node::operator>(const map_node mn)const{
	return val>mn.val;
}

const bool map_node::operator<(const map_node mn)const{
	return val<mn.val;
}



class directed_graph{//due to the structure, numbers start from 1
	private:
		int num;
		int n;
		int root[MAXNUM+5];
		map_node m[MAXN];
		int timer;
		int tx;
		bool neg;
		bool vis[MAXN];
		bool ins[MAXN];
		int dfn[MAXN];
		int low[MAXN];
		array_c<> dis;
		array_c<> arr_scc;
		stack_c<int> st;
		
		const array_c<>& dijkstra(const int s);
		const array_c<>& spfa(const int s);
		bool scctarjan(int p,int from);
	public:
		directed_graph(void);
		directed_graph(const int size);
		const SIZE_C size(void);
		void connect(const int from,const int to,const int value);
		const array_c<>& shortest_path(const int s);
		const array_c<>& SCC(void);
};

const array_c<>& directed_graph::dijkstra(const int s){
	dis.n=num;
	for(int i=0;i<MAXNUM;i++){
		dis[i]=INF;
		vis[i]=0;
	}
	dis[s]=0;
	dis[0]=num;
	if(s<1||s>num){
		return dis;
	}
	small_heap <pair_c <int,int> > hp;
	int x=root[s];
	pair_c <int,int> cur;
	while(x!=-1){
		hp.insert(pair_c <int,int>(m[x].val,m[x].to));
		dis[m[x].to]=m[x].val;
		x=m[x].nex;
	}
	while(!hp.empty()){
		cur=hp.top();
		hp.pop();
		x=root[cur.x2];
		if(vis[cur.x2]){
			continue;
		}
		vis[cur.x2]=1;
		while(x!=-1){
			if(cur.x1+m[x].val<dis[m[x].to]){
				dis[m[x].to]=cur.x1+m[x].val;
				hp.insert(pair_c <int,int> (dis[m[x].to],m[x].to));
			}
			x=m[x].nex;
		}
	}
	return dis;
}

const array_c<>& directed_graph::spfa(const int s){
	queue_c <int> q;
	int inq[MAXNUM];
	dis.n=num;
	dis[0]=num;
	for(int i=0;i<MAXNUM;i++){
		dis[i]=INF;
		vis[i]=0;
		inq[i]=0;
	}
	dis[s]=0;
	q.insert(s);
	int cur;
	int cx;
	while(!q.empty()){
		cur=q.front();
		q.pop();
		vis[cur]=0;
		cx=root[cur];
		if(inq[cur]>num){
			dis[0]=0;
			return dis;
		}
		while(cx!=-1){
			if(dis[m[cx].to]>dis[cur]+m[cx].val){
				if(!vis[m[cx].to]){
					q.insert(m[cx].to);
					inq[m[cx].to]++;
				}
				dis[m[cx].to]=dis[cur]+m[cx].val;
				vis[m[cx].to]=1;
			}
			cx=m[cx].nex;
		}
	}
	return dis;
}

bool directed_graph::scctarjan(int p,int from){
	if(vis[p]){
		return 0;
	}
	vis[p]=1;
	ins[p]=1;
	timer++;
	dfn[p]=low[p]=timer;
	st.insert(p);
	for(int px=root[p];px>0;px=m[px].nex){
		if(scctarjan(m[px].to,p)){
			if(low[p]>low[m[px].to]){
				low[p]=low[m[px].to];
			}
		}else{
			if(ins[m[px].to]){
				if(low[p]>dfn[m[px].to]){
					low[p]=dfn[m[px].to];
				}
			}
		}
	}
	if(dfn[p]==low[p]){
		int t;
		tx++;
		while(1){
			t=st.top();
			st.pop();
			ins[t]=0;
			arr_scc[t]=tx;
			if(t==p){
				return 1;
			}
		}
	}
	return 1;
}

directed_graph::directed_graph(void){
	num=MAXNUM;
	neg=0;
	n=0;
	for(int i=0;i<MAXNUM;i++){
		root[i]=-1;
	}
}

directed_graph::directed_graph(const int size){
	num=size;
	neg=0;
	n=0;
	for(int i=0;i<MAXNUM;i++){
		root[i]=-1;
	}
}

const SIZE_C directed_graph::size(void){
	return n;
}

void directed_graph::connect(const int from,const int to,const int value){
	if(from<1||to<1||from>num||to>num){
		return;
	}else{
		m[n]=map_node(from,to,value,root[from]);
		root[from]=n;
		n++;
		if(value<0){
			neg=1;
		}
	}
}

const array_c<>& directed_graph::shortest_path(const int s){
	if(neg){
		return spfa(s);
	}else{
		return dijkstra(s);
	}
}

const array_c<>& directed_graph::SCC(void){
	for(int i=1;i<=num;i++){
		vis[i]=0;
		ins[i]=0;
	}
	arr_scc.n=num;
	timer=0;
	tx=0;
	for(int i=1;i<=num;i++){
		scctarjan(i,-1);
	}
	return arr_scc;
}



class undirected_graph{
	private:
		int num;//number of points (length of root)
		int n;//number of edges (length of m)
		int timer;
		array_c<> dis;
		int root[MAXNUM+5];//the root of edges
		int back_root[MAXNUM+5];//how many sub_trees there are
		map_node m[MAXN];//map edges
		bool neg;//if there are negative edges
		bool vis[MAXN];//visited
		map_node edge_sort[MAXN];//edges for kruskal
		int en;//size for kruskal
		int dfn[MAXNUM];//dfn for dfs
		int low[MAXNUM];//low for tarjan
		array_c<> ret_v;//array for returning vertexes
		array_c<pair_c<int,int> > ret_e;//array for returning edges
		
		void clear_vis(void);
		const array_c<>& dijkstra(const int s);
		const array_c<>& spfa(const int s);
		const int kruskal(void);
		bool cut_vertex_tarjan(int p,int from);
		bool cut_edge_tarjan(int p,int from);
	public:
		undirected_graph(void);
		undirected_graph(const int size);
		const SIZE_C size(void);
		void connect(const int from,const int to,const int value);
		const array_c<>& shortest_path(const int s);
		const int MST(void);
		const array_c<>& cut_vertex(void);
		const array_c<pair_c<int,int> >& cut_edge(void);
};

void undirected_graph::clear_vis(void){
	for(int i=1;i<=num;i++){
		vis[i]=0;
	}
	timer=0;
}

const array_c<>& undirected_graph::dijkstra(const int s){
	dis.n=num;
	for(int i=0;i<MAXNUM;i++){
		dis[i]=INF;
		vis[i]=0;
	}
	dis[s]=0;
	if(s<1||s>num){
		return dis;
	}
	small_heap <pair_c <int,int> > hp;
	int x=root[s];
	pair_c <int,int> cur;
	while(x!=-1){
		hp.insert(pair_c <int,int>(m[x].val,m[x].to));
		dis[m[x].to]=m[x].val;
		x=m[x].nex;
	}
	while(!hp.empty()){
		cur=hp.top();
		hp.pop();
		x=root[cur.x2];
		if(vis[cur.x2]){
			continue;
		}
		vis[cur.x2]=1;
		while(x!=-1){
			if(cur.x1+m[x].val<dis[m[x].to]){
				dis[m[x].to]=cur.x1+m[x].val;
				hp.insert(pair_c <int,int> (dis[m[x].to],m[x].to));
			}
			x=m[x].nex;
		}
	}
	return dis;
}

const array_c<>& undirected_graph::spfa(const int s){
	queue_c <int> q;
	int inq[MAXNUM];
	dis.n=num;
	dis[0]=num;
	for(int i=0;i<MAXNUM;i++){
		dis[i]=INF;
		vis[i]=0;
		inq[i]=0;
	}
	dis[s]=0;
	q.insert(s);
	int cur;
	int cx;
	while(!q.empty()){
		cur=q.front();
		q.pop();
		vis[cur]=0;
		cx=root[cur];
		if(inq[cur]>num){
			dis[0]=0;
			return dis;
		}
		while(cx!=-1){
			if(dis[m[cx].to]>dis[cur]+m[cx].val){
				if(!vis[m[cx].to]){
					q.insert(m[cx].to);
					inq[m[cx].to]++;
				}
				dis[m[cx].to]=dis[cur]+m[cx].val;
				vis[m[cx].to]=1;
			}
			cx=m[cx].nex;
		}
	}
	return dis;
}

const int undirected_graph::kruskal(void){
	union_set u;
	sort(edge_sort,edge_sort+en);
	int cnt=0,ret=0;
	for(int i=0;i<en;i++){
		if(u.relate(edge_sort[i].from,edge_sort[i].to)){
			continue;
		}else{
			cnt++;
			u.merge(edge_sort[i].from,edge_sort[i].to);
			ret+=edge_sort[i].val;
			if(cnt==num){
				return ret;
			}
		}
	}
	return INF;
}

bool undirected_graph::cut_vertex_tarjan(int p,int from){
	if(vis[p]){
		return 0;
	}
	vis[p]=1;
	timer++;
	int child=0;
	dfn[p]=timer;
	low[p]=timer;
	bool flag=0;
	for(int px=root[p];px!=-1;px=m[px].nex){
		if(m[px].to!=from){
			if(cut_vertex_tarjan(m[px].to,p)){
				if(low[m[px].to]<low[p]){
					low[p]=low[m[px].to];
				}
				child++;
				if(low[m[px].to]>=dfn[p]){
					flag=1;
				}
			}else{
				if(dfn[m[px].to]<low[p]){
					low[p]=dfn[m[px].to];
				}
			}
		}
	}
	if(from==-1){
		if(child>1){
			ret_v.insert(p);
		}
	}else{
		if(flag){
			ret_v.insert(p);
		}
	}
	return 1;
}

bool undirected_graph::cut_edge_tarjan(int p,int from){
	if(vis[p]){
		return 0;
	}
	timer++;
	dfn[p]=low[p]=timer;
	vis[p]=1;
	for(int px=root[p];px!=-1;px=m[px].nex){
		if(m[px].to!=from){
			if(cut_edge_tarjan(m[px].to,p)){
				if(low[p]>low[m[px].to]){
					low[p]=low[m[px].to];
				}
				if(low[m[px].to]>dfn[p]){
					ret_e.insert(pair_c<int,int>(p,m[px].to));
				}
			}else{
				if(low[p]>dfn[m[px].to]){
					low[p]=dfn[m[px].to];
				}
			}
		}
	}
	return 1;
}

undirected_graph::undirected_graph(void){
	num=MAXNUM;
	neg=0;
	n=0;
	for(int i=0;i<MAXNUM;i++){
		root[i]=-1;
	}
	en=0;
}

undirected_graph::undirected_graph(const int size){
	num=size;
	neg=0;
	n=0;
	for(int i=1;i<=size;i++){
		root[i]=-1;
	}
	en=0;
}

const SIZE_C undirected_graph::size(void){
	return n;
}

void undirected_graph::connect(const int from,const int to,const int value){
	if(from<1||to<1||from>num||to>num){
		return;
	}else{
		m[n]=map_node(from,to,value,root[from]);
		root[from]=n;
		n++;
		m[n]=map_node(to,from,value,root[to]);
		root[to]=n;
		n++;
		if(value<0){
			neg=1;
		}
		edge_sort[en]=map_node(from,to,value,-1);
		en++;
	}
}

const array_c<>& undirected_graph::shortest_path(const int s){
	if(neg){
		return spfa(s);
	}else{
		return dijkstra(s);
	}
}

const int undirected_graph::MST(void){
	return kruskal();
}

const array_c<>& undirected_graph::cut_vertex(void){
	clear_vis();
	ret_v.n=0;
	for(int i=1;i<=num;i++){
		cut_vertex_tarjan(i,-1);
	}
	return ret_v;
}

const array_c<pair_c<int,int> >& undirected_graph::cut_edge(void){
	clear_vis();
	ret_e.n=0;
	for(int i=1;i<=num;i++){
		cut_edge_tarjan(i,-1);
	}
	return ret_e;
}

/*******************************************************************************/

class p_trie_node{
	friend class persistent_trie;
	private:
		int ch[52];
		int cnt;
		int sz;
		p_trie_node(void);
		void operator=(p_trie_node ptnd);
};

p_trie_node::p_trie_node(void){
	cnt=sz=0;
}

void p_trie_node::operator=(p_trie_node ptnd){
	cnt=ptnd.cnt;
	sz=ptnd.sz;
	for(int i=0;i<52;i++){
		ch[i]=ptnd.ch[i];
	}
}



class persistent_trie{
	private:
		int n;
		int num;//versions
		int root[MAXNUM];
		p_trie_node tr[MAXN];
		int trans(char c);
		int new_node(void);
		int copy_node(int p);
		void init(void);
		void simple_insert_in(string s);
		void simple_insert_in(char* s);
		void insert_in(string s,int ver);
		void insert_in(char* s,int ver);
		bool simple_del_in(string s);
		bool simple_del_in(char* s);
		bool del_in(string s,int ver);
		bool del_in(char* s,int ver);
		bool simple_find_in(string s);
		bool simple_find_in(char* s);
		bool find_in(string s,int ver);
		bool find_in(char* s,int ver);
		int simple_count_in(string s);
		int simple_count_in(char* s);
		int count_in(string s,int ver);
		int count_in(char* s,int ver);
		int simple_prefix_in(string s);
		int simple_prefix_in(char* s);
		int prefix_in(string s,int ver);
		int prefix_in(char* s,int ver);
		void simple_new_version_in(void);
		void new_version_in(int ver);
	public:
		persistent_trie(void);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		const SIZE_C versions(void);
		void simple_insert(const string s);
		void simple_insert(const char* s);
		void insert(const string s,const int version);
		void insert(const char* s,const int version);
		const bool simple_del(const string s);
		const bool simple_del(const char* s);
		const bool del(const string s,const int version);
		const bool del(const char* s,const int version);
		const bool simple_find(const string s);
		const bool simple_find(const char* s);
		const bool find(const string s,const int version);
		const bool find(const char* s,const int version);
		const int simple_count(const string s);
		const int simple_count(const char* s);
		const int count(const string s,const int version);
		const int count(const char* s,const int version);
		const int simple_prefix(string s);
		const int simple_prefix(char* s);
		const int prefix(const string s,const int version);
		const int prefix(const char* s,const int version);
		void simple_new_version(void);
		void new_version(const int version);
};

int persistent_trie::trans(char c){
	if(c<='Z'){
		return c-'A';
	}else{
		return c-'a'+26;
	}
}

int persistent_trie::new_node(void){
	n++;
	tr[n]=p_trie_node();
	return n;
}

int persistent_trie::copy_node(int p){
	n++;
	tr[n]=tr[p];
	return n;
}

void persistent_trie::init(void){
	n=0;
	num=0;
	root[0]=0;
}

void persistent_trie::simple_insert_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_trie::simple_insert_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_trie::insert_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_trie::insert_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

bool persistent_trie::simple_del_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_trie::simple_del_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_trie::del_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_trie::del_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_trie::simple_find_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_trie::simple_find_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_trie::find_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_trie::find_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

int persistent_trie::simple_count_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_trie::simple_count_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_trie::count_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_trie::count_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_trie::simple_prefix_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_trie::simple_prefix_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_trie::prefix_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_trie::prefix_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

void persistent_trie::simple_new_version_in(void){
	num++;
	root[num]=copy_node(root[num-1]);
}

void persistent_trie::new_version_in(int ver){
	num++;
	root[num]=copy_node(root[ver]);
}

persistent_trie::persistent_trie(void){
	init();
}

const SIZE_C persistent_trie::size(const int version){
	return tr[root[version]].sz;
}

const SIZE_C persistent_trie::simple_size(void){
	return tr[root[num]].sz;
}

const SIZE_C persistent_trie::versions(void){
	return num;
}

void persistent_trie::simple_insert(const string s){
	simple_insert_in(s);
}

void persistent_trie::simple_insert(const char* s){
	simple_insert_in(s);
}

void persistent_trie::insert(const string s,const int version){
	insert_in(s,version);
}

void persistent_trie::insert(const char* s,const int version){
	insert_in(s,version);
}

const bool persistent_trie::simple_del(const string s){
	return simple_del_in(s);
}

const bool persistent_trie::simple_del(const char* s){
	return simple_del_in(s);
}

const bool persistent_trie::del(const string s,const int version){
	return del_in(s,version);
}

const bool persistent_trie::del(const char* s,const int version){
	return del_in(s,version);
}

const bool persistent_trie::simple_find(const string s){
	return simple_find_in(s);
}

const bool persistent_trie::simple_find(const char* s){
	return simple_find_in(s);
}

const bool persistent_trie::find(const string s,const int version){
	return find_in(s,version);
}

const bool persistent_trie::find(const char* s,const int version){
	return find_in(s,version);
}

const int persistent_trie::simple_count(const string s){
	return simple_count_in(s);
}

const int persistent_trie::simple_count(const char* s){
	return simple_count_in(s);
}

const int persistent_trie::count(const string s,const int version){
	return count_in(s,version);
}

const int persistent_trie::count(const char* s,const int version){
	return count_in(s,version);
}

const int persistent_trie::simple_prefix(string s){
	return simple_prefix_in(s);
}

const int persistent_trie::simple_prefix(char* s){
	return simple_prefix_in(s);
}

const int persistent_trie::prefix(const string s,const int version){
	return prefix_in(s,version);
}

const int persistent_trie::prefix(const char* s,const int version){
	return prefix_in(s,version);
}

void persistent_trie::simple_new_version(void){
	simple_new_version_in();
}

void persistent_trie::new_version(const int version){
	new_version_in(version);
}



class p_upper_trie_node{
	friend class persistent_uppercase_trie;
	private:
		int ch[26];
		int cnt;
		int sz;
		p_upper_trie_node(void);
		void operator=(p_upper_trie_node ptnd);
};

p_upper_trie_node::p_upper_trie_node(void){
	cnt=sz=0;
}

void p_upper_trie_node::operator=(p_upper_trie_node ptnd){
	cnt=ptnd.cnt;
	sz=ptnd.sz;
	for(int i=0;i<26;i++){
		ch[i]=ptnd.ch[i];
	}
}



class persistent_uppercase_trie{
	private:
		int n;
		int num;//versions
		int root[MAXNUM];
		p_upper_trie_node tr[MAXN];
		int trans(char c);
		int new_node(void);
		int copy_node(int p);
		void init(void);
		void simple_insert_in(string s);
		void simple_insert_in(char* s);
		void insert_in(string s,int ver);
		void insert_in(char* s,int ver);
		bool simple_del_in(string s);
		bool simple_del_in(char* s);
		bool del_in(string s,int ver);
		bool del_in(char* s,int ver);
		bool simple_find_in(string s);
		bool simple_find_in(char* s);
		bool find_in(string s,int ver);
		bool find_in(char* s,int ver);
		int simple_count_in(string s);
		int simple_count_in(char* s);
		int count_in(string s,int ver);
		int count_in(char* s,int ver);
		int simple_prefix_in(string s);
		int simple_prefix_in(char* s);
		int prefix_in(string s,int ver);
		int prefix_in(char* s,int ver);
		void simple_new_version_in(void);
		void new_version_in(int ver);
	public:
		persistent_uppercase_trie(void);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		const SIZE_C versions(void);
		void simple_insert(const string s);
		void simple_insert(const char* s);
		void insert(const string s,const int version);
		void insert(const char* s,const int version);
		const bool simple_del(const string s);
		const bool simple_del(const char* s);
		const bool del(const string s,const int version);
		const bool del(const char* s,const int version);
		const bool simple_find(const string s);
		const bool simple_find(const char* s);
		const bool find(const string s,const int version);
		const bool find(const char* s,const int version);
		const int simple_count(const string s);
		const int simple_count(const char* s);
		const int count(const string s,const int version);
		const int count(const char* s,const int version);
		const int simple_prefix(string s);
		const int simple_prefix(char* s);
		const int prefix(const string s,const int version);
		const int prefix(const char* s,const int version);
		void simple_new_version(void);
		void new_version(const int version);
};

int persistent_uppercase_trie::trans(char c){
	return c-'A';
}

int persistent_uppercase_trie::new_node(void){
	n++;
	tr[n]=p_upper_trie_node();
	return n;
}

int persistent_uppercase_trie::copy_node(int p){
	n++;
	tr[n]=tr[p];
	return n;
}

void persistent_uppercase_trie::init(void){
	n=0;
	num=0;
	root[0]=0;
}

void persistent_uppercase_trie::simple_insert_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_uppercase_trie::simple_insert_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_uppercase_trie::insert_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_uppercase_trie::insert_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

bool persistent_uppercase_trie::simple_del_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_uppercase_trie::simple_del_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_uppercase_trie::del_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_uppercase_trie::del_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_uppercase_trie::simple_find_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_uppercase_trie::simple_find_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_uppercase_trie::find_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_uppercase_trie::find_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

int persistent_uppercase_trie::simple_count_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_uppercase_trie::simple_count_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_uppercase_trie::count_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_uppercase_trie::count_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_uppercase_trie::simple_prefix_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_uppercase_trie::simple_prefix_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_uppercase_trie::prefix_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_uppercase_trie::prefix_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

void persistent_uppercase_trie::simple_new_version_in(void){
	num++;
	root[num]=copy_node(root[num-1]);
}

void persistent_uppercase_trie::new_version_in(int ver){
	num++;
	root[num]=copy_node(root[ver]);
}

persistent_uppercase_trie::persistent_uppercase_trie(void){
	init();
}

const SIZE_C persistent_uppercase_trie::size(const int version){
	return tr[root[version]].sz;
}

const SIZE_C persistent_uppercase_trie::simple_size(void){
	return tr[root[num]].sz;
}

const SIZE_C persistent_uppercase_trie::versions(void){
	return num;
}

void persistent_uppercase_trie::simple_insert(const string s){
	simple_insert_in(s);
}

void persistent_uppercase_trie::simple_insert(const char* s){
	simple_insert_in(s);
}

void persistent_uppercase_trie::insert(const string s,const int version){
	insert_in(s,version);
}

void persistent_uppercase_trie::insert(const char* s,const int version){
	insert_in(s,version);
}

const bool persistent_uppercase_trie::simple_del(const string s){
	return simple_del_in(s);
}

const bool persistent_uppercase_trie::simple_del(const char* s){
	return simple_del_in(s);
}

const bool persistent_uppercase_trie::del(const string s,const int version){
	return del_in(s,version);
}

const bool persistent_uppercase_trie::del(const char* s,const int version){
	return del_in(s,version);
}

const bool persistent_uppercase_trie::simple_find(const string s){
	return simple_find_in(s);
}

const bool persistent_uppercase_trie::simple_find(const char* s){
	return simple_find_in(s);
}

const bool persistent_uppercase_trie::find(const string s,const int version){
	return find_in(s,version);
}

const bool persistent_uppercase_trie::find(const char* s,const int version){
	return find_in(s,version);
}

const int persistent_uppercase_trie::simple_count(const string s){
	return simple_count_in(s);
}

const int persistent_uppercase_trie::simple_count(const char* s){
	return simple_count_in(s);
}

const int persistent_uppercase_trie::count(const string s,const int version){
	return count_in(s,version);
}

const int persistent_uppercase_trie::count(const char* s,const int version){
	return count_in(s,version);
}

const int persistent_uppercase_trie::simple_prefix(string s){
	return simple_prefix_in(s);
}

const int persistent_uppercase_trie::simple_prefix(char* s){
	return simple_prefix_in(s);
}

const int persistent_uppercase_trie::prefix(const string s,const int version){
	return prefix_in(s,version);
}

const int persistent_uppercase_trie::prefix(const char* s,const int version){
	return prefix_in(s,version);
}

void persistent_uppercase_trie::simple_new_version(void){
	simple_new_version_in();
}

void persistent_uppercase_trie::new_version(const int version){
	new_version_in(version);
}



class p_lower_trie_node{
	friend class persistent_lowercase_trie;
	private:
		int ch[26];
		int cnt;
		int sz;
		p_lower_trie_node(void);
		void operator=(p_lower_trie_node ptnd);
};

p_lower_trie_node::p_lower_trie_node(void){
	cnt=sz=0;
}

void p_lower_trie_node::operator=(p_lower_trie_node ptnd){
	cnt=ptnd.cnt;
	sz=ptnd.sz;
	for(int i=0;i<26;i++){
		ch[i]=ptnd.ch[i];
	}
}



class persistent_lowercase_trie{
	private:
		int n;
		int num;//versions
		int root[MAXNUM];
		p_lower_trie_node tr[MAXN];
		int trans(char c);
		int new_node(void);
		int copy_node(int p);
		void init(void);
		void simple_insert_in(string s);
		void simple_insert_in(char* s);
		void insert_in(string s,int ver);
		void insert_in(char* s,int ver);
		bool simple_del_in(string s);
		bool simple_del_in(char* s);
		bool del_in(string s,int ver);
		bool del_in(char* s,int ver);
		bool simple_find_in(string s);
		bool simple_find_in(char* s);
		bool find_in(string s,int ver);
		bool find_in(char* s,int ver);
		int simple_count_in(string s);
		int simple_count_in(char* s);
		int count_in(string s,int ver);
		int count_in(char* s,int ver);
		int simple_prefix_in(string s);
		int simple_prefix_in(char* s);
		int prefix_in(string s,int ver);
		int prefix_in(char* s,int ver);
		void simple_new_version_in(void);
		void new_version_in(int ver);
	public:
		persistent_lowercase_trie(void);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		const SIZE_C versions(void);
		void simple_insert(const string s);
		void simple_insert(const char* s);
		void insert(const string s,const int version);
		void insert(const char* s,const int version);
		const bool simple_del(const string s);
		const bool simple_del(const char* s);
		const bool del(const string s,const int version);
		const bool del(const char* s,const int version);
		const bool simple_find(const string s);
		const bool simple_find(const char* s);
		const bool find(const string s,const int version);
		const bool find(const char* s,const int version);
		const int simple_count(const string s);
		const int simple_count(const char* s);
		const int count(const string s,const int version);
		const int count(const char* s,const int version);
		const int simple_prefix(string s);
		const int simple_prefix(char* s);
		const int prefix(const string s,const int version);
		const int prefix(const char* s,const int version);
		void simple_new_version(void);
		void new_version(const int version);
};

int persistent_lowercase_trie::trans(char c){
	return c-'a';
}

int persistent_lowercase_trie::new_node(void){
	n++;
	tr[n]=p_lower_trie_node();
	return n;
}

int persistent_lowercase_trie::copy_node(int p){
	n++;
	tr[n]=tr[p];
	return n;
}

void persistent_lowercase_trie::init(void){
	n=0;
	num=0;
	root[0]=0;
}

void persistent_lowercase_trie::simple_insert_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_lowercase_trie::simple_insert_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_lowercase_trie::insert_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_lowercase_trie::insert_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

bool persistent_lowercase_trie::simple_del_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_lowercase_trie::simple_del_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_lowercase_trie::del_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_lowercase_trie::del_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_lowercase_trie::simple_find_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_lowercase_trie::simple_find_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_lowercase_trie::find_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_lowercase_trie::find_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

int persistent_lowercase_trie::simple_count_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_lowercase_trie::simple_count_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_lowercase_trie::count_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_lowercase_trie::count_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_lowercase_trie::simple_prefix_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_lowercase_trie::simple_prefix_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_lowercase_trie::prefix_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_lowercase_trie::prefix_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

void persistent_lowercase_trie::simple_new_version_in(void){
	num++;
	root[num]=copy_node(root[num-1]);
}

void persistent_lowercase_trie::new_version_in(int ver){
	num++;
	root[num]=copy_node(root[ver]);
}

persistent_lowercase_trie::persistent_lowercase_trie(void){
	init();
}

const SIZE_C persistent_lowercase_trie::size(const int version){
	return tr[root[version]].sz;
}

const SIZE_C persistent_lowercase_trie::simple_size(void){
	return tr[root[num]].sz;
}

const SIZE_C persistent_lowercase_trie::versions(void){
	return num;
}

void persistent_lowercase_trie::simple_insert(const string s){
	simple_insert_in(s);
}

void persistent_lowercase_trie::simple_insert(const char* s){
	simple_insert_in(s);
}

void persistent_lowercase_trie::insert(const string s,const int version){
	insert_in(s,version);
}

void persistent_lowercase_trie::insert(const char* s,const int version){
	insert_in(s,version);
}

const bool persistent_lowercase_trie::simple_del(const string s){
	return simple_del_in(s);
}

const bool persistent_lowercase_trie::simple_del(const char* s){
	return simple_del_in(s);
}

const bool persistent_lowercase_trie::del(const string s,const int version){
	return del_in(s,version);
}

const bool persistent_lowercase_trie::del(const char* s,const int version){
	return del_in(s,version);
}

const bool persistent_lowercase_trie::simple_find(const string s){
	return simple_find_in(s);
}

const bool persistent_lowercase_trie::simple_find(const char* s){
	return simple_find_in(s);
}

const bool persistent_lowercase_trie::find(const string s,const int version){
	return find_in(s,version);
}

const bool persistent_lowercase_trie::find(const char* s,const int version){
	return find_in(s,version);
}

const int persistent_lowercase_trie::simple_count(const string s){
	return simple_count_in(s);
}

const int persistent_lowercase_trie::simple_count(const char* s){
	return simple_count_in(s);
}

const int persistent_lowercase_trie::count(const string s,const int version){
	return count_in(s,version);
}

const int persistent_lowercase_trie::count(const char* s,const int version){
	return count_in(s,version);
}

const int persistent_lowercase_trie::simple_prefix(string s){
	return simple_prefix_in(s);
}

const int persistent_lowercase_trie::simple_prefix(char* s){
	return simple_prefix_in(s);
}

const int persistent_lowercase_trie::prefix(const string s,const int version){
	return prefix_in(s,version);
}

const int persistent_lowercase_trie::prefix(const char* s,const int version){
	return prefix_in(s,version);
}

void persistent_lowercase_trie::simple_new_version(void){
	simple_new_version_in();
}

void persistent_lowercase_trie::new_version(const int version){
	new_version_in(version);
}



class p_asc_trie_node{
	friend class persistent_ascii_trie;
	private:
		int ch[128];
		int cnt;
		int sz;
		p_asc_trie_node(void);
		void operator=(p_asc_trie_node ptnd);
};

p_asc_trie_node::p_asc_trie_node(void){
	cnt=sz=0;
}

void p_asc_trie_node::operator=(p_asc_trie_node ptnd){
	cnt=ptnd.cnt;
	sz=ptnd.sz;
	for(int i=0;i<128;i++){
		ch[i]=ptnd.ch[i];
	}
}



class persistent_ascii_trie{
	private:
		int n;
		int num;//versions
		int root[MAXNUM];
		p_asc_trie_node tr[MAXN];
		int trans(char c);
		int new_node(void);
		int copy_node(int p);
		void init(void);
		void simple_insert_in(string s);
		void simple_insert_in(char* s);
		void insert_in(string s,int ver);
		void insert_in(char* s,int ver);
		bool simple_del_in(string s);
		bool simple_del_in(char* s);
		bool del_in(string s,int ver);
		bool del_in(char* s,int ver);
		bool simple_find_in(string s);
		bool simple_find_in(char* s);
		bool find_in(string s,int ver);
		bool find_in(char* s,int ver);
		int simple_count_in(string s);
		int simple_count_in(char* s);
		int count_in(string s,int ver);
		int count_in(char* s,int ver);
		int simple_prefix_in(string s);
		int simple_prefix_in(char* s);
		int prefix_in(string s,int ver);
		int prefix_in(char* s,int ver);
		void simple_new_version_in(void);
		void new_version_in(int ver);
	public:
		persistent_ascii_trie(void);
		const SIZE_C size(const int version);
		const SIZE_C simple_size(void);
		const SIZE_C versions(void);
		void simple_insert(const string s);
		void simple_insert(const char* s);
		void insert(const string s,const int version);
		void insert(const char* s,const int version);
		const bool simple_del(const string s);
		const bool simple_del(const char* s);
		const bool del(const string s,const int version);
		const bool del(const char* s,const int version);
		const bool simple_find(const string s);
		const bool simple_find(const char* s);
		const bool find(const string s,const int version);
		const bool find(const char* s,const int version);
		const int simple_count(const string s);
		const int simple_count(const char* s);
		const int count(const string s,const int version);
		const int count(const char* s,const int version);
		const int simple_prefix(string s);
		const int simple_prefix(char* s);
		const int prefix(const string s,const int version);
		const int prefix(const char* s,const int version);
		void simple_new_version(void);
		void new_version(const int version);
};

int persistent_ascii_trie::trans(char c){
	return (int)c;
}

int persistent_ascii_trie::new_node(void){
	n++;
	tr[n]=p_asc_trie_node();
	return n;
}

int persistent_ascii_trie::copy_node(int p){
	n++;
	tr[n]=tr[p];
	return n;
}

void persistent_ascii_trie::init(void){
	n=0;
	num=0;
	root[0]=0;
}

void persistent_ascii_trie::simple_insert_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_ascii_trie::simple_insert_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_ascii_trie::insert_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

void persistent_ascii_trie::insert_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;i++,s++){
		j=trans(*s);
		tr[pt].sz++;
		if(tr[pt].ch[j]){
			tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		}else{
			tr[pt].ch[j]=new_node();
		}
		pt=tr[pt].ch[j];
	}
	tr[pt].sz++;
	tr[pt].cnt++;
}

bool persistent_ascii_trie::simple_del_in(string s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_ascii_trie::simple_del_in(char* s){
	num++;
	root[num]=copy_node(root[num-1]);
	if(!simple_find_in(s)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_ascii_trie::del_in(string s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_ascii_trie::del_in(char* s,int ver){
	num++;
	root[num]=copy_node(root[ver]);
	if(!find_in(s,ver)){
		return 0;
	}
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		tr[pt].sz--;
		tr[pt].ch[j]=copy_node(tr[pt].ch[j]);
		pt=tr[pt].ch[j];
	}
	tr[pt].sz--;
	tr[pt].cnt--;
	return 1;
}

bool persistent_ascii_trie::simple_find_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_ascii_trie::simple_find_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_ascii_trie::find_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

bool persistent_ascii_trie::find_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return (bool)tr[pt].cnt;
}

int persistent_ascii_trie::simple_count_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_ascii_trie::simple_count_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_ascii_trie::count_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_ascii_trie::count_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].cnt;
}

int persistent_ascii_trie::simple_prefix_in(string s){
	int pt=root[num];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_ascii_trie::simple_prefix_in(char* s){
	int pt=root[num];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_ascii_trie::prefix_in(string s,int ver){
	int pt=root[ver];
	int len=s.length();
	for(int i=0,j;i<len;i++){
		j=trans(s[i]);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

int persistent_ascii_trie::prefix_in(char* s,int ver){
	int pt=root[ver];
	int len=strlen(s);
	for(int i=0,j;i<len;s++,i++){
		j=trans(*s);
		if(tr[pt].ch[j]){
			pt=tr[pt].ch[j];
		}else{
			return 0;
		}
	}
	return tr[pt].sz;
}

void persistent_ascii_trie::simple_new_version_in(void){
	num++;
	root[num]=copy_node(root[num-1]);
}

void persistent_ascii_trie::new_version_in(int ver){
	num++;
	root[num]=copy_node(root[ver]);
}

persistent_ascii_trie::persistent_ascii_trie(void){
	init();
}

const SIZE_C persistent_ascii_trie::size(const int version){
	return tr[root[version]].sz;
}

const SIZE_C persistent_ascii_trie::simple_size(void){
	return tr[root[num]].sz;
}

const SIZE_C persistent_ascii_trie::versions(void){
	return num;
}

void persistent_ascii_trie::simple_insert(const string s){
	simple_insert_in(s);
}

void persistent_ascii_trie::simple_insert(const char* s){
	simple_insert_in(s);
}

void persistent_ascii_trie::insert(const string s,const int version){
	insert_in(s,version);
}

void persistent_ascii_trie::insert(const char* s,const int version){
	insert_in(s,version);
}

const bool persistent_ascii_trie::simple_del(const string s){
	return simple_del_in(s);
}

const bool persistent_ascii_trie::simple_del(const char* s){
	return simple_del_in(s);
}

const bool persistent_ascii_trie::del(const string s,const int version){
	return del_in(s,version);
}

const bool persistent_ascii_trie::del(const char* s,const int version){
	return del_in(s,version);
}

const bool persistent_ascii_trie::simple_find(const string s){
	return simple_find_in(s);
}

const bool persistent_ascii_trie::simple_find(const char* s){
	return simple_find_in(s);
}

const bool persistent_ascii_trie::find(const string s,const int version){
	return find_in(s,version);
}

const bool persistent_ascii_trie::find(const char* s,const int version){
	return find_in(s,version);
}

const int persistent_ascii_trie::simple_count(const string s){
	return simple_count_in(s);
}

const int persistent_ascii_trie::simple_count(const char* s){
	return simple_count_in(s);
}

const int persistent_ascii_trie::count(const string s,const int version){
	return count_in(s,version);
}

const int persistent_ascii_trie::count(const char* s,const int version){
	return count_in(s,version);
}

const int persistent_ascii_trie::simple_prefix(string s){
	return simple_prefix_in(s);
}

const int persistent_ascii_trie::simple_prefix(char* s){
	return simple_prefix_in(s);
}

const int persistent_ascii_trie::prefix(const string s,const int version){
	return prefix_in(s,version);
}

const int persistent_ascii_trie::prefix(const char* s,const int version){
	return prefix_in(s,version);
}

void persistent_ascii_trie::simple_new_version(void){
	simple_new_version_in();
}

void persistent_ascii_trie::new_version(const int version){
	new_version_in(version);
}

/*******************************************************************************/

class dinic_node{
	friend class dinic;
	private:
		int to;
		int flow;
		int cap;
		int nex;
		dinic_node(void);
		dinic_node(int to_,int flow_,int cap_,int nex_);
};

dinic_node::dinic_node(void){
	return;
}

dinic_node::dinic_node(int to_,int flow_,int cap_,int nex_){
	to=to_;
	flow=flow_;
	cap=cap_;
	nex=nex_;
}



class dinic{
	private:
		dinic_node m[MAXN];
		int cnt;
		int root[MAXNUM];
		int n;
		int s_,t_;
		int cur[MAXNUM];
		int dep[MAXNUM];
		bool vis[MAXNUM];
		queue_c <int> q;
		bool bfs(void);
		int dfs(int u,int flow);
		void dinic_in(void);
	public:
		int maxflow;
	public:
		explicit dinic(const int num);
		const SIZE_C size(void);
		void connect(const int from,const int to,const int flow);
		const int max_flow(const int s,const int t);
};

bool dinic::bfs(void){
	for(int i=1;i<=n;i++){
		dep[i]=INF;
	}
	dep[s_]=0;
	q.insert(s_);
	int tp;
	while(!q.empty()){
		tp=q.front();
		q.pop();
		for(int p=root[tp];p!=-1;p=m[p].nex){
			if(dep[m[p].to]==INF&&m[p].flow<m[p].cap){
				dep[m[p].to]=dep[tp]+1;
			}
		}
	}
	return dep[t_]!=INF;
}

int dinic::dfs(int u,int flow){
	if(u==t_||flow==0){
		return flow;
	}
	int d;
	int ret=0;
	for(int& p=cur[u];p!=-1;p=m[p].nex){
		if(dep[m[p].to]==dep[u]+1){
			d=dfs(m[p].to,min(flow-ret,m[p].cap-m[p].flow));
			ret+=d;
			m[p].flow+=d;
			m[p^1].flow-=d;
			if(flow==ret)break;
		}
	}
	return ret;
}

void dinic::dinic_in(void){
	while(bfs()){
		for(int i=1;i<=n;i++){
			cur[i]=root[i];
		}
		maxflow+=dfs(s_,INF);
	}
}

dinic::dinic(const int num){
	n=num;
	cnt=0;
	for(int i=1;i<=num;i++){
		root[i]=-1;
	}
}

const SIZE_C dinic::size(void){
	return n;
}

void dinic::connect(const int from,const int to,const int flow){
	m[cnt]=dinic_node(to,0,flow,root[from]);
	root[from]=cnt;
	cnt++;
	m[cnt]=dinic_node(from,0,0,root[to]);
	root[to]=cnt;
	cnt++;
}

const int dinic::max_flow(const int s,const int t){
	maxflow=0;
	dinic_in();
	return maxflow;
}

/**********************************************************************************/

class dinic_mcmf_node{
	friend class dinic_mcmf;
	private:
		int to;
		int flow;
		int cap;
		int cost;
		int nex;
		dinic_mcmf_node(void);
		dinic_mcmf_node(int to_,int flow_,int cap_,int cost_,int nex_);
};

dinic_mcmf_node::dinic_mcmf_node(void){
	return;
}

dinic_mcmf_node::dinic_mcmf_node(int to_,int flow_,int cap_,int cost_,int nex_){
	to=to_;
	flow=flow_;
	cap=cap_;
	cost=cost_;
	nex=nex_;
}



class dinic_mcmf{
	private:
		dinic_mcmf_node m[MAXN];
		int cnt;
		int n;
		int root[MAXN];
		queue_c <int> q;
		int cur[MAXN];
		int dis[MAXN];
		bool vis[MAXN];
		int s_,t_;
		const bool spfa(void);
		int dfs(int u,int flow);
		void dinic_in(void);
	public:
		int maxflow;
		int mincost;
	public:
		explicit dinic_mcmf(const int num);
		const SIZE_C size(void);
		void connect(const int from,const int to,const int flow,const int cost);
		const pair_c<int,int> mcmf(const int s,const int t);
};

const bool dinic_mcmf::spfa(void){
	for(int i=1;i<=n;i++){
		dis[i]=0x3fffffff;
		vis[i]=0;
	}
	dis[s_]=0;
	q.insert(s_);
	vis[s_]=1;
	int tp;
	while(!q.empty()){
		tp=q.front();
		vis[tp]=0;
		q.pop();
		for(int p=root[tp];p!=-1;p=m[p].nex){
			if(m[p].flow<m[p].cap&&dis[m[p].to]>dis[tp]+m[p].cost){
				dis[m[p].to]=dis[tp]+m[p].cost;
				if(!vis[m[p].to]){
					q.insert(m[p].to);
					vis[m[p].to]=1;
				}
			}
		}
	}
	return dis[t_]!=0x3fffffff;
}

int dinic_mcmf::dfs(int u,int flow){
	if(u==t_||flow==0){
		return flow;
	}
	int d=0,ret=0;
	vis[u]=1;
	for(int& p=cur[u];p!=-1;p=m[p].nex){
		if(!vis[m[p].to]&&dis[m[p].to]==dis[u]+m[p].cost){
			d=dfs(m[p].to,min(flow-ret,m[p].cap-m[p].flow));
			ret+=d;
			mincost+=m[p].cost*d;
			m[p].flow+=d;
			m[p^1].flow-=d;
			if(ret==flow)break;
		}
	}
	vis[u]=0;
	return ret;
}

void dinic_mcmf::dinic_in(void){
	while(spfa()){
		for(int i=1;i<=n;i++){
			cur[i]=root[i];
			vis[i]=0;
		}
		maxflow+=dfs(s_,INF);
	}
}

dinic_mcmf::dinic_mcmf(const int num){
	n=num;
	cnt=0;
	for(int i=1;i<=n;i++){
		root[i]=-1;
	}
}

const SIZE_C dinic_mcmf::size(void){
	return n;
}

void dinic_mcmf::connect(const int from,const int to,const int flow,const int cost){
	m[cnt]=dinic_mcmf_node(to,0,flow,cost,root[from]);
	root[from]=cnt;
	cnt++;
	m[cnt]=dinic_mcmf_node(from,0,0,cost,root[to]);
	root[to]=cnt;
	cnt++;
}

const pair_c<int,int> dinic_mcmf::mcmf(const int s,const int t){
	s_=s;
	t_=t;
	maxflow=0;
	mincost=0;
	dinic_in();
	return pair_c<int,int>(maxflow,mincost);
}

/*******************************************************************************/

class lc_segment{
	friend class max_line_segment_tree;
	friend class min_line_segment_tree;
	private:
		double k,b;
		lc_segment(void);
		lc_segment(double k_,double b_);
		lc_segment(double xl,double xr,double yl,double yr);
		const double fx(double x);
};

lc_segment::lc_segment(void){
	k=0.0;
	b=0.0;
}

lc_segment::lc_segment(double k_,double b_){
	k=k_;
	b=b_;
}

lc_segment::lc_segment(double xl,double xr,double yl,double yr){
	k=(yr-yl)/(xr-xl);
	b=yr-xr*k;
}

const double lc_segment::fx(double x){
	return k*x+b;
}



class max_line_segment_tree{
	private:
		lc_segment a[MAXN];
		int tr[MAXN*2];
		int cnt;
		int n;//range
		int cmp(double x,double y);
		pair_c<double,int> max(pair_c<double,int> x,pair_c<double,int> y);
		void build(int p,int l,int r);
		void pushdown(int p,int id,int l,int r);
		void insert_in(int p,int l,int r,int id,int lx,int rx);
		pair_c<double,int> query(int p,int l,int r,int px);
	public:
		explicit max_line_segment_tree(const int range);
		const SIZE_C size(void);
		const SIZE_C value_range(void);
		const int insert(const int xl,const int yl,const int xr,const int yr);
		const double max(const int p);
		const int max_segment(const int p);
};

int max_line_segment_tree::cmp(double x,double y){
	if(x-y>eps)return 1;
	if(y-x>eps)return -1;
	return 0;
}

pair_c<double,int> max_line_segment_tree::max(pair_c<double,int> x,pair_c<double,int> y){
	if(x.x2==0)return y;
	if(y.x2==0)return x;
	int c=cmp(x.x1,y.x1);
	if(c==1||(c==0&&x.x2<y.x2)){
		return x;
	}else{
		return y;
	}
}

void max_line_segment_tree::build(int p,int l,int r){
	tr[p]=0;
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	build(p<<1,l,mid);
	build(p<<1|1,mid+1,r);
}

void max_line_segment_tree::pushdown(int p,int id,int l,int r){
	if(!id)return;
	if(tr[p]==0){
		tr[p]=id;
		return;
	}
	int mid=(l+r)>>1;
	int dmid=cmp(a[tr[p]].fx(mid),a[id].fx(mid));
	if(dmid==-1||(dmid==0&&tr[p]>id)){
		swap_c(tr[p],id);
	}
	int dl=cmp(a[tr[p]].fx(l),a[id].fx(l));
	int dr=cmp(a[tr[p]].fx(r),a[id].fx(r));
	if(dl==-1||(dl==0&&id<tr[p])){
		if(l^r)pushdown(p<<1,id,l,mid);
	}
	if(dr==-1||(dr==0&&id<tr[p])){
		if(l^r)pushdown(p<<1|1,id,mid+1,r);
	}
}

void max_line_segment_tree::insert_in(int p,int l,int r,int id,int lx,int rx){
	if(inrange(l,r,lx,rx)){
		pushdown(p,id,l,r);
		return;
	}
	if(outofrange(l,r,lx,rx)){
		return;
	}
	int mid=(l+r)>>1;
	insert_in(p<<1,l,mid,id,lx,rx);
	insert_in(p<<1|1,mid+1,r,id,lx,rx);
}

pair_c<double,int> max_line_segment_tree::query(int p,int l,int r,int px){
	if(l==r){
		return pair_c<double,int>(a[tr[p]].fx(px),tr[p]);
	}
	int mid=(l+r)>>1;
	pair_c<double,int> t=pair_c<double,int>(a[tr[p]].fx(px),tr[p]);
	if(px>mid){
		return max(query(p<<1|1,mid+1,r,px),t);
	}else{
		return max(query(p<<1,l,mid,px),t);
	}
}

max_line_segment_tree::max_line_segment_tree(const int range){
	n=range;
	build(1,1,n);
	cnt=0;
}

const SIZE_C max_line_segment_tree::size(void){
	return cnt;
}

const SIZE_C max_line_segment_tree::value_range(void){
	return n;
}

const int max_line_segment_tree::insert(const int xl,const int yl,const int xr,const int yr){
	cnt++;
	if(xl==xr){
		a[cnt]=lc_segment(0.0,max_c(yl,yr));
	}else{
		a[cnt]=lc_segment(xl,xr,yl,yr);
	}
	if(xl>xr){
		insert_in(1,1,n,cnt,xr,xl);
	}else{
		insert_in(1,1,n,cnt,xl,xr);
	}
	return cnt;
}

const double max_line_segment_tree::max(const int p){
	return query(1,1,n,p).x1;
}

const int max_line_segment_tree::max_segment(const int p){
	return query(1,1,n,p).x2;
}



class min_line_segment_tree{
	private:
		lc_segment a[MAXN];
		int tr[MAXN*2];
		int cnt;
		int n;//range
		int cmp(double x,double y);
		pair_c<double,int> min(pair_c<double,int> x,pair_c<double,int> y);
		void build(int p,int l,int r);
		void pushdown(int p,int id,int l,int r);
		void insert_in(int p,int l,int r,int id,int lx,int rx);
		pair_c<double,int> query(int p,int l,int r,int px);
	public:
		explicit min_line_segment_tree(const int range);
		const SIZE_C size(void);
		const SIZE_C value_range(void);
		const int insert(const int xl,const int yl,const int xr,const int yr);
		const double min(const int p);
		const int min_segment(const int p);
};

int min_line_segment_tree::cmp(double x,double y){
	if(x-y>eps)return 1;
	if(y-x>eps)return -1;
	return 0;
}

pair_c<double,int> min_line_segment_tree::min(pair_c<double,int> x,pair_c<double,int> y){
	if(x.x2==0)return y;
	if(y.x2==0)return x;
	int c=cmp(x.x1,y.x1);
	if(c==1||(c==0&&x.x2<y.x2)){
		return y;
	}else{
		return x;
	}
}

void min_line_segment_tree::build(int p,int l,int r){
	tr[p]=0;
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	build(p<<1,l,mid);
	build(p<<1|1,mid+1,r);
}

void min_line_segment_tree::pushdown(int p,int id,int l,int r){
	if(!id)return;
	if(tr[p]==0){
		tr[p]=id;
		return;
	}
	int mid=(l+r)>>1;
	int dmid=cmp(a[tr[p]].fx(mid),a[id].fx(mid));
	if(dmid==1||(dmid==0&&tr[p]>id)){
		swap_c(tr[p],id);
	}
	int dl=cmp(a[tr[p]].fx(l),a[id].fx(l));
	int dr=cmp(a[tr[p]].fx(r),a[id].fx(r));
	if(dl==1||(dl==0&&id<tr[p])){
		if(l^r)pushdown(p<<1,id,l,mid);
	}
	if(dr==1||(dr==0&&id<tr[p])){
		if(l^r)pushdown(p<<1|1,id,mid+1,r);
	}
}

void min_line_segment_tree::insert_in(int p,int l,int r,int id,int lx,int rx){
	if(inrange(l,r,lx,rx)){
		pushdown(p,id,l,r);
		return;
	}
	if(outofrange(l,r,lx,rx)){
		return;
	}
	int mid=(l+r)>>1;
	insert_in(p<<1,l,mid,id,lx,rx);
	insert_in(p<<1|1,mid+1,r,id,lx,rx);
}

pair_c<double,int> min_line_segment_tree::query(int p,int l,int r,int px){
	if(l==r){
		return pair_c<double,int>(a[tr[p]].fx(px),tr[p]);
	}
	int mid=(l+r)>>1;
	pair_c<double,int> t=pair_c<double,int>(a[tr[p]].fx(px),tr[p]);
	if(px>mid){
		return min(query(p<<1|1,mid+1,r,px),t);
	}else{
		return min(query(p<<1,l,mid,px),t);
	}
}

min_line_segment_tree::min_line_segment_tree(const int range){
	n=range;
	build(1,1,n);
	cnt=0;
}

const SIZE_C min_line_segment_tree::size(void){
	return cnt;
}

const SIZE_C min_line_segment_tree::value_range(void){
	return n;
}

const int min_line_segment_tree::insert(const int xl,const int yl,const int xr,const int yr){
	cnt++;
	if(xl==xr){
		a[cnt]=lc_segment(0.0,min_c(yl,yr));
	}else{
		a[cnt]=lc_segment(xl,xr,yl,yr);
	}
	if(xl>xr){
		insert_in(1,1,n,cnt,xr,xl);
	}else{
		insert_in(1,1,n,cnt,xl,xr);
	}
	return cnt;
}

const double min_line_segment_tree::min(const int p){
	return query(1,1,n,p).x1;
}

const int min_line_segment_tree::min_segment(const int p){
	return query(1,1,n,p).x2;
}








#endif
