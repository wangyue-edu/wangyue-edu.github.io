#include <iostream>
#include <string>
#include <vector>
using namespace std;

class SExpr {
  public:
    string value;
    vector<SExpr *> children;
    SExpr *parent;
    SExpr(string value, SExpr *parent);
    ~SExpr();
};

SExpr::SExpr(string value, SExpr *parent) {
    this->value = value;
    this->parent = parent;
}

SExpr::~SExpr() {
    for (auto ptr : children) {
        delete ptr;
    }
}

SExpr* &Parse(string src) {
    string s1 = "(", s2 = ")", s3 = " ( ", s4 = " ) ";
    size_t pos, targetSize, resSize;

    pos = src.find(s1);
    targetSize = s1.size();
    resSize = s3.size();
    while (pos != string::npos) {
        src.replace(pos, targetSize, s3);
        pos = src.find(s1, pos + resSize);
    }

    pos = src.find(s2);
    targetSize = s2.size();
    resSize = s4.size();
    while (pos != string::npos) {
        src.replace(pos, targetSize, s4);
        pos = src.find(s2, pos + resSize);
    }

    vector<string> tokens;
    string temp;
    for (auto ch : src) {
        if (ch != ' ') {
            temp += ch;
        } else {
            if (!temp.empty()) {
                tokens.push_back(temp);
                temp.clear();
            }
        }
    }

    SExpr *AST = new SExpr(" ", nullptr);
    SExpr *current = AST;
    for (auto token : tokens) {
        if (token == "(") {
            SExpr *node = new SExpr("*", current);
            current->children.push_back(node);
            current = node;
        } else if (token == ")") {
            current = current->parent;
        } else {
            current->children.push_back(new SExpr(token, current));
        }
    }
    return AST->children[0];
}

void Search(SExpr *AST) {
    cout << AST->value << " ";
    for (auto i : AST->children) {
        Search(i);
    }
    return;
}

int main() {
    string src;
    getline(cin, src);
    SExpr* AST = Parse(src);
    Search(AST);
	cout << endl;
    return 0;
}
