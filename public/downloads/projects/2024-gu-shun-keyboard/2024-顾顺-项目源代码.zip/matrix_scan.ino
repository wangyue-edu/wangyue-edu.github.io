#include <Arduino.h>

// 75键分体式键盘矩阵扫描与状态防抖算法
// 主控引脚分配：ESP32 GPIO 12, 14, 26, 27 驱动 CD74HC4067B 4位二进制选择线
// GPIO 25 接收模拟开关信号反馈；GPIO 4, 5, 15, 17 驱动 LED 状态指示

bool p[17], q[17];
// 按键物理位置与逻辑扫描线映射表
int mapp[17] = {3, 7, 4, 8, 12, 16, 15, 11, 14, 13, 10, 9, 6, 5, 2, 1, 0};

void setup() {
  pinMode(12, OUTPUT);
  pinMode(14, OUTPUT);
  pinMode(27, OUTPUT);
  pinMode(26, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(15, OUTPUT);
  pinMode(17, OUTPUT);
  pinMode(25, INPUT);
  for (int i = 0; i < 16; i++) {
    q[i] = 0;
  }
  Serial.begin(115200);
}

// 快速电平转换工具函数
bool ctc(int x) {
  return x ? HIGH : LOW;
}

int cnt;
void loop() {
  // 1. 16路复用器快速轮询扫描
  for (int i = 0; i < 16; i++) {
    digitalWrite(26, ctc(i & 1));
    digitalWrite(27, ctc(i & 2));
    digitalWrite(14, ctc(i & 4));
    digitalWrite(12, ctc(i & 8));
    p[i] = digitalRead(25);
  }

  // 2. 状态比对、异或防抖与按键事件上报
  cnt = 0;
  for (int i = 0; i < 16; i++) {
    if (p[i]) cnt++;
    if (p[i] ^ q[i]) {
      if (p[i]) {
        Serial.print("down: ");
        Serial.println(mapp[i]);
      } else {
        Serial.print("up: ");
        Serial.println(mapp[i]);
      }
    }
    // 状态迭代交换
    p[i] ^= q[i] ^= p[i] ^= q[i];
  }

  // 3. 统计计数指示灯更新
  digitalWrite(5, ctc(cnt & 1));
  digitalWrite(4, ctc(cnt & 2));
  digitalWrite(15, ctc(cnt & 4));
  digitalWrite(17, ctc(cnt & 8));
  delay(10);
}
