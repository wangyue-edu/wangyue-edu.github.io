//Rover center control program

#define in1_pin 6
#define in2_pin 7
#define enA_pin 10
#define in3_pin 4
#define in4_pin 5
#define enB_pin 9
#define lanuch_pin 8

int lanuch_pin_state=0;
long cmd = 0;

void InitRoverPins();
void SetWheel(int lrate, int rrate);
long getSerialCmd();
void ExcSerialCmd(long cmd);
void test();

void setup() {
  pinMode(13, OUTPUT);
  digitalWrite(13, 0);

  Serial.begin(9600);
  InitRoverPins();
  SetWheel(0, 0);
  Serial.println("yepReady");
  
  delay(300);
  digitalWrite(13, 1);

  digitalWrite(13, 0);
  delay(300);
  digitalWrite(13, 1);
}

void loop() {
  cmd = getSerialCmd();
  ExcSerialCmd(cmd);
  cmd=0;
  delay(100);
}

long getSerialCmd() {
  long t=0;
  while (Serial.available() > 0) {
    t = Serial.parseInt();
    if (Serial.read() == 'X') {
      return t;
    }
  }
  return 0;
}

void ExcSerialCmd(long cmd) {
  if (cmd >= 100100 && cmd <= 300300) {
    int lrate = (cmd / 1000) - 200;
    int rrate = (cmd % 1000) - 200;
    SetWheel(lrate, rrate);
    return;
  }
  if (cmd == 666666) {
    test();
    return;
  }
}

void test() {
  lanuch_pin_state=1-lanuch_pin_state;
  digitalWrite(lanuch_pin, lanuch_pin_state);
  Serial.print("yep");Serial.println(lanuch_pin_state);
}

void InitRoverPins() {
  pinMode(in1_pin, OUTPUT);
  pinMode(in2_pin, OUTPUT);
  pinMode(in3_pin, OUTPUT);
  pinMode(in4_pin, OUTPUT);
  pinMode(enA_pin, OUTPUT);
  pinMode(enB_pin, OUTPUT);
  pinMode(lanuch_pin,OUTPUT);

  digitalWrite(in1_pin, 0);
  digitalWrite(in2_pin, 0);
  digitalWrite(in3_pin, 0);
  digitalWrite(in4_pin, 0);
  digitalWrite(enA_pin, 0);
  digitalWrite(enB_pin, 0);
  digitalWrite(lanuch_pin,0);
}

void SetWheel(int lrate, int rrate) {
  if (lrate == 0) {
    digitalWrite(in1_pin, 0);
    digitalWrite(in2_pin, 0);
    digitalWrite(enA_pin, 0);
  }
  else {
    if (lrate > 0) {
      digitalWrite(in1_pin, 1);
      digitalWrite(in2_pin, 0);
    }
    if (lrate < 0) {
      digitalWrite(in1_pin, 0);
      digitalWrite(in2_pin, 1);
    }
    lrate = abs(lrate); lrate = map(lrate, 0, 100, 0, 255);
    analogWrite(enA_pin, lrate);
  }

  if (rrate == 0) {
    digitalWrite(in3_pin, 0);
    digitalWrite(in4_pin, 0);
    digitalWrite(enB_pin, 0);
  }
  else {
    if (rrate > 0) {
      digitalWrite(in3_pin, 1);
      digitalWrite(in4_pin, 0);
    }
    if (rrate < 0) {
      digitalWrite(in3_pin, 0);
      digitalWrite(in4_pin, 1);
    }
    rrate = abs(rrate); rrate = map(rrate, 0, 100, 0, 255);
    analogWrite(enB_pin, rrate);
  }
  Serial.print("yep");Serial.print(lrate);Serial.print("&");Serial.println(rrate);
}
