#coding=utf8
from RoverMethods import *
import cv2
import datetime
import serial

VideoUrl = 'http://admin:*******************:8081/video'
SizePerReading = 16000
try:
    ipCam = IpCamera(VideoUrl, SizePerReading)
except:
    print 'Error:IpCamera is not online.'
    exit(0)

try:
    ser = serial.Serial('com6', 9600)
except:
    ser=None
    print 'Error:RoverBlueTooth is not online.'

aim = AimCircle()
aim.StTime = datetime.datetime.now()

rover=Rover()

cv2.namedWindow('RoverCamera', cv2.WINDOW_NORMAL)
cv2.setWindowProperty("RoverCamera", cv2.WND_PROP_FULLSCREEN, 1)

while True:
    img = ipCam.getFrame()
    if img is None:
        print 'IpCamera is offline.'
        exit(0)

    img = aim.drawAimCircle(img)
    #img=drawLaserCircle(img)
    img=rover.drawDirectionArc(img)

    if img is None:
        print 'Unknown Error.'
        exit(0)
    cv2.imshow('RoverCamera', img)

    #key = cv2.waitKey(1)
    key=waitkey(10)
    if key == 27:
        exit(0)
    if key == ord('q'):
        aim.StTime = datetime.datetime.now()
    if key == -1:
        rover.sendCmd(ser,'stop')
    if key == ord('w'):
        rover.sendCmd(ser, 'goForward')
    if key == ord('s'):
        rover.sendCmd(ser, 'goBackward')
    if key == ord('a'):
        rover.sendCmd(ser, 'turnLeft')
    if key == ord('d'):
        rover.sendCmd(ser, 'turnRight')

"""
TODO:
    莫名其妙的失去响应
"""