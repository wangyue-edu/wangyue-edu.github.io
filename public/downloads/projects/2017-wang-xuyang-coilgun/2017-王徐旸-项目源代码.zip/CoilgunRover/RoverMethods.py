import cv2
import urllib
import numpy as np
import datetime
import serial
from math import *

#class AimCircle()
#class IpCamera()
#class Rover()
#def drawLaserCircle(frame)
#def getLaserDistance(img,LaserPoints,PHI)

class AimCircle():
    Circle_MaxRadii = 150
    Circle_MinRadii = 10
    AimTime = 3000
    Circle_Color = (0, 255, 0)

    def __init__(self):
        self.StTime = None

    def drawAimCircle(self, img):
        if self.StTime is None: return img
        stTime = self.StTime.minute * 60000 + self.StTime.second * 1000 + self.StTime.microsecond / 1000
        now = datetime.datetime.now()
        edTime = now.minute * 60000 + now.second * 1000 + now.microsecond / 1000
        radii = AimCircle.getRadii(edTime - stTime)
        (Ox, Oy) = (img.shape[1] / 2, img.shape[0] / 2)
        cv2.circle(img, (Ox, Oy), radii, AimCircle.Circle_Color, 2)
        if radii==AimCircle.Circle_MinRadii:cv2.putText(img,'Locked',(Ox-20,Oy-20),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),2)
        return img

    @classmethod
    def getRadii(cls, dTime):
        if dTime <= 0: return AimCircle.Circle_MaxRadii
        if dTime > 0 and dTime < AimCircle.AimTime:
            return int((
                           AimCircle.Circle_MinRadii - AimCircle.Circle_MaxRadii) * dTime / AimCircle.AimTime + AimCircle.Circle_MaxRadii)
        if dTime >= AimCircle.AimTime:
            return AimCircle.Circle_MinRadii

class IpCamera():
    def __init__(self, url, size):
        self.stream = urllib.urlopen(url)
        self.bytes = ''
        self.SizePerReading = size
    def getFrame(self):
        for i in range(8):
            if i == 7: return None
            self.bytes += self.stream.read(self.SizePerReading)
            a = self.bytes.find('\xff\xd8')
            b = self.bytes.find('\xff\xd9')
            if a != -1 and b != -1:
                jpg = self.bytes[a:b + 2]
                self.bytes = self.bytes[b + 2:]
                break
        return cv2.imdecode(np.fromstring(jpg, dtype=np.uint8), cv2.IMREAD_COLOR)

class Rover():
    def __init__(self):
        self.state=""

    def sendCmd(self,ser,cmd):
        if ser is None:return
        if cmd is None or cmd=='':return

        if self.state==cmd:
            return
        else:
            ser.write(Rover.RoverCmd[cmd])
            self.state=cmd
            # print cmd

    def drawDirectionArc(self,img):
        axes=(40,40)
        if self.state=="goForward":
            cv2.ellipse(img,(img.shape[1]//2,img.shape[0]//2),axes,-90,45,-45,(0,255,0),2)
        if self.state=="goBackward":
            cv2.ellipse(img, (img.shape[1] // 2, img.shape[0] // 2), axes, 90, 45, -45, (0, 255, 0),2)
        if self.state == "turnLeft":
            cv2.ellipse(img, (img.shape[1] // 2, img.shape[0] // 2), axes, -90,0, -90, (0, 255, 0),2)
        if self.state == "turnRight":
            cv2.ellipse(img, (img.shape[1] // 2, img.shape[0] // 2), axes, 0, 0, -90, (0, 255, 0),2)
        return img

    RoverCmd = {
    'stop': '200200X',
    'goForward': '300300X',
    'goBackward': '100100X',
    'turnLeft': '100300X',
    'turnRight': '300100X',
    'lanuch': '',
    'reload': '',
    'chargeOn': '',
    'chargeOff': '',
    'X+': '',
    'X-': '',
    'Y+': '',
    'Y-': '',
    'X0': '',
    'Y0': ''
}

def drawLaserCircle(frame):
    img = frame
    r = cv2.split(img)[2]
    (T, gr) = cv2.threshold(r, 225, 255, cv2.THRESH_BINARY)
    contours, h = cv2.findContours(gr, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    if contours == []: return frame
    LaserPoints=[]
    for c in contours:
        try:
            M = cv2.moments(c)
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            LaserPoints.append((cX,cY))
        except:
            continue

    (lX,lY),distance=getLaserDistance(img,LaserPoints,0)
    if distance is None:return frame
    cv2.circle(img, (lX, lY), 10, [0, 255, 0], 1)
    cv2.putText(img,'Target:'+distance+'cm',(lX-20,lY-20),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),2)
    return img



def getLaserDistance(img,LaserPoints,PHI):
    '''if LaserPoints is None:return None
    oX,oY=img.shape[1]/2,img.shape[0]/2
    lX,lY=-1,-1
    MinPixelDistance=sqrt(img.shape[1]**2+img.shape[0]**2)
    for (pX,pY) in LaserPoints:
        pPixelDistance=sqrt((pX-oX)**2+(pY-oY)**2)
        if pPixelDistance<MinPixelDistance and img[pY,pX,2]>225:
            lX,lY=pX,pY
            MinPixelDistance=pPixelDistance
    ''unit:cm''
    S=10
    Rop=0.0015974
    Offset=0.0073933
    LaserDistance=S/(tan(MinPixelDistance*Rop+Offset))
    LaserDistance='{:.2f}'.format(LaserDistance)
    return (lX,lY),LaserDistance'''
    if LaserPoints is None:return None
    oX,oY=img.shape[1]/2,img.shape[0]/2
    lX,lY=-1,-1
    '''S unit:cm'''
    S,Rop,Offset,PHItol=10,0.0015974,0.0073933,0.05
    for (pX,pY) in LaserPoints:
        alphaX,alphaY=abs(pX-oX)*Rop+Offset,abs(pY-oY)*Rop+Offset
        if pX>oX:continue
        if abs((cos(alphaX)*tan(alphaY)))-abs(tan(PHI))>PHItol:continue
        lX,lY=pX,pY
    if lX==-1:return (0,0),None
    PixelDistance=abs(lX-oX)
    LaserDistance='{:.2f}'.format(S/(tan(PixelDistance*Rop+Offset))/cos(PHI)+13)
    return (lX,lY),LaserDistance

def waitkey(delay=0):
    getkey = lambda key1, key2: key1 if key2 == -1 else key2
    st = datetime.datetime.now().microsecond / 1000
    key = getkey(-1, cv2.waitKey(1))
    while (True):
        ed = datetime.datetime.now().microsecond / 1000
        if ed < st: ed += 1000
        if ed - st >= delay:
            break
        else:
            key = getkey(key, cv2.waitKey(1))
    return key

if __name__ == '__main__':
    img = cv2.imread('D:\\test\img002.jpg')
    img = drawLaserCircle(img)
    cv2.imshow('img', img)
    print type(datetime.datetime.now().second)
    waitkey(10)
