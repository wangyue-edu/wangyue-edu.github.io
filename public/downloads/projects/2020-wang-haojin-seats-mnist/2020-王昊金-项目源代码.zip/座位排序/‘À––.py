from xlrd import *
from xlwt import *
from tkinter import *
import xlrd
import xlwt
import tkinter
top = Tk()
top.title("座位自动处理")
Label(text="输入文件名").pack(side=LEFT,fill=Y)
file = Entry()
file.pack(side=LEFT,fill=BOTH)
def deal():
    global file
    filename = file.get()
    try:
        data = xlrd.open_workbook(filename)
        table = data.sheets()[0]
        classname = table.col_values(0, start_rowx=0, end_rowx=None)
        classnum = table.col_values(1, start_rowx=0, end_rowx=None)

        example = xlrd.open_workbook('ex.xlsx')
        book = example.sheets()[0]
        m = book.nrows
        n = book.ncols
        
        workbook = xlwt.Workbook()
        worksheet = workbook.add_sheet('result')

##begin 算法————————————————————————————————
        for sit in range(1,1097):
            for i in range(m):
                for j in range(n):
                    if book.cell_value(i,j)==sit:
                        for s in range(len(classnum)):
                            if classnum[s] > 0:
                                break
                        if s == len(classnum) - 1:
                            break
                        color = [3,4,5,6,3,4,5,6,3,4,5,6,3,4,5,6]
                        style = XFStyle()
                        pattern = Pattern()
                        pattern.pattern = Pattern.SOLID_PATTERN
                        pattern.pattern_fore_colour = color[s]
                        style.pattern = pattern
                        worksheet.write(i,j,classname[s],style)
                        classnum[s] = classnum[s] - 1
        style = XFStyle()
        pattern = Pattern()
        pattern.pattern = Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = 24
        style.pattern = pattern
        workbook.save('result.xls')
        top.destroy()
        tb = Tk()
        tb.title("关于")
        Label(tb,text="本软件\n由南通中学科技社团联盟完成\n").pack(fill=X)
        Button(tb,text="确定",command=tb.destroy).pack(fill=X)
    except:
        Messagebox = Tk()
        Messagebox.title("找不到文件。")
        Label(Messagebox,text="\n请检查文件位置是否放在同一文件夹下，是否输入文件后缀名,本软件暂时不支持中文名。\n").grid(row=0,ipadx=20)
        Button(Messagebox,text="确定",command=Messagebox.destroy).grid(row=1,ipadx=100)
Button(text="处理",command=deal).pack(side=RIGHT,fill=Y)
top.mainloop()
