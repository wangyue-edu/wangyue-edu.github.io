from tkinter import *
from tkinter import ttk, messagebox
from xlutils.copy import copy
import tkinter
import tkinter.messagebox
import xlrd
import datetime
import xlwt

tk = Tk()
var = IntVar()
tk.geometry('800x400')
tk.title("仓库管理系统")
l = 2000
modify = [0] * l
date1 = str(datetime.datetime.now())
date1 = date1[0:10]
readbook = xlrd.open_workbook('Excel_Workbook.xls')
readsheet = readbook.sheets()[0]
classname = readsheet.col_values(0, start_rowx=1, end_rowx=None)
classnum = readsheet.col_values(1, start_rowx=1, end_rowx=None)
numa = -1
numb = -1
numc = -1
classa = []
classb = []
classc = []
# 序号/数目
tota = []
totb = []
ordera = []
orderb = []
orderc = []
# 前缀和
suma = []
sumb = []
length = len(classname)
for x in range(len(classname)):
    if classname[x][0] == '*':
        numa += 1
        classa.append(classname[x])
        tota.append(0)
        ordera.append(x)
    else:
        if classname[x][0] == '/':
            numb += 1
            classb.append(classname[x])
            totb.append(0)
            orderb.append(x)
            tota[numa] += 1
        else:
            numc += 1
            classc.append(classname[x])
            totb[numb] += 1
            orderc.append(x)
suma.append(tota[0])
sumb.append(totb[0])
for x in range(1, numa + 1):
    suma.append(suma[x - 1] + tota[x])
for x in range(1, numb + 1):
    sumb.append(sumb[x - 1] + totb[x])
for x in range(0, numc + 1):
    print(orderc[x])
for x in range(0, 9):
    print(classnum[x])

def run4():
    if messagebox.askokcancel("提示", "是否将数据录入excel？"):
        run1()


def revi(event):
    global classnum
    lbnum.config(text=classnum[orderc[cbx_1.current()]], font="tahoma 12 normal")
    lbmodify.config(text=modify[orderc[cbx_1.current()]], font="tahoma 12 normal")


def run1():
    global readbook
    global readsheet
    copybook = copy(readbook)
    worksheet = copybook.get_sheet(0)

    style1 = xlwt.XFStyle()
    style1.num_format_str = 'M/D/YY'
    '''
    pattern2 = xlwt.Pattern()
    pattern2.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern2.pattern_fore_colour = 2
    style2 = xlwt.XFStyle()
    style2.pattern = pattern2
    pattern3 = xlwt.Pattern()
    pattern3.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern3.pattern_fore_colour = 3
    style3 = xlwt.XFStyle()
    style3.pattern = pattern3
    '''
    for x in range(len(classname)):
        if modify[x] != 0:
            worksheet.write(x + 1, 1, classnum[x] + modify[x])
            roww = readsheet.row_values(x + 1)
            lengy=len(roww)
            for y in range(len(roww)):
                cell_value = readsheet.cell(x, y).value
                if cell_value == '' or cell_value == ' ':
                    lengy=y+1
                    break

            worksheet.col(lengy).width = 3000
            worksheet.col(lengy+1).width = 3000
            worksheet.write(x + 1, lengy, date1, style1)
            if modify[x] > 0:
                worksheet.write(x + 1, lengy + 1, modify[x])
            if modify[x] < 0:
                worksheet.write(x + 1, lengy + 1, modify[x])

    copybook.save('Excel_Workbook.xls')
    tkinter.messagebox.showinfo(title='提示', message='修改内容已录入excel')


def run2():
    global modify
    a = int(numb1.get())
    if cbx_2.current() == 0:
        modify[orderc[cbx_1.current()]] = a * (-1)
    else:
        modify[orderc[cbx_1.current()]] = a
    lbmodify.config(text=modify[orderc[cbx_1.current()]], font="tahoma 12 normal")


def run3():
    global classname, classnum, cbx_1, cbx_2, numa, numb
    def run5():
        global classname, classnum, numa, numb
        a = str(numb3.get())
        if a == '':
            tkinter.messagebox.showinfo(title='提示', message='请输入种类的名称')
        else:
            classa.append(a)
            tota.append(0)
            cbx_3["values"] = classa
            suma.append(suma[numa])
            numa += 1
    def run6():
        global classname, classnum, cbx_1, length, numa, numb
        a = str(numb4.get())
        if a == '':
            tkinter.messagebox.showinfo(title='提示', message='请输入种类的名称')
        else:
            tota[cbx_3.current()] += 1
            classb.append(classb[numb])
            totb.append(totb[numb])
            sumb.append(sumb[numb])
            for x in range(numb, suma[cbx_3.current()], -1):
                classb[x] = classb[x-1]
                totb[x] = totb[x - 1]
                totb[x] = totb[x - 1]
                classnum[x] = classnum[x - 1]
            classb[suma[cbx_3.current()]] = a
            totb[suma[cbx_3.current()]] = 0
            sumb[suma[cbx_3.current()]] = sumb[suma[cbx_3.current()]-1]
            # classnum[suma[cbx_3.current()]] =
            cbx_4["values"] = classb
            numb += 1
    def run7():
        global classname, classnum, cbx_2, numa, numb, numc
        a = str(numb2.get())
        b = int(numb5.get())
        if a == '':
            tkinter.messagebox.showinfo(title='提示', message='请输入种类的名称')
        else:
            totb[cbx_4.current()] += 1
            classc.append(classc[numc])
            print(sumb[cbx_4.current()])
            for x in range(numc, sumb[cbx_4.current()], -1):
                print(x)
                classc[x] = classc[x - 1]
                classnum[x] = classnum[x - 1]
            classc[sumb[cbx_4.current()]] = a
            classnum[sumb[cbx_4.current()]] = b
            cbx_1["values"] = classc
            numc += 1

    t1 = Toplevel(tk)
    t1.geometry('600x400')
    t1.title("新建种类")

    lb8 = Label(t1, text="请选择一级类别", font="tahoma 12 normal")
    lb8.grid(column=0, row=0, pady=20)

    lb9 = Label(t1, text="请选择二级类别", font="tahoma 12 normal")
    lb9.grid(column=1, row=0, )

    lb7 = Label(t1, text="请输入新建种类的名字", font="tahoma 12 normal")
    lb7.grid(column=2, row=0, sticky=E)

    cbx_3 = ttk.Combobox(t1, width=12, height=8)
    cbx_3.grid(column=0, row=1, padx=20, pady=20)
    cbx_3.configure(state="readonly")
    cbx_3["values"] = classa
    cbx_3.current(0)

    cbx_4 = ttk.Combobox(t1, width=12, height=8)
    cbx_4.grid(column=1, row=1, padx=20, pady=20)
    cbx_4.configure(state="readonly")
    cbx_4["values"] = classb
    cbx_4.current(0)

    numb2=Entry(t1)
    numb2.grid(column=2, row=1, padx=20, pady=20)

    numb3 = Entry(t1)
    numb3.grid(column=0, row=2)

    numb4 = Entry(t1)
    numb4.grid(column=1, row=2, padx=20, pady=20)

    lb11 = Label(t1, text="请输入新建种类的库存数量", font="tahoma 12 normal")
    lb11.grid(column=2, row=2, sticky=E)

    btn_a = Button(t1, text="新建一级类别", command=run5)
    btn_a.grid(column=0, row=3)

    btn_b = Button(t1, text="新建二级类别", command=run6)
    btn_b.grid(column=1, row=3)

    numb5 = Entry(t1)
    numb5.grid(column=2, row=3, padx=20, pady=20)

    lb10 = Label(t1)
    lb10.grid(row=4, pady=30)

    btn_c = Button(t1, text="确认新建", command=run7)
    btn_c.grid(column=3, row=5)


lb1 = Label(tk, text="请选择货物的种类", font="tahoma 12 normal")
lb1.grid(column=0, row=0, padx=20, pady=40)


value = StringVar()
cbx_1 = ttk.Combobox(tk, width=12, height=8, textvariable=value)
cbx_1.grid(column=1, row=0)
cbx_1.configure(state="readonly")
cbx_1["values"] = classc
cbx_1.current(0)
cbx_1.bind('<<ComboboxSelected>>', revi)

btn3 = Button(tk, text="新建种类", command=run3)
btn3.grid(column=2, row=0)

lb2 = Label(tk, text="出入情况", font="tahoma 12 normal")
lb2.grid(column=0, row=1)

lbmodify = Label(tk, text=modify[orderc[cbx_1.current()]], font="tahoma 12 normal")
lbmodify.grid(column=1, row=1)

lb3 = Label(tk, text="修改前库存", font="tahoma 12 normal")
lb3.grid(column=2, row=1)

lbnum = Label(tk, text=classnum[orderc[cbx_1.current()]], font="tahoma 12 normal")
lbnum.grid(column=3, row=1)

lb4 = Label(tk, text="修改", font="tahoma 12 normal")
lb4.grid(column=0, row=2)

data2 = ["出", "入", ]
cbx_2 = ttk.Combobox(tk, width=12, height=8)
cbx_2.grid(column=1, row=2, padx=40, pady=40)
cbx_2.configure(state="readonly")
cbx_2["values"] = data2


lb5 = Label(tk, text="数量", font="tahoma 12 normal")
lb5.grid(column=2, row=2, sticky=E)

numb1 = Entry(tk)
numb1.grid(column=3, row=2)

lb6 = Label(tk)
lb6.grid(row=3, pady=30)

btn2 = Button(tk, text="确认修改", command=run2)
btn2.grid(column=3, row=3)

btn1 = Button(tk, text="保存并录入excel", command=run4)
btn1.grid(column=3, row=4)

tk.mainloop()