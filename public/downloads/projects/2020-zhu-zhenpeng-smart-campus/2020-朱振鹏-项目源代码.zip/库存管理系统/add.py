from tkinter import *
from tkinter import ttk, messagebox
from xlutils.copy import copy
import tkinter
import tkinter.messagebox
import xlrd
import xlwt

t1 = Tk()
var = IntVar()
t1.geometry('600x400')
t1.title("新建种类系统")
readbook = xlrd.open_workbook('Excel_Workbook.xls')
readsheet = readbook.sheets()[0]
# 序号
ordera = []
orderb = []
orderc = []
classa = []
classb = []
numa = -1
numb = -1
numc = -1
classname = readsheet.col_values(0, start_rowx=1, end_rowx=None)
for x in range(len(classname)):
    if classname[x][0] == '*':
        numa += 1
        classa.append(classname[x])
        ordera.append(x)
    else:
        if classname[x][0] == '/':
            numb += 1
            classb.append(classname[x])
            orderb.append(x)
        else:
            numc += 1
            orderc.append(x)
# for x in range(0, numc + 1):
    # print(orderc[x])
# for x in range(0, numb + 1):
    # print(orderb[x])
def run1():
    global readbook, readsheet, ordera, orderb, orderc, classa, classb, classc, numa, numb, numc, classname
    readbook = xlrd.open_workbook('save.xls')
    readsheet = readbook.sheets()[0]
    ordera = []
    orderb = []
    orderc = []
    classa = []
    classb = []
    numa = -1
    numb = -1
    numc = -1
    classname = readsheet.col_values(0, start_rowx=1, end_rowx=None)
    for x in range(len(classname)):
        if classname[x][0] == '*':
            numa += 1
            classa.append(classname[x])
            ordera.append(x)
        else:
            if classname[x][0] == '/':
                numb += 1
                classb.append(classname[x])
                orderb.append(x)
            else:
                numc += 1
                orderc.append(x)
    # for x in range(0, numc + 1):
    # print(orderc[x])
    # for x in range(0, numb + 1):
    # print(orderb[x])


def run5():
    global classname, classnum, numa, numb
    a = str(numb3.get())
    if a == '':
        tkinter.messagebox.showinfo(title='提示', message='请输入种类的名称')
    else:
        classa.append(a)
        tota.append(0)
        # ordera.append(len(classname)+1)
        cbx_3["values"] = classa
        suma.append(suma[numa])
        numa += 1
        global readbook
        global readsheet
        copybook = copy(readbook)
        worksheet = copybook.get_sheet(0)
        worksheet.write(ordera[numa], 0, a)
        copybook.save('Excel_Workbook.xls')
        tkinter.messagebox.showinfo(title='提示', message='新建种类已录入excel')
        run1()
        cbx_3["values"] = classa
def run6():
    global classname, classnum, cbx_1, length, numa, numb
    a = str(numb4.get())
    if a == '':
        tkinter.messagebox.showinfo(title='提示', message='请输入种类的名称')
    else:
        copybook = copy(readbook)
        worksheet = copybook.get_sheet(0)
        for x in range(len(classname), ordera[cbx_3.current()]+1, -1):
            coco = readsheet.row_values(x, start_colx=0, end_colx=None)
            for y in range(len(coco)):
                worksheet.write(x + 1, y, coco[y])
        worksheet.write(ordera[cbx_3.current()]+2, 0, a)
        copybook.save('save.xls')
        tkinter.messagebox.showinfo(title='提示', message='新建种类已录入excel')
        run1()
        cbx_4["values"] = classb

def run7():
    global classname, classnum, cbx_2, numa, numb, numc
    a = str(numb2.get())
    b = int(numb5.get())
    if a == '':
        tkinter.messagebox.showinfo(title='提示', message='请输入种类的名称')
    else:
        copybook = copy(readbook)
        worksheet = copybook.get_sheet(0)
        for x in range(len(classname), orderb[cbx_4.current()] + 1, -1):
            coco = readsheet.row_values(x, start_colx=0, end_colx=None)
            for y in range(len(coco)):
                worksheet.write(x + 1, y, coco[y])
        worksheet.write(orderb[cbx_4.current()] + 2, 0, a)
        worksheet.write(orderb[cbx_4.current()] + 2, 1, b)
        for x in range(2,len(readsheet.row_values(orderb[cbx_4.current()] + 2))):
            worksheet.write(orderb[cbx_4.current()] + 2, x, '')
        copybook.save('save.xls')
        copybook.save('Excel_Workbook.xls')
        tkinter.messagebox.showinfo(title='提示', message='新建种类已录入excel')
        run1()

lb8 = Label(t1, text="请选择一级类别", font="tahoma 12 normal")
lb8.grid(column=0, row=0, pady=20)

lb9 = Label(t1, text="请选择二级类别", font="tahoma 12 normal")
lb9.grid(column=1, row=0, )

lb7 = Label(t1, text="请输入新建种类的名字", font="tahoma 12 normal")
lb7.grid(column=2, row=0, sticky=E)

cbx_3 = ttk.Combobox(t1, width=12, height=8)
cbx_3.grid(column=0, row=1, padx=20, pady=20)
cbx_3.configure(state="readonly")
cbx_3["values"] = classa
cbx_3.current(0)

cbx_4 = ttk.Combobox(t1, width=12, height=8)
cbx_4.grid(column=1, row=1, padx=20, pady=20)
cbx_4.configure(state="readonly")
cbx_4["values"] = classb
cbx_4.current(0)

numb2=Entry(t1)
numb2.grid(column=2, row=1, padx=20, pady=20)

numb3 = Entry(t1)
numb3.grid(column=0, row=2)

numb4 = Entry(t1)
numb4.grid(column=1, row=2, padx=20, pady=20)

lb11 = Label(t1, text="请输入新建种类的库存数量", font="tahoma 12 normal")
lb11.grid(column=2, row=2, sticky=E)

btn_a = Button(t1, text="新建一级类别", command=run5)
btn_a.grid(column=0, row=3)

btn_b = Button(t1, text="新建二级类别", command=run6)
btn_b.grid(column=1, row=3)

numb5 = Entry(t1)
numb5.grid(column=2, row=3, padx=20, pady=20)

lb10 = Label(t1)
lb10.grid(row=4, pady=30)

btn_c = Button(t1, text="确认新建", command=run7)
btn_c.grid(column=3, row=5)

t1.mainloop()