#include<bits/stdc++.h>
using namespace std;
int main()
{
	for(int i=6;i<=9;i++)
	{
		for(int j=1;j<=2;j++)
		{
			cout<<"value=\"{{array.sport00"<<i<<j<<"}}\" "<<endl;
			cout<<"value=\"{{array.name00"<<i<<j<<"}}\" "<<endl;
		}
	}
	for(int i=10;i<=16;i++)
	{
		for(int j=1;j<=2;j++)
		{
			cout<<"value=\"{{array.sport0"<<i<<j<<"}}\" "<<endl;
			cout<<"value=\"{{array.name0"<<i<<j<<"}}\" "<<endl;
		}
	}
} 
