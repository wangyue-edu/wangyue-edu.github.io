#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
		cout<<"title"; 
		for(int j=1;j<=6;j++)
		{
			for(int i=1;i<=3;i++)
			cout<<",account"<<j<<i;
		}
		cout<<endl;
	
} 
