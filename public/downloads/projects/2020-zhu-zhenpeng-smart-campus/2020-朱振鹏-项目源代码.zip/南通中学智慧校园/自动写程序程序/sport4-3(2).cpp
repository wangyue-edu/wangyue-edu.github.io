#include<bits/stdc++.h>
using namespace std;
int main()
{
	for(int i=1;i<=9;i++)
	{
		for(int j=1;j<=2;j++)
		{
			cout<<"sport00"<<i<<j<<": this.data.array.sport00"<<i<<j<<",name00"<<i<<j<<": this.data.array.name00"<<i<<j<<","<<endl;
		}
	}
	for(int i=10;i<=16;i++)
	{
		for(int j=1;j<=2;j++)
		{
			cout<<"sport0"<<i<<j<<": this.data.array.sport0"<<i<<j<<",name0"<<i<<j<<": this.data.array.name0"<<i<<j<<","<<endl;
		}
	} 
} 
