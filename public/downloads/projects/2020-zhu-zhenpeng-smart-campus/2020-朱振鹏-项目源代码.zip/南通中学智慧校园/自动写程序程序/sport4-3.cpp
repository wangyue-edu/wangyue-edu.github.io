#include<bits/stdc++.h>
using namespace std;
int main()
{
    string a="if (former.sport0092 != this.data.array.sport0092) {if (former.sport0092 != ''&&former.sport0092 != undefined) {db.collection('sport009' + val[9]).doc(former.sport0092).remove()}if (this.data.array.sport0092 != '') {db.collection('sport009' + val[9]).add({data: {_id: this.data.array.sport0092,name: this.data.array.name0092}})}} else if (this.data.array.name0092 != former.name0092) {db.collection('sport009' + val[9]).doc(former.sport0092).update({data: {name: this.data.array.name0092}})}";    for(int i=0;i<=6;i++)
    {
    	for(int j=1;j<=2;j++)
    	{
    		cout<<"if (former.sport01"<<i<<j<<"!=this.data.array.sport01"<<i<<j<<") {if (former.sport01"<<i<<j<<"!= ''&&former.sport01"<<i<<j<<"!= undefined) {db.collection('sport01"<<i<<"'+ val[9]).doc(former.sport01"<<i<<j<<").remove()}if (this.data.array.sport01"<<i<<j<<"!= '') {db.collection('sport01"<<i<<"' + val[9]).add({data: {_id: this.data.array.sport01"<<i<<j<<",name: this.data.array.name01"<<i<<j<<"}})}} else if (this.data.array.name01"<<i<<j<<"!= former.name01"<<i<<j<<") {db.collection('sport01"<<i<<"' + val[9]).doc(former.sport01"<<i<<j<<").update({data: {name: this.data.array.name01"<<i<<j<<"}})}"<<endl;
    	}
    }
} 
