#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
		cout<<"name"; 
		for(int j=1;j<=16;j++)
		{
			if(j==5||j==13) n=1;
			else if(j==8||j==16) n=4;
			else n=2;
			for(int i=1;i<=n;i++)
			{
			if(j<10)
			cout<<",name00"<<j<<i;
			else
			cout<<",name0"<<j<<i;
			}
		}
		for(int j=1;j<=16;j++)
		{
			if(j==5||j==13) n=1;
			else if(j==8||j==16) n=4;
			else n=2;
			for(int i=1;i<=n;i++)
			{		
			if(j<10)
			cout<<",sport00"<<j<<i;
			else
			cout<<",sport0"<<j<<i;
			}
		}
		cout<<endl;
	
} 
