# coding=utf-8
import random
import sys
import time

sys.path.append("/userdata/")
from clicbot import *

# 初始化 ClicBot 多模块机器人控制实例
robot = Clicbot()
print("ClicBot Vision Tracking System Initialized.")

# 智能循迹与动态避障抓取主循环
while True:
    # 读取测距传感器数值 (传感器 ID 9 与 8)
    dist_front = robot.distance_sensor(9)
    dist_side = robot.distance_sensor(8)
    
    if dist_front > 360:
        if dist_side <= 50:
            # 偏离中线过近，执行微幅右修
            robot.preset_action("单右")
            robot.act_wheel_rotate("5ccw,7ccw,4cw,6cw", 50)
        elif dist_side <= 110:
            # 姿态正常，保持正向全速巡线
            robot.preset_action("正")
            robot.act_wheel_rotate("5ccw,7ccw,4cw,6cw", 80)
        elif dist_side <= 350:
            # 偏离中线过远，执行微幅左修
            robot.preset_action("单左")
            robot.act_wheel_rotate("5ccw,7ccw,4cw,6cw", 50)
        else:
            # 到达目标抓取工位，刹车并执行抓取动作
            robot.act_wheel_rotate("5ccw,7ccw,4cw,6cw", 0)
            robot.preset_action("正")
            robot.act_wheel_rotate("5cw,7cw,4ccw,6ccw", 50)
            time.sleep(0.5)
            robot.act_wheel_rotate("5ccw,7ccw,4cw,6cw", 0)
            print("Target reached. Grasping sequence completed.")
            break
    else:
        # 前方遭遇障碍物，执行紧急转弯避障预设动作
        robot.preset_action("转")
        robot.act_wheel_rotate("5ccw,7ccw,4cw,6cw", 60)
        time.sleep(0.5)
