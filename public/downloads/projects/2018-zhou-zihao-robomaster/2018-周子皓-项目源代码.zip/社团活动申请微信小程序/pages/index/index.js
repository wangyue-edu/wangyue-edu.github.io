// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    "name": "",
    "master": "",
    "time": "",
    "place": "",
    "activity": "",
    "purpose": "",
    "method": "",
    "safety": "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  name: function(e) {
    this.setData({
      name: e.detail.value
    })
  },

  master: function (e) {
    this.setData({
      master: e.detail.value
    })
  },

  place: function (e) {
    this.setData({
      place: e.detail.value
    })
  },

  time: function (e) {
    this.setData({
      time: e.detail.value
    })
  },

  activity: function (e) {
    this.setData({
      activity: e.detail.value
    })
  },

  purpose: function (e) {
    this.setData({
      purpose: e.detail.value
    })
  },

  safety: function (e) {
    this.setData({
      safety: e.detail.value
    })
  },

  method: function (e) {
    this.setData({
      method: e.detail.value
    })
  },

  submit: function (e) {
    wx.request({
      url: 'http://118.24.220.49:8080/submit/',
      method: 'POST',
      data: this.data,
      header: { 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      success: function (res) {
        if(res.data == "success"){
          wx.showToast({
            title: '提交成功',
            icon: 'success',
            duration: 2000
          })
        } else if (res.data == "exists") {
          wx.showToast({
            title: '提交失败\r\n该社团已提交',
            icon: 'none',
            duration: 2000
          })
        } else if (res.data == "fail") {
          wx.showToast({
            title: '提交失败\r\n社团名不存在',
            icon: 'none',
            duration: 2000
          })
        } else {
          wx.showToast({
            title: res.data,
            icon: 'none',
            duration: 2000
          })
        }
      }
    })
  }
})