#include <iostream>
#include "rm_msgs/status.h"
#include "rm_msgs/action.h"
#include <std_msgs/UInt8.h>
#include <std_msgs/String.h>
#include <ros/ros.h>
#include <cstring>

typedef struct
{
    struct castle_energy
    {
        uint8_t energy[2];
    } castle_energy[7];

    struct region_occupy
    {
        uint8_t status : 2; // 0 = no one, 1 = weak, 2 = strong
        uint8_t belong : 2; // 0 = no one, 1 = red, 2 = blue
        uint8_t have_robot : 2; // same as belong // resv
        uint8_t resv : 2;
    } region_occupy[9][7];

    uint8_t car_location[2];
    uint8_t round_remain_tick;
    uint8_t round_remain_cnt;
    uint8_t round_team;
    int16_t realtime_score[2];
} summer_camp_info_t;

rm_msgs::status get_status(summer_camp_info_t info, int me)
{
    rm_msgs::status t;
    std_msgs::UInt8 n;
    for(int i = 0; i < 8; i++)
    {
        n.data = info.castle_energy[i].energy[0];
        t.tower_power_red.push_back(n);
    }
    for(int i = 0; i < 8; i++)
    {
        n.data = info.castle_energy[i].energy[1];
        t.tower_power_blue.push_back(n);
    }
    t.car_pos_x_red.data = (info.car_location[0] & 15) + 1;
    t.car_pos_y_red.data = (info.car_location[0] >> 4) + 1;
    t.car_pos_x_blue.data = (info.car_location[1] & 15) + 1;
    t.car_pos_y_blue.data = (info.car_location[1] >> 4) + 1;
    t.round_team.data = info.round_team + 1;
    t.me.data = me;
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][0].belong;
        t.graph_occupy_1.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][1].belong;
        t.graph_occupy_2.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][2].belong;
        t.graph_occupy_3.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][3].belong;
        t.graph_occupy_4.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][4].belong;
        t.graph_occupy_5.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][5].belong;
        t.graph_occupy_6.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = info.region_occupy[i][6].belong;
        t.graph_occupy_7.push_back(n);
    }
    return t;
}

void callback(const rm_msgs::action &msg)
{
    std::cout<<msg<<std::endl;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "test");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<rm_msgs::status>("/status", 1);
    ros::Subscriber sub = nh.subscribe("/actions", 1, &callback);
    rm_msgs::status stat;
    summer_camp_info_t info;
    memset(&info, 0, sizeof(summer_camp_info_t));
    info.car_location[0] = (0 << 4) + 0;
    info.car_location[1] = (8 << 4) + 6;
    info.round_team = 0;
    while(1)
    {
        ros::spinOnce();
        pub.publish(get_status(info, 1));
        std::cout<<"printed\n";
        sleep(3);
    }
    return 0;
}