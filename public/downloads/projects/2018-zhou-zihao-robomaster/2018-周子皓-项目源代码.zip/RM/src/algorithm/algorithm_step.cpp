#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/String.h"
#include "std_msgs/UInt8.h"

using namespace std;

//define some settings
int max_square = 15; //the max square to go in a turn
int min_time = 0;
int min_square = 0;
int max_ball = 30;
int max_cup = 10;
int strong_need_towers = 3;
#define SQUARE_LENGTH 0.93

//variables about time(ms)
int tot_time = 50000; //total time in a turn
int ball_time = 3000; //time cost when push a ball
int cup_time = 50000; //time cost when push a cup
int move_time = 1000; //time cost when move a square
int occupy_time = 1000; //time cost when occupy a square

//weight about actions
int occupy_weight_weak = 15;
int occupy_weight_strong = 20;
int push_ball_weight = 5;
int push_cup_weight = 20;
int tower_power_weight = 0;
int occupy_tower_weight = 50;
int move_weight = 0;
int pass_weight = -5;
int visited_cost = -0;
int occupied_cost = -0;

//variables about estimate
float estimate_per_time = 0.001;
int estimate_per_square = 10;
int estimate_times = 20000;
#define CUP_ESTIMATE 20
#define MOVE_ESTIMATE 5
#define BALL_ESTIMATE 15
#define OCCUPY_ESTIMATE 10
#define ALL_ESTIMATE 50

//players
#define RED 1
#define BLUE 2
int me, enemy;

//graph
#define EMPTY_SQUARE 0
#define RED_SQUARE 1
#define BLUE_SQUARE 2
#define EMPTY 0
#define STRONG 2
#define WEAK 1

bool tower_connected[10];
bool visited[10][10];
bool visited_strong[10][10];
bool work_visited[10][10];


//car status
int pos_x[3], pos_y[3];

//actions list
#define MAX_ACTIONS 3
#define MOVE 0
#define OCCUPY 1
#define PUSH_BALL 2
#define PUSH_CUP 3
#define MOVE_UP 4
#define MOVE_LEFT 5
#define MOVE_DOWN 6
#define MOVE_RIGHT 7

int dx[8] = {0, 0, 0, 0, -1, 0, 1, 0};
int dy[8] = {0, 0, 0, 0, 0, -1, 0, 1};

int tower_x[8] = {0, 1, 1, 4, 4, 4, 7, 7};
int tower_y[8] = {0, 3, 7, 1, 5, 9, 3, 7};

//occupy status list
#define CANT_OCCUPY 0
#define WEAK_OCCUPY 1
#define STRONG_OCCUPY 2

#define nullptr 0

//search status struct
struct status
{
    ///note:all these values get from its parent status and change some of them
    int x;
    int y;
    int rest_time;
    int rest_square;
    int rest_cup;
    int rest_ball;
    int score; ///the total score of this status
    int weight; ///the sum of score and estimate
    int action; ///the action moved from parent status
    int graph_occupy[8][10];
    int graph_status[8][10];
    int tower_power[8][3];
    int tower_occupy[8];
    int father;
}stat[1000000]; ///note:stat[0] is a sepcial stat, if necessary, we should consider it as illegal
int tot;

struct node
{
    int index;
    int weight;

    bool operator < (const node &b) const
    {
        return weight < b.weight;
    }
};

priority_queue <node> q;

queue <status> actions;

ros::Publisher pub;

///check if the car can move to this square
bool check(int x, int y)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return false;
    return !((x == 1 && y == 3) || (x == 1 && y == 7) || (x == 4 && y == 1) ||
             (x == 4 && y == 5) || (x == 4 && y == 9) || (x == 7 && y == 3) || (x == 7 && y == 7)
             || (x == pos_x[enemy] && y == pos_y[enemy]));
}

///get the tower near the square (x, y)
int get_tower(int x, int y)
{
    if((x == 1 && y == 2) || (x == 2 && y == 3) || (x == 1 && y == 4)) return 1;
    if((x == 1 && y == 6) || (x == 2 && y == 7) || (x == 1 && y == 8)) return 2;
    if((x == 3 && y == 1) || (x == 4 && y == 2) || (x == 5 && y == 1)) return 3;
    if((x == 3 && y == 5) || (x == 5 && y == 5) || (x == 4 && y == 4) || (x == 4 && y == 6)) return 4;
    if((x == 3 && y == 9) || (x == 4 && y == 8) || (x == 5 && y == 9)) return 5;
    if((x == 7 && y == 2) || (x == 6 && y == 3) || (x == 7 && y == 4)) return 6;
    if((x == 7 && y == 6) || (x == 6 && y == 7) || (x == 7 && y == 8)) return 7;
    return 0;
}

///used before dfs to change the square of tower to its owner
void change_tower_square(int index)
{
    for(int i = 1; i < 8; i++)
        stat[index].graph_occupy[tower_x[i]][tower_y[i]] = stat[index].tower_occupy[i];
}

///used after dfs to change the square of tower to none
void clear_tower_square(int index)
{
    for(int i = 1; i < 8; i++)
        stat[index].graph_occupy[tower_x[i]][tower_y[i]] = EMPTY_SQUARE;
}

///return who occupy this tower
int get_tower_occupy(int index, int tower)
{
    if(stat[index].tower_power[tower][RED] > stat[index].tower_power[tower][BLUE]) return RED;
    if(stat[index].tower_power[tower][RED] < stat[index].tower_power[tower][BLUE]) return BLUE;
    return 0;
}

///get the connected towers around the block
void occupy_dfs(int index, int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(stat[index].graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    if(get_tower(x, y) && stat[index].tower_occupy[get_tower(x, y)] == player) tower_connected[get_tower(x, y)] = true;
    occupy_dfs(index, x + 1, y, player);
    occupy_dfs(index, x - 1, y, player);
    occupy_dfs(index, x, y + 1, player);
    occupy_dfs(index, x, y - 1, player);
}

///get the occupy status of this car
int get_occupy_status(int index, int player)
{
    int tower_count = 0;
    int x = stat[index].x;
    int y = stat[index].y;
    memset(tower_connected, 0, sizeof(tower_connected));
    memset(visited, 0, sizeof(visited));
    ///note:assume the square is the player's
    int t = stat[index].graph_occupy[x][y];
    stat[index].graph_occupy[x][y] = player;
    change_tower_square(index);
    occupy_dfs(index, x, y, player);
    clear_tower_square(index);
    stat[index].graph_occupy[x][y] = t;
    for (int k = 1; k < 8; ++k)
        if(tower_connected[k]) tower_count++;
    if(tower_count >= strong_need_towers) return STRONG_OCCUPY;
    if(tower_count > 0) return WEAK_OCCUPY;
    return CANT_OCCUPY;
}

///check if the action is legal
bool check_action(int index, int action)
{
    if(action >= MOVE_UP && action <= MOVE_RIGHT)
        if(check(stat[index].x + dx[action], stat[index].y + dy[action]) && stat[index].rest_time >= min_time + move_time) return true;
    ///note:the last condition is made to avoid multiply placing cup or ball
    if(action == PUSH_CUP)
        if(get_tower(stat[index].x + dx[action], stat[index].y + dy[action]) &&
           stat[index].rest_ball >= 1 && stat[index].rest_cup >= 1 &&
           stat[index].tower_occupy[get_tower(stat[index].x + dx[action], stat[index].y + dy[action])] != me
           && stat[index].rest_time >= min_time + cup_time) return true;
    if(action == PUSH_BALL) if(get_tower(stat[index].x, stat[index].y) && stat[index].rest_ball >= 1 &&
                               stat[index].tower_occupy[get_tower(stat[index].x + dx[action],stat[index].y + dy[action])] != me
                               && stat[index].rest_time >= min_time + ball_time) return true;
    ///note:the last condition is made to avoid multiply occupying
    if(action == OCCUPY) if(get_occupy_status(index, me) &&
                            stat[index].graph_occupy[stat[index].x][stat[index].y] != me &&
                            stat[index].graph_status[stat[index].x][stat[index].y] != STRONG_OCCUPY &&
                            stat[index].rest_time >= min_time + occupy_time) return true;
    return false;
}

///change the action number to string
std::string number2action(int number)
{
    switch (number)
    {
        case OCCUPY:
            return "occupy";
        case PUSH_BALL:
            return "ball";
        case PUSH_CUP:
            return "cap";
        case MOVE_LEFT:
            return "left";
        case MOVE_RIGHT:
            return "right";
        case MOVE_UP:
            return "up";
        case MOVE_DOWN:
            return "down";
        default:
            return "0";
    }
}

///print the result
void print_status(status stat1)
{
    printf("----x:%d;y:%d;rest_time:%d;rest_square:%d;rest_cup:%d;rest_ball:%d;score:%d;weight:%d;\n",
           stat1.x, stat1.y, stat1.rest_time, stat1.rest_square, stat1.rest_cup, stat1.rest_ball, stat1.score,
           stat1.weight);
}

void print(int index)
{
    if(index == 1)
    {
        return;
    }
    print(stat[index].father);
    cout << number2action(stat[index].action);// << endl;
    print_status(stat[index]);
    actions.push(stat[index]);
}

///sum the total score for each player
void sum(int index, int *blue, int *red)
{
    *blue = 0;
    *red = 0;
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            if(stat[index].graph_occupy[i][j] == BLUE)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *blue += occupy_weight_weak;
                else *blue += occupy_weight_strong;
            }
            else if(stat[index].graph_occupy[i][j] == RED)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *red += occupy_weight_weak;
                else *red += occupy_weight_strong;
            }
        }
    for (int i = 1; i < 8; ++i)
    {
        if(stat[index].tower_occupy[i] == RED) *red += occupy_tower_weight;
        if(stat[index].tower_occupy[i] == BLUE) *blue += occupy_tower_weight;
        //*red += stat[index].tower_power[i][RED] * tower_power_weight;
        //*blue += stat[index].tower_power[i][BLUE] * tower_power_weight;
    }
    //std::cout<<*red<<" "<<*blue<<std::endl;
}

int get_score(int init, int index, int player)
{
    int red, blue, score, score_blue, score_red;
    sum(init, &score_blue, &score_red);
    sum(index, &blue, &red);
    //cout<<red<<" "<<blue<<endl;
    if(player == RED) score = red - score_red + score_blue - blue;
    else score = blue - score_blue + score_red - red;
    //cout<<score<<endl;
    return score;
}

///change the status of the block
void update_dfs(int index, int x, int y, int player, int tag)
{
    if(player == 0) return;
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(stat[index].graph_occupy[x][y] != player) return;
    if(visited_strong[x][y]) return;
    visited_strong[x][y] = true;
    stat[index].graph_status[x][y] = tag;
    update_dfs(index, x + 1, y, player, tag);
    update_dfs(index, x - 1, y, player, tag);
    update_dfs(index, x, y + 1, player, tag);
    update_dfs(index, x, y - 1, player, tag);
}

///update graph status(strong or weak)
///used after a tower status changed
void update_graph_status(int index)
{
    change_tower_square(index);
    memset(visited, 0, sizeof(visited));
    for (int i = 1; i < 8; ++i)
    {
        for (int j = 1; j < 10; ++j)
        {
            if(!visited[i][j])
            {
                int tower_count = 0;
                memset(tower_connected, 0, sizeof(tower_connected));
                occupy_dfs(index, i, j, stat[index].graph_occupy[i][j]);
                for (int k = 1; k < 8; ++k) if(tower_connected[k]) tower_count++;
                memset(visited_strong, 0, sizeof(visited_strong));
                if (tower_count >= strong_need_towers)
                    update_dfs(index, i, j, stat[index].graph_occupy[i][j], STRONG);
                else
                    update_dfs(index, i, j, stat[index].graph_occupy[i][j], WEAK);
            }
        }
    }
    clear_tower_square(index);
}

///dfs until depth is 3
int dfs(int init, int index, int depth)
{
    if(depth == 8 || stat[index].rest_time <= min_time || stat[index].rest_square <= min_square)
    {
        return get_score(init, index, me);
    }
    int max_score = -1000000;
    for(int i = 1; i < 8; i++)
    {
        stat[++tot] = stat[index];
        if(!check_action(tot, i))
        {
            tot--;
            continue;
        }
        switch (i)
        {
            case OCCUPY:
            {
                stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
                stat[tot].graph_status[stat[tot].x][stat[tot].y] = get_occupy_status(tot, me);
                stat[tot].rest_time -= occupy_time;
                update_graph_status(tot);
                break;
            }
            case PUSH_BALL:
            {
                stat[tot].rest_ball--;
                stat[tot].rest_time -= ball_time;
                stat[tot].tower_power[get_tower(stat[tot].x, stat[tot].y)][me]++;
                stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)] = get_tower_occupy(tot, get_tower(stat[tot].x, stat[tot].y));
                update_graph_status(tot);
                break;
            }
            case PUSH_CUP:
            {
                stat[tot].rest_ball--;
                stat[tot].rest_cup--;
                stat[tot].rest_time -= cup_time;
                stat[tot].tower_power[get_tower(stat[tot].x, stat[tot].y)][me] += 4;
                stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)] = get_tower_occupy(tot, get_tower(stat[tot].x, stat[tot].y));
                update_graph_status(tot);
                //cout<<stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)]<<endl;
                break;
            }
                ///move
            default:
            {
                stat[tot].rest_square--;
                stat[tot].rest_time -= move_time;
                stat[tot].x += dx[i];
                stat[tot].y += dy[i];
                if(stat[tot].graph_occupy[stat[tot].x][stat[tot].y] == enemy) stat[tot].score += pass_weight;
            }
        }
        max_score = max(dfs(init, tot, depth + 1), max_score);
        tot--;
    }
    return max_score;
}

///fully expand stat[index] and return the max estimate of the them
int simulate(int index)
{
    return dfs(index, index, 0);
}

///priority and three-depth estimate BFS
void work()
{
    while(!q.empty())
    {
        ///step1:choose the status which has the max weight
        node n = q.top();
        q.pop();
        ///if this status can not do anything, return and print
        if(stat[n.index].rest_time <= min_time || stat[n.index].rest_square <= min_square)
        {
            FILE *fout = fopen("/home/robomaster/RM/test.txt", "w");
            fprintf(fout, "# tower_power,RED=1,BLUE=2\n");
            for (int i = 1; i <= 7; i++)
                fprintf(fout, "%d ", stat[n.index].tower_power[i][RED]);
            fprintf(fout, "\n");
            for (int i = 1; i <= 7; i++)
                fprintf(fout, "%d ", stat[n.index].tower_power[i][BLUE]);
            fprintf(fout, "\n# car_pos\n");
            if(me == RED)
            {
                fprintf(fout, "%d %d\n%d %d", stat[n.index].x, stat[n.index].y, pos_x[BLUE], pos_y[BLUE]);
            }
            else
            {
                fprintf(fout, "%d %d\n%d %d", pos_x[RED], pos_y[RED], stat[n.index].x, stat[n.index].y);
            }
            fprintf(fout, "\n# graph occupy\n");
            for (int i = 1; i <= 7; i++)
            {
                for (int j = 1; j <= 9; j++)
                    fprintf(fout, "%d ", stat[n.index].graph_occupy[i][j]);
                fprintf(fout, "\n");
            }
            fprintf(fout, "# me\n");
            fprintf(fout, "%d", enemy);
            fclose(fout);
            print(n.index);
            while(!q.empty()) q.pop();
            return;
        }
        ///step2:expand every possible choice of this status
        ///step3:simulate many times to get its average reward
        for(int i = 1; i < 8; i++)
        {
            if(!check_action(n.index, i)) continue;
            tot++;
            stat[tot] = stat[n.index];
            stat[tot].action = i;
            stat[tot].father = n.index;
            switch (i)
            {
                case OCCUPY:
                {
                    stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
                    stat[tot].graph_status[stat[tot].x][stat[tot].y] = get_occupy_status(tot, me);
                    stat[tot].rest_time -= occupy_time;
                    update_graph_status(tot);
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                case PUSH_BALL:
                {
                    stat[tot].rest_ball--;
                    stat[tot].rest_time -= ball_time;
                    stat[tot].tower_power[get_tower(stat[tot].x, stat[tot].y)][me]++;
                    stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)] = get_tower_occupy(tot, get_tower(stat[tot].x, stat[tot].y));
                    update_graph_status(tot);
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                case PUSH_CUP:
                {
                    stat[tot].rest_ball--;
                    stat[tot].rest_cup--;
                    stat[tot].rest_time -= cup_time;
                    stat[tot].tower_power[get_tower(stat[tot].x, stat[tot].y)][me] += 4;
                    stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)] = get_tower_occupy(tot, get_tower(stat[tot].x, stat[tot].y));
                    update_graph_status(tot);
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                    ///move
                default:
                {
                    stat[tot].rest_square--;
                    stat[tot].rest_time -= move_time;
                    stat[tot].x += dx[i];
                    stat[tot].y += dy[i];
                    if(stat[tot].graph_occupy[stat[tot].x][stat[tot].y] == enemy) stat[tot].score += pass_weight;
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                }
            }
            ///step4:add this status to the queue
            q.push(node{tot, stat[tot].weight});
        }
    }
}

int main(int argc, char** argv)
{
    ///load origin status from the text
    FILE *fp = fopen("/home/robomaster/RM/testex.txt", "r");
    srand((unsigned int) time(0));
    fscanf(fp, "# tower_power,RED=1,BLUE=2\n");
    for (int i = 1; i <= 7; i++)
        fscanf(fp, "%d", &stat[1].tower_power[i][RED]);
    for (int i = 1; i <= 7; i++)
        fscanf(fp, "%d", &stat[1].tower_power[i][BLUE]);
    for (int i = 1; i <= 7; ++i)
        stat[1].tower_occupy[i] = get_tower_occupy(1, i);
    fscanf(fp, "\n# car_pos\n");
    fscanf(fp, "%d %d %d %d", &pos_x[RED], &pos_y[RED], &pos_x[BLUE], &pos_y[BLUE]);
    fscanf(fp, "\n# graph occupy\n");
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &stat[1].graph_occupy[i][j]);
    fscanf(fp, "\n# graph status\n");
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &stat[1].graph_status[i][j]);
    fscanf(fp, "\n# me\n");
    fscanf(fp, "%d", &me);
    fclose(fp);
    ///who i am
    if (me == BLUE) enemy = RED;
    else enemy = BLUE;
    ///set origin status
    stat[1].x = pos_x[me];
    stat[1].y = pos_y[me];
    stat[1].rest_time = tot_time;
    stat[1].score = 0;
    stat[1].rest_square = max_square;
    stat[1].rest_ball = max_ball;
    stat[1].rest_cup = max_cup;
    update_graph_status(1);
    ///WARNING:C++11
    q.push(node{1, 0});
    tot = 1;
    work();
    return 0;
}
