#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <cstdlib>
#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/UInt8.h"
#include "rm_msgs/action.h"
#include "rm_msgs/status.h"
#include <tf/tf.h>

using namespace std;

//define some settings
int max_square = 15; //the max square to go in a turn
int min_time = 0;
int min_square = 0;
int max_ball = 20;
int max_cup = 4;
int strong_need_towers = 3;
int ball_from_front = 9;
int ball_from_side = 3;
int cup_from_front = 3;
int cup_from_side = 1; ///note:the cups from front contain the two from side
bool running = false;
const double PI = 3.14159265358979323846264338;
#define SQUARE_LENGTH 0.93
#define SQUARE_CUP_DIFF 0
#define SQUARE_BALL_DIFF 0.15
#define BALL_DIFF 0//0.217
#define CUP_DIFF 0//0.38
#define DFS_DEPTH 8
#define CUP_ENERGY 6
///left_diff is the diff per ball when pushing from left
#define BALL_LEFT_DIFF (0.062 - 0.1) / 2//0.527
#define BALL_RIGHT_DIFF (-0.248 - 0.1) / 2//0.279
#define BALL_FRONT_DIFF (-0.248 - 0.1) / 2//0.217
#define BALL_PER_DIFF 0.062 / 2//0.062
#define CUP_LEFT_DIFF 0.123//0.38
#define CUP_RIGHT_DIFF -0.123//0.38
#define CUP_FRONT_DIFF -0.123//0.465
#define CUP_PER_DIFF 0.123

//variables about time(ms)
int tot_time = 40000; //total time in a turn
int ball_time = 10000; //time cost when push a ball
int cup_time = 80000; //time cost when push a cup
int move_time = 1000; //time cost when move a square
int occupy_time = 1000; //time cost when occupy a square

//weight about actions
int occupy_weight_weak = 15;
int occupy_weight_strong = 20;
int occupy_tower_weight = 50;
int pass_weight = -5;

//players
#define RED 1
#define BLUE 2
int me, enemy;

//graph
#define EMPTY_SQUARE 0
#define RED_SQUARE 1
#define BLUE_SQUARE 2
#define EMPTY 0
#define STRONG 2
#define WEAK 1

bool tower_connected[10];
bool visited[10][10];
bool visited_strong[10][10];

//car status
int pos_x[3], pos_y[3];

//actions list
#define STOP 0
#define OCCUPY 1
#define PUSH_BALL 2
#define PUSH_CUP 3
#define MOVE_UP 4
#define MOVE_LEFT 5
#define MOVE_DOWN 6
#define MOVE_RIGHT 7
#define MOVE 8

int dx[8] = {0, 0, 0, 0, -1, 0, 1, 0};
int dy[8] = {0, 0, 0, 0, 0, -1, 0, 1};

int tower_x[8] = {0, 1, 1, 4, 4, 4, 7, 7};
int tower_y[8] = {0, 3, 7, 1, 5, 9, 3, 7};

//define the side of a tower
#define SIDE_UP 1
#define SIDE_LEFT 2
#define SIDE_DOWN 3
#define SIDE_RIGHT 4

//occupy status list
#define CANT_OCCUPY 0
#define WEAK_OCCUPY 1
#define STRONG_OCCUPY 2

//search status struct
struct status
{
    ///note:all these values get from its parent status and change some of them
    int x;
    int y;
    int rest_time;
    int rest_square;
    int rest_cup;
    int rest_ball;
    int score; ///the total score of this status
    int weight; ///the sum of score and estimate
    int action; ///the action moved from parent status
    int ball;
    int cup_index; ///if the cup is put from front, how much is its index
    int ball_in_box[5]; ///the number of balls in a box
    int graph_occupy[8][10];
    int graph_status[8][10];
    int tower_power[8][3];
    int tower_occupy[8];
    int tower_cup_number[8][5]; ///the number of my cups in a tower
    int tower_ball_number[8][5]; ///the number of my balls in a tower
    int father;
}stat[1000000]; ///note:stat[0] is a sepcial stat, if necessary, we should consider it as illegal
int tot;

struct node
{
    int index;
    int weight;

    bool operator < (const node &b) const
    {
        return weight < b.weight;
    }
};

typedef struct
{
    struct castle_energy
    {
        uint8_t energy[2];
    } castle_energy[7];

    struct region_occupy
    {
        uint8_t status : 2; // 0 = no one, 1 = weak, 2 = strong
        uint8_t belong : 2; // 0 = no one, 1 = red, 2 = blue
        uint8_t have_robot : 2; // same as belong // resv
        uint8_t resv : 2;
    } region_occupy[9][7];

    uint8_t car_location[2];
    uint8_t round_step_move[2];
    uint8_t round_remain_tick;
    uint8_t round_remain_cnt : 7;
    uint8_t round_team : 1;
    int16_t realtime_score[2];
} summer_camp_info_t;

priority_queue <node> q;

queue <status> actions;

ros::Publisher pub;
ros::Publisher result_pub;

///get the tower near the square (x, y)
int get_tower(int x, int y)
{
    if((x == 1 && y == 2) || (x == 2 && y == 3) || (x == 1 && y == 4)) return 1;
    if((x == 1 && y == 6) || (x == 2 && y == 7) || (x == 1 && y == 8)) return 2;
    if((x == 3 && y == 1) || (x == 4 && y == 2) || (x == 5 && y == 1)) return 3;
    if((x == 3 && y == 5) || (x == 5 && y == 5) || (x == 4 && y == 4) || (x == 4 && y == 6)) return 4;
    if((x == 3 && y == 9) || (x == 4 && y == 8) || (x == 5 && y == 9)) return 5;
    if((x == 7 && y == 2) || (x == 6 && y == 3) || (x == 7 && y == 4)) return 6;
    if((x == 7 && y == 6) || (x == 6 && y == 7) || (x == 7 && y == 8)) return 7;
    return 0;
}

///change the number of balls in a box
///return the first box to push the ball
///note:only work() need this function while estimate() doesn't need to update box status
int change_ball_status(int index, int d)
{
    int ret = 100;
    for(int i = 1; i <= 4; i++)
    {
        if(stat[index].ball_in_box[i] > 0 && d > 0)
        {
            stat[index].ball_in_box[i]--;
            d--;
            ret = min(ret, i);
        }
    }
    while(d > 0)
    {
        stat[index].ball_in_box[4]--;
        d--;
    }
    return ret;
}

///get the side of the tower
int get_tower_side(int tower, int x, int y)
{
    int tx = tower_x[tower];
    int ty = tower_y[tower];
    if(tx - x == 1 && ty - y == 0) return SIDE_UP;
    if(tx - x == -1 && ty - y == 0) return SIDE_DOWN;
    if(tx - x == 0 && ty - y == 1) return SIDE_LEFT;
    if(tx - x == 0 && ty - y == -1) return SIDE_RIGHT;
    cout<<"WTF?\n";
    return 0;
}

///check if the position is in the front
///note: a player's front is the other's back
///note: not a player's front means the other can push ball or cup from this side
bool is_from_front(int x, int y, int player)
{
    int tower = get_tower(x, y);
    int side = get_tower_side(tower, x, y);
    if(player == RED)
    {
        switch (tower)
        {
            case 1:
                return side == SIDE_RIGHT;
            case 2:
                return side == SIDE_RIGHT;
            case 3:
                return side == SIDE_DOWN;
            case 4:
                return side == SIDE_DOWN;
            case 5:
                return side == SIDE_UP;
            case 6:
                return side == SIDE_LEFT;
            case 7:
                return side == SIDE_LEFT;
            default:
                return false;
        }
    }
    else
    {
        switch (tower)
        {
            case 1:
                return side == SIDE_LEFT;
            case 2:
                return side == SIDE_LEFT;
            case 3:
                return side == SIDE_UP;
            case 4:
                return side == SIDE_UP;
            case 5:
                return side == SIDE_DOWN;
            case 6:
                return side == SIDE_RIGHT;
            case 7:
                return side == SIDE_RIGHT;
            default:
                return false;
        }
    }
}

///return if the side if from a tower's left
///note:LEFT here means a player's side's left. it is different from LEFT in the map
bool is_from_left(int x, int y, int player)
{
    int tower = get_tower(x, y);
    int side = get_tower_side(tower, x, y);
    if(player == RED)
    {
        switch (tower)
        {
            case 1:
                return side == SIDE_DOWN;
            case 2:
                return side == SIDE_DOWN;
            case 3:
                return side == SIDE_LEFT;
            case 4:
                return side == SIDE_LEFT;
            case 5:
                return side == SIDE_RIGHT;
            case 6:
                return side == SIDE_UP;
            case 7:
                return side == SIDE_UP;
            default:
                return false;
        }
    }
    else
    {
        switch (tower)
        {
            case 1:
                return side == SIDE_UP;
            case 2:
                return side == SIDE_UP;
            case 3:
                return side == SIDE_RIGHT;
            case 4:
                return side == SIDE_RIGHT;
            case 5:
                return side == SIDE_LEFT;
            case 6:
                return side == SIDE_DOWN;
            case 7:
                return side == SIDE_DOWN;
            default:
                return false;
        }
    }
}

///return the number of balls needed to be put
int get_ball_number(int index, int tower)
{
    //TODO
    return 1;
    int d = stat[index].tower_power[tower][enemy] - stat[index].tower_power[tower][me] + 1;
    int max_balls = 0;
    for (int i = 1; i <= 4; ++i) if(stat[index].ball_in_box[i] > 0) max_balls++;
    if(d > max_balls) return max_balls;
    if(d > stat[index].rest_ball) return stat[index].rest_ball;
    int side = get_tower_side(tower, stat[index].x, stat[index].y);
    int rest;
    if(is_from_front(stat[index].x, stat[index].y, me))
        rest = ball_from_front - stat[index].tower_ball_number[tower][side];
    else rest = ball_from_side - stat[index].tower_ball_number[tower][side];
    if(d > rest) return rest;
    if(d > 4) return 4;
    return d;
}

///check if the car can move to this square
bool check(int x, int y)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return false;
    return !((x == 1 && y == 3) || (x == 1 && y == 7) || (x == 4 && y == 1) ||
             (x == 4 && y == 5) || (x == 4 && y == 9) || (x == 7 && y == 3) || (x == 7 && y == 7)
             || (x == pos_x[enemy] && y == pos_y[enemy]));
}

///used before dfs to change the square of tower to its owner
void change_tower_square(int index)
{
    for(int i = 1; i < 8; i++)
        stat[index].graph_occupy[tower_x[i]][tower_y[i]] = stat[index].tower_occupy[i];
}

///used after dfs to change the square of tower to none
void clear_tower_square(int index)
{
    for(int i = 1; i < 8; i++)
    {
        stat[index].graph_occupy[tower_x[i]][tower_y[i]] = EMPTY_SQUARE;
        stat[index].graph_status[tower_x[i]][tower_y[i]] = EMPTY;
    }
}

///return who occupy this tower
int get_tower_occupy(int index, int tower)
{
    if(stat[index].tower_power[tower][RED] > stat[index].tower_power[tower][BLUE]) return RED;
    if(stat[index].tower_power[tower][RED] < stat[index].tower_power[tower][BLUE]) return BLUE;
    return 0;
}

///get the connected towers around the block
void occupy_dfs(int index, int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(stat[index].graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    int tower = get_tower(x, y);
    if(tower && stat[index].tower_occupy[tower] == player) tower_connected[tower] = true;
    occupy_dfs(index, x + 1, y, player);
    occupy_dfs(index, x - 1, y, player);
    occupy_dfs(index, x, y + 1, player);
    occupy_dfs(index, x, y - 1, player);
}

///get the occupy status of this car
int get_occupy_status(int index, int player)
{
    int tower_count = 0;
    int x = stat[index].x;
    int y = stat[index].y;
    memset(tower_connected, 0, sizeof(tower_connected));
    memset(visited, 0, sizeof(visited));
    ///note:assume the square is the player's
    int t = stat[index].graph_occupy[x][y];
    stat[index].graph_occupy[x][y] = player;
    change_tower_square(index);
    occupy_dfs(index, x, y, player);
    clear_tower_square(index);
    stat[index].graph_occupy[x][y] = t;
    for (int k = 1; k < 8; ++k)
        if(tower_connected[k]) tower_count++;
    if(tower_count >= strong_need_towers) return STRONG_OCCUPY;
    if(tower_count > 0) return WEAK_OCCUPY;
    return CANT_OCCUPY;
}

///check if the action is legal
bool check_action(int index, int action)
{
    int tower = get_tower(stat[index].x, stat[index].y);
    int side = 0;
    if(tower) side = get_tower_side(tower, stat[index].x, stat[index].y);
    if(action >= MOVE_UP && action <= MOVE_RIGHT)
        if(check(stat[index].x + dx[action], stat[index].y + dy[action]) && stat[index].rest_time >= min_time + move_time) return true;
    ///note:the last condition is made to avoid multiply placing cup or ball
    if(action == PUSH_CUP)
        if(tower && stat[index].rest_cup >= 1 && stat[index].tower_occupy[tower] != me
        && stat[index].rest_time >= min_time + cup_time && !is_from_front(stat[index].x, stat[index].y, enemy))
        {
            int left = side - 1;
            if(left < 1) left = 4;
            int right = side + 1;
            if(right > 4) right = 1;
            if(is_from_front(stat[index].x, stat[index].y, me))
            {
                return stat[index].tower_cup_number[tower][side] + stat[index].tower_cup_number[tower][left]
                + stat[index].tower_cup_number[tower][right] < cup_from_front;
            }
            else return stat[index].tower_cup_number[tower][side] < cup_from_side;
        }
    if(action == PUSH_BALL)
        if(tower && stat[index].rest_ball >= 1 && stat[index].tower_occupy[tower] != me
        && stat[index].rest_time >= min_time + ball_time && !is_from_front(stat[index].x, stat[index].y, enemy))
        {
            if(is_from_front(stat[index].x, stat[index].y, me))
                return stat[index].tower_ball_number[tower][side] < ball_from_front;
            else return stat[index].tower_ball_number[tower][side] < ball_from_side;
        }
    ///note:the last condition is made to avoid multiply occupying
    if(action == OCCUPY) if(get_occupy_status(index, me) &&
                            stat[index].graph_occupy[stat[index].x][stat[index].y] != me &&
                            stat[index].graph_status[stat[index].x][stat[index].y] != STRONG_OCCUPY &&
                            stat[index].rest_time >= min_time + occupy_time) return true;
    return false;
}

///change the action number to string
std::string number2action(int number)
{
    switch (number)
    {
        case OCCUPY:
            return "occupy";
        case PUSH_BALL:
            return "ball";
        case PUSH_CUP:
            return "cap";
        case MOVE_LEFT:
            return "left";
        case MOVE_RIGHT:
            return "right";
        case MOVE_UP:
            return "up";
        case MOVE_DOWN:
            return "down";
        default:
            return "0";
    }
}

///print the result
void print_status(status stat1)
{
    int tower = get_tower(stat1.x, stat1.y);
    int side = 0;
    if(tower) side =  get_tower_side(tower, stat1.x, stat1.y);
    printf("----x:%d;y:%d;ball:%d;ball_index:%d;rest_time:%d;rest_square:%d;rest_cup:%d;rest_ball:%d;score:%d;weight:%d;\n",
           stat1.x, stat1.y, stat1.ball, stat1.tower_ball_number[tower][side] - stat1.ball,
           stat1.rest_time, stat1.rest_square, stat1.rest_cup, stat1.rest_ball, stat1.score, stat1.weight);
}

void print(int index)
{
    if(index == 1) return;
    print(stat[index].father);
    cout << number2action(stat[index].action);
    print_status(stat[index]);
    actions.push(stat[index]);
}

///sum the total score for each player
void sum(int index, int *blue, int *red)
{
    *blue = 0;
    *red = 0;
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            if(stat[index].graph_occupy[i][j] == BLUE)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *blue += occupy_weight_weak;
                else *blue += occupy_weight_strong;
            }
            else if(stat[index].graph_occupy[i][j] == RED)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *red += occupy_weight_weak;
                else *red += occupy_weight_strong;
            }
        }
    for (int i = 1; i < 8; ++i)
    {
        if(stat[index].tower_occupy[i] == RED) *red += occupy_tower_weight;
        if(stat[index].tower_occupy[i] == BLUE) *blue += occupy_tower_weight;
    }
}

int get_score(int init, int index, int player)
{
    int red, blue, score, score_blue, score_red;
    sum(init, &score_blue, &score_red);
    sum(index, &blue, &red);
    if(player == RED) score = red - score_red + score_blue - blue;
    else score = blue - score_blue + score_red - red;
    return score;
}

///change the status of the block
void update_dfs(int index, int x, int y, int player, int tag)
{
    if(player == 0) return;
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(stat[index].graph_occupy[x][y] != player) return;
    if(visited_strong[x][y]) return;
    visited_strong[x][y] = true;
    stat[index].graph_status[x][y] = tag;
    update_dfs(index, x + 1, y, player, tag);
    update_dfs(index, x - 1, y, player, tag);
    update_dfs(index, x, y + 1, player, tag);
    update_dfs(index, x, y - 1, player, tag);
}

///update graph status(strong or weak)
///used after a tower status changed
void update_graph_status(int index)
{
    change_tower_square(index);
    memset(visited, 0, sizeof(visited));
    for (int i = 1; i < 8; ++i)
    {
        for (int j = 1; j < 10; ++j)
        {
            if(!visited[i][j])
            {
                int tower_count = 0;
                memset(tower_connected, 0, sizeof(tower_connected));
                occupy_dfs(index, i, j, stat[index].graph_occupy[i][j]);
                for (int k = 1; k < 8; ++k) if(tower_connected[k]) tower_count++;
                memset(visited_strong, 0, sizeof(visited_strong));
                if (tower_count >= strong_need_towers)
                    update_dfs(index, i, j, stat[index].graph_occupy[i][j], STRONG);
                else
                    update_dfs(index, i, j, stat[index].graph_occupy[i][j], WEAK);
            }
        }
    }
    clear_tower_square(index);
}

///return the front side of a tower
int get_front(int tower, int player)
{
    if(player == RED)
    {
        switch (tower)
        {
            case 1:
                return SIDE_RIGHT;
            case 2:
                return SIDE_RIGHT;
            case 3:
                return SIDE_DOWN;
            case 4:
                return SIDE_DOWN;
            case 5:
                return SIDE_UP;
            case 6:
                return SIDE_LEFT;
            case 7:
                return SIDE_LEFT;
            default:
                return 233;
        }
    }
    else
    {
        switch (tower)
        {
            case 1:
                return SIDE_LEFT;
            case 2:
                return SIDE_LEFT;
            case 3:
                return SIDE_UP;
            case 4:
                return SIDE_UP;
            case 5:
                return SIDE_DOWN;
            case 6:
                return SIDE_RIGHT;
            case 7:
                return SIDE_RIGHT;
            default:
                return 233;
        }
    }
}

///return if player can not put the ball or cup to the tower from side
bool isimpossible(int tower,int side, int player)
{
    switch (tower)
    {
        case 1:
            return side == SIDE_UP;
        case 2:
            return side == SIDE_UP;
        case 3:
            return side == SIDE_LEFT;
        case 4:
            return false;
        case 5:
            return side == SIDE_RIGHT;
        case 6:
            return side == SIDE_DOWN;
        case 7:
            return side == SIDE_DOWN;
        default:
            return false;
    }
}

///return the place to put the cup
int get_put_side(int index, int tower, int player)
{
    int front = get_front(tower, player);
    int left = front - 1;
    if(left < 1) left = 4;
    int right = front + 1;
    if(right > 4) right = 1;
    int front_ball = stat[index].tower_cup_number[tower][front] - stat[index].tower_cup_number[tower][left] - stat[index].tower_cup_number[tower][right];
    if(front_ball == 0) return front;
    if(isimpossible(tower, left, me) && stat[index].tower_cup_number[tower][left] == 0) return left;
    return right;
}

///get the cup index from its side
int get_cup_index(int front, int side)
{
    if(front == SIDE_RIGHT && side == SIDE_UP) return 3;
    if(front == SIDE_UP && side == SIDE_RIGHT) return 1;
    return side - front + 2;
}

///dfs until depth is 3
int dfs(int init, int index, int depth)
{
    if(depth == DFS_DEPTH || stat[index].rest_time <= min_time || stat[index].rest_square <= min_square)
    {
        return get_score(init, index, me);
    }
    int max_score = -1000000;
    for(int i = 1; i < 8; i++)
    {
        stat[++tot] = stat[index];
        stat[tot].ball = 0;
        if(!check_action(tot, i))
        {
            tot--;
            continue;
        }
        int tower = get_tower(stat[tot].x, stat[tot].y);
        int side = 0;
        if(tower) side = get_tower_side(tower, stat[tot].x, stat[tot].y);
        switch (i)
        {
            case OCCUPY:
            {
                stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
                stat[tot].graph_status[stat[tot].x][stat[tot].y] = get_occupy_status(tot, me);
                stat[tot].rest_time -= occupy_time;
                update_graph_status(tot);
                break;
            }
            case PUSH_BALL:
            {
                int ball = get_ball_number(index, tower);
                stat[tot].rest_ball -= ball;
                stat[tot].rest_time -= ball_time;
                stat[tot].ball = ball;
                stat[tot].tower_power[tower][me] += ball;
                stat[tot].tower_occupy[tower] = get_tower_occupy(tot, tower);
                stat[tot].tower_ball_number[tower][side] += ball;
                update_graph_status(tot);
                break;
            }
            case PUSH_CUP:
            {
                stat[tot].rest_cup--;
                stat[tot].rest_time -= cup_time;
                stat[tot].tower_power[tower][me] += CUP_ENERGY;
                stat[tot].tower_occupy[tower] = get_tower_occupy(tot, tower);
                if(!is_from_front(stat[tot].x, stat[tot].y, me))
                {
                    stat[tot].tower_cup_number[tower][side]++;
                    stat[tot].tower_cup_number[tower][get_front(tower, me)]++;
                }
                else
                {
                    if(stat[tot].tower_cup_number[tower][side])
                    {
                        int put_side = get_put_side(index, tower, me);
                        stat[tot].cup_index = get_cup_index(side, put_side);
                        stat[tot].tower_cup_number[tower][side]++;
                        if(put_side != side) stat[tot].tower_cup_number[tower][put_side]++;
                    }
                }
                update_graph_status(tot);
                break;
            }
                ///move
            default:
            {
                stat[tot].rest_square--;
                stat[tot].rest_time -= move_time;
                stat[tot].x += dx[i];
                stat[tot].y += dy[i];
                if(stat[tot].graph_occupy[stat[tot].x][stat[tot].y] == enemy) stat[tot].score += pass_weight;
            }
        }
        max_score = max(dfs(init, tot, depth + 1), max_score);
        tot--;
    }
    return max_score;
}

///fully expand stat[index] and return the max estimate of the them
int simulate(int index)
{
    return dfs(index, index, 0);
}

///priority and three-depth estimate BFS
void work()
{
    while(!q.empty())
    {
        ///step1:choose the status which has the max weight
        node n = q.top();
        q.pop();
        ///if this status can not do anything, return and print
        if(stat[n.index].rest_time <= min_time || stat[n.index].rest_square <= min_square)
        {
            stat[0] = stat[n.index];
            print(n.index);
            stat[1] = stat[0];
            while(!q.empty()) q.pop();
            return;
        }
        ///step2:expand every possible choice of this status
        ///step3:simulate many times to get its average reward
        for(int i = 1; i < 8; i++)
        {
            if(!check_action(n.index, i)) continue;
            tot++;
            stat[tot] = stat[n.index];
            stat[tot].ball = 0;
            stat[tot].action = i;
            stat[tot].father = n.index;
            int tower = get_tower(stat[tot].x, stat[tot].y);
            int side = 0;
            if(tower) side = get_tower_side(tower, stat[tot].x, stat[tot].y);
            switch (i)
            {
                case OCCUPY:
                {
                    stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
                    stat[tot].graph_status[stat[tot].x][stat[tot].y] = get_occupy_status(tot, me);
                    stat[tot].rest_time -= occupy_time;
                    update_graph_status(tot);
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                case PUSH_BALL:
                {
                    int ball = get_ball_number(tot, tower);
                    stat[tot].rest_ball -= ball;
                    stat[tot].rest_time -= ball_time;
                    stat[tot].ball = ball;
                    stat[tot].tower_power[tower][me] += ball;
                    stat[tot].tower_occupy[tower] = get_tower_occupy(tot, tower);
                    stat[tot].tower_ball_number[tower][side] += ball;
                    update_graph_status(tot);
                    change_ball_status(tot, ball);
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                case PUSH_CUP:
                {
                    stat[tot].rest_cup--;
                    stat[tot].rest_time -= cup_time;
                    stat[tot].tower_power[tower][me] += CUP_ENERGY;
                    stat[tot].tower_occupy[tower] = get_tower_occupy(tot, tower);
                    if(!is_from_front(stat[tot].x, stat[tot].y, me))
                    {
                        stat[tot].tower_cup_number[tower][side]++;
                        stat[tot].tower_cup_number[tower][get_front(tower, me)]++;
                    }
                    else
                    {
                        if(stat[tot].tower_cup_number[tower][side])
                        {
                            int put_side = get_put_side(tot, tower, me);
                            stat[tot].cup_index = get_cup_index(side, put_side);
                            stat[tot].tower_cup_number[tower][side]++;
                            if(put_side != side) stat[tot].tower_cup_number[tower][put_side]++;
                        }
                    }
                    update_graph_status(tot);
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                    ///move
                default:
                {
                    stat[tot].rest_square--;
                    stat[tot].rest_time -= move_time;
                    stat[tot].x += dx[i];
                    stat[tot].y += dy[i];
                    if(stat[tot].graph_occupy[stat[tot].x][stat[tot].y] == enemy) stat[tot].score += pass_weight;
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                }
            }
            ///step4:add this status to the queue
            q.push(node{tot, stat[tot].weight});
        }
    }
}

///note:x and y have been fixed
geometry_msgs::PoseStamped new_pose(double x, double y, double z, double w)
{
    geometry_msgs::PoseStamped pose;
    pose.header.frame_id = "map";
    pose.header.seq = 0;
    pose.header.stamp = ros::Time::now();
    pose.pose.position.x = x + SQUARE_LENGTH / 2;
    if(pose.pose.position.x > 6210) pose.pose.position.x = 6210;
    if(pose.pose.position.x < 300) pose.pose.position.x = 300;
    if(pose.pose.position.y > 8070) pose.pose.position.y = 8070;
    if(pose.pose.position.y < 300) pose.pose.position.y = 300;
    pose.pose.position.y = y + SQUARE_LENGTH / 2;
    pose.pose.position.z = z;
    pose.pose.orientation = tf::createQuaternionMsgFromYaw(w);
    return pose;
}

rm_msgs::status get_status(summer_camp_info_t info, int I)
{
    rm_msgs::status t;
    std_msgs::UInt8 n;
    for(int i = 0; i < 8; i++)
    {
        n.data = info.castle_energy[i].energy[0];
        t.tower_power_red.push_back(n);
    }
    for(int i = 0; i < 8; i++)
    {
        n.data = info.castle_energy[i].energy[1];
        t.tower_power_blue.push_back(n);
    }
    t.car_pos_x_red.data = (info.car_location[0] & 15) + 1;
    t.car_pos_y_red.data = (info.car_location[0] >> 4) + 1;
    t.car_pos_x_blue.data = (info.car_location[1] & 15) + 1;
    t.car_pos_y_blue.data = (info.car_location[1] >> 4) + 1;
    t.remain_tick.data = info.round_remain_tick;
    t.remain_square.data = info.round_remain_cnt;
    t.round_team.data = info.round_team + 1;
    t.me.data = I;
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][0].belong + 1) % 3;
        t.graph_occupy_1.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][1].belong + 1) % 3;
        t.graph_occupy_2.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][2].belong + 1) % 3;
        t.graph_occupy_3.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][3].belong + 1) % 3;
        t.graph_occupy_4.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][4].belong + 1) % 3;
        t.graph_occupy_5.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][5].belong + 1) % 3;
        t.graph_occupy_6.push_back(n);
    }
    for(int i = 0; i < 9; i++)
    {
        n.data = (info.region_occupy[i][6].belong + 1) % 3;
        t.graph_occupy_7.push_back(n);
    }
    return t;
}

void result_callback(const std_msgs::String &msg)
{
    if(msg.data == "success" && running)
    {
        rm_msgs::action pub_msg;
        if(actions.empty())
        {
            pub_msg.action.data = STOP;
            running = false;
        }
        else
        {
            while(actions.front().action >= 4)
            {
                pub_msg.action.data = MOVE; ///move
                pub_msg.path.header.frame_id = "map";
                pub_msg.path.header.seq = 0;
                pub_msg.path.header.stamp = ros::Time::now();
                int x = actions.front().x;
                int y = actions.front().y;
                pub_msg.path.poses.push_back(new_pose((x - 1) * SQUARE_LENGTH,
                        (y - 1) * SQUARE_LENGTH, 0, 0));
                actions.pop();
                /*if(actions.front().action < 4) break;
                double ddx = (double)(actions.front().x - x) / 5.0;
                double ddy = (double)(actions.front().y - y) / 5.0;
                for(int i = 1; i <= 4; i++)
                    pub_msg.path.poses.push_back(new_pose((x + ddx * i - 1) * SQUARE_LENGTH,
                                                          (y + ddy * i - 1) * SQUARE_LENGTH, 0, 0));*/
            }
            if(pub_msg.action.data == MOVE)
            {
                pub.publish(pub_msg);
                return;
            }
            int tower = get_tower(actions.front().x, actions.front().y);
            pub_msg.action.data = actions.front().action;
            if(actions.front().action == OCCUPY)
            {
                pub_msg.path.header.frame_id = "map";
                pub_msg.path.header.seq = 0;
                pub_msg.path.header.stamp = ros::Time::now();
                pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH, (actions.front().y - 1) * SQUARE_LENGTH, 0, 0));
            }
            if(actions.front().action == PUSH_CUP)
            {
                int side = get_tower_side(tower, actions.front().x, actions.front().y);
                double diff = 0.0;
                if(is_from_front(actions.front().x, actions.front().y, me)) diff = CUP_FRONT_DIFF + actions.front().cup_index * CUP_PER_DIFF;
                else if(is_from_left(actions.front().x, actions.front().y, me)) diff = CUP_LEFT_DIFF;
                else diff = CUP_RIGHT_DIFF;
                switch (side)
                {
                    case SIDE_UP:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH + SQUARE_CUP_DIFF,
                                                              (actions.front().y - 1) * SQUARE_LENGTH - diff, 0, - PI / 2));
                        break;
                    }
                    case SIDE_LEFT:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH + diff,
                                                              (actions.front().y - 1) * SQUARE_LENGTH + SQUARE_CUP_DIFF, 0, 0));
                        break;
                    }
                    case SIDE_DOWN:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH - SQUARE_CUP_DIFF,
                                                              (actions.front().y - 1) * SQUARE_LENGTH + diff, 0, PI / 2));
                        break;
                    }
                    case SIDE_RIGHT:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH - diff,
                                                              (actions.front().y - 1) * SQUARE_LENGTH - SQUARE_CUP_DIFF, 0, PI));
                        break;
                    }
                    default:
                        std::cout << "result_callback():WTF???\n";
                }
            }
            else if(actions.front().action == PUSH_BALL)
            {
                int side = get_tower_side(tower, actions.front().x, actions.front().y);
                double diff = pub_msg.ball_index.data * BALL_PER_DIFF;
                int first_box = 1;
                while(actions.front().ball_in_box[first_box] <= 0)
                {
                    first_box++;
                    if(first_box >= 5) break;
                }
                pub_msg.ball_index.data = actions.front().tower_ball_number[tower][get_tower_side(tower, actions.front().x, actions.front().y)]
                                          - actions.front().ball;
                for (int i = first_box; i < first_box + actions.front().ball; ++i) pub_msg.ball.data += (1 << (i - first_box));
                diff += first_box * BALL_PER_DIFF;
                if(is_from_front(actions.front().x, actions.front().y, me)) diff += BALL_FRONT_DIFF;
                else if(is_from_left(actions.front().x, actions.front().y, me)) diff += BALL_LEFT_DIFF;
                else diff += BALL_RIGHT_DIFF;
                switch (side)
                {
                    case SIDE_UP:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH + SQUARE_BALL_DIFF,
                                                              (actions.front().y - 1) * SQUARE_LENGTH - diff, 0, PI));
                        break;
                    }
                    case SIDE_LEFT:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH + diff,
                                                              (actions.front().y - 1) * SQUARE_LENGTH + SQUARE_BALL_DIFF, 0, - PI / 2));
                        break;
                    }
                    case SIDE_DOWN:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH - SQUARE_BALL_DIFF,
                                                              (actions.front().y - 1) * SQUARE_LENGTH + diff, 0, 0));
                        break;
                    }
                    case SIDE_RIGHT:
                    {
                        pub_msg.path.header.frame_id = "map";
                        pub_msg.path.header.seq = 0;
                        pub_msg.path.header.stamp = ros::Time::now();
                        pub_msg.path.poses.push_back(new_pose((actions.front().x - 1) * SQUARE_LENGTH + diff,
                                                              (actions.front().y - 1) * SQUARE_LENGTH - SQUARE_BALL_DIFF, 0, PI / 2));
                        break;
                    }
                    default:
                        std::cout << "result_callback():WTF???\n";
                }
            }
            actions.pop();
        }
        pub.publish(pub_msg);
    }
}

void status_callback(const rm_msgs::status &msg)
{
    if(running)
    {
        if(msg.round_team.data != msg.me.data && msg.remain_square.data > 0 && msg.remain_tick.data > 0)
        {
            running = false;
            while(!actions.empty()) actions.pop();
        }
        return;
    }
    if(msg.round_team.data != msg.me.data && msg.remain_square.data > 0 && msg.remain_tick.data > 0) return;
    if(msg.round_team.data == msg.me.data && msg.remain_square.data < 10 && msg.remain_tick.data < 30) return;
    running = true;
    for (int i = 0; i < 7; i++)
        stat[1].tower_power[i + 1][RED] = msg.tower_power_red[i].data;
    for (int i = 0; i < 7; i++)
        stat[1].tower_power[i + 1][BLUE] = msg.tower_power_blue[i].data;
    for (int i = 0; i < 7; ++i)
        stat[1].tower_occupy[i + 1] = get_tower_occupy(1, i + 1);
    pos_x[RED] = msg.car_pos_x_red.data;
    pos_y[RED] = msg.car_pos_y_red.data;
    pos_x[BLUE] = msg.car_pos_x_blue.data;
    pos_y[BLUE] = msg.car_pos_y_blue.data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[1][j + 1] = msg.graph_occupy_1[j].data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[2][j + 1] = msg.graph_occupy_2[j].data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[3][j + 1] = msg.graph_occupy_3[j].data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[4][j + 1] = msg.graph_occupy_4[j].data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[5][j + 1] = msg.graph_occupy_5[j].data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[6][j + 1] = msg.graph_occupy_6[j].data;
    for (int j = 0; j < 9; j++) stat[1].graph_occupy[7][j + 1] = msg.graph_occupy_7[j].data;
    me = msg.me.data;
    ///who i am
    if (me == BLUE) enemy = RED;
    else enemy = BLUE;
    ///set origin status
    stat[1].x = pos_x[me];
    stat[1].y = pos_y[me];
    stat[1].rest_time = tot_time;
    stat[1].score = 0;
    stat[1].weight = 0;
    stat[1].action = 0;
    stat[1].ball = 0;
    stat[1].father = 0;
    stat[1].rest_square = max_square;
    update_graph_status(1);
    ///WARNING:C++11
    q.push(node{1, 0});
    tot = 1;
    std::cout << "started\n";
    print_status(stat[1]);
    work();
    std_msgs::String suc_str;
    suc_str.data = "success";
    result_pub.publish(suc_str);
}

int main(int argc, char** argv)
{
    stat[1].ball_in_box[1] = 5;
    stat[1].ball_in_box[2] = 5;
    stat[1].ball_in_box[3] = 5;
    stat[1].ball_in_box[4] = 5;
    stat[1].rest_ball = max_ball;
    stat[1].rest_cup = max_cup;
    ros::init(argc, argv, "algorithm");
    ros::NodeHandle nh;
    pub = nh.advertise<rm_msgs::action>("actions",1);
    result_pub = nh.advertise<std_msgs::String>("result", 1);
    ros::Subscriber sub_result = nh.subscribe("result", 1, &result_callback);
    ros::Subscriber sub_status = nh.subscribe("status", 1, &status_callback);
    ros::spin();
    return 0;
}
