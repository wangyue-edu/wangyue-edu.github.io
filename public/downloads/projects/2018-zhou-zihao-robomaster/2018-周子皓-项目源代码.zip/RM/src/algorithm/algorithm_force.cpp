#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>

//define some settings
int max_square = 15; //the max square to go in a turn
int min_time = 25000;
int min_square = 0;
int max_ball = 30;
int max_cup = 10;

//variables about time(ms)
int tot_time = 40000; //total time in a turn
int ball_time = 3000; //time cost when push a ball
int cup_time = 5000; //time cost when push a cup
int move_time = 1000; //time cost when move a square
int occupy_time = 1000; //time cost when occupy a square

//weight about actions
int occupy_weight_weak = 15;
int occupy_weight_strong = 20;
int push_ball_weight = 0;
int push_cup_weight = 0;
int occupy_tower_weight = 50;
int move_weight = 0;
int pass_weight = -1;
int visited_cost = -2;
int occupied_cost = -0;

//variables about estimate
float estimate_per_time = 0.001;
int estimate_per_square = 10;
int random_time = 500;
int random_step = 20;
#define CUP_ESTIMATE 20
#define MOVE_ESTIMATE 20
#define BALL_ESTIMATE 30
#define OCCUPY_ESTIMATE 30
#define ALL_ESTIMATE CUP_ESTIMATE + MOVE_ESTIMATE + BALL_ESTIMATE + OCCUPY_ESTIMATE

//players
#define RED 1
#define BLUE 2
int me, enemy;

//graph
#define EMPTY_SQUARE 0
#define RED_SQUARE 1
#define BLUE_SQUARE 2
#define EMPTY 0
#define STRONG 2
#define WEAK 1

bool tower_connected[10];
bool visited[10][10];
bool visited_strong[10][10];
bool work_visited[10][10];
int graph_occupy[10][10]; //who occupy one square
int graph_status[10][10]; //whether the square is strong or weak occupied
int tower_power[10][3];
int tower_occupy[10];

//car status
int pos_x[3], pos_y[3];

//actions list
#define MAX_ACTIONS 3
#define MOVE 0
#define OCCUPY 1
#define PUSH_BALL 2
#define PUSH_CUP 3
#define MOVE_UP 4
#define MOVE_LEFT 5
#define MOVE_DOWN 6
#define MOVE_RIGHT 7

int dx[8] = {0, 0, 0, 0, -1, 0, 1, 0};
int dy[8] = {0, 0, 0, 0, 0, -1, 0, 1};

//occupy status list
#define CANT_OCCUPY 0
#define WEAK_OCCUPY 1
#define STRONG_OCCUPY 2

#define nullptr 0

//search status struct
struct status
{
    int x;
    int y;
    int rest_time;
    int rest_square;
    int rest_cup;
    int rest_ball;
    int score;
    int action;
    int expand;
    int child_status[8];
    int father;
}stat[20000000];

int tot;
int max_index;
int max_score;

int get_tower(int x, int y)
{
    if((x == 1 && y == 2) || (x == 2 && y == 3) || (x == 1 && y == 4)) return 1;
    if((x == 1 && y == 6) || (x == 2 && y == 7) || (x == 1 && y == 8)) return 2;
    if((x == 3 && y == 1) || (x == 4 && y == 2) || (x == 5 && y == 1)) return 3;
    if((x == 3 && y == 5) || (x == 5 && y == 5) || (x == 4 && y == 4) || (x == 4 && y == 6)) return 4;
    if((x == 3 && y == 9) || (x == 4 && y == 8) || (x == 5 && y == 9)) return 5;
    if((x == 7 && y == 2) || (x == 6 && y == 3) || (x == 7 && y == 4)) return 6;
    if((x == 7 && y == 6) || (x == 6 && y == 7) || (x == 7 && y == 8)) return 7;
    return 0;
}

//check if this square is accessible(if it is a tower or it is out of limit)
bool check(int x, int y)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return false;
    return !((x == 1 && y == 3) || (x == 1 && y == 7) || (x == 4 && y == 1) ||
             (x == 4 && y == 5) || (x == 4 && y == 9) || (x == 7 && y == 3) || (x == 7 && y == 7)
             || (x == pos_x[enemy] && y == pos_y[enemy]));
}

/*double uct(status *stat, int child_index)
{
    if(stat->child_status[child_index] == nullptr) return -1.0;
    status *child = stat->child_status[child_index];
    return (double)child->score / (double)stat->score + 1.0 * sqrt((double)log(stat->score) / (double)child->score);
}*/

int random_action()
{
    int t = rand() % ALL_ESTIMATE + 1;
    if(t < CUP_ESTIMATE) return PUSH_CUP;
    t -= CUP_ESTIMATE;
    if(t < BALL_ESTIMATE) return PUSH_BALL;
    t -= BALL_ESTIMATE;
    if(t < OCCUPY_ESTIMATE) return OCCUPY;
    return rand() % 4 + 4;
}

void occupy_dfs(int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    if(get_tower(x, y) && tower_occupy[get_tower(x, y)] == player) tower_connected[get_tower(x, y)] = true;
    occupy_dfs(x + 1, y, player);
    occupy_dfs(x - 1, y, player);
    occupy_dfs(x, y + 1, player);
    occupy_dfs(x, y - 1, player);
}

int get_occupy_status(int x, int y, int player)
{
    int tower_count = 0;
    memset(tower_connected, 0, sizeof(tower_connected));
    memset(visited, 0, sizeof(visited));
    int t = graph_occupy[x][y];
    graph_occupy[x][y] = player;
    occupy_dfs(x, y, player);
    graph_occupy[x][y] = t;
    for (int k = 0; k < 10; ++k)
        if(tower_connected[k]) tower_count++;
    if(tower_count >= 3) return STRONG_OCCUPY;
    if(tower_count > 0) return WEAK_OCCUPY;
    return CANT_OCCUPY;
}

//sum the total square score for each player
void sum(int *blue, int *red)
{
    *blue = 0;
    *red = 0;
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            if(graph_occupy[i][j] == BLUE)
            {
                if(graph_status[i][j] == WEAK_OCCUPY) *blue += occupy_weight_weak;
                else *blue += occupy_weight_strong;
            }
            else if(graph_occupy[i][j] == RED)
            {
                if(graph_status[i][j] == WEAK_OCCUPY) *red += occupy_weight_weak;
                else *red += occupy_weight_strong;
            }
        }
    for (int i = 0; i < 10; ++i)
    {
        if(tower_occupy[i] == RED) *red += occupy_tower_weight;
        if(tower_occupy[i] == BLUE) *blue += occupy_tower_weight;
    }
    //std::cout<<*red<<" "<<*blue<<std::endl;
}

bool check_action(status *stat, int action)
{
    if(action >= MOVE_UP && action <= MOVE_RIGHT) if(check(stat->x + dx[action], stat->y + dy[action])) return true;
    if(action == PUSH_CUP)
        if(get_tower(stat->x + dx[action], stat->y + dy[action]) && stat->rest_ball >= 1 && stat->rest_cup >= 1) return true;
    if(action == PUSH_BALL) if(get_tower(stat->x + dx[action], stat->y + dy[action]) && stat->rest_ball >= 1) return true;
    if(action == OCCUPY) if(get_occupy_status(stat->x + dx[action], stat->y + dy[action], me)) return true;
    return false;
}

status* new_status(status *parent)
{
    status *stat = new status;
    stat->rest_square = parent->rest_square;
    stat->rest_time = parent->rest_time;
    stat->rest_cup = parent->rest_cup;
    stat->rest_ball = parent->rest_ball;
    stat->x = parent->x;
    stat->y = parent->y;
    stat->expand = 0;
    memset(stat->child_status, 0, sizeof(stat->child_status));
    stat->score = 1;
    return stat;
}

/*int simulation(status *stat)
{
    if(stat->rest_time <= min_time || stat->rest_square <= min_square)
    {
        int blue, red;
        sum(&blue, &red);
        if(me == RED)
            stat->score = red - blue;
        else
            stat->score = blue - red;
        return stat->score;
    }
    int action;
    while(true)
    {
        action = random_action();
        if(check_action(stat, action)) break;
    }
    if(stat->child_status[action] == nullptr) stat->child_status[action] = new_status(stat);
    int score = simulation(stat->child_status[action]);
    stat->score += score;
    return score;
}

void work(status *stat)
{
    double max_uct = -10000;
    int max_action = 0;
    if(stat->expand == 7)
    {
        for (int i = 1; i < 8; ++i)
        {
            if(stat->child_status[i] != nullptr && max_uct < uct(stat, i) && check_action(stat, i))
            {
                max_action = i;
                max_uct = uct(stat, i);
            }
        }
        work(stat->child_status[max_action]);
    }
    for (int i = 1; i < 7; ++i)
    {
        if(stat->child_status[i] == nullptr)
        {
            simulation(stat->child_status[i] = new_status(stat));
            break;
        }
    }
}*/

std::string number2action(int number)
{
    switch (number)
    {
        case OCCUPY:
            return "occupy";
        case PUSH_BALL:
            return "ball";
        case PUSH_CUP:
            return "cap";
        case MOVE_LEFT:
            return "left";
        case MOVE_RIGHT:
            return "right";
        case MOVE_UP:
            return "up";
        case MOVE_DOWN:
            return "down";
        default:
            return "";
    }
}

void print(int index)
{
    if(index == 0) return;
    print(stat[index].father);
    std::cout << index << number2action(stat[index].action) << std::endl;
}

void force_work(int index)
{
    if(stat[index].rest_time <= min_time || stat[index].rest_square <= min_square)
    {
        int red, blue, score;
        sum(&blue, &red);
        std::cout<<red<<" "<<blue<<std::endl;
        if(me == RED) score = red - blue;
        else score = blue - red;
        if(score > max_score)
        {
            max_score = score;
            max_index = index;
        }
        return;
    }
    for(int i = 1; i <= 7; i++)
    {
        switch (i)
        {
            case OCCUPY:
            {
                int occupy_status = get_occupy_status(stat[index].x, stat[index].y, me);
                if(occupy_status == CANT_OCCUPY) break;
                if(graph_occupy[stat[index].x][stat[index].y] == me || graph_status[stat[index].x][stat[index].y] == STRONG_OCCUPY)
                    break;
                stat[++tot] = stat[index];
                int t1 = graph_occupy[stat[tot].x][stat[tot].y];
                int t2 = graph_status[stat[tot].x][stat[tot].y];
                graph_occupy[stat[tot].x][stat[tot].y] = me;
                graph_status[stat[tot].x][stat[tot].y] = occupy_status;
                stat[tot].father = index;
                stat[tot].action = OCCUPY;
                stat[index].child_status[OCCUPY] = tot;
                stat[tot].rest_time -= occupy_time;
                force_work(tot);
                graph_occupy[stat[tot].x][stat[tot].y] = t1;
                graph_status[stat[tot].x][stat[tot].y] = t2;
                break;
            }
            case PUSH_BALL:
            {
                int tower = get_tower(stat[index].x, stat[index].y);
                if(tower == 0) break;
                if(tower_occupy[tower] == me) break;
                if(stat[index].rest_ball <= 0) break;
                stat[++tot] = stat[index];
                stat[tot].rest_ball--;
                stat[tot].rest_time -= ball_time;
                tower_power[tower][me]++;
                int t = tower_occupy[tower];
                if(tower_power[tower][me] > tower_power[tower][enemy]) tower_occupy[tower] = me;
                stat[tot].father = index;
                stat[tot].action = PUSH_BALL;
                stat[index].child_status[PUSH_BALL] = tot;
                force_work(tot);
                tower_power[tower][me]--;
                tower_occupy[tower] = t;
                break;
            }
            case PUSH_CUP:
            {
                int tower = get_tower(stat[index].x, stat[index].y);
                if(tower == 0) break;
                if(tower_occupy[tower] == me) break;
                if(!(stat[index].rest_ball >= 1 && stat[index].rest_cup >= 1)) break;
                stat[++tot] = stat[index];
                stat[tot].rest_ball--;
                stat[tot].rest_cup--;
                stat[tot].rest_time -= cup_time;
                tower_power[tower][me] += 4;
                int t = tower_occupy[tower];
                if(tower_power[tower][me] > tower_power[tower][enemy]) tower_occupy[tower] = me;
                stat[tot].father = index;
                stat[tot].action = PUSH_CUP;
                stat[index].child_status[PUSH_CUP] = tot;
                force_work(tot);
                tower_power[tower][me]-=4;
                tower_occupy[tower] = t;
                break;
            }
            default:
            {
                for (int j = 4; j < 8; ++j)
                {
                    int x = stat[index].x + dx[j];
                    int y = stat[index].y + dy[j];
                    if(!check(x, y)) continue;
                    if(work_visited[x][y]) break;
                    work_visited[x][y] = true;
                    stat[++tot] = stat[index];
                    stat[tot].x = x;
                    stat[tot].y = y;
                    stat[tot].rest_time -= move_time;
                    stat[tot].rest_square -= 1;
                    stat[tot].action = j;
                    stat[tot].father = index;
                    stat[index].child_status[j] = tot;
                    force_work(tot);
                    work_visited[x][y] = false;
                }
                break;
            }
        }
    }
}

int main()
{
    FILE *fp = fopen("/home/robomaster/RM/test.txt", "r");
    srand((unsigned int) time(0));
    fscanf(fp, "# tower_power,RED=1,BLUE=2\n");
    for(int i = 1; i <= 7; i++) fscanf(fp, "%d", &tower_power[i][RED]);
    for(int i = 1; i <= 7; i++) fscanf(fp, "%d", &tower_power[i][BLUE]);
    fscanf(fp, "\n# car_pos\n");
    fscanf(fp, "%d %d %d %d", &pos_x[RED], &pos_y[RED], &pos_x[BLUE], &pos_y[BLUE]);
    fscanf(fp, "\n# graph occupy\n");
    for(int i = 1; i <= 7; i++)
        for(int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &graph_occupy[i][j]);
    fscanf(fp, "\n# graph status\n");
    for(int i = 1; i <= 7; i++)
        for(int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &graph_status[i][j]);
    fscanf(fp, "\n# me\n");
    fscanf(fp, "%d", &me);
    if(me == BLUE) enemy = RED;
    else enemy = BLUE;
    stat[0].x = pos_x[me];
    stat[0].y = pos_y[me];
    stat[0].rest_time = tot_time;
    stat[0].score = 1;
    stat[0].rest_square = max_square;
    stat[0].rest_ball = max_ball;
    stat[0].rest_cup = max_cup;
    force_work(0);
    std::cout << max_index << ":" << max_score << std::endl;
    print(max_index);
    return 0;
    //work(&origin);
    return 0;
}