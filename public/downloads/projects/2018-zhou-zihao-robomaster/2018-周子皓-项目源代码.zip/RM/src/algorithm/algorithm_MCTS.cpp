#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;

//define some settings
int max_square = 15; //the max square to go in a turn
int min_time = 0;
int min_square = 0;
int max_ball = 30;
int max_cup = 10;

//variables about time(ms)
int tot_time = 40000; //total time in a turn
int ball_time = 3000; //time cost when push a ball
int cup_time = 5000; //time cost when push a cup
int move_time = 1000; //time cost when move a square
int occupy_time = 1000; //time cost when occupy a square

//weight about actions
int occupy_weight_weak = 15;
int occupy_weight_strong = 20;
int push_ball_weight = 0;
int push_cup_weight = 0;
int occupy_tower_weight = 50;
int move_weight = 0;
int pass_weight = -5;
int visited_cost = -0;
int occupied_cost = -0;

//variables about estimate
float estimate_per_time = 0.001;
int estimate_per_square = 10;
int estimate_times = 10000;
#define CUP_ESTIMATE 20
#define MOVE_ESTIMATE 20
#define BALL_ESTIMATE 20
#define OCCUPY_ESTIMATE 50
#define ALL_ESTIMATE CUP_ESTIMATE + MOVE_ESTIMATE + BALL_ESTIMATE + OCCUPY_ESTIMATE

//players
#define RED 1
#define BLUE 2
int me, enemy;
int score_red, score_blue;

//graph
#define EMPTY_SQUARE 0
#define RED_SQUARE 1
#define BLUE_SQUARE 2
#define EMPTY 0
#define STRONG 2
#define WEAK 1

bool tower_connected[10];
bool visited[10][10];
bool visited_strong[10][10];
bool work_visited[10][10];


//car status
int pos_x[3], pos_y[3];

//actions list
#define MAX_ACTIONS 3
#define MOVE 0
#define OCCUPY 1
#define PUSH_BALL 2
#define PUSH_CUP 3
#define MOVE_UP 4
#define MOVE_LEFT 5
#define MOVE_DOWN 6
#define MOVE_RIGHT 7

int dx[8] = {0, 0, 0, 0, -1, 0, 1, 0};
int dy[8] = {0, 0, 0, 0, 0, -1, 0, 1};

//occupy status list
#define CANT_OCCUPY 0
#define WEAK_OCCUPY 1
#define STRONG_OCCUPY 2

#define nullptr 0

//search status struct
struct status
{
    char x;
    char y;
    unsigned short rest_time;
    char rest_square;
    char rest_cup;
    char rest_ball;
    int score; //the total score of this status
    char action;
    short expand; //times this status being expanded
    int child_status[8];
    char graph_occupy[8][10];
    char graph_status[8][10];
    char tower_power[8][3];
    char tower_occupy[8];
    int father;
}stat[7500000];

struct node
{
    int index;
    double uct;
    bool operator < (const node &b) const
    {
        return uct < b.uct;
    }
};

priority_queue <node> q;

int tot;

bool check(int x, int y)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return false;
    return !((x == 1 && y == 3) || (x == 1 && y == 7) || (x == 4 && y == 1) ||
             (x == 4 && y == 5) || (x == 4 && y == 9) || (x == 7 && y == 3) || (x == 7 && y == 7)
             || (x == pos_x[enemy] && y == pos_y[enemy]));
}

int get_tower(int x, int y)
{
    if((x == 1 && y == 2) || (x == 2 && y == 3) || (x == 1 && y == 4)) return 1;
    if((x == 1 && y == 6) || (x == 2 && y == 7) || (x == 1 && y == 8)) return 2;
    if((x == 3 && y == 1) || (x == 4 && y == 2) || (x == 5 && y == 1)) return 3;
    if((x == 3 && y == 5) || (x == 5 && y == 5) || (x == 4 && y == 4) || (x == 4 && y == 6)) return 4;
    if((x == 3 && y == 9) || (x == 4 && y == 8) || (x == 5 && y == 9)) return 5;
    if((x == 7 && y == 2) || (x == 6 && y == 3) || (x == 7 && y == 4)) return 6;
    if((x == 7 && y == 6) || (x == 6 && y == 7) || (x == 7 && y == 8)) return 7;
    return 0;
}

int random_action()
{
    int t = rand() % ALL_ESTIMATE + 1;
    if(t < CUP_ESTIMATE) return PUSH_CUP;
    t -= CUP_ESTIMATE;
    if(t < BALL_ESTIMATE) return PUSH_BALL;
    t -= BALL_ESTIMATE;
    if(t < OCCUPY_ESTIMATE) return OCCUPY;
    return rand() % 4 + 4;
}

void occupy_dfs(int index, int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(stat[index].graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    if(get_tower(x, y) && stat[index].tower_occupy[get_tower(x, y)] == player) tower_connected[get_tower(x, y)] = true;
    occupy_dfs(index, x + 1, y, player);
    occupy_dfs(index, x - 1, y, player);
    occupy_dfs(index, x, y + 1, player);
    occupy_dfs(index, x, y - 1, player);
}

int get_occupy_status(int index, int player)
{
    int tower_count = 0;
    int x = stat[index].x;
    int y = stat[index].y;
    memset(tower_connected, 0, sizeof(tower_connected));
    memset(visited, 0, sizeof(visited));
    int t = stat[index].graph_occupy[x][y];
    stat[index].graph_occupy[x][y] = player;
    occupy_dfs(index, x, y, player);
    stat[index].graph_occupy[x][y] = t;
    for (int k = 0; k < 10; ++k)
        if(tower_connected[k]) tower_count++;
    if(tower_count >= 3) return STRONG_OCCUPY;
    if(tower_count > 0) return WEAK_OCCUPY;
    return CANT_OCCUPY;
}

bool check_action(int index, int action)
{
    if(action >= MOVE_UP && action <= MOVE_RIGHT) if(check(stat[index].x + dx[action], stat[index].y + dy[action])) return true;
    if(action == PUSH_CUP)
        if(get_tower(stat[index].x + dx[action], stat[index].y + dy[action]) &&
            stat[index].rest_ball >= 1 && stat[index].rest_cup >= 1) return true;
    if(action == PUSH_BALL) if(get_tower(stat[index].x, stat[index].y) && stat[index].rest_ball >= 1) return true;
    if(action == OCCUPY) if(get_occupy_status(index, me)) return true;
    return false;
}

std::string number2action(int number)
{
    switch (number)
    {
        case OCCUPY:
            return "occupy";
        case PUSH_BALL:
            return "ball";
        case PUSH_CUP:
            return "cap";
        case MOVE_LEFT:
            return "left";
        case MOVE_RIGHT:
            return "right";
        case MOVE_UP:
            return "up";
        case MOVE_DOWN:
            return "down";
        default:
            return "";
    }
}

//sum the total square score for each player
void sum(int index, int *blue, int *red)
{
    *blue = 0;
    *red = 0;
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            if(stat[index].graph_occupy[i][j] == BLUE)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *blue += occupy_weight_weak;
                else *blue += occupy_weight_strong;
            }
            else if(stat[index].graph_occupy[i][j] == RED)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *red += occupy_weight_weak;
                else *red += occupy_weight_strong;
            }
        }
    for (int i = 0; i < 10; ++i)
    {
        if(stat[index].tower_occupy[i] == RED) *red += occupy_tower_weight;
        if(stat[index].tower_occupy[i] == BLUE) *blue += occupy_tower_weight;
    }
    //std::cout<<*red<<" "<<*blue<<std::endl;
}

double uct(int father, int child)
{
    //cout << stat[child].score << " " << stat[father].score << " " << (double)stat[father].expand << " "
    // << (double)stat[child].expand << endl;
    double result = (double)stat[child].score / (double)stat[father].score +
        10.0 * sqrt((double)log(stat[father].expand) / (double)stat[child].expand);
    //cout << result << endl;
    return result;
}

//choice random action until this status can not do anything and then return the score of the end status
int estimate(int index)
{
    if(stat[index].rest_time <= min_time || stat[index].rest_square <= min_square)
    {
        int red, blue, score;
        sum(index, &blue, &red);
        //std::cout<<red<<" "<<blue<<std::endl;
        if(me == RED) score = red - score_red + score_blue - blue;
        else score = blue - score_blue + score_red - red;
        return score;
    }
    //TODO:make a function to make these steps better
    //TODO:make a proper random function
    int action;
    while(true)
    {
        action = random_action();
        if(check_action(index, action)) break;
    }
    switch (action)
    {
        case OCCUPY:
        {
            int occupy_status = get_occupy_status(index, me);
            if(occupy_status == CANT_OCCUPY) return estimate(index);
            if(stat[index].graph_occupy[stat[index].x][stat[index].y] == me ||
               stat[index].graph_status[stat[index].x][stat[index].y] == STRONG_OCCUPY) return estimate(index);
            stat[++tot] = stat[index];
            stat[tot].score = 0;
            stat[tot].expand = 0;
            memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
            stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
            stat[tot].graph_status[stat[tot].x][stat[tot].y] = occupy_status;
            stat[tot].father = index;
            stat[tot].action = OCCUPY;
            stat[index].child_status[OCCUPY] = tot;
            stat[tot].rest_time -= occupy_time;
            int t = tot;
            int score = estimate(tot);
            stat[t].score += score;
            return score;
        }
        case PUSH_BALL:
        {
            int tower = get_tower(stat[index].x, stat[index].y);
            if(stat[index].tower_occupy[tower] == me) return estimate(index);
            stat[++tot] = stat[index];
            stat[tot].score = 0;
            stat[tot].expand = 0;
            memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
            stat[tot].rest_ball--;
            stat[tot].rest_time -= ball_time;
            stat[tot].tower_power[tower][me]++;
            if(stat[tot].tower_power[tower][me] > stat[tot].tower_power[tower][enemy]) stat[tot].tower_occupy[tower] = me;
            stat[tot].father = index;
            stat[tot].action = PUSH_BALL;
            stat[index].child_status[PUSH_BALL] = tot;
            int t = tot;
            int score = estimate(tot);
            stat[t].score += score;
            return score;
        }
        case PUSH_CUP:
        {
            int tower = get_tower(stat[index].x, stat[index].y);
            if(stat[index].tower_occupy[tower] == me) return estimate(index);
            stat[++tot] = stat[index];
            stat[tot].score = 0;
            stat[tot].expand = 0;
            memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
            stat[tot].rest_ball--;
            stat[tot].rest_cup--;
            stat[tot].rest_time -= cup_time;
            stat[tot].tower_power[tower][me] += 4;
            if(stat[tot].tower_power[tower][me] > stat[tot].tower_power[tower][enemy]) stat[tot].tower_occupy[tower] = me;
            stat[tot].father = index;
            stat[tot].action = PUSH_CUP;
            stat[index].child_status[PUSH_CUP] = tot;
            int t = tot;
            int score = estimate(tot);
            stat[t].score += score;
            return score;
        }
        default:
        {
            int j = action;
            int x = stat[index].x + dx[j];
            int y = stat[index].y + dy[j];
            //if(work_visited[x][y]) break;
            //work_visited[x][y] = true;
            stat[++tot] = stat[index];
            stat[tot].score = 0;
            stat[tot].expand = 0;
            memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
            stat[tot].score += move_weight;
            stat[tot].x = x;
            stat[tot].y = y;
            stat[tot].rest_time -= move_time;
            stat[tot].rest_square -= 1;
            stat[tot].action = j;
            stat[tot].father = index;
            stat[index].child_status[j] = tot;
            int t = tot;
            int score = estimate(tot);
            if(stat[t].graph_occupy[x][y] == enemy) score -= pass_weight;
            stat[t].score += score;
            return score;
        }
    }
}

//Monte Carlo Tree Search
void MCTS(int index)
{
    //cout<<index<<" ";
    //if this status can not do anything, return
    if(stat[index].rest_time <= min_time || stat[index].rest_square <= min_square) return;
    //stat[index].score = 0;
    //step1: do all of the possible choices and estimate them
    for(int i = 1; i <= 7; i++)
    {
        switch (i)
        {
            case OCCUPY:
            {
                int occupy_status = get_occupy_status(index, me);
                if(occupy_status == CANT_OCCUPY) break;
                if(stat[index].graph_occupy[stat[index].x][stat[index].y] == me ||
                    stat[index].graph_status[stat[index].x][stat[index].y] == STRONG_OCCUPY) break;
                stat[++tot] = stat[index];
                stat[tot].score = 0;
                stat[tot].expand = 0;
                memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
                stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
                stat[tot].graph_status[stat[tot].x][stat[tot].y] = occupy_status;
                stat[tot].father = index;
                stat[tot].action = OCCUPY;
                stat[index].child_status[OCCUPY] = tot;
                stat[tot].rest_time -= occupy_time;
                stat[tot].expand = 1;
                node n;
                n.index = tot;
                n.uct = 0;
                q.push(n);
                break;
            }
            case PUSH_BALL:
            {
                int tower = get_tower(stat[index].x, stat[index].y);
                if(tower == 0) break;
                if(stat[index].tower_occupy[tower] == me) break;
                if(stat[index].rest_ball <= 0) break;
                stat[++tot] = stat[index];
                stat[tot].score = 0;
                stat[tot].expand = 0;
                memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
                stat[tot].rest_ball--;
                stat[tot].rest_time -= ball_time;
                stat[tot].tower_power[tower][me]++;
                if(stat[tot].tower_power[tower][me] > stat[tot].tower_power[tower][enemy]) stat[tot].tower_occupy[tower] = me;
                stat[tot].father = index;
                stat[tot].action = PUSH_BALL;
                stat[index].child_status[PUSH_BALL] = tot;
                stat[tot].expand = 1;
                node n;
                n.index = tot;
                n.uct = 0;
                q.push(n);
                break;
            }
            case PUSH_CUP:
            {
                int tower = get_tower(stat[index].x, stat[index].y);
                if(tower == 0) break;
                if(stat[index].tower_occupy[tower] == me) break;
                if(!(stat[index].rest_ball >= 1 && stat[index].rest_cup >= 1)) break;
                stat[++tot] = stat[index];
                stat[tot].score = 0;
                stat[tot].expand = 0;
                memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
                stat[tot].rest_ball--;
                stat[tot].rest_cup--;
                stat[tot].rest_time -= cup_time;
                stat[tot].tower_power[tower][me] += 4;
                if(stat[tot].tower_power[tower][me] > stat[tot].tower_power[tower][enemy]) stat[tot].tower_occupy[tower] = me;
                stat[tot].father = index;
                stat[tot].action = PUSH_CUP;
                stat[index].child_status[PUSH_CUP] = tot;
                stat[tot].expand = 1;
                node n;
                n.index = tot;
                n.uct = 0;
                q.push(n);
                break;
            }
            default:
            {
                int x = stat[index].x + dx[i];
                int y = stat[index].y + dy[i];
                if(!check(x, y)) continue;
                //if(work_visited[x][y]) break;
                //work_visited[x][y] = true;
                stat[++tot] = stat[index];
                stat[tot].score = 0;
                stat[tot].expand = 0;
                memset(stat[tot].child_status, 0, sizeof(stat[tot].child_status));
                if(stat[tot].graph_occupy[x][y] == enemy) stat[tot].score -= pass_weight;
                stat[tot].x = x;
                stat[tot].y = y;
                stat[tot].rest_time -= move_time;
                stat[tot].rest_square -= 1;
                stat[tot].action = i;
                stat[tot].father = index;
                stat[index].child_status[i] = tot;
                stat[tot].expand = 1;
                node n;
                n.index = tot;
                n.uct = 0;
                q.push(n);
                //work_visited[x][y] = false;
                break;
            }
        }
    }
    for (int i = 1; i < 8; ++i)
    {
        if(stat[index].child_status[i] == 0) continue;
        int score = estimate(stat[index].child_status[i]);
        stat[stat[index].child_status[i]].score += score;
        stat[index].score += score;
    }
    //step2: choose the max UCT status and estimate it for some times
    //init UCT
    vector <node> v;
    while(!q.empty())
    {
        node n = q.top();
        q.pop();
        n.uct = uct(index, n.index);
        v.push_back(n);
    }
    for (int i = 0; i < v.size(); ++i)
    {
        q.push(v[i]);
    }
    v.clear();
    for (int i = 0; i < estimate_times; ++i)
    {
        node n = q.top();
        q.pop();
        stat[n.index].expand++;
        int score = estimate(n.index);
        stat[n.index].score += score;
        stat[index].score += score;
        n.uct = uct(index, n.index);
        q.push(n);
    }
    while(!q.empty()) q.pop();
    int max_expand = 0, max_index = 0;
    for (int i = 1; i <= 7; ++i)
    {
        if(max_expand < stat[stat[index].child_status[i]].expand)
        {
            max_expand = stat[stat[index].child_status[i]].expand;
            max_index = stat[index].child_status[i];
        }
    }
    //step3: choose the most chosen status and MCTS(status)
    std::cout << max_expand << " " << max_index << " : " << number2action(stat[max_index].action) << std::endl;
    MCTS(max_index);
}

int main()
{
    FILE *fp = fopen("/home/robomaster/RM/testex.txt", "r");
    srand((unsigned int) time(0));
    fscanf(fp, "# tower_power,RED=1,BLUE=2\n");
    for(int i = 1; i <= 7; i++) fscanf(fp, "%d", &stat[0].tower_power[i][RED]);
    for(int i = 1; i <= 7; i++) fscanf(fp, "%d", &stat[0].tower_power[i][BLUE]);
    for (int i = 1; i <= 7; ++i)
    {
        if(stat[0].tower_power[i][RED] > stat[0].tower_power[i][BLUE]) stat[0].tower_occupy[i] = RED;
        else if(stat[0].tower_power[i][RED] < stat[0].tower_power[i][BLUE]) stat[0].tower_occupy[i] = BLUE;
        else stat[0].tower_occupy[i] = 0;
    }
    fscanf(fp, "\n# car_pos\n");
    fscanf(fp, "%d %d %d %d", &pos_x[RED], &pos_y[RED], &pos_x[BLUE], &pos_y[BLUE]);
    fscanf(fp, "\n# graph occupy\n");
    for(int i = 1; i <= 7; i++)
        for(int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &stat[0].graph_occupy[i][j]);
    fscanf(fp, "\n# graph status\n");
    for(int i = 1; i <= 7; i++)
        for(int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &stat[0].graph_status[i][j]);
    fscanf(fp, "\n# me\n");
    fscanf(fp, "%d", &me);
    if(me == BLUE) enemy = RED;
    else enemy = BLUE;
    stat[0].x = pos_x[me];
    stat[0].y = pos_y[me];
    stat[0].rest_time = tot_time;
    stat[0].score = 1;
    stat[0].rest_square = max_square;
    stat[0].rest_ball = max_ball;
    stat[0].rest_cup = max_cup;
    sum(0, &score_blue, &score_red);
    MCTS(0);
    return 0;
}
