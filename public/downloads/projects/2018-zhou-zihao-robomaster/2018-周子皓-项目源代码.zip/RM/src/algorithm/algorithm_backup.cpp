#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>

//define some settings
int max_square = 15; //the max square to go in a turn
int min_time = 0;
int min_square = 0;
int max_ball = 30;
int max_cup = 10;

//variables about time(ms)
int tot_time = 40000; //total time in a turn
int ball_time = 3000; //time cost when push a ball
int cup_time = 5000; //time cost when push a cup
int move_time = 1000; //time cost when move a square
int occupy_time = 1000; //time cost when occupy a square

//weight about actions
int occupy_weight_weak = 15;
int occupy_weight_strong = 20;
int push_ball_weight = 0;
int push_cup_weight = 0;
int occupy_tower_weight = 50;
int move_weight = 0;
int pass_weight = -1;
int visited_cost = -2;
int occupied_cost = -0;

//variables about estimate
float estimate_per_time = 0.001;
int estimate_per_square = 10;
int random_time = 500;
int random_step = 20;
#define CUP_ESTIMATE 20
#define MOVE_ESTIMATE 20
#define BALL_ESTIMATE 30
#define OCCUPY_ESTIMATE 30
#define ALL_ESTIMATE CUP_ESTIMATE + MOVE_ESTIMATE + BALL_ESTIMATE + OCCUPY_ESTIMATE

//players
#define RED 1
#define BLUE 2
int me, enemy;

//graph
#define EMPTY_SQUARE 0
#define RED_SQUARE 1
#define BLUE_SQUARE 2
#define EMPTY 0
#define STRONG 2
#define WEAK 1

bool tower_connected[10];
bool visited[10][10];
bool visited_strong[10][10];
bool work_visited[10][10];
int graph_occupy[10][10]; //who occupy one square
int graph_status[10][10]; //whether the square is strong or weak occupied
int tower_power[10][3];

//car status
int pos_x[3], pos_y[3];

//actions list
#define MAX_ACTIONS 3
#define MOVE 0
#define OCCUPY 1
#define PUSH_BALL 2
#define PUSH_CUP 3
#define MOVE_UP 4
#define MOVE_LEFT 5
#define MOVE_DOWN 6
#define MOVE_RIGHT 7

int dx[8] = {0, 0, 0, 0, -1, 0, 1, 0};
int dy[8] = {0, 0, 0, 0, 0, -1, 0, 1};

//occupy status list
#define CANT_OCCUPY 0
#define WEAK_OCCUPY 1
#define STRONG_OCCUPY 2


//search status struct
struct status
{
    int x;
    int y;
    int rest_time;
    int rest_square;
    int rest_cup;
    int rest_ball;
    int score;
    int weight;
    int occupy_status;
    int last_status_index;
    int action;
    bool operator < (const status &b) const
    {
        return (weight < b.weight) || (weight == b.weight && rest_time < b.rest_time);
    }
    bool operator == (const status &b) const
    {
        return x == b.x && y == b.y && rest_time == b.rest_time && rest_square == b.rest_square && rest_cup == b.rest_cup &&
        rest_ball == b.rest_ball && score == b.score && weight == b.weight && occupy_status == b.occupy_status &&
        last_status_index == b.last_status_index && action == b.action;
    }
};

std::priority_queue <status> q;

std::vector <status> statuses;

int random_action()
{
    int t = rand() % ALL_ESTIMATE + 1;
    if(t < CUP_ESTIMATE) return PUSH_CUP;
    t -= CUP_ESTIMATE;
    if(t < BALL_ESTIMATE) return PUSH_BALL;
    t -= BALL_ESTIMATE;
    if(t < OCCUPY_ESTIMATE) return OCCUPY;
    return rand() % 4 + 4;
}

void print_status(status stat)
{
    printf("x:%d;y:%d;rest_time:%d;rest_square:%d;rest_cup:%d;rest_ball:%d;score:%d;weight:%d;occupy_status:%d;"
           "last_status_index:%d\n",
            stat.x, stat.y, stat.rest_time, stat.rest_square, stat.rest_cup, stat.rest_ball, stat.score,
            stat.weight, stat.occupy_status, stat.last_status_index);
}

std::string number2action(int number)
{
    switch (number)
    {
        case OCCUPY:
            return "occupy";
        case PUSH_BALL:
            return "ball";
        case PUSH_CUP:
            return "cap";
        case MOVE_LEFT:
            return "left";
        case MOVE_RIGHT:
            return "right";
        case MOVE_UP:
            return "up";
        case MOVE_DOWN:
            return "down";
        default:
            return "";
    }
}

//print actions
void print(int x)
{
    if (x < 0) return;
    if (x == 0) {
        std::cout << x << "------" << statuses[x].action << "------" << number2action(statuses[x].action) << std::endl;
        //print_status(statuses[x]);
        return;
    }
    print(statuses[x].last_status_index);
    std::cout << x << "------" << statuses[x].action << "------" << number2action(statuses[x].action) << std::endl;
    //print_status(statuses[x]);
}

int get_tower(int x, int y)
{
    if((x == 1 && y == 2) || (x == 2 && y == 3) || (x == 1 && y == 4)) return 1;
    if((x == 1 && y == 6) || (x == 2 && y == 7) || (x == 1 && y == 8)) return 2;
    if((x == 3 && y == 1) || (x == 4 && y == 2) || (x == 5 && y == 1)) return 3;
    if((x == 3 && y == 5) || (x == 5 && y == 5) || (x == 4 && y == 4) || (x == 4 && y == 6)) return 4;
    if((x == 3 && y == 9) || (x == 4 && y == 8) || (x == 5 && y == 9)) return 5;
    if((x == 7 && y == 2) || (x == 6 && y == 3) || (x == 7 && y == 4)) return 6;
    if((x == 7 && y == 6) || (x == 6 && y == 7) || (x == 7 && y == 8)) return 7;
    return 0;
}

void dfs_strong(int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(graph_occupy[x][y] != player) return;
    if(visited_strong[x][y]) return;
    visited_strong[x][y] = true;
    graph_status[x][y] = STRONG_OCCUPY;
    dfs_strong(x + 1, y, player);
    dfs_strong(x - 1, y, player);
    dfs_strong(x, y + 1, player);
    dfs_strong(x, y - 1, player);
}

void dfs(int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    if(get_tower(x, y)) tower_connected[get_tower(x, y)] = true;
    graph_status[x][y] = WEAK_OCCUPY;
    dfs(x + 1, y, player);
    dfs(x - 1, y, player);
    dfs(x, y + 1, player);
    dfs(x, y - 1, player);
}

//sum the total square score for each player
void sum(int *blue, int *red)
{
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            if(graph_occupy[i][j] == BLUE)
            {
                if(graph_status[i][j] == WEAK_OCCUPY) blue += occupy_weight_weak;
                else blue += occupy_weight_strong;
            }
            else
            {
                if(graph_status[i][j] == WEAK_OCCUPY) red += occupy_weight_weak;
                else red += occupy_weight_strong;
            }
        }
}

//change the occupied status in the graph
//use it when a player occupies the tower
//return the added score
int change_occupy_status(int player)
{
    int blue1 = 0, red1 = 0;
    sum(&blue1, &red1);
    memset(visited, 0, sizeof(visited));
    for(int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            int tower_count = 0;
            memset(tower_connected, 0, sizeof(tower_connected));
            if(!visited[i][j] && graph_occupy[i][j] != EMPTY_SQUARE)
            {
                memset(visited_strong, 0, sizeof(visited_strong));
                dfs(i, j, graph_occupy[i][j]);
            }
            for (int k = 0; k < 10; ++k)
            {
                if(tower_connected[k]) tower_count++;
                if(tower_count >= 3) dfs_strong(i, j, graph_occupy[i][j]);
            }
        }
    int blue2 = 0, red2 = 0;
    sum(&blue2, &red2);
    if(player == RED) return red2 - red1 + blue1 - blue2;
    else return blue2 - blue1 + red1 - red2;
}

//find status in the queue
int find(status stat)
{
    for(int i = 0; i < statuses.size(); ++i)
    {
        if(statuses[i] == stat) return i;
    }
    return -1;
}

//check if this square is accessible(if it is a tower or it is out of limit)
bool check(int x, int y)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return false;
    return !((x == 1 && y == 3) || (x == 1 && y == 7) || (x == 4 && y == 1) ||
             (x == 4 && y == 5) || (x == 4 && y == 9) || (x == 7 && y == 3) || (x == 7 && y == 7)
             || (x == pos_x[enemy] && y == pos_y[enemy]));
}

//estimate score
int estimate(status stat)
{
    bool work_visited_backup[10][10];
    int graph_occupy_backup[10][10];
    int graph_status_backup[10][10];
    int tower_power_backup[10][3];
    memcpy(work_visited_backup, work_visited, sizeof(work_visited));
    memcpy(graph_occupy_backup, graph_occupy, sizeof(graph_occupy));
    memcpy(graph_status_backup, graph_status, sizeof(graph_status));
    memcpy(tower_power_backup, tower_power, sizeof(tower_power));
    status new_stat, old_stat = stat;
    int max_estimate = -10000;
    for (int experiment = 0; experiment < random_time; experiment++)
    {
        stat = old_stat;
        memcpy(work_visited, work_visited_backup, sizeof(work_visited));
        memcpy(graph_occupy, graph_occupy_backup, sizeof(graph_occupy));
        memcpy(graph_status, graph_status_backup, sizeof(graph_status));
        memcpy(tower_power, tower_power_backup, sizeof(tower_power));
        for (int i = 0; i < random_step; ++i)
        {
            if (stat.rest_time <= min_time || stat.rest_square <= min_square) {
                max_estimate = std::max(max_estimate, stat.score - old_stat.score);
                i = random_step;
            }
            //print_status(old_stat);
            new_stat = stat;
            int step = random_action();
            switch (step) {
                case OCCUPY:
                    switch (stat.occupy_status) {
                        case CANT_OCCUPY:
                            i--;
                            break;
                        case WEAK_OCCUPY:
                            if (graph_occupy[new_stat.x][new_stat.y] != me &&
                                graph_status[new_stat.x][new_stat.y] != STRONG) {
                                if (graph_occupy[new_stat.x][new_stat.y] == enemy) new_stat.score += occupy_weight_weak;
                                graph_occupy[new_stat.x][new_stat.y] = me;
                                graph_status[new_stat.x][new_stat.y] = WEAK;
                                new_stat.score += occupy_weight_weak;
                                new_stat.rest_time -= occupy_time;
                                new_stat.action = WEAK_OCCUPY;
                                new_stat.last_status_index = find(stat);
                                stat = new_stat;
                            }
                            else i--;
                            break;
                        case STRONG_OCCUPY:
                            if (graph_occupy[new_stat.x][new_stat.y] != me &&
                                graph_status[new_stat.x][new_stat.y] != STRONG) {
                                if (graph_occupy[new_stat.x][new_stat.y] == enemy) new_stat.score += occupy_weight_weak;
                                graph_occupy[new_stat.x][new_stat.y] = me;
                                graph_status[new_stat.x][new_stat.y] = STRONG;
                                new_stat.score += occupy_weight_strong;
                                new_stat.rest_time -= occupy_time;
                                new_stat.action = STRONG_OCCUPY;
                                new_stat.last_status_index = find(stat);
                                stat = new_stat;
                            }
                            else i--;
                            break;
                        default:
                            break;
                    }
                    break;
                case PUSH_BALL: {
                    int tower = get_tower(new_stat.x, new_stat.y);
                    if (tower && new_stat.rest_ball >= 0) {
                        bool flag = false;
                        if (tower_power[tower][me] <= tower_power[tower][enemy]) flag = true;
                        new_stat.rest_ball--;
                        tower_power[tower][me]++;
                        if (tower_power[tower][me] > tower_power[tower][enemy]) {
                            if (flag) new_stat.score += occupy_tower_weight;
                            else new_stat.score += push_ball_weight;
                            if (tower_power[tower] != 0) new_stat.score += push_cup_weight;
                            new_stat.rest_time -= ball_time;
                            new_stat.score += change_occupy_status(me);
                            if (graph_status[new_stat.x][new_stat.y] == STRONG_OCCUPY)
                                new_stat.occupy_status = STRONG_OCCUPY;
                            else new_stat.occupy_status = WEAK_OCCUPY;
                            new_stat.action = PUSH_BALL;
                            new_stat.last_status_index = find(stat);
                            stat = new_stat;
                        }
                    }
                    else i--;
                    break;
                }
                case PUSH_CUP: {
                    int tower = get_tower(new_stat.x, new_stat.y);
                    /*if(tower)
                        std::cout<<"debug:",print_status(new_stat);*/
                    if (tower && new_stat.rest_ball >= 0 && new_stat.rest_cup >= 0) {
                        bool flag = false;
                        if (tower_power[tower][me] <= tower_power[tower][enemy]) flag = true;
                        new_stat.rest_ball--;
                        new_stat.rest_cup--;
                        tower_power[tower][me] += 4;
                        if (tower_power[tower][me] > tower_power[tower][enemy]) {
                            if (flag) new_stat.score += occupy_tower_weight;
                            else new_stat.score += push_cup_weight;
                            if (tower_power[tower] != 0) new_stat.score += push_cup_weight;
                            new_stat.rest_time -= cup_time;
                            new_stat.score += change_occupy_status(me);
                            if (graph_status[new_stat.x][new_stat.y] == STRONG_OCCUPY)
                                new_stat.occupy_status = STRONG_OCCUPY;
                            else new_stat.occupy_status = WEAK_OCCUPY;
                            new_stat.action = PUSH_CUP;
                            new_stat.last_status_index = find(stat);
                            stat = new_stat;
                        }
                    }
                    else i--;
                    break;
                }
                default:
                {
                    new_stat = stat;
                    new_stat.x = stat.x + dx[step];
                    new_stat.y = stat.y + dy[step];
                    if (!check(new_stat.x, new_stat.y))
                    {
                        i--;
                        continue;
                    }
                    if (work_visited[new_stat.x][new_stat.y]) new_stat.score += visited_cost;
                    work_visited[new_stat.x][new_stat.y] = true;
                    new_stat.score += move_weight;
                    if (graph_occupy[new_stat.x][new_stat.y] == enemy) new_stat.score += pass_weight;
                    new_stat.rest_time -= move_time;
                    new_stat.rest_square--;
                    new_stat.action = step;
                    new_stat.last_status_index = find(stat);
                    stat = new_stat;
                    break;
                }
            }
        }
        max_estimate = std::max(max_estimate, stat.score - old_stat.score);
    }
    memcpy(work_visited, work_visited_backup, sizeof(work_visited));
    memcpy(graph_occupy, graph_occupy_backup, sizeof(graph_occupy));
    memcpy(graph_status, graph_status_backup, sizeof(graph_status));
    memcpy(tower_power, tower_power_backup, sizeof(tower_power));
    return max_estimate;
}

//search for the best actions
void work()
{
    int count = 0;
    status result_status;
    while (!q.empty())
    {
        status stat = q.top();
        q.pop();
        //print_status(stat);
        if(stat.rest_time <= min_time || stat.rest_square <= min_square)
        {
            count++;
            if(count == 1) result_status = stat;
            if(count < 3)
            {
                if(result_status.score < stat.score) result_status = stat;
                continue;
            }
            else
            {
                print(find(result_status));
                std::cout << "the total score is " << result_status.score << std::endl;
                return;
            }
        }
        for(int i = 0; i <= MAX_ACTIONS; i++)
        {
            status new_stat = stat;
            switch (i)
            {
                case MOVE:
                    for(int j = 4; j <= 7; j++)
                    {
                        new_stat = stat;
                        new_stat.x = stat.x + dx[j];
                        new_stat.y = stat.y + dy[j];
                        if(!check(new_stat.x, new_stat.y)) continue;
                        if(work_visited[new_stat.x][new_stat.y]) new_stat.score += visited_cost;
                        work_visited[new_stat.x][new_stat.y] = true;
                        new_stat.score += move_weight;
                        if(graph_occupy[new_stat.x][new_stat.y] == enemy) new_stat.score += pass_weight;
                        new_stat.rest_time -= move_time;
                        new_stat.rest_square--;
                        new_stat.action = j;
                        new_stat.weight = new_stat.score + estimate(new_stat);
                        new_stat.last_status_index = find(stat);
                        q.push(new_stat);
                        statuses.push_back(new_stat);
                    }
                    break;
                case OCCUPY:
                    switch (stat.occupy_status)
                    {
                        case CANT_OCCUPY:
                            break;
                        case WEAK_OCCUPY:
                            if(graph_occupy[new_stat.x][new_stat.y] != me && graph_status[new_stat.x][new_stat.y] != STRONG)
                            {
                                if(graph_occupy[new_stat.x][new_stat.y] == enemy) new_stat.score += occupy_weight_weak;
                                graph_occupy[new_stat.x][new_stat.y] = me;
                                graph_status[new_stat.x][new_stat.y] = WEAK;
                                new_stat.score += occupy_weight_weak;
                                new_stat.rest_time -= occupy_time;
                                new_stat.action = WEAK_OCCUPY;
                                new_stat.weight = new_stat.score + estimate(new_stat);
                                new_stat.last_status_index = find(stat);
                                q.push(new_stat);
                                statuses.push_back(new_stat);
                            }
                            break;
                        case STRONG_OCCUPY:
                            if(graph_occupy[new_stat.x][new_stat.y] != me && graph_status[new_stat.x][new_stat.y] != STRONG)
                            {
                                if(graph_occupy[new_stat.x][new_stat.y] == enemy) new_stat.score += occupy_weight_weak;
                                graph_occupy[new_stat.x][new_stat.y] = me;
                                graph_status[new_stat.x][new_stat.y] = STRONG;
                                new_stat.score += occupy_weight_strong;
                                new_stat.rest_time -= occupy_time;
                                new_stat.action = STRONG_OCCUPY;
                                new_stat.weight = new_stat.score + estimate(new_stat);
                                new_stat.last_status_index = find(stat);
                                q.push(new_stat);
                                statuses.push_back(new_stat);
                            }
                            break;
                        default:
                            break;
                    }
                    break;
                case PUSH_BALL:
                {
                    int tower = get_tower(new_stat.x, new_stat.y);
                    if(tower && new_stat.rest_ball >= 0)
                    {
                        bool flag = false;
                        if(tower_power[tower][me] <= tower_power[tower][enemy]) flag = true;
                        new_stat.rest_ball--;
                        tower_power[tower][me]++;
                        if(tower_power[tower][me] > tower_power[tower][enemy])
                        {
                            if(flag) new_stat.score += occupy_tower_weight;
                            else new_stat.score += push_ball_weight;
                            if(tower_power[tower] != 0) new_stat.score += push_cup_weight;
                            new_stat.rest_time -= ball_time;
                            new_stat.score += change_occupy_status(me);
                            if(graph_status[new_stat.x][new_stat.y] == STRONG_OCCUPY) new_stat.occupy_status = STRONG_OCCUPY;
                            else new_stat.occupy_status = WEAK_OCCUPY;
                            new_stat.action = PUSH_BALL;
                            new_stat.weight = new_stat.score + estimate(new_stat);
                            new_stat.last_status_index = find(stat);
                            q.push(new_stat);
                            statuses.push_back(new_stat);
                        }
                    }
                    break;
                }
                case PUSH_CUP:
                {
                    int tower = get_tower(new_stat.x, new_stat.y);
                    /*if(tower)
                        std::cout<<"debug:",print_status(new_stat);*/
                    if(tower && new_stat.rest_ball >= 0 && new_stat.rest_cup >= 0)
                    {
                        bool flag = false;
                        if(tower_power[tower][me] <= tower_power[tower][enemy]) flag = true;
                        new_stat.rest_ball --;
                        new_stat.rest_cup -- ;
                        tower_power[tower][me] += 4;
                        if(tower_power[tower][me] > tower_power[tower][enemy])
                        {
                            if(flag) new_stat.score += occupy_tower_weight;
                            else new_stat.score += push_cup_weight;
                            if(tower_power[tower] != 0) new_stat.score += push_cup_weight;
                            new_stat.rest_time -= cup_time;
                            new_stat.score += change_occupy_status(me);
                            if(graph_status[new_stat.x][new_stat.y] == STRONG_OCCUPY) new_stat.occupy_status = STRONG_OCCUPY;
                            else new_stat.occupy_status = WEAK_OCCUPY;
                            new_stat.action = PUSH_CUP;
                            new_stat.weight = new_stat.score + estimate(new_stat);
                            new_stat.last_status_index = find(stat);
                            q.push(new_stat);
                            statuses.push_back(new_stat);
                        }
                    }
                    break;
                }
                default:
                    break;
            }
        }
    }
}

void dfs_init(int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    if(get_tower(x, y)) tower_connected[get_tower(x, y)] = true;
    dfs(x + 1, y, player);
    dfs(x - 1, y, player);
    dfs(x, y + 1, player);
    dfs(x, y - 1, player);
}

int main()
{
    FILE *fp = fopen("/home/robomaster/RM/testex.txt", "r");
    srand((unsigned int) time(0));
    fscanf(fp, "# tower_power,RED=1,BLUE=2\n");
    for(int i = 1; i <= 7; i++) fscanf(fp, "%d", &tower_power[i][RED]);
    for(int i = 1; i <= 7; i++) fscanf(fp, "%d", &tower_power[i][BLUE]);
    fscanf(fp, "\n# car_pos\n");
    fscanf(fp, "%d %d %d %d", &pos_x[RED], &pos_y[RED], &pos_x[BLUE], &pos_y[BLUE]);
    fscanf(fp, "\n# graph occupy\n");
    for(int i = 1; i <= 7; i++)
        for(int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &graph_occupy[i][j]);
    fscanf(fp, "\n# graph status\n");
    for(int i = 1; i <= 7; i++)
        for(int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &graph_status[i][j]);
    fscanf(fp, "\n# me\n");
    fscanf(fp, "%d", &me);
    if(me == BLUE) enemy = RED;
    else enemy = BLUE;
    status origin;
    origin.x = pos_x[me];
    origin.y = pos_y[me];
    origin.rest_time = tot_time;
    origin.weight = 0;
    origin.score = 0;
    origin.rest_square = max_square;
    origin.last_status_index = -1;
    origin.rest_ball = max_ball;
    origin.rest_cup = max_cup;
    q.push(origin);
    memset(tower_connected, 0, sizeof(tower_connected));
    memset(visited, 0, sizeof(visited));
    dfs_init(pos_x[me], pos_y[me], me);
    int tower_count = 0;
    for (int k = 0; k < 10; ++k)
    {
        if(tower_connected[k]) tower_count++;
        if(tower_count >= 3) origin.occupy_status = STRONG_OCCUPY;
        else if(tower_count > 0) origin.occupy_status = WEAK_OCCUPY;
        else origin.occupy_status = CANT_OCCUPY;
    }
    work_visited[origin.x][origin.y] = true;
    work();
    return 0;
}
