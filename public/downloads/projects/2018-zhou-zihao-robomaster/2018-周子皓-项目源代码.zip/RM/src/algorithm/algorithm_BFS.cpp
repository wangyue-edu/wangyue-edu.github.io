#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;

//define some settings
int max_square = 15; //the max square to go in a turn
int min_time = 0;
int min_square = 0;
int max_ball = 30;
int max_cup = 10;

//variables about time(ms)
int tot_time = 40000; //total time in a turn
int ball_time = 3000; //time cost when push a ball
int cup_time = 5000; //time cost when push a cup
int move_time = 1000; //time cost when move a square
int occupy_time = 1000; //time cost when occupy a square

//weight about actions
int occupy_weight_weak = 15;
int occupy_weight_strong = 20;
int push_ball_weight = 5;
int push_cup_weight = 20;
int tower_power_weight = 0;
int occupy_tower_weight = 50;
int move_weight = 0;
int pass_weight = -5;
int visited_cost = -0;
int occupied_cost = -0;

//variables about estimate
float estimate_per_time = 0.001;
int estimate_per_square = 10;
int estimate_times = 20000;
#define CUP_ESTIMATE 20
#define MOVE_ESTIMATE 5
#define BALL_ESTIMATE 15
#define OCCUPY_ESTIMATE 10
#define ALL_ESTIMATE 50

//players
#define RED 1
#define BLUE 2
int me, enemy;

//graph
#define EMPTY_SQUARE 0
#define RED_SQUARE 1
#define BLUE_SQUARE 2
#define EMPTY 0
#define STRONG 2
#define WEAK 1

bool tower_connected[10];
bool visited[10][10];
bool visited_strong[10][10];
bool work_visited[10][10];


//car status
int pos_x[3], pos_y[3];

//actions list
#define MAX_ACTIONS 3
#define MOVE 0
#define OCCUPY 1
#define PUSH_BALL 2
#define PUSH_CUP 3
#define MOVE_UP 4
#define MOVE_LEFT 5
#define MOVE_DOWN 6
#define MOVE_RIGHT 7

int dx[8] = {0, 0, 0, 0, -1, 0, 1, 0};
int dy[8] = {0, 0, 0, 0, 0, -1, 0, 1};

//occupy status list
#define CANT_OCCUPY 0
#define WEAK_OCCUPY 1
#define STRONG_OCCUPY 2

#define nullptr 0

//search status struct
struct status
{
    ///note:all these values get from its parent status and change some of them
    char x;
    char y;
    int rest_time;
    char rest_square;
    char rest_cup;
    char rest_ball;
    int score; ///the total score of this status
    int weight; ///the sum of score and estimate
    char action; ///the action moved from parent status
    char graph_occupy[8][10];
    char graph_status[8][10];
    char tower_power[8][3];
    char tower_occupy[8];
    int father;
}stat[1000000]; ///note:stat[0] is a sepcial stat, if necessary, we should consider it as illegal
int tot;

struct node
{
    int index;
    int weight;

    bool operator < (const node &b) const
    {
        return weight < b.weight;
    }
};

priority_queue <node> q;

///check if the car can move to this square
bool check(int x, int y)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return false;
    return !((x == 1 && y == 3) || (x == 1 && y == 7) || (x == 4 && y == 1) ||
             (x == 4 && y == 5) || (x == 4 && y == 9) || (x == 7 && y == 3) || (x == 7 && y == 7)
             || (x == pos_x[enemy] && y == pos_y[enemy]));
}

///get the tower near the square (x, y)
int get_tower(int x, int y)
{
    if((x == 1 && y == 2) || (x == 2 && y == 3) || (x == 1 && y == 4)) return 1;
    if((x == 1 && y == 6) || (x == 2 && y == 7) || (x == 1 && y == 8)) return 2;
    if((x == 3 && y == 1) || (x == 4 && y == 2) || (x == 5 && y == 1)) return 3;
    if((x == 3 && y == 5) || (x == 5 && y == 5) || (x == 4 && y == 4) || (x == 4 && y == 6)) return 4;
    if((x == 3 && y == 9) || (x == 4 && y == 8) || (x == 5 && y == 9)) return 5;
    if((x == 7 && y == 2) || (x == 6 && y == 3) || (x == 7 && y == 4)) return 6;
    if((x == 7 && y == 6) || (x == 6 && y == 7) || (x == 7 && y == 8)) return 7;
    return 0;
}

///return who occupy this tower
int get_tower_occupy(int index, int tower)
{
    if(stat[index].tower_power[tower][RED] > stat[index].tower_power[tower][BLUE]) return RED;
    if(stat[index].tower_power[tower][RED] < stat[index].tower_power[tower][BLUE]) return BLUE;
    return 0;
}

///get the connected towers around the block
void occupy_dfs(int index, int x, int y, int player)
{
    if(x <= 0 || x >= 8 || y <= 0 || y >= 10) return;
    if(stat[index].graph_occupy[x][y] != player) return;
    if(visited[x][y]) return;
    visited[x][y] = true;
    if(get_tower(x, y) && stat[index].tower_occupy[get_tower(x, y)] == player) tower_connected[get_tower(x, y)] = true;
    occupy_dfs(index, x + 1, y, player);
    occupy_dfs(index, x - 1, y, player);
    occupy_dfs(index, x, y + 1, player);
    occupy_dfs(index, x, y - 1, player);
}

///get the occupy status of this car
int get_occupy_status(int index, int player)
{
    int tower_count = 0;
    int x = stat[index].x;
    int y = stat[index].y;
    memset(tower_connected, 0, sizeof(tower_connected));
    memset(visited, 0, sizeof(visited));
    ///note:assume the square is the player's
    int t = stat[index].graph_occupy[x][y];
    stat[index].graph_occupy[x][y] = player;
    occupy_dfs(index, x, y, player);
    stat[index].graph_occupy[x][y] = t;
    for (int k = 0; k < 10; ++k)
        if(tower_connected[k]) tower_count++;
    if(tower_count >= 3) return STRONG_OCCUPY;
    if(tower_count > 0) return WEAK_OCCUPY;
    return CANT_OCCUPY;
}

///check if the action is legal
bool check_action(int index, int action)
{
    if(action >= MOVE_UP && action <= MOVE_RIGHT)
        if(check(stat[index].x + dx[action], stat[index].y + dy[action]) && stat[index].rest_time >= min_time + move_time) return true;
    ///note:the last condition is made to avoid multiply placing cup or ball
    if(action == PUSH_CUP)
        if(get_tower(stat[index].x + dx[action], stat[index].y + dy[action]) &&
           stat[index].rest_ball >= 1 && stat[index].rest_cup >= 1 &&
            stat[index].tower_occupy[get_tower(stat[index].x + dx[action], stat[index].y + dy[action])] != me
                && stat[index].rest_time >= min_time + cup_time) return true;
    if(action == PUSH_BALL) if(get_tower(stat[index].x, stat[index].y) && stat[index].rest_ball >= 1 &&
        stat[index].tower_occupy[get_tower(stat[index].x + dx[action],stat[index].y + dy[action])] != me
            && stat[index].rest_time >= min_time + ball_time) return true;
    ///note:the last condition is made to avoid multiply occupying
    if(action == OCCUPY) if(get_occupy_status(index, me) &&
        stat[index].graph_occupy[stat[index].x][stat[index].y] != me &&
            stat[index].graph_status[stat[index].x][stat[index].y] != STRONG_OCCUPY &&
                stat[index].rest_time >= min_time + occupy_time) return true;
    return false;
}

///choose a random action
int random_action(int index)
{
    vector <int> actions;
    for (int i = 1; i < 8; ++i) if(check_action(index, i)) actions.push_back(i);
    return actions[rand() % actions.size()];
}

///change the action number to string
std::string number2action(int number)
{
    switch (number)
    {
        case OCCUPY:
            return "occupy";
        case PUSH_BALL:
            return "ball";
        case PUSH_CUP:
            return "cap";
        case MOVE_LEFT:
            return "left";
        case MOVE_RIGHT:
            return "right";
        case MOVE_UP:
            return "up";
        case MOVE_DOWN:
            return "down";
        default:
            return "0";
    }
}

///print the result
void print_status(status stat)
{
    printf("----x:%d;y:%d;rest_time:%d;rest_square:%d;rest_cup:%d;rest_ball:%d;score:%d;weight:%d;\n",
           stat.x, stat.y, stat.rest_time, stat.rest_square, stat.rest_cup, stat.rest_ball, stat.score,
           stat.weight);
}

void print(int index)
{
    if(index == 1) return;
    print(stat[index].father);
    cout << number2action(stat[index].action);// << endl;
    print_status(stat[index]);
}

///sum the total score for each player
void sum(int index, int *blue, int *red)
{
    *blue = 0;
    *red = 0;
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; ++j)
        {
            if(stat[index].graph_occupy[i][j] == BLUE)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *blue += occupy_weight_weak;
                else *blue += occupy_weight_strong;
            }
            else if(stat[index].graph_occupy[i][j] == RED)
            {
                if(stat[index].graph_status[i][j] == WEAK_OCCUPY) *red += occupy_weight_weak;
                else *red += occupy_weight_strong;
            }
        }
    for (int i = 0; i < 10; ++i)
    {
        if(stat[index].tower_occupy[i] == RED) *red += occupy_tower_weight;
        if(stat[index].tower_occupy[i] == BLUE) *blue += occupy_tower_weight;
        *red += stat[index].tower_power[i][RED] * tower_power_weight;
        *blue += stat[index].tower_power[i][BLUE] * tower_power_weight;
    }
    //std::cout<<*red<<" "<<*blue<<std::endl;
}

int get_score(int init, int index, int player)
{
    int red, blue, score, score_blue, score_red;
    sum(init, &score_blue, &score_red);
    sum(index, &blue, &red);
    //cout<<red<<" "<<blue<<endl;
    if(player == RED) score = red - score_red + score_blue - blue;
    else score = blue - score_blue + score_red - red;
    //cout<<score<<endl;
    return score;
}

///the dfs part of simulation
///note:this function uses stat[0] as a temp
int simulate_dfs(status simulate_stat, int index)
{
    if(simulate_stat.rest_time <= min_time || simulate_stat.rest_square <= min_square) return get_score(index, 0, me);
    int action;
    stat[0] = simulate_stat;
    action = random_action(0);
    stat[0].action = action;
    stat[0].father = 0;
    //cout<<action<<endl;
    switch (action)
    {
        case OCCUPY:
        {
            stat[0].graph_occupy[stat[0].x][stat[0].y] = me;
            stat[0].graph_status[stat[0].x][stat[0].y] = get_occupy_status(0, me);
            stat[0].rest_time -= occupy_time;
            break;
        }
        case PUSH_BALL:
        {
            stat[0].rest_ball--;
            stat[0].rest_time -= ball_time;
            stat[0].tower_power[get_tower(stat[0].x, stat[0].y)][me]++;
            stat[0].tower_occupy[get_tower(stat[0].x, stat[0].y)] = get_tower_occupy(0, get_tower(stat[0].x, stat[0].y));
            break;
        }
        case PUSH_CUP:
        {
            stat[0].rest_ball--;
            stat[0].rest_cup--;
            stat[0].rest_time -= cup_time;
            stat[0].tower_power[get_tower(stat[0].x, stat[0].y)][me] += 4;
            stat[0].tower_occupy[get_tower(stat[0].x, stat[0].y)] = get_tower_occupy(0, get_tower(stat[0].x, stat[0].y));
            //cout<<stat[0].tower_occupy[get_tower(stat[0].x, stat[0].y)]<<endl;
            break;
        }
            ///move
        default:
        {
            stat[0].rest_square--;
            stat[0].rest_time -= move_time;
            stat[0].x += dx[action];
            stat[0].y += dy[action];
            if(stat[0].graph_occupy[stat[0].x][stat[0].y] == enemy) stat[0].score += pass_weight;
        }
    }
    return simulate_dfs(stat[0], index);
}

///simulate the status to get a assume weight
int simulate(int index)
{
    int total_score = 0, last_score;
    ///step1:choose a random way until this status can not do anything
    for (int i = 0; i < 100; ++i)
    {
        last_score = total_score;
        for (int j = 0; j < stat[index].rest_time / 100; ++j)
            total_score = max(simulate_dfs(stat[index], index), total_score);
        if (total_score == last_score) break;
    }
    ///step2:count and return the score of this status
    return total_score;
}

///priority and Monte Carlo Method BFS
void work()
{
    while(!q.empty())
    {
        ///step1:choose the status which has the max weight
        node n = q.top();
        q.pop();
        ///if this status can not do anything, return and print
        if(stat[n.index].rest_time <= min_time || stat[n.index].rest_square <= min_square)
        {
            print(n.index);
            while(!q.empty()) q.pop();
            return;
        }
        ///step2:expand every possible choice of this status
        ///step3:simulate many times to get its average reward
        for(int i = 1; i < 8; i++)
        {
            if(!check_action(n.index, i)) continue;
            tot++;
            stat[tot] = stat[n.index];
            stat[tot].action = i;
            stat[tot].father = n.index;
            switch (i)
            {
                case OCCUPY:
                {
                    stat[tot].graph_occupy[stat[tot].x][stat[tot].y] = me;
                    stat[tot].graph_status[stat[tot].x][stat[tot].y] = get_occupy_status(tot, me);
                    stat[tot].rest_time -= occupy_time;
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                case PUSH_BALL:
                {
                    stat[tot].rest_ball--;
                    stat[tot].rest_time -= ball_time;
                    stat[tot].tower_power[get_tower(stat[tot].x, stat[tot].y)][me]++;
                    stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)] = get_tower_occupy(tot, get_tower(stat[tot].x, stat[tot].y));
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                case PUSH_CUP:
                {
                    stat[tot].rest_ball--;
                    stat[tot].rest_cup--;
                    stat[tot].rest_time -= cup_time;
                    stat[tot].tower_power[get_tower(stat[tot].x, stat[tot].y)][me] += 4;
                    stat[tot].tower_occupy[get_tower(stat[tot].x, stat[tot].y)] = get_tower_occupy(tot, get_tower(stat[tot].x, stat[tot].y));
                    stat[tot].score = get_score(1, tot, me);
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                    break;
                }
                ///move
                default:
                {
                    stat[tot].rest_square--;
                    stat[tot].rest_time -= move_time;
                    stat[tot].x += dx[i];
                    stat[tot].y += dy[i];
                    if(stat[tot].graph_occupy[stat[tot].x][stat[tot].y] == enemy) stat[tot].score += pass_weight;
                    stat[tot].weight = simulate(tot) + stat[tot].score;
                }
            }
            ///step4:add this status to the queue
            q.push(node{tot, stat[tot].weight});
        }
    }
}

int main()
{
    ///load origin status from the text
    FILE *fp = fopen("/home/robomaster/RM/test.txt", "r");
    srand((unsigned int) time(0));
    fscanf(fp, "# tower_power,RED=1,BLUE=2\n");
    for (int i = 1; i <= 7; i++) fscanf(fp, "%d", &stat[1].tower_power[i][RED]);
    for (int i = 1; i <= 7; i++) fscanf(fp, "%d", &stat[1].tower_power[i][BLUE]);
    for (int i = 1; i <= 7; ++i) stat[1].tower_occupy[i] = get_tower_occupy(1, i);
    fscanf(fp, "\n# car_pos\n");
    fscanf(fp, "%d %d %d %d", &pos_x[RED], &pos_y[RED], &pos_x[BLUE], &pos_y[BLUE]);
    fscanf(fp, "\n# graph occupy\n");
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &stat[1].graph_occupy[i][j]);
    fscanf(fp, "\n# graph status\n");
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= 9; j++)
            fscanf(fp, "%d", &stat[1].graph_status[i][j]);
    fscanf(fp, "\n# me\n");
    fscanf(fp, "%d", &me);
    ///who i am
    if (me == BLUE) enemy = RED;
    else enemy = BLUE;
    ///set origin status
    stat[1].x = pos_x[me];
    stat[1].y = pos_y[me];
    stat[1].rest_time = tot_time;
    stat[1].score = 0;
    stat[1].rest_square = max_square;
    stat[1].rest_ball = max_ball;
    stat[1].rest_cup = max_cup;
    ///WARNING:C++11
    q.push(node{1, 0});
    tot = 1;
    work();
    return 0;
}