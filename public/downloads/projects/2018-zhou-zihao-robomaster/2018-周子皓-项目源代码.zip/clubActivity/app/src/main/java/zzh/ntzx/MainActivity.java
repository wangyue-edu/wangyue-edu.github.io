package zzh.ntzx;

import android.os.Looper;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void submit(View view) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Log.d("submit", "run");
                String SUBMIT_URL = "http://118.24.220.49:8080/submit/";
                String msg = "";
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(SUBMIT_URL).openConnection();
                    conn.setRequestMethod("POST");
                    conn.setReadTimeout(5000);
                    conn.setConnectTimeout(5000);
                    conn.setDoInput(true);
                    conn.setDoInput(true);
                    conn.setUseCaches(false);
                    String data = "name=" + URLEncoder.encode(((EditText)findViewById(R.id.name)).getText().toString(), "UTF-8") +
                            "&master=" + URLEncoder.encode(((EditText)findViewById(R.id.master)).getText().toString(), "UTF-8") +
                            "&time=" + URLEncoder.encode(((EditText)findViewById(R.id.time)).getText().toString(), "UTF-8") +
                            "&place=" + URLEncoder.encode(((EditText)findViewById(R.id.place)).getText().toString(), "UTF-8") +
                            "&activity=" + URLEncoder.encode(((EditText)findViewById(R.id.activity)).getText().toString(), "UTF-8") +
                            "&purpose=" + URLEncoder.encode(((EditText)findViewById(R.id.purpose)).getText().toString(), "UTF-8") +
                            "&method=" + URLEncoder.encode(((EditText)findViewById(R.id.method)).getText().toString(), "UTF-8") +
                            "&safety=" + URLEncoder.encode(((EditText)findViewById(R.id.safety)).getText().toString(), "UTF-8");
                    OutputStream out = conn.getOutputStream();
                    out.write(data.getBytes());
                    out.flush();
                    if (conn.getResponseCode() == 200) {
                        InputStream is = conn.getInputStream();
                        ByteArrayOutputStream message = new ByteArrayOutputStream();
                        int len = 0;
                        byte buffer[] = new byte[1024];
                        while ((len = is.read(buffer)) != -1) {
                            message.write(buffer, 0, len);
                        }
                        is.close();
                        message.close();
                        msg = new String(message.toByteArray());
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Log.d("onClick->submit", msg);
                Looper.prepare();
                if (msg.equals("success")) {
                    Toast.makeText(MainActivity.this, "提交成功", Toast.LENGTH_LONG).show();
                } else if (msg.equals("exists")) {
                    Toast.makeText(MainActivity.this, "提交失败\n该社团本周已提交", Toast.LENGTH_LONG).show();
                } else if (msg.equals("fail")) {
                    Toast.makeText(MainActivity.this, "提交失败\n该社团不存在", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                }
                Looper.loop();
            }
        }).start();
    }
}
