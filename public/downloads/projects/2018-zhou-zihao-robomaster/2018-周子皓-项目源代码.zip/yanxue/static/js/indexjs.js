function leftTimer(year,month,day,hour,minute,second){
    var now = new Date();
    var start = new Date(year,month-1,day,hour,minute,second);
    if(now.getTime()>=start.getTime())
    {
        $("#submitbutton").removeAttr("disabled");
        $("#time").hide();
    }
    else
    {
        var leftTime = start - now; //计算剩余的毫秒数
        var days = parseInt(leftTime / 1000 / 60 / 60 / 24 , 10);//计算剩余的天数
        var hours = parseInt(leftTime / 1000 / 60 / 60 % 24 , 10); //计算剩余的小时
        var minutes = parseInt(leftTime / 1000 / 60 % 60, 10);//计算剩余的分钟
        var seconds = parseInt(leftTime / 1000 % 60, 10);//计算剩余的秒数
        /*days = checkTime(days);
        hours = checkTime(hours);
        minutes = checkTime(minutes);
        seconds = checkTime(seconds);*/
        document.getElementById("timer").innerHTML = days+"天" + hours+"小时" + minutes+"分"+seconds+"秒";
    }
}
function checkTime(i){ //将0-9的数字前面加上0，例1变为01 
    if(i<10) 
    { 
        i = "0" + i; 
    } 
    return i; 
}
var lines = {
    'A' : '科技之旅（上海方向）',
    'B' : '红色之旅',
    'C' : '名校之旅（南京）',
    'D' : '名校之旅（上海）',
    'E' : '现代农业之旅（南京）',
    'F' : '现代农业之旅（上海）',
    'G' : '改革开放之旅（上海方向1）',
    'H' : '改革开放之旅（上海方向2）',
    'I' : '文化之旅（南京扬州方向）',
    'J' : '文化之旅（上海方向）'
};
function submit()
{
    $('#submitbutton').attr("disabled","disabled");
    var reg=/^[\u4E00-\u9FA5]{2,4}$/;
    if(!reg.test($("#name").val()))
    {
        $("#namediv").addClass("mdui-textfield-invalid");
        $("#nameerror").text("不正确的姓名");
        $("#submitbutton").removeAttr("disabled");
        return;
    }
    $("#namediv").removeClass("mdui-textfield-invalid");
    var reg2 = /^(\d{2})(\d{3})([0-9]|X)$/;
    if(!reg2.test($("#password").val()))
    {
        $("#passworddiv").addClass("mdui-textfield-invalid");
        $("#passworderror").text("不正确的身份证后6位格式（X大写）");
        $("#submitbutton").removeAttr("disabled");
        return;
    }
    $("#passworddiv").removeClass("mdui-textfield-invalid");
    var reg3 = /^[A-Z]$/;
    if(!reg3.test($('input:radio:checked').val()))
    {
        mdui.alert('未选择线路','报名失败！');
        $("#submitbutton").removeAttr("disabled");
        return;
    }
    data = {
        'name': $("#name").val(),
        'password': $("#password").val(),
        'aim': $('input:radio:checked').val()
    }
    $.post('submit/', data=data, function (data) {
        if(data == 'success')
        {
            mdui.alert('报名成功');
        }
        else if(data == 'timeout')
        {
            mdui.alert('提交过于频繁，请1分钟后重试','提交失败！');
        }
        else if(data == 'full')
        {
            mdui.alert('该线路人数已满','报名失败！');
        }
        else if(data == 'notfound')
        {
            mdui.alert('姓名或身份证错误','报名失败！');
        }
        else if(data == 'unstarted')
        {
            mdui.alert('报名尚未开始','报名失败！');
        }
        else if(data == 'error')
        {
            mdui.alert('服务器错误，请记录相关信息并联系管理员','报名失败！');
        }
        else
        {
            mdui.alert('该学生已经报名线路：' + lines[data],'重复报名！');
        }
        $("#submitbutton").removeAttr("disabled");
    });
}
function login()
{
    $("#loginbutton").attr("disabled", "disabled");
    var reg=/^[\u4E00-\u9FA5]{2,4}$/;
    if(!reg.test($("#name").val()))
    {
        $("#namediv").addClass("mdui-textfield-invalid");
        $("#nameerror").text("不正确的姓名");
        $('#loginbutton').removeAttr("disabled");
        mdui.updateTextFields();
        return;
    }
    $("#namediv").removeClass("mdui-textfield-invalid");
    var reg2 = /^(\d{2})(\d{3})([0-9]|X)$/;
    if(!reg2.test($("#password").val()))
    {
        $("#passworddiv").addClass("mdui-textfield-invalid");
        $("#passworderror").text("不正确的身份证后6位格式（X大写）");
        $('#loginbutton').removeAttr("disabled");
        mdui.updateTextFields();
        return;
    }
    $("#passworddiv").removeClass("mdui-textfield-invalid");
    mdui.updateTextFields();
    data = {
        'name' : $("#name").val(),
        'password' : $("#password").val()
    }
    $.post('login/', data=data, function (data) {
        data = JSON.parse(data);
        if(data['status'] == 'success')
        {
            $('#loginbutton').hide();
            $('#aim').show();
            $('#A1').text(data['A']);
            $('#A2').text(data['maxA']);
            if(data['A'] >= data['maxA'])
            {
                $("#A").attr('disabled',true);
            }
            $('#B1').text(data['B']);
            $('#B2').text(data['maxB']);
            if(data['B'] >= data['maxB'])
            {
                $("#B").attr('disabled',true);
            }
            $('#C1').text(data['C']);
            $('#C2').text(data['maxC']);
            if(data['C'] >= data['maxC'])
            {
                $("#C").attr('disabled',true);
            }
            $('#D1').text(data['D']);
            $('#D2').text(data['maxD']);
            if(data['D'] >= data['maxD'])
            {
                $("#D").attr('disabled',true);
            }
            $('#E1').text(data['E']);
            $('#E2').text(data['maxE']);
            if(data['E'] >= data['maxE'])
            {
                $("#E").attr('disabled',true);
            }
            $('#F1').text(data['F']);
            $('#F2').text(data['maxF']);
            if(data['F'] >= data['maxF'])
            {
                $("#F").attr('disabled',true);
            }
            $('#G1').text(data['G']);
            $('#G2').text(data['maxG']);
            if(data['G'] >= data['maxG'])
            {
                $("#G").attr('disabled',true);
            }
            $('#H1').text(data['H']);
            $('#H2').text(data['maxH']);
            if(data['H'] >= data['maxH'])
            {
                $("#H").attr('disabled',true);
            }
            $('#I1').text(data['I']);
            $('#I2').text(data['maxI']);
            if(data['I'] >= data['maxI'])
            {
                $("#I").attr('disabled',true);
            }
            $('#J1').text(data['J']);
            $('#J2').text(data['maxJ']);
            if(data['J'] >= data['maxJ'])
            {
                $("#J").attr('disabled',true);
            }
            $('#tot').text(data['tot']);
        }
        else if(data['status'] == 'timeout')
        {
            mdui.alert("提交过于频繁，请1分钟后重试","登录失败！");
        }
        else
        {
            mdui.alert("用户名或密码错误","登录失败！");
        }
        $("#loginbutton").removeAttr("disabled");
    });
}