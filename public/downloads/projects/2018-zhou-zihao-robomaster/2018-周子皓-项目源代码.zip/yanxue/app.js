'use strict'

var http = require('http');
var url = require('url');
var fs = require('fs');
var path = require('path');
var querystring = require('querystring');
var mysql = require('mysql');
var log4js = require('log4js');
log4js.configure(require("./log4js.json"));

var log = log4js.getLogger('log');

log.info('log4js started!');

var config = JSON.parse(fs.readFileSync('config.json','utf-8'));

var connection = mysql.createConnection({
    host: 'localhost',
    user: config.SQLuser,
    password: config.SQLpassword,
    database: config.SQLdatabase
});

connection.connect();

var root = path.resolve(process.argv[2] || '.');
log.info(root);

//各条线路人数
function sqlMember(callback)
{
    var memberstr = "SELECT * FROM member";
    connection.query(memberstr,(err,results)=>{
        if(err)
        {
            log.error("MySQL ERROR - sqlMember() - " + err);
            callback('error');
            return;
        }
        else
        {
            var returndata = {
                'A': 0,
                'maxA': config.maxA,
                'B': 0,
                'maxB': config.maxB,
                'C': 0,
                'maxC': config.maxC,
                'D': 0,
                'maxD': config.maxD,
                'E': 0,
                'maxE': config.maxE,
                'F': 0,
                'maxF': config.maxF,
                'G': 0,
                'maxG': config.maxG,
                'H': 0,
                'maxH': config.maxH,
                'I': 0,
                'maxI': config.maxI,
                'J': 0,
                'maxJ': config.maxJ,
                'null' : 0,
                'tot': 0
            };
            for(var i = 0;i < results.length;i++)
            {
                returndata[results[i]['aim']] = returndata[results[i]['aim']] + 1;
                if(results[i]['aim'] != null) returndata['tot'] = returndata['tot'] + 1;
            }
            callback(returndata);
            return;
        }
    });
}

//更新报名信息
function sqlAdd(name,password,aim,ip,callback)
{
    if(new Date().getTime()<config.startTime)
    {
        callback('unstarted');
        return;
    }
    else
    {
        sqlMember(function(dat){
            //判定人数是否满
            var maxaim = 'max' + aim;
            if(dat[aim]>=dat[maxaim])
            {
                callback('full');
                return;
            }
            //查找、添加报名信息
            var searchstr = "SELECT * FROM member WHERE name = '" + name + "' AND password = '" + password + "'";
            connection.query(searchstr,function(err,results){
                if(err)
                {
                    log.error("MySQL ERROR - sqlAdd():search - " + err);
                    callback('error');
                    return;
                }
                if(results.length == 0)
                {
                    callback('notfound');
                    return;
                }
                if(results[0]['aim'] != null)
                {
                    callback(results[0]['aim']);
                    return;
                }
                var updatestr = "UPDATE member SET aim = '" + aim + "',ip = '" + ip + "',submittime = '" + new Date().getTime() + "' WHERE name = '" + name + "' AND password = '" + password + "'";
                connection.query(updatestr,function(err){
                    if(err)
                    {
                        log.error("MySQL ERROR - sqlAdd():update - " + err);
                        return;
                    }
                });
                callback('success');
                return;
            });
        });
    }
}

function checkTime(name,callback)
{
	var searchstr = "SELECT * FROM member WHERE name = '" + name + "'";
	connection.query(searchstr,function(err,results){
		if(err)
		{
            log.error("MySQL ERROR - checkTime():search - " + err);
			callback('error');
			return;
        }
        else if(results.length == 0)
        {
            callback('notfound');
            return;
        }
		else
		{
			var time = new Date().getTime();
			if(time > results[0]['lasttime'] + 60000)
			{
				var updatestr = "UPDATE member SET lasttime = '" + time + "',times = 1 WHERE name = '" + name + "'";
				connection.query(updatestr,function(err){
                    if(err)
                    {
                        log.error("MySQL ERROR - checkTime():update1 - " + err);
                        return;
                    }
                });
			}
			else
			{
				if(results[0]['times'] >= 10)
				{
                    callback('timeout');
                    return;
				}
				else
				{
					var updatestr = "UPDATE member SET lasttime = '" + time + "',times = times + 1 WHERE name = '" + name + "'";
					connection.query(updatestr,function(err){
						if(err)
						{
							log.error("MySQL ERROR - checkTime():update2 - " + err);
							return;
						}
					});
				}
			}
		}
        callback('timein');
        return;
	});
}

var server = http.createServer(function(request,response){
    var pathname = url.parse(request.url).pathname;
    var ip = request.headers['x-forwarded-for'] || request.ip || request.connection.remoteAddress || request.socket.remoteAddress || request.connection.socket.remoteAddress || '';
    //POST——login
    if(request.method == 'POST' && pathname == '/login/')
    {
        var data = '';
        request.on('data', function (chunk) {
            data += chunk;
        });
        request.on('end', function () {
            data = decodeURI(data);
            var dataObject = querystring.parse(data);
            //正则表单验证
            var reg=/^[\u4E00-\u9FA5]{2,4}$/;
            if(!reg.test(dataObject['name']))
            {
                log.warn('unexcepted request - ' + ip + ' - POST /login/ - ' + JSON.stringify(dataObject));
                response.writeHead(200);
                response.end('hello');
                return;
            }
            var reg2 = /^(\d{2})(\d{3})([0-9]|X)$/;
            if(!reg2.test(dataObject['password']))
            {
                log.warn('unexcepted request - ' + ip + ' - POST /login/ - ' + JSON.stringify(dataObject));
                response.writeHead(200);
                response.end('hello');
                return;
            }
            checkTime(dataObject['name'],function(result){
				if(result == 'timein')
				{
					var searchstr = "SELECT * FROM member WHERE name = '" + dataObject['name'] + "' AND password = '" + dataObject['password'] + "'";
                    connection.query(searchstr,(err,results)=>{
                        if(err)
                        {
                            log.error('MySQL ERROR - ' + ip + ' - POST /login/ - ' + JSON.stringify(dataObject) + '\n' + err);
                            return;
                        }
                        log.info(ip + ' - POST /login/ - ' + JSON.stringify(dataObject));
                        if(results.length == 0)
                        {
                            response.writeHead(200);
                            var returndata = {
                                "status" : "fail"
                            }
                            response.end(JSON.stringify(returndata));
                        }
                        else
                        {
                            sqlMember((returndata)=>{
                                returndata['status'] = 'success';
                                response.writeHead(200);
                                response.end(JSON.stringify(returndata));
                            });
                        }
                    });
				}
				else
				{
					response.writeHead(200);
                    response.end(JSON.stringify({'status':'timeout'}));
                    log.info('Timeout - ' + ip + ' - POST /login/ - ' + JSON.stringify(dataObject));
				}
			});
        });
    }
    //POST——submit
    else if(request.method == 'POST' && pathname == '/submit/')
    {
        var data = '';
        request.on('data', function (chunk) {
            data += chunk;
        });
        request.on('end', function () {
            data = decodeURI(data);
            var dataObject = querystring.parse(data);
            //正则表单验证
            var reg=/^[\u4E00-\u9FA5]{2,4}$/;
            if(!reg.test(dataObject['name']))
            {
                log.warn('unexcepted request - ' + ip + ' - POST /submit/ - ' + JSON.stringify(dataObject));
                response.writeHead(200);
                response.end('hello');
                return;
            }
            var reg2 = /^(\d{2})(\d{3})([0-9]|X)$/;
            if(!reg2.test(dataObject['password']))
            {
                log.warn('unexcepted request - ' + ip + ' - POST /submit/ - ' + JSON.stringify(dataObject));
                response.writeHead(200);
                response.end('hello');
                return;
            }
            var reg3 = /^[A-Z]$/;
            if(!reg3.test(dataObject['aim']))
            {
                log.warn('unexcepted request - ' + ip + ' - POST /submit/ - ' + JSON.stringify(dataObject));
                response.writeHead(200);
                response.end('hello');
                return;
            }
            checkTime(dataObject['name'],function(result){
				if(result == 'timein')
				{
					sqlAdd(dataObject['name'],dataObject['password'],dataObject['aim'],ip,function(result){
                        response.writeHead(200);
                        response.end(result);
                        log.info(ip + ' - POST /submit/ - ' + JSON.stringify(dataObject));
                    });
				}
				else
				{
					response.writeHead(200);
                    response.end(result);
                    log.info('Timeout - ' + ip + ' - POST /submit/ - ' + JSON.stringify(dataObject));
				}
			});
        });
    }
    else if(request.method == 'GET' && pathname == '/')
    {
        pathname = '/index.html';
        var filepath = path.join(root, pathname);
        fs.stat(filepath, function (err, stats) {
            if(!err && stats.isFile())
            {
                response.writeHead(200);
                fs.createReadStream(filepath).pipe(response);
            }
        });
    }
    else if(request.method == 'GET' && pathname == '/favicon.ico')
    {
        response.writeHead(404);
        response.end();
    }
    else
    {
        log.warn('unexpected request - ' + ip + ' - ' + request.method + ' ' + pathname);
        response.writeHead(403);
        response.end('403 Forbidden');
    }
});

server.listen(14250);

log.info('running 14250');