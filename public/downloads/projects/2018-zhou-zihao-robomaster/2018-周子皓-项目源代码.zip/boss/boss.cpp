﻿#include "pch.h"
#include <tchar.h>
#include <windows.h>
#include <iostream>
#include <time.h>
#include <sys/timeb.h>
#include <math.h>
#include <thread>
#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)
using namespace std;

int myId, bossId;
HWND hWnd;
DWORD pid;
HANDLE hProcess;
DWORD base_addr = 0x006A9EC0;
DWORD offset = 0x768;
DWORD addr;
PVOID pRemoteThread;
DWORD zombiesStart;
DWORD plantsStart;

typedef struct MY_PARAMETER {
	DWORD line, y, x, dx, dy, type, hit; //速度均*10000
}parameter, *parameterp;
parameterp remoteParap;
parameter remotePara;
union float2dword {
	float f;
	DWORD d;
}f2d;

DWORD __stdcall createBullet(LPVOID lParam)
{
	DWORD callAddr = 0x40D620;
	DWORD f600 = 0x44160000; //600的浮点数表示
	DWORD wan = 0x461C4000; //10000的浮点数表示
	parameter *lp;
	lp = (parameter*)lParam;
	DWORD line = lp->line;
	DWORD y = lp->y;
	DWORD x = lp->x;
	DWORD Dxx = lp->dx;
	DWORD Dy = lp->dy;
	DWORD TType = lp->type;
	DWORD hit = lp->hit;
	__asm
	{
		pushad
		push TType
		push line
		push 1000
		push y
		push x
		mov eax, 0x6A9EC0
		mov eax, [eax]
		mov eax, [eax + 0x768]
		call callAddr
		mov[eax + 0x58], 7
		mov edx, hit
		mov[eax + 0x74], edx
		fld Dxx
		fstp[eax + 0x3C]
		fld Dy
		fstp[eax + 0x40]
		popad
	}
	return 0;
}
int randStar()
{
	int type = rand() % 4;
	if (type == 0) return 4;
	else if (type == 1) return 2;
	else if (type == 2) return 8;
	else if (type == 3) return 10;
}
int randBigStar()
{
	int type = rand() % 3;
	if (type == 0) return 3;
	else if (type == 1) return 5;
	else if (type == 2) return 9;
}
long long getTimeStamp()
{
	timeb t;
	ftime(&t);
	return t.time * 1000 + t.millitm;
}
void getId()
{
	DWORD plantsNumber;
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xB0), &plantsNumber, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xAC), &plantsStart, 4, 0);
	for (int i = 0; i < plantsNumber; i++)
	{
		DWORD plantClass, plantStatus;
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x24 + 0x14C * i), &plantClass, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x148 + 0x14C * i), &plantStatus, 4, 0);
		if (plantClass == 1 && (plantStatus & 0xFFFF0000) != 0)
		{
			bossId = i;
			break;
		}
	}
	DWORD zombiesNumber;
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0x94), &zombiesNumber, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0x90), &zombiesStart, 4, 0);
	for (int i = 0; i < zombiesNumber; i++)
	{
		DWORD zombieClass;
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0x24 + 0x15C * i), &zombieClass, 4, 0);
		if (zombieClass == 24)
		{
			myId = i;
			break;
		}
	}
	return;
}
void shot(DWORD line, int x, int y, float dx, float dy, DWORD type, DWORD hit)
{
	remotePara.x = x;
	remotePara.y = y;
	remotePara.line = 7;
	remotePara.type = type;
	f2d.f = dx;
	remotePara.dx = f2d.d;
	f2d.f = dy;
	remotePara.dy = f2d.d;
	remotePara.hit = hit;
	WriteProcessMemory(hProcess, remoteParap, &remotePara, sizeof(parameter), 0);
	//创建远程线程
	DWORD dwThreadId = 0;
	HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)pRemoteThread, remoteParap, 0, &dwThreadId);
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	return;
}
void laser(int x, int y, float r, float d, int t)
{
	while (t -= 20)
	{
		shot(5, x, y, 10 * cos(r), 10 * sin(r), 1, 0);
		r += d;
		Sleep(20);
	}
	return;
}
void bossMove(int dx, int dy, DWORD time)
{
	int bossX, bossY;
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
	while (time-=10)
	{
		bossX += dx; bossY += dy;
		WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
		WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
		Sleep(10);
	}
}
double randAngle(int a, int b)
{
	int degree = (rand() % (b - a + 1)) + a;
	cout << degree << endl;
	return degree * 0.01744444;
}
void clear()
{
	DWORD bulletNumber, bulletStart;
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xCC), &bulletNumber, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xC8), &bulletStart, 4, 0);
	for (int i = 0; i < bulletNumber; i++)
	{
		DWORD bulletType, bulletX, bulletY;
		ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x5C + 0x94 * i), &bulletType, 4, 0);
		if (bulletType == 13)continue;
		f2d.f = 1000.0;
		WriteProcessMemory(hProcess, (LPVOID)(bulletStart + 0x30 + 0x94 * i), &f2d.d, 4, 0);
	}
}
void milkyWay()
{
	DWORD tab;
	int bossX, bossY;
	float r = 0;
	while (1)
	{
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0x5610), &tab, 4, 0);
		if (tab == 0)
		{
			return;
		}
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
		for (int i = 0; i < 4; i++)
		{
			shot(5, bossX, bossY, 3.33*cos(r + 1.57 * i), 3.33*sin(r + 1.57 * i), randBigStar(), 0);
		}
		double angle = randAngle(45, 135);
		shot(5, rand() % 801, -100, 1*cos(angle), 1*sin(angle), randStar(), 0);
		angle = randAngle(225, 315);
		shot(5, rand() % 801, 700, 1*cos(angle), 1*sin(angle), randStar(), 0);
		r += 0.17444;
		Sleep(500);
	}
}
void starDust_move()
{
	DWORD tab;
	DWORD bulletNumber, bulletStart;
	int bossX, bossY;
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
	while (1)
	{
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0x5610), &tab, 4, 0);
		if (tab == 0)return;
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0xCC), &bulletNumber, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0xC8), &bulletStart, 4, 0);
		for (int i = 0; i < bulletNumber; i++)
		{
			DWORD bulletType, bulletTime;
			int bulletX, bulletY;
			float dx, dy;
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x5C + 0x94 * i), &bulletType, 4, 0);
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x60 + 0x94 * i), &bulletTime, 4, 0);
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x3C + 0x94 * i), &dx, 4, 0);
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x40 + 0x94 * i), &dy, 4, 0);
			if (bulletType != 13 && bulletTime >= 500 && dx == 0.0 && dy == 0.0)
			{
				ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x8 + 0x94 * i), &bulletX, 4, 0);
				ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0xC + 0x94 * i), &bulletY, 4, 0);
				float r = atan(((float)bossY - (float)bulletY) / ((float)bossX - (float)bulletX)) + 0.314;
				float flag;
				if (bulletX > bossX) flag = -1;
				else flag = 1;
				if (bulletType == 10 || bulletType == 4) flag *= -1;
				float dx = 1 * cos(r) * flag;
				float dy = 1 * sin(r) * flag;
				WriteProcessMemory(hProcess, (LPVOID)(bulletStart + 0x3C + 0x94 * i), &dx, 4, 0);
				WriteProcessMemory(hProcess, (LPVOID)(bulletStart + 0x40 + 0x94 * i), &dy, 4, 0);
			}
		}
	}
}
void starDust()
{
	DWORD tab;
	int bossX, bossY;
	thread t(starDust_move);
	t.detach();
	int r = 500;
	float angle = 0;
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
	while (1)
	{
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0x5610), &tab, 4, 0);
		if (tab == 0)
		{
			return;
		}
		int type, type2;
		if (r >= 0) type = 10;
		else type = 8;
		if (r >= 0) type2 = 4;
		else type2 = 2;
		shot(5, bossX + r * cos(angle), bossY + r * sin(angle), 0, 0, type, 0);
		shot(5, bossX + r * cos(angle + 1.57), bossY + r * sin(angle + 1.57), 0, 0, type2, 0);
		shot(5, bossX + r * cos(angle + 3.14), bossY + r * sin(angle + 3.14), 0, 0, type, 0);
		shot(5, bossX + r * cos(angle + 4.71), bossY + r * sin(angle + 4.71), 0, 0, type2, 0);
		angle += 0.0696;
		r -= 20;
		Sleep(200);
		if (r == -500) r = 500;
	}
}
void typhoon()
{
	DWORD tab;
	int bossX, bossY, myX, myY, bulletX, bulletY = 0;
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
	float r = 0, flag, dx, dy, rr = 0;
	int t = 0;
	while (1)
	{
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0x5610), &tab, 4, 0);
		if (tab == 0)
		{
			return;
		}
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0x8 + 0x15C * myId), &myX, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0xC + 0x15C * myId), &myY, 4, 0);
		myX += 50; myY += 40;
		rr += 0.174;
		for (int i = 0; i < 3; i++)
		{
			bulletX = bossX + 400 * cos(i*2.09 + rr);
			bulletY = bossY + 400 * sin(i*2.09 + rr);
			r = atan(((float)bossY - (float)bulletY) / ((float)bossX - (float)bulletX));
			if (bulletX > bossY) flag = -1;
			else flag = 1;
			dx = 3 * cos(r) * flag;
			dy = 3 * sin(r) * flag;
			shot(5, bulletX, bulletY, dx, dy, randBigStar(), 0);
		}
		if (t == 2)
		{
			t = 0;
			for (int i = 0; i < 6; i++)
			{
				bulletX = bossX + 100 * cos(i*1.0466);
				bulletY = bossY + 100 * sin(i*1.0466);
				r = atan(((float)myY - (float)bulletY) / ((float)myX - (float)bulletX));
				if (bulletX > myX) flag = -1;
				else flag = 1;
				dx = 3 * cos(r) * flag;
				dy = 3 * sin(r) * flag;
				shot(5, bulletX, bulletY, dx, dy, randStar(), 0);
			}
		}
		t++;
		Sleep(500);
	}
}
void masterSpark()
{
	cout << "shake()" << endl;
	DWORD tab;
	int bossX, bossY, myX, myY, bulletX, bulletY = 0;
	int move = 1;
	float r = 0, flag, dx, dy, rr = 0;
	int times = 0;
	while (1)
	{
		times++;
		//bossMove(0, move, 500);
		//if (rand() & 1) move *= -1;
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0x8 + 0x15C * myId), &myX, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0xC + 0x15C * myId), &myY, 4, 0);
		myX += 50; myY += 40;
		r = atan(((float)myY - (float)bossY) / ((float)myX - (float)bossX));
		if (bossX > myX) r += 3.14;
		if (times == 8)
		{
			times = 0;
			if (myY <= 300)
			{
				thread t(laser, bossX, bossY, r + 0.348, -0.003485, 4000);
				t.detach();
			}
			else
			{
				thread t(laser, bossX, bossY, r - 0.348, 0.003485, 4000);
				t.detach();
			}
		}
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0x5610), &tab, 4, 0);
		if (tab == 0)
		{
			return;
		}
		for (float i = 0; i < 6.28; i += 0.174)
		{
			//shot(5, bossX, bossY, 2 * cos(i), 2 * sin(i), randBigStar(), 0);
			shot(5, bossX, bossY, 1 * cos(i), 1 * sin(i), randBigStar(), 0);
		}
		DWORD ten = 20;
		WriteProcessMemory(hProcess, (LPVOID)(addr + 0x5544), &ten, 4, 0);
		WriteProcessMemory(hProcess, (LPVOID)(addr + 0x5548), &ten, 4, 0);
		Sleep(1000);
	}
}
void earthRay()
{
	cout << "earthway()" << endl;
	DWORD tab;
	int bossX, bossY, myX, myY, bulletX, bulletY = 0;
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x8 + 0x14C * bossId), &bossX, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0xC + 0x14C * bossId), &bossY, 4, 0);
	float r = 0, flag, dx, dy, rr = 0;
	int t = 0;
	while (1)
	{
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0x5610), &tab, 4, 0);
		if (tab == 0)
		{
			return;
		}
		/*for (int i = 1; i <= 5; i++)
		{
			thread t(laser, 10, i * 100, 0, 0, 500);
			t.detach();
		}*/
		for (int i = 90; i <= 450; i += 10)
		{
			int j = 540 - i;
			shot(5, bossX, bossY, (float)j / 100 * cos(i*0.0174), (float)j / 100 * sin(i*0.0174), randStar(), 0);
		}
		Sleep(500);
		for (int i = 270; i <= 630; i += 10)
		{
			int j = i - 180;
			shot(5, bossX, bossY, (float)j / 100 * cos(i*0.0174), (float)j / 100 * sin(i*0.0174), randStar(), 0);
		}
		Sleep(500);
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0x8 + 0x15C * myId), &myX, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0xC + 0x15C * myId), &myY, 4, 0);
		myX += 50; myY += 40;
		for (int i = -2; i <= 2; i++)
		{
			r = atan(((float)myY - (float)bossY) / ((float)myX - (float)bossX)) + i * 0.0488;
			if (bossX > myX) flag = -1;
			else flag = 1;
			dx = 3 * cos(r) * flag;
			dy = 3 * sin(r) * flag;
			shot(5, bossX, bossY, dx, dy, randStar(), 0);
		}
		Sleep(500);
	}
}
int main()
{
	srand((unsigned)time(NULL));
	hWnd = FindWindow(NULL, _T("植物大战僵尸中文版"));
	GetWindowThreadProcessId(hWnd, &pid);
	hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	ReadProcessMemory(hProcess, (LPVOID)base_addr, &addr, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + offset), &addr, 4, 0); //addr is [[6A9EC0]+768]
	//打开debug模式
	//DWORD four = 4;
	//WriteProcessMemory(hProcess, (LPVOID)(addr + 0x55f8), &four, 4, 0);
	//获取自机和boss的ID
	getId();
	//写入发射子弹代码
	pRemoteThread = VirtualAllocEx(hProcess, NULL, 0x1000, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	WriteProcessMemory(hProcess, pRemoteThread, &createBullet, 0x1000, 0);
	cout << pRemoteThread << endl;
	//申请参数内存
	remoteParap = (parameterp)VirtualAllocEx(hProcess, NULL, sizeof(parameter), MEM_COMMIT, PAGE_READWRITE);
	Sleep(10000);
	//魔符【银河】
	milkyWay();
	//魔符【星辰狂欢】
	clear();
	bossMove(-2, 0, 1600);
	Sleep(1300);
	DWORD bossHp = 450000;
	WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
	Sleep(100);
	starDust();
	//魔符【星光台风】
	clear();
	Sleep(1300);
	bossHp = 450000;
	WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
	Sleep(100);
	typhoon();
	//魔符【master spark】
	clear();
	bossMove(2, 0, 1600);
	Sleep(1300);
	bossHp = 450000;
	WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
	Sleep(100);
	masterSpark();
	//魔符【地球光】
	clear();
	Sleep(2900);
	bossHp = 450000;
	WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
	Sleep(100);
	earthRay();
	return 0;
}
