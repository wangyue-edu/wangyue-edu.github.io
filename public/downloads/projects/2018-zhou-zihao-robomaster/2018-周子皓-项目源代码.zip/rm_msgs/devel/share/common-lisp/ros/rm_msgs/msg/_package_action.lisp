(cl:in-package rm_msgs-msg)
(cl:export '(ACTION-VAL
          ACTION
          BALL-VAL
          BALL
          BALL_INDEX-VAL
          BALL_INDEX
          PATH-VAL
          PATH
))