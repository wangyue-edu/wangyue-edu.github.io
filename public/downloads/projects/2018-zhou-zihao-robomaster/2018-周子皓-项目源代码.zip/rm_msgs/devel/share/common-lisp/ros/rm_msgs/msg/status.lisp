; Auto-generated. Do not edit!


(cl:in-package rm_msgs-msg)


;//! \htmlinclude status.msg.html

(cl:defclass <status> (roslisp-msg-protocol:ros-message)
  ((tower_power_red
    :reader tower_power_red
    :initarg :tower_power_red
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (tower_power_blue
    :reader tower_power_blue
    :initarg :tower_power_blue
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (car_pos_x_red
    :reader car_pos_x_red
    :initarg :car_pos_x_red
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (car_pos_x_blue
    :reader car_pos_x_blue
    :initarg :car_pos_x_blue
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (car_pos_y_red
    :reader car_pos_y_red
    :initarg :car_pos_y_red
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (car_pos_y_blue
    :reader car_pos_y_blue
    :initarg :car_pos_y_blue
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (me
    :reader me
    :initarg :me
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (round_team
    :reader round_team
    :initarg :round_team
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (remain_tick
    :reader remain_tick
    :initarg :remain_tick
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (remain_square
    :reader remain_square
    :initarg :remain_square
    :type std_msgs-msg:UInt8
    :initform (cl:make-instance 'std_msgs-msg:UInt8))
   (graph_occupy_1
    :reader graph_occupy_1
    :initarg :graph_occupy_1
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (graph_occupy_2
    :reader graph_occupy_2
    :initarg :graph_occupy_2
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (graph_occupy_3
    :reader graph_occupy_3
    :initarg :graph_occupy_3
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (graph_occupy_4
    :reader graph_occupy_4
    :initarg :graph_occupy_4
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (graph_occupy_5
    :reader graph_occupy_5
    :initarg :graph_occupy_5
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (graph_occupy_6
    :reader graph_occupy_6
    :initarg :graph_occupy_6
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8)))
   (graph_occupy_7
    :reader graph_occupy_7
    :initarg :graph_occupy_7
    :type (cl:vector std_msgs-msg:UInt8)
   :initform (cl:make-array 0 :element-type 'std_msgs-msg:UInt8 :initial-element (cl:make-instance 'std_msgs-msg:UInt8))))
)

(cl:defclass status (<status>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <status>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'status)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rm_msgs-msg:<status> is deprecated: use rm_msgs-msg:status instead.")))

(cl:ensure-generic-function 'tower_power_red-val :lambda-list '(m))
(cl:defmethod tower_power_red-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:tower_power_red-val is deprecated.  Use rm_msgs-msg:tower_power_red instead.")
  (tower_power_red m))

(cl:ensure-generic-function 'tower_power_blue-val :lambda-list '(m))
(cl:defmethod tower_power_blue-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:tower_power_blue-val is deprecated.  Use rm_msgs-msg:tower_power_blue instead.")
  (tower_power_blue m))

(cl:ensure-generic-function 'car_pos_x_red-val :lambda-list '(m))
(cl:defmethod car_pos_x_red-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:car_pos_x_red-val is deprecated.  Use rm_msgs-msg:car_pos_x_red instead.")
  (car_pos_x_red m))

(cl:ensure-generic-function 'car_pos_x_blue-val :lambda-list '(m))
(cl:defmethod car_pos_x_blue-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:car_pos_x_blue-val is deprecated.  Use rm_msgs-msg:car_pos_x_blue instead.")
  (car_pos_x_blue m))

(cl:ensure-generic-function 'car_pos_y_red-val :lambda-list '(m))
(cl:defmethod car_pos_y_red-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:car_pos_y_red-val is deprecated.  Use rm_msgs-msg:car_pos_y_red instead.")
  (car_pos_y_red m))

(cl:ensure-generic-function 'car_pos_y_blue-val :lambda-list '(m))
(cl:defmethod car_pos_y_blue-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:car_pos_y_blue-val is deprecated.  Use rm_msgs-msg:car_pos_y_blue instead.")
  (car_pos_y_blue m))

(cl:ensure-generic-function 'me-val :lambda-list '(m))
(cl:defmethod me-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:me-val is deprecated.  Use rm_msgs-msg:me instead.")
  (me m))

(cl:ensure-generic-function 'round_team-val :lambda-list '(m))
(cl:defmethod round_team-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:round_team-val is deprecated.  Use rm_msgs-msg:round_team instead.")
  (round_team m))

(cl:ensure-generic-function 'remain_tick-val :lambda-list '(m))
(cl:defmethod remain_tick-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:remain_tick-val is deprecated.  Use rm_msgs-msg:remain_tick instead.")
  (remain_tick m))

(cl:ensure-generic-function 'remain_square-val :lambda-list '(m))
(cl:defmethod remain_square-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:remain_square-val is deprecated.  Use rm_msgs-msg:remain_square instead.")
  (remain_square m))

(cl:ensure-generic-function 'graph_occupy_1-val :lambda-list '(m))
(cl:defmethod graph_occupy_1-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_1-val is deprecated.  Use rm_msgs-msg:graph_occupy_1 instead.")
  (graph_occupy_1 m))

(cl:ensure-generic-function 'graph_occupy_2-val :lambda-list '(m))
(cl:defmethod graph_occupy_2-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_2-val is deprecated.  Use rm_msgs-msg:graph_occupy_2 instead.")
  (graph_occupy_2 m))

(cl:ensure-generic-function 'graph_occupy_3-val :lambda-list '(m))
(cl:defmethod graph_occupy_3-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_3-val is deprecated.  Use rm_msgs-msg:graph_occupy_3 instead.")
  (graph_occupy_3 m))

(cl:ensure-generic-function 'graph_occupy_4-val :lambda-list '(m))
(cl:defmethod graph_occupy_4-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_4-val is deprecated.  Use rm_msgs-msg:graph_occupy_4 instead.")
  (graph_occupy_4 m))

(cl:ensure-generic-function 'graph_occupy_5-val :lambda-list '(m))
(cl:defmethod graph_occupy_5-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_5-val is deprecated.  Use rm_msgs-msg:graph_occupy_5 instead.")
  (graph_occupy_5 m))

(cl:ensure-generic-function 'graph_occupy_6-val :lambda-list '(m))
(cl:defmethod graph_occupy_6-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_6-val is deprecated.  Use rm_msgs-msg:graph_occupy_6 instead.")
  (graph_occupy_6 m))

(cl:ensure-generic-function 'graph_occupy_7-val :lambda-list '(m))
(cl:defmethod graph_occupy_7-val ((m <status>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rm_msgs-msg:graph_occupy_7-val is deprecated.  Use rm_msgs-msg:graph_occupy_7 instead.")
  (graph_occupy_7 m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <status>) ostream)
  "Serializes a message object of type '<status>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'tower_power_red))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'tower_power_red))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'tower_power_blue))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'tower_power_blue))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'car_pos_x_red) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'car_pos_x_blue) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'car_pos_y_red) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'car_pos_y_blue) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'me) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'round_team) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'remain_tick) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'remain_square) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_1))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_1))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_2))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_2))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_3))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_3))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_4))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_4))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_5))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_5))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_6))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_6))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'graph_occupy_7))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'graph_occupy_7))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <status>) istream)
  "Deserializes a message object of type '<status>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'tower_power_red) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'tower_power_red)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'tower_power_blue) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'tower_power_blue)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'car_pos_x_red) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'car_pos_x_blue) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'car_pos_y_red) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'car_pos_y_blue) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'me) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'round_team) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'remain_tick) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'remain_square) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_1) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_1)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_2) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_2)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_3) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_3)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_4) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_4)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_5) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_5)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_6) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_6)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'graph_occupy_7) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'graph_occupy_7)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'std_msgs-msg:UInt8))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<status>)))
  "Returns string type for a message object of type '<status>"
  "rm_msgs/status")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'status)))
  "Returns string type for a message object of type 'status"
  "rm_msgs/status")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<status>)))
  "Returns md5sum for a message object of type '<status>"
  "28f7689f1a21926f156f70f6a36bf275")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'status)))
  "Returns md5sum for a message object of type 'status"
  "28f7689f1a21926f156f70f6a36bf275")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<status>)))
  "Returns full string definition for message of type '<status>"
  (cl:format cl:nil "std_msgs/UInt8[] tower_power_red~%std_msgs/UInt8[] tower_power_blue~%std_msgs/UInt8 car_pos_x_red~%std_msgs/UInt8 car_pos_x_blue~%std_msgs/UInt8 car_pos_y_red~%std_msgs/UInt8 car_pos_y_blue~%std_msgs/UInt8 me~%std_msgs/UInt8 round_team~%std_msgs/UInt8 remain_tick~%std_msgs/UInt8 remain_square~%std_msgs/UInt8[] graph_occupy_1~%std_msgs/UInt8[] graph_occupy_2~%std_msgs/UInt8[] graph_occupy_3~%std_msgs/UInt8[] graph_occupy_4~%std_msgs/UInt8[] graph_occupy_5~%std_msgs/UInt8[] graph_occupy_6~%std_msgs/UInt8[] graph_occupy_7~%~%================================================================================~%MSG: std_msgs/UInt8~%uint8 data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'status)))
  "Returns full string definition for message of type 'status"
  (cl:format cl:nil "std_msgs/UInt8[] tower_power_red~%std_msgs/UInt8[] tower_power_blue~%std_msgs/UInt8 car_pos_x_red~%std_msgs/UInt8 car_pos_x_blue~%std_msgs/UInt8 car_pos_y_red~%std_msgs/UInt8 car_pos_y_blue~%std_msgs/UInt8 me~%std_msgs/UInt8 round_team~%std_msgs/UInt8 remain_tick~%std_msgs/UInt8 remain_square~%std_msgs/UInt8[] graph_occupy_1~%std_msgs/UInt8[] graph_occupy_2~%std_msgs/UInt8[] graph_occupy_3~%std_msgs/UInt8[] graph_occupy_4~%std_msgs/UInt8[] graph_occupy_5~%std_msgs/UInt8[] graph_occupy_6~%std_msgs/UInt8[] graph_occupy_7~%~%================================================================================~%MSG: std_msgs/UInt8~%uint8 data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <status>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'tower_power_red) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'tower_power_blue) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'car_pos_x_red))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'car_pos_x_blue))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'car_pos_y_red))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'car_pos_y_blue))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'me))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'round_team))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'remain_tick))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'remain_square))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_1) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_2) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_3) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_4) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_5) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_6) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'graph_occupy_7) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <status>))
  "Converts a ROS message object to a list"
  (cl:list 'status
    (cl:cons ':tower_power_red (tower_power_red msg))
    (cl:cons ':tower_power_blue (tower_power_blue msg))
    (cl:cons ':car_pos_x_red (car_pos_x_red msg))
    (cl:cons ':car_pos_x_blue (car_pos_x_blue msg))
    (cl:cons ':car_pos_y_red (car_pos_y_red msg))
    (cl:cons ':car_pos_y_blue (car_pos_y_blue msg))
    (cl:cons ':me (me msg))
    (cl:cons ':round_team (round_team msg))
    (cl:cons ':remain_tick (remain_tick msg))
    (cl:cons ':remain_square (remain_square msg))
    (cl:cons ':graph_occupy_1 (graph_occupy_1 msg))
    (cl:cons ':graph_occupy_2 (graph_occupy_2 msg))
    (cl:cons ':graph_occupy_3 (graph_occupy_3 msg))
    (cl:cons ':graph_occupy_4 (graph_occupy_4 msg))
    (cl:cons ':graph_occupy_5 (graph_occupy_5 msg))
    (cl:cons ':graph_occupy_6 (graph_occupy_6 msg))
    (cl:cons ':graph_occupy_7 (graph_occupy_7 msg))
))
