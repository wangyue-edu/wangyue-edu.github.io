// Auto-generated. Do not edit!

// (in-package rm_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class status {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tower_power_red = null;
      this.tower_power_blue = null;
      this.car_pos_x_red = null;
      this.car_pos_x_blue = null;
      this.car_pos_y_red = null;
      this.car_pos_y_blue = null;
      this.me = null;
      this.round_team = null;
      this.remain_tick = null;
      this.remain_square = null;
      this.graph_occupy_1 = null;
      this.graph_occupy_2 = null;
      this.graph_occupy_3 = null;
      this.graph_occupy_4 = null;
      this.graph_occupy_5 = null;
      this.graph_occupy_6 = null;
      this.graph_occupy_7 = null;
    }
    else {
      if (initObj.hasOwnProperty('tower_power_red')) {
        this.tower_power_red = initObj.tower_power_red
      }
      else {
        this.tower_power_red = [];
      }
      if (initObj.hasOwnProperty('tower_power_blue')) {
        this.tower_power_blue = initObj.tower_power_blue
      }
      else {
        this.tower_power_blue = [];
      }
      if (initObj.hasOwnProperty('car_pos_x_red')) {
        this.car_pos_x_red = initObj.car_pos_x_red
      }
      else {
        this.car_pos_x_red = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('car_pos_x_blue')) {
        this.car_pos_x_blue = initObj.car_pos_x_blue
      }
      else {
        this.car_pos_x_blue = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('car_pos_y_red')) {
        this.car_pos_y_red = initObj.car_pos_y_red
      }
      else {
        this.car_pos_y_red = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('car_pos_y_blue')) {
        this.car_pos_y_blue = initObj.car_pos_y_blue
      }
      else {
        this.car_pos_y_blue = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('me')) {
        this.me = initObj.me
      }
      else {
        this.me = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('round_team')) {
        this.round_team = initObj.round_team
      }
      else {
        this.round_team = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('remain_tick')) {
        this.remain_tick = initObj.remain_tick
      }
      else {
        this.remain_tick = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('remain_square')) {
        this.remain_square = initObj.remain_square
      }
      else {
        this.remain_square = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('graph_occupy_1')) {
        this.graph_occupy_1 = initObj.graph_occupy_1
      }
      else {
        this.graph_occupy_1 = [];
      }
      if (initObj.hasOwnProperty('graph_occupy_2')) {
        this.graph_occupy_2 = initObj.graph_occupy_2
      }
      else {
        this.graph_occupy_2 = [];
      }
      if (initObj.hasOwnProperty('graph_occupy_3')) {
        this.graph_occupy_3 = initObj.graph_occupy_3
      }
      else {
        this.graph_occupy_3 = [];
      }
      if (initObj.hasOwnProperty('graph_occupy_4')) {
        this.graph_occupy_4 = initObj.graph_occupy_4
      }
      else {
        this.graph_occupy_4 = [];
      }
      if (initObj.hasOwnProperty('graph_occupy_5')) {
        this.graph_occupy_5 = initObj.graph_occupy_5
      }
      else {
        this.graph_occupy_5 = [];
      }
      if (initObj.hasOwnProperty('graph_occupy_6')) {
        this.graph_occupy_6 = initObj.graph_occupy_6
      }
      else {
        this.graph_occupy_6 = [];
      }
      if (initObj.hasOwnProperty('graph_occupy_7')) {
        this.graph_occupy_7 = initObj.graph_occupy_7
      }
      else {
        this.graph_occupy_7 = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type status
    // Serialize message field [tower_power_red]
    // Serialize the length for message field [tower_power_red]
    bufferOffset = _serializer.uint32(obj.tower_power_red.length, buffer, bufferOffset);
    obj.tower_power_red.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [tower_power_blue]
    // Serialize the length for message field [tower_power_blue]
    bufferOffset = _serializer.uint32(obj.tower_power_blue.length, buffer, bufferOffset);
    obj.tower_power_blue.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [car_pos_x_red]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.car_pos_x_red, buffer, bufferOffset);
    // Serialize message field [car_pos_x_blue]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.car_pos_x_blue, buffer, bufferOffset);
    // Serialize message field [car_pos_y_red]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.car_pos_y_red, buffer, bufferOffset);
    // Serialize message field [car_pos_y_blue]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.car_pos_y_blue, buffer, bufferOffset);
    // Serialize message field [me]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.me, buffer, bufferOffset);
    // Serialize message field [round_team]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.round_team, buffer, bufferOffset);
    // Serialize message field [remain_tick]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.remain_tick, buffer, bufferOffset);
    // Serialize message field [remain_square]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.remain_square, buffer, bufferOffset);
    // Serialize message field [graph_occupy_1]
    // Serialize the length for message field [graph_occupy_1]
    bufferOffset = _serializer.uint32(obj.graph_occupy_1.length, buffer, bufferOffset);
    obj.graph_occupy_1.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [graph_occupy_2]
    // Serialize the length for message field [graph_occupy_2]
    bufferOffset = _serializer.uint32(obj.graph_occupy_2.length, buffer, bufferOffset);
    obj.graph_occupy_2.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [graph_occupy_3]
    // Serialize the length for message field [graph_occupy_3]
    bufferOffset = _serializer.uint32(obj.graph_occupy_3.length, buffer, bufferOffset);
    obj.graph_occupy_3.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [graph_occupy_4]
    // Serialize the length for message field [graph_occupy_4]
    bufferOffset = _serializer.uint32(obj.graph_occupy_4.length, buffer, bufferOffset);
    obj.graph_occupy_4.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [graph_occupy_5]
    // Serialize the length for message field [graph_occupy_5]
    bufferOffset = _serializer.uint32(obj.graph_occupy_5.length, buffer, bufferOffset);
    obj.graph_occupy_5.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [graph_occupy_6]
    // Serialize the length for message field [graph_occupy_6]
    bufferOffset = _serializer.uint32(obj.graph_occupy_6.length, buffer, bufferOffset);
    obj.graph_occupy_6.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [graph_occupy_7]
    // Serialize the length for message field [graph_occupy_7]
    bufferOffset = _serializer.uint32(obj.graph_occupy_7.length, buffer, bufferOffset);
    obj.graph_occupy_7.forEach((val) => {
      bufferOffset = std_msgs.msg.UInt8.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type status
    let len;
    let data = new status(null);
    // Deserialize message field [tower_power_red]
    // Deserialize array length for message field [tower_power_red]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tower_power_red = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tower_power_red[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [tower_power_blue]
    // Deserialize array length for message field [tower_power_blue]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tower_power_blue = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tower_power_blue[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [car_pos_x_red]
    data.car_pos_x_red = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [car_pos_x_blue]
    data.car_pos_x_blue = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [car_pos_y_red]
    data.car_pos_y_red = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [car_pos_y_blue]
    data.car_pos_y_blue = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [me]
    data.me = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [round_team]
    data.round_team = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [remain_tick]
    data.remain_tick = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [remain_square]
    data.remain_square = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [graph_occupy_1]
    // Deserialize array length for message field [graph_occupy_1]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_1 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_1[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [graph_occupy_2]
    // Deserialize array length for message field [graph_occupy_2]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_2 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_2[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [graph_occupy_3]
    // Deserialize array length for message field [graph_occupy_3]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_3 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_3[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [graph_occupy_4]
    // Deserialize array length for message field [graph_occupy_4]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_4 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_4[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [graph_occupy_5]
    // Deserialize array length for message field [graph_occupy_5]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_5 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_5[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [graph_occupy_6]
    // Deserialize array length for message field [graph_occupy_6]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_6 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_6[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [graph_occupy_7]
    // Deserialize array length for message field [graph_occupy_7]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.graph_occupy_7 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.graph_occupy_7[i] = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.tower_power_red.length;
    length += object.tower_power_blue.length;
    length += object.graph_occupy_1.length;
    length += object.graph_occupy_2.length;
    length += object.graph_occupy_3.length;
    length += object.graph_occupy_4.length;
    length += object.graph_occupy_5.length;
    length += object.graph_occupy_6.length;
    length += object.graph_occupy_7.length;
    return length + 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rm_msgs/status';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '28f7689f1a21926f156f70f6a36bf275';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/UInt8[] tower_power_red
    std_msgs/UInt8[] tower_power_blue
    std_msgs/UInt8 car_pos_x_red
    std_msgs/UInt8 car_pos_x_blue
    std_msgs/UInt8 car_pos_y_red
    std_msgs/UInt8 car_pos_y_blue
    std_msgs/UInt8 me
    std_msgs/UInt8 round_team
    std_msgs/UInt8 remain_tick
    std_msgs/UInt8 remain_square
    std_msgs/UInt8[] graph_occupy_1
    std_msgs/UInt8[] graph_occupy_2
    std_msgs/UInt8[] graph_occupy_3
    std_msgs/UInt8[] graph_occupy_4
    std_msgs/UInt8[] graph_occupy_5
    std_msgs/UInt8[] graph_occupy_6
    std_msgs/UInt8[] graph_occupy_7
    
    ================================================================================
    MSG: std_msgs/UInt8
    uint8 data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new status(null);
    if (msg.tower_power_red !== undefined) {
      resolved.tower_power_red = new Array(msg.tower_power_red.length);
      for (let i = 0; i < resolved.tower_power_red.length; ++i) {
        resolved.tower_power_red[i] = std_msgs.msg.UInt8.Resolve(msg.tower_power_red[i]);
      }
    }
    else {
      resolved.tower_power_red = []
    }

    if (msg.tower_power_blue !== undefined) {
      resolved.tower_power_blue = new Array(msg.tower_power_blue.length);
      for (let i = 0; i < resolved.tower_power_blue.length; ++i) {
        resolved.tower_power_blue[i] = std_msgs.msg.UInt8.Resolve(msg.tower_power_blue[i]);
      }
    }
    else {
      resolved.tower_power_blue = []
    }

    if (msg.car_pos_x_red !== undefined) {
      resolved.car_pos_x_red = std_msgs.msg.UInt8.Resolve(msg.car_pos_x_red)
    }
    else {
      resolved.car_pos_x_red = new std_msgs.msg.UInt8()
    }

    if (msg.car_pos_x_blue !== undefined) {
      resolved.car_pos_x_blue = std_msgs.msg.UInt8.Resolve(msg.car_pos_x_blue)
    }
    else {
      resolved.car_pos_x_blue = new std_msgs.msg.UInt8()
    }

    if (msg.car_pos_y_red !== undefined) {
      resolved.car_pos_y_red = std_msgs.msg.UInt8.Resolve(msg.car_pos_y_red)
    }
    else {
      resolved.car_pos_y_red = new std_msgs.msg.UInt8()
    }

    if (msg.car_pos_y_blue !== undefined) {
      resolved.car_pos_y_blue = std_msgs.msg.UInt8.Resolve(msg.car_pos_y_blue)
    }
    else {
      resolved.car_pos_y_blue = new std_msgs.msg.UInt8()
    }

    if (msg.me !== undefined) {
      resolved.me = std_msgs.msg.UInt8.Resolve(msg.me)
    }
    else {
      resolved.me = new std_msgs.msg.UInt8()
    }

    if (msg.round_team !== undefined) {
      resolved.round_team = std_msgs.msg.UInt8.Resolve(msg.round_team)
    }
    else {
      resolved.round_team = new std_msgs.msg.UInt8()
    }

    if (msg.remain_tick !== undefined) {
      resolved.remain_tick = std_msgs.msg.UInt8.Resolve(msg.remain_tick)
    }
    else {
      resolved.remain_tick = new std_msgs.msg.UInt8()
    }

    if (msg.remain_square !== undefined) {
      resolved.remain_square = std_msgs.msg.UInt8.Resolve(msg.remain_square)
    }
    else {
      resolved.remain_square = new std_msgs.msg.UInt8()
    }

    if (msg.graph_occupy_1 !== undefined) {
      resolved.graph_occupy_1 = new Array(msg.graph_occupy_1.length);
      for (let i = 0; i < resolved.graph_occupy_1.length; ++i) {
        resolved.graph_occupy_1[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_1[i]);
      }
    }
    else {
      resolved.graph_occupy_1 = []
    }

    if (msg.graph_occupy_2 !== undefined) {
      resolved.graph_occupy_2 = new Array(msg.graph_occupy_2.length);
      for (let i = 0; i < resolved.graph_occupy_2.length; ++i) {
        resolved.graph_occupy_2[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_2[i]);
      }
    }
    else {
      resolved.graph_occupy_2 = []
    }

    if (msg.graph_occupy_3 !== undefined) {
      resolved.graph_occupy_3 = new Array(msg.graph_occupy_3.length);
      for (let i = 0; i < resolved.graph_occupy_3.length; ++i) {
        resolved.graph_occupy_3[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_3[i]);
      }
    }
    else {
      resolved.graph_occupy_3 = []
    }

    if (msg.graph_occupy_4 !== undefined) {
      resolved.graph_occupy_4 = new Array(msg.graph_occupy_4.length);
      for (let i = 0; i < resolved.graph_occupy_4.length; ++i) {
        resolved.graph_occupy_4[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_4[i]);
      }
    }
    else {
      resolved.graph_occupy_4 = []
    }

    if (msg.graph_occupy_5 !== undefined) {
      resolved.graph_occupy_5 = new Array(msg.graph_occupy_5.length);
      for (let i = 0; i < resolved.graph_occupy_5.length; ++i) {
        resolved.graph_occupy_5[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_5[i]);
      }
    }
    else {
      resolved.graph_occupy_5 = []
    }

    if (msg.graph_occupy_6 !== undefined) {
      resolved.graph_occupy_6 = new Array(msg.graph_occupy_6.length);
      for (let i = 0; i < resolved.graph_occupy_6.length; ++i) {
        resolved.graph_occupy_6[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_6[i]);
      }
    }
    else {
      resolved.graph_occupy_6 = []
    }

    if (msg.graph_occupy_7 !== undefined) {
      resolved.graph_occupy_7 = new Array(msg.graph_occupy_7.length);
      for (let i = 0; i < resolved.graph_occupy_7.length; ++i) {
        resolved.graph_occupy_7[i] = std_msgs.msg.UInt8.Resolve(msg.graph_occupy_7[i]);
      }
    }
    else {
      resolved.graph_occupy_7 = []
    }

    return resolved;
    }
};

module.exports = status;
