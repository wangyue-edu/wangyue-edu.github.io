# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(rm_msgs_MSG_INCLUDE_DIRS "/home/robomaster/rm_msgs/src/rm_msgs/msg")
set(rm_msgs_MSG_DEPENDENCIES geometry_msgs;std_msgs;nav_msgs)
