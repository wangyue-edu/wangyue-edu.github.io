// Auto-generated. Do not edit!

// (in-package rm_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let nav_msgs = _finder('nav_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class action {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.action = null;
      this.ball = null;
      this.ball_index = null;
      this.path = null;
    }
    else {
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('ball')) {
        this.ball = initObj.ball
      }
      else {
        this.ball = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('ball_index')) {
        this.ball_index = initObj.ball_index
      }
      else {
        this.ball_index = new std_msgs.msg.UInt8();
      }
      if (initObj.hasOwnProperty('path')) {
        this.path = initObj.path
      }
      else {
        this.path = new nav_msgs.msg.Path();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type action
    // Serialize message field [action]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.action, buffer, bufferOffset);
    // Serialize message field [ball]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.ball, buffer, bufferOffset);
    // Serialize message field [ball_index]
    bufferOffset = std_msgs.msg.UInt8.serialize(obj.ball_index, buffer, bufferOffset);
    // Serialize message field [path]
    bufferOffset = nav_msgs.msg.Path.serialize(obj.path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type action
    let len;
    let data = new action(null);
    // Deserialize message field [action]
    data.action = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [ball]
    data.ball = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [ball_index]
    data.ball_index = std_msgs.msg.UInt8.deserialize(buffer, bufferOffset);
    // Deserialize message field [path]
    data.path = nav_msgs.msg.Path.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += nav_msgs.msg.Path.getMessageSize(object.path);
    return length + 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rm_msgs/action';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1e570589fc53e22bc4b1f317df403a6d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/UInt8 action
    std_msgs/UInt8 ball
    std_msgs/UInt8 ball_index
    nav_msgs/Path path
    
    ================================================================================
    MSG: std_msgs/UInt8
    uint8 data
    
    ================================================================================
    MSG: nav_msgs/Path
    #An array of poses that represents a Path for a robot to follow
    Header header
    geometry_msgs/PoseStamped[] poses
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new action(null);
    if (msg.action !== undefined) {
      resolved.action = std_msgs.msg.UInt8.Resolve(msg.action)
    }
    else {
      resolved.action = new std_msgs.msg.UInt8()
    }

    if (msg.ball !== undefined) {
      resolved.ball = std_msgs.msg.UInt8.Resolve(msg.ball)
    }
    else {
      resolved.ball = new std_msgs.msg.UInt8()
    }

    if (msg.ball_index !== undefined) {
      resolved.ball_index = std_msgs.msg.UInt8.Resolve(msg.ball_index)
    }
    else {
      resolved.ball_index = new std_msgs.msg.UInt8()
    }

    if (msg.path !== undefined) {
      resolved.path = nav_msgs.msg.Path.Resolve(msg.path)
    }
    else {
      resolved.path = new nav_msgs.msg.Path()
    }

    return resolved;
    }
};

module.exports = action;
