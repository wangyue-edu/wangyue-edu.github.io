(cl:defpackage rm_msgs-msg
  (:use )
  (:export
   "<ACTION>"
   "ACTION"
   "<STATUS>"
   "STATUS"
  ))

