set(rm_msgs_MESSAGE_FILES "/home/robomaster/rm_msgs/src/rm_msgs/msg/action.msg;/home/robomaster/rm_msgs/src/rm_msgs/msg/status.msg")
set(rm_msgs_SERVICE_FILES "")
