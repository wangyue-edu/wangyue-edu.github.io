﻿#include "pch.h"
#include <tchar.h>
#include <windows.h>
#include <iostream>
#include <time.h>
#include <sys/timeb.h>
#include <math.h>
#include <thread>
#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)
using namespace std;

int myId, bossId;
HWND hWnd;
DWORD pid;
HANDLE hProcess;
DWORD base_addr = 0x006A9EC0;
DWORD offset = 0x768;
DWORD addr;
PVOID pRemoteThread;
DWORD zombiesStart;
DWORD plantsStart;
DWORD bulletStart, bulletNumber;
union float2dword {
	float f;
	DWORD d;
}f2d;
long long getTimeStamp()
{
	timeb t;
	ftime(&t);
	return t.time * 1000 + t.millitm;
}
void getId()
{
	DWORD plantsNumber;
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xB0), &plantsNumber, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xAC), &plantsStart, 4, 0);
	for (int i = 0; i < plantsNumber; i++)
	{
		DWORD plantClass, plantStatus;
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x24 + 0x14C * i), &plantClass, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x148 + 0x14C * i), &plantStatus, 4, 0);
		if (plantClass == 1 && (plantStatus & 0xFFFF0000) != 0)
		{
			bossId = i;
			break;
		}
	}
	DWORD zombiesNumber;
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0x94), &zombiesNumber, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0x90), &zombiesStart, 4, 0);
	for (int i = 0; i < zombiesNumber; i++)
	{
		DWORD zombieClass;
		ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0x24 + 0x15C * i), &zombieClass, 4, 0);
		if (zombieClass == 24)
		{
			myId = i;
			break;
		}
	}
	return;
}
void clear()
{
	DWORD bulletNumber, bulletStart;
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xCC), &bulletNumber, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + 0xC8), &bulletStart, 4, 0);
	for (int i = 0; i < bulletNumber; i++)
	{
		DWORD bulletType, bulletX, bulletY;
		ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x5C + 0x94 * i), &bulletType, 4, 0);
		if (bulletType == 13)continue;
		f2d.f = 1000.0;
		WriteProcessMemory(hProcess, (LPVOID)(bulletStart + 0x30 + 0x94 * i), &f2d.d, 4, 0);
	}
}
int main()
{
	hWnd = FindWindow(NULL, _T("植物大战僵尸中文版"));
	GetWindowThreadProcessId(hWnd, &pid);
	hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	ReadProcessMemory(hProcess, (LPVOID)base_addr, &addr, 4, 0);
	ReadProcessMemory(hProcess, (LPVOID)(addr + offset), &addr, 4, 0); //addr is [[6A9EC0]+768]
	//获取自机和boss的ID
	getId();
	long long lasttime = getTimeStamp();
	long long thistime;
	while (1)
	{
		thistime = getTimeStamp();
		if (thistime - lasttime < 10)continue;
		lasttime = thistime;
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0xCC), &bulletNumber, 4, 0);
		ReadProcessMemory(hProcess, (LPVOID)(addr + 0xC8), &bulletStart, 4, 0);
		for (int i = 0; i < bulletNumber; i++)
		{
			DWORD bulletType;
			short bulletStatus;
			char bulletVisible;
			int bulletX, bulletY;
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x5C + 0x94 * i), &bulletType, 4, 0);
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x92 + 0x94 * i), &bulletStatus, 2, 0);
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x50 + 0x94 * i), &bulletVisible, 1, 0);
			if (bulletType == 13 || bulletStatus == 0 || bulletVisible != 0)continue;
			int myX, myY;
			ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0x8 + 0x15C * myId), &myX, 4, 0);
			ReadProcessMemory(hProcess, (LPVOID)(zombiesStart + 0xC + 0x15C * myId), &myY, 4, 0);
			myX += 50; myY += 40;
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0x8 + 0x94 * i), &bulletX, 4, 0);
			ReadProcessMemory(hProcess, (LPVOID)(bulletStart + 0xC + 0x94 * i), &bulletY, 4, 0);
			if (bulletX <= -100 || bulletX >= 900 || bulletY <= -200 || bulletY >= 800)
			{
				f2d.f = 1000.0;
				WriteProcessMemory(hProcess, (LPVOID)(bulletStart + 0x30 + 0x94 * i), &f2d.d, 4, 0);
				continue;
			}
			if (bulletType == 3 || bulletType == 5 || bulletType == 9)
			{
				bulletX += 10; bulletY += 10;
				if ((myX - bulletX)*(myX - bulletX) + (myY - bulletY)*(myY - bulletY) <= 225)
				{
					cout << "hit\n";
					clear();
					DWORD bossHp;
					ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
					bossHp += 10000;
					if (bossHp > 450000) bossHp = 450000;
					WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
				}
			}
			else
			{
				bulletX += 5; bulletY += 5;
				if ((myX - bulletX)*(myX - bulletX) + (myY - bulletY)*(myY - bulletY) <= 100)
				{
					cout << "hit\n";
					clear();
					DWORD bossHp;
					ReadProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
					bossHp += 10000;
					if (bossHp > 450000) bossHp = 450000;
					WriteProcessMemory(hProcess, (LPVOID)(plantsStart + 0x40 + 0x14C * bossId), &bossHp, 4, 0);
				}
			}
		}
	}
	return 0;
}