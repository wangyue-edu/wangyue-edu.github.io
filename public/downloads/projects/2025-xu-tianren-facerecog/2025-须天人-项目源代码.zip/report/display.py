import matplotlib.pyplot as plt
import numpy as np

# 设置样式
plt.style.use('default')
plt.rcParams['font.family'] = 'DejaVu Sans'

# 数据准备
models = ['ResNet50', 'ResNet18', 'Our Model', 'EfficientNet-B0']
accuracy = [97.56, 98.75, 93.69, 94.08]
colors = ['#4C72B0', '#55A868', '#C44E52', '#CCB974']

# 创建图形和子图
fig, ax = plt.subplots(figsize=(10, 6))

# 绘制条形图
bars = ax.bar(models, accuracy, color=colors, alpha=0.8, edgecolor='white')

# 添加数据标签
for bar in bars:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
            f'{height:.2f}%', ha='center', va='bottom', fontsize=11, fontweight='bold')

# 设置图表元素
ax.set_xlabel('Model Architecture', fontsize=12, labelpad=10)
ax.set_ylabel('Accuracy (%)', fontsize=12, labelpad=10)
ax.set_title('Model Performance with Adam/W Optimizer and scheduler in large scale dataset', fontsize=14, pad=20)
ax.set_ylim(90, 100)

# 添加网格
ax.yaxis.grid(True, linestyle='--', alpha=0.7)

# 添加性能排名注释
'''for i, (model, acc) in enumerate(zip(models, accuracy)):
    rank = sorted(accuracy, reverse=True).index(acc) + 1
    ax.text(i, acc - 1.5, f'#{rank}', ha='center', va='center', 
            fontsize=12, fontweight='bold', color='white')'''

# 调整布局
plt.tight_layout()

# 显示图表
plt.show()