import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import numpy as np

# 定义与原始代码相同的模型结构
class StableGenderCNN(nn.Module):
    def __init__(self):
        super(StableGenderCNN, self).__init__()
        
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout(0.1),
            
            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout(0.2),
            
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout(0.3),
            
            nn.Conv2d(128, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4))
        )
        
        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(256 * 4 * 4, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.4),
            nn.Linear(128, 1)
        )
    
    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

def create_simple_architecture_diagram():
    """创建简化的模型架构图（纯英文）"""
    fig, ax = plt.subplots(1, 1, figsize=(14, 10))
    
    # 定义各层信息（英文）
    layers = [
        {"name": "Input\n3x128x128", "type": "Input Layer", "shape": "3x128x128", "color": "lightblue", "y": 0},
        {"name": "Conv2d", "type": "Conv Layer", "shape": "32x128x128", "color": "lightgreen", "y": 1},
        {"name": "BatchNorm", "type": "Normalization", "shape": "32x128x128", "color": "lightyellow", "y": 2},
        {"name": "ReLU", "type": "Activation", "shape": "32x128x128", "color": "lightcoral", "y": 3},
        {"name": "MaxPool2d", "type": "Pooling", "shape": "32x64x64", "color": "lightcyan", "y": 4},
        {"name": "Dropout", "type": "Regularization", "shape": "32x64x64", "color": "lavender", "y": 5},
        
        {"name": "Conv2d", "type": "Conv Layer", "shape": "64x64x64", "color": "lightgreen", "y": 6},
        {"name": "BatchNorm", "type": "Normalization", "shape": "64x64x64", "color": "lightyellow", "y": 7},
        {"name": "ReLU", "type": "Activation", "shape": "64x64x64", "color": "lightcoral", "y": 8},
        {"name": "MaxPool2d", "type": "Pooling", "shape": "64x32x32", "color": "lightcyan", "y": 9},
        {"name": "Dropout", "type": "Regularization", "shape": "64x32x32", "color": "lavender", "y": 10},
        
        {"name": "Conv2d", "type": "Conv Layer", "shape": "128x32x32", "color": "lightgreen", "y": 11},
        {"name": "BatchNorm", "type": "Normalization", "shape": "128x32x32", "color": "lightyellow", "y": 12},
        {"name": "ReLU", "type": "Activation", "shape": "128x32x32", "color": "lightcoral", "y": 13},
        {"name": "MaxPool2d", "type": "Pooling", "shape": "128x16x16", "color": "lightcyan", "y": 14},
        {"name": "Dropout", "type": "Regularization", "shape": "128x16x16", "color": "lavender", "y": 15},
        
        {"name": "Conv2d", "type": "Conv Layer", "shape": "256x16x16", "color": "lightgreen", "y": 16},
        {"name": "BatchNorm", "type": "Normalization", "shape": "256x16x16", "color": "lightyellow", "y": 17},
        {"name": "ReLU", "type": "Activation", "shape": "256x16x16", "color": "lightcoral", "y": 18},
        {"name": "AdaptiveAvgPool", "type": "Global Pooling", "shape": "256x4x4", "color": "lightcyan", "y": 19},
        
        {"name": "Flatten", "type": "Flatten", "shape": "4096", "color": "wheat", "y": 20},
        {"name": "Dropout", "type": "Regularization", "shape": "4096", "color": "lavender", "y": 21},
        {"name": "Linear", "type": "Fully Connected", "shape": "128", "color": "lightgreen", "y": 22},
        {"name": "ReLU", "type": "Activation", "shape": "128", "color": "lightcoral", "y": 23},
        {"name": "BatchNorm", "type": "Normalization", "shape": "128", "color": "lightyellow", "y": 24},
        {"name": "Dropout", "type": "Regularization", "shape": "128", "color": "lavender", "y": 25},
        {"name": "Linear", "type": "Fully Connected", "shape": "1", "color": "lightgreen", "y": 26},
        {"name": "Output", "type": "Output Layer", "shape": "1 (Probability)", "color": "lightblue", "y": 27},
    ]
    
    # 绘制各层
    for i, layer in enumerate(layers):
        # 绘制层框
        box = FancyBboxPatch((0.1, layer["y"] * 0.3), 0.8, 0.25,
                           boxstyle="round,pad=0.02",
                           facecolor=layer["color"],
                           edgecolor='black',
                           linewidth=1)
        ax.add_patch(box)
        
        # 添加文本
        ax.text(0.5, layer["y"] * 0.3 + 0.125, 
               f"{layer['name']}\n{layer['shape']}", 
               ha='center', va='center', fontsize=8, weight='bold')
        
        # 绘制连接线
        if i < len(layers) - 1:
            ax.plot([0.5, 0.5], 
                   [layer["y"] * 0.3 + 0.25, (layer["y"] + 1) * 0.3],
                   'k-', linewidth=1)
            ax.arrow(0.5, (layer["y"] + 1) * 0.3 - 0.05, 0, -0.05,
                   head_width=0.02, head_length=0.02, fc='k', ec='k')
    
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.1, len(layers) * 0.3 + 0.1)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_title('Gender Classification CNN Model Architecture', fontsize=16, weight='bold', pad=20)
    
    # 添加图例
    legend_elements = [
        patches.Patch(facecolor='lightblue', edgecolor='black', label='Input/Output'),
        patches.Patch(facecolor='lightgreen', edgecolor='black', label='Conv/Linear'),
        patches.Patch(facecolor='lightyellow', edgecolor='black', label='BatchNorm'),
        patches.Patch(facecolor='lightcoral', edgecolor='black', label='Activation'),
        patches.Patch(facecolor='lightcyan', edgecolor='black', label='Pooling'),
        patches.Patch(facecolor='lavender', edgecolor='black', label='Dropout'),
        patches.Patch(facecolor='wheat', edgecolor='black', label='Flatten'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.1, 1))
    
    plt.tight_layout()
    plt.savefig('simple_model_architecture.png', dpi=300, bbox_inches='tight')
    plt.show()

def create_model_flowchart():
    """创建模型流程图（纯英文）"""
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 定义模块和位置
    modules = [
        {"name": "Input\n3x128x128", "pos": (1, 7), "color": "lightblue", "type": "input"},
        {"name": "Feature\nExtraction", "pos": (3, 7), "color": "lightgreen", "type": "module"},
        {"name": "Classification\nNetwork", "pos": (5, 7), "color": "lightcoral", "type": "module"},
        {"name": "Output\nGender Probability", "pos": (7, 7), "color": "lightblue", "type": "output"},
    ]
    
    # 绘制模块
    for module in modules:
        if module["type"] in ["input", "output"]:
            # 椭圆表示输入输出
            ellipse = patches.Ellipse(module["pos"], 1.2, 0.6, 
                                    facecolor=module["color"], 
                                    edgecolor='black', linewidth=2)
            ax.add_patch(ellipse)
        else:
            # 矩形表示处理模块
            rect = patches.Rectangle((module["pos"][0]-0.6, module["pos"][1]-0.3), 
                                   1.2, 0.6,
                                   facecolor=module["color"], 
                                   edgecolor='black', linewidth=2)
            ax.add_patch(rect)
        
        ax.text(module["pos"][0], module["pos"][1], module["name"], 
               ha='center', va='center', fontsize=10, weight='bold')
    
    # 绘制箭头
    arrows = [
        ((1.6, 7), (2.4, 7)),  # 输入到特征提取
        ((3.6, 7), (4.4, 7)),  # 特征提取到分类
        ((5.6, 7), (6.4, 7)),  # 分类到输出
    ]
    
    for start, end in arrows:
        ax.annotate('', xy=end, xytext=start,
                   arrowprops=dict(arrowstyle='->', lw=2, color='black'))
    
    # 添加特征提取网络细节
    feature_details = [
        "4 Conv Blocks:",
        "• 32 -> 64 -> 128 -> 256 channels",
        "• Each block contains:",
        "  Conv + BN + ReLU + Pool + Dropout",
        "• Final Global Average Pooling",
        "Output: 256x4x4 feature maps"
    ]
    
    # 添加分类网络细节
    classifier_details = [
        "Fully Connected Classifier:",
        "• Flatten: 256x4x4 -> 4096",
        "• Dropout(0.5)",
        "• Linear: 4096 -> 128",
        "• ReLU + BN + Dropout(0.4)",
        "• Linear: 128 -> 1",
        "• Sigmoid activation"
    ]
    
    # 添加文本说明
    ax.text(3, 5.5, '\n'.join(feature_details), 
           ha='center', va='top', fontsize=9,
           bbox=dict(boxstyle="round,pad=0.5", facecolor="white", alpha=0.8))
    
    ax.text(5, 5.5, '\n'.join(classifier_details), 
           ha='center', va='top', fontsize=9,
           bbox=dict(boxstyle="round,pad=0.5", facecolor="white", alpha=0.8))
    
    ax.set_xlim(0, 8)
    ax.set_ylim(4.5, 8)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_title('CNN Model Flowchart for Gender Classification', fontsize=16, weight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig('model_flowchart.png', dpi=300, bbox_inches='tight')
    plt.show()

def create_layer_statistics():
    """创建模型统计信息图（纯英文）"""
    model = StableGenderCNN()
    
    # 计算各层参数
    total_params = 0
    layer_info = []
    
    for name, param in model.named_parameters():
        if param.requires_grad:
            param_count = param.numel()
            total_params += param_count
            layer_info.append({
                'name': name,
                'shape': tuple(param.shape),
                'params': param_count,
                'percentage': param_count / total_params * 100
            })
    
    # 创建图表
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # 左侧：参数分布饼图
    param_categories = {
        'Conv Layers': 0,
        'Linear Layers': 0,
        'BatchNorm': 0,
        'Other': 0
    }
    
    for info in layer_info:
        if 'features' in info['name'] and 'weight' in info['name']:
            if len(info['shape']) == 4:  # 卷积权重
                param_categories['Conv Layers'] += info['params']
            elif len(info['shape']) == 1:  # BatchNorm
                param_categories['BatchNorm'] += info['params']
        elif 'classifier' in info['name'] and 'weight' in info['name']:
            param_categories['Linear Layers'] += info['params']
        else:
            param_categories['Other'] += info['params']
    
    labels = list(param_categories.keys())
    sizes = list(param_categories.values())
    colors = ['lightgreen', 'lightcoral', 'lightyellow', 'lavender']
    
    ax1.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
    ax1.set_title('Parameter Distribution', weight='bold')
    
    # 右侧：模型信息表格
    ax2.axis('tight')
    ax2.axis('off')
    
    # 模型统计信息
    stats_data = [
        ['Total Parameters', f'{total_params:,}'],
        ['Trainable Parameters', f'{total_params:,}'],
        ['Conv Layers', '4'],
        ['Linear Layers', '2'],
        ['BatchNorm Layers', '5'],
        ['Dropout Layers', '5'],
        ['Input Size', '3x128x128'],
        ['Output Size', '1 (Probability)']
    ]
    
    table = ax2.table(cellText=stats_data,
                     cellLoc='center',
                     loc='center',
                     bbox=[0.1, 0.3, 0.8, 0.6])
    
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.5)
    
    ax2.set_title('Model Statistics', weight='bold', pad=20)
    
    plt.suptitle('CNN Model Analysis Report', fontsize=16, weight='bold')
    plt.tight_layout()
    plt.savefig('model_statistics.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    return total_params

def create_data_flow_diagram():
    """创建数据流图（纯英文）"""
    fig, ax = plt.subplots(figsize=(16, 8))
    
    # 定义数据流步骤
    steps = [
        {"name": "Input\n3x128x128", "x": 1, "color": "lightblue"},
        {"name": "Conv2d\n3->32", "x": 2, "color": "lightgreen"},
        {"name": "BN+ReLU\n32x128x128", "x": 3, "color": "lightyellow"},
        {"name": "MaxPool\n32x64x64", "x": 4, "color": "lightcyan"},
        {"name": "Dropout\n0.1", "x": 5, "color": "lavender"},
        
        {"name": "Conv2d\n32->64", "x": 6, "color": "lightgreen"},
        {"name": "BN+ReLU\n64x64x64", "x": 7, "color": "lightyellow"},
        {"name": "MaxPool\n64x32x32", "x": 8, "color": "lightcyan"},
        {"name": "Dropout\n0.2", "x": 9, "color": "lavender"},
        
        {"name": "Conv2d\n64->128", "x": 10, "color": "lightgreen"},
        {"name": "BN+ReLU\n128x32x32", "x": 11, "color": "lightyellow"},
        {"name": "MaxPool\n128x16x16", "x": 12, "color": "lightcyan"},
        {"name": "Dropout\n0.3", "x": 13, "color": "lavender"},
        
        {"name": "Conv2d\n128->256", "x": 14, "color": "lightgreen"},
        {"name": "BN+ReLU\n256x16x16", "x": 15, "color": "lightyellow"},
        {"name": "AdaptivePool\n256x4x4", "x": 16, "color": "lightcyan"},
        
        {"name": "Flatten\n4096", "x": 17, "color": "wheat"},
        {"name": "Dropout\n0.5", "x": 18, "color": "lavender"},
        {"name": "Linear\n4096->128", "x": 19, "color": "lightgreen"},
        {"name": "ReLU+BN\n128", "x": 20, "color": "lightyellow"},
        {"name": "Dropout\n0.4", "x": 21, "color": "lavender"},
        {"name": "Linear\n128->1", "x": 22, "color": "lightgreen"},
        {"name": "Output\nProbability", "x": 23, "color": "lightblue"},
    ]
    
    # 绘制步骤
    for step in steps:
        rect = patches.Rectangle((step["x"]-0.4, 3), 0.8, 1,
                               facecolor=step["color"], 
                               edgecolor='black', linewidth=1)
        ax.add_patch(rect)
        ax.text(step["x"], 3.5, step["name"], 
               ha='center', va='center', fontsize=8, weight='bold')
    
    # 绘制连接箭头
    for i in range(len(steps)-1):
        ax.arrow(steps[i]["x"]+0.4, 3.5, 
                steps[i+1]["x"]-steps[i]["x"]-0.8, 0,
                head_width=0.1, head_length=0.2, 
                fc='black', ec='black', linewidth=1)
    
    # 添加区域标注
    ax.text(8, 2, "Feature Extraction Network", 
           ha='center', va='center', fontsize=12, weight='bold',
           bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgreen", alpha=0.7))
    
    ax.text(20, 2, "Classification Network", 
           ha='center', va='center', fontsize=12, weight='bold',
           bbox=dict(boxstyle="round,pad=0.5", facecolor="lightcoral", alpha=0.7))
    
    ax.set_xlim(0, 24)
    ax.set_ylim(2, 5)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_title('CNN Data Flow Diagram', fontsize=16, weight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig('data_flow_diagram.png', dpi=300, bbox_inches='tight')
    plt.show()

def print_model_analysis():
    """打印模型分析报告（纯英文）"""
    model = StableGenderCNN()
    total_params = sum(p.numel() for p in model.parameters())
    
    print("=" * 60)
    print("            CNN MODEL STRUCTURE ANALYSIS")
    print("=" * 60)
    
    print("\n1. MODEL OVERVIEW:")
    print("-" * 40)
    print("• Model Type: Convolutional Neural Network (CNN)")
    print("• Task: Binary Classification (Gender)")
    print("• Input Size: 3x128x128 (RGB Image)")
    print("• Output Size: 1 (Probability)")
    print(f"• Total Parameters: {total_params:,}")
    
    print("\n2. NETWORK ARCHITECTURE:")
    print("-" * 40)
    print("FEATURE EXTRACTION (Sequential):")
    print("  Block 1: Conv(3->32) -> BN -> ReLU -> MaxPool -> Dropout(0.1)")
    print("  Block 2: Conv(32->64) -> BN -> ReLU -> MaxPool -> Dropout(0.2)") 
    print("  Block 3: Conv(64->128) -> BN -> ReLU -> MaxPool -> Dropout(0.3)")
    print("  Block 4: Conv(128->256) -> BN -> ReLU -> AdaptiveAvgPool(4)")
    
    print("\nCLASSIFICATION (Sequential):")
    print("  Flatten -> Dropout(0.5) -> Linear(4096->128)")
    print("  -> ReLU -> BN -> Dropout(0.4) -> Linear(128->1)")
    
    print("\n3. DATA FLOW:")
    print("-" * 40)
    sizes = [
        "Input: 3x128x128",
        "-> Conv1: 32x128x128 -> Pool: 32x64x64",
        "-> Conv2: 64x64x64 -> Pool: 64x32x32", 
        "-> Conv3: 128x32x32 -> Pool: 128x16x16",
        "-> Conv4: 256x16x16 -> Global Pool: 256x4x4",
        "-> Flatten: 4096 -> Linear1: 128 -> Linear2: 1"
    ]
    for size in sizes:
        print(f"  {size}")
    
    print("\n4. DESIGN FEATURES:")
    print("-" * 40)
    print("• Progressive channel increase: 32 -> 64 -> 128 -> 256")
    print("• Progressive dropout: 0.1 -> 0.2 -> 0.3 -> 0.5 -> 0.4")
    print("• BatchNorm in every layer for faster convergence")
    print("• AdaptiveAvgPool for flexible input sizes")
    print("• Sigmoid activation for binary classification")
    
    print("\n5. LAYER DETAILS:")
    print("-" * 40)
    print("Conv Layers: 4 (3->32, 32->64, 64->128, 128->256)")
    print("Linear Layers: 2 (4096->128, 128->1)")
    print("BatchNorm Layers: 5 (4 in features, 1 in classifier)")
    print("Dropout Layers: 5 (progressive rates)")
    print("Activation: ReLU (hidden), Sigmoid (output)")

def main():
    """主函数"""
    print("Generating CNN Model Visualization...")
    
    # 打印文本分析
    print_model_analysis()
    
    # 生成可视化图表（全部使用英文）
    create_simple_architecture_diagram()
    print("✓ Generated model architecture: simple_model_architecture.png")
    
    create_model_flowchart() 
    print("✓ Generated model flowchart: model_flowchart.png")
    
    create_data_flow_diagram()
    print("✓ Generated data flow diagram: data_flow_diagram.png")
    
    total_params = create_layer_statistics()
    print("✓ Generated model statistics: model_statistics.png")
    
    print(f"\nTotal parameters: {total_params:,}")
    print("\nAll visualizations completed! Using English only to avoid font issues.")

if __name__ == "__main__":
    main()