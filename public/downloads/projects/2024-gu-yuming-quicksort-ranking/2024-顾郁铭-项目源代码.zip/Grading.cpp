#include <iostream>
#include <algorithm>
#include <ctime>
#include <cassert>
#include "InsertionSort.h"

using namespace std;


template <typename T>
int _partition(T arr[], int l, int r){

    swap( arr[l] , arr[rand()%(r-l+1)+l] );
    T v = arr[l];
    int i = l+1, j = r;
    while( true ){
        while( i <= r && arr[i] < v )
            i ++;

        while( j >= l+1 && arr[j] > v )
            j --;

        if( i > j )
            break;

        swap( arr[i] , arr[j] );
        i ++;
        j --;
    }

    swap( arr[l] , arr[j]);

    return j;
}

template <typename T>
void _quickSort(T arr[], int l, int r){

	// 䳤<=15ʱòٶȸ
    if( r - l <= 15 ){
        insertionSort(arr,l,r);
        return;
    }

    int p = _partition(arr, l, r);
    _quickSort(arr, l, p-1 );
    _quickSort(arr, p+1, r);
}

template <typename T>
void quickSort(T arr[], int n){

    srand(time(NULL));
    _quickSort(arr, 0, n-1);
}


template <typename T>
// · 
void __quickSort3Ways(T arr[], int l, int r){

    if( r - l <= 15 ){
        insertionSort(arr,l,r);
        return;
    }

    swap( arr[l], arr[rand()%(r-l+1)+l ] );

    T v = arr[l];

    int lt = l;     // arr[l+1...lt] < v
    int gt = r + 1; // arr[gt...r] > v
    int i = l+1;    // arr[lt+1...i) == v
    while( i < gt ){
        if( arr[i] < v ){
            swap( arr[i], arr[lt+1]);
            i ++;
            lt ++;
        }
        else if( arr[i] > v ){
            swap( arr[i], arr[gt-1]);
            gt --;
        }
        else{ // arr[i] == v
            i ++;
        }
    }

    swap( arr[l] , arr[lt] );

    __quickSort3Ways(arr, l, lt-1);
    __quickSort3Ways(arr, gt, r);
}

template <typename T>
void quickSort3Ways(T arr[], int n){

    srand(time(NULL));
    __quickSort3Ways( arr, 0, n-1);
}

// 
int *generateRandomArray(int n, int range_l, int range_r) {

        int *arr = new int[n];

        srand(time(NULL));
        for (int i = 0; i < n; i++)
            arr[i] = rand() % (range_r - range_l + 1) + range_l;
        return arr;
    }

//ʱ 
int *copyIntArray(int a[], int n){

    int *arr = new int[n];
    copy(a, a+n, arr);
    return arr;
}
    
template<typename T>
bool isSorted(T arr[], int n) {

    for (int i = 0; i < n - 1; i++)
        if (arr[i] > arr[i + 1])
            return false;
    return true;
}

bool areSameIntArrs(int* arr, int* arr2, int n){

    std::sort(arr,arr+n);
    std::sort(arr2,arr2+n);
    for( int i = 0 ; i < n ; i ++ )
        if( arr[i] != arr2[i] )
            return false;
    return true;
}

template<typename T>
void testSort(const string &sortName, void (*sort)(T[], int), T arr[], int n) {

    T* arr2 = copyIntArray(arr, n);

    clock_t startTime = clock();
    sort(arr, n);
    clock_t endTime = clock();
    cout << sortName << " : " << double(endTime - startTime) / CLOCKS_PER_SEC << " s"<<endl;

    assert(isSorted(arr, n));
    assert(areSameIntArrs(arr,arr2,n));
    delete[] arr2;
    return;
}
    
int main() {

	//Ϊn(Ŀǰ50) 
	int n = 500000;
	int *arr=generateRandomArray(n,0,100);
	__quickSort3Ways(arr,0,n);
	
	testSort("Time of Sort", quickSort3Ways, arr, n);
	
	double t1=86,t2=100,t3=71,t4=85,t5=56,t6=70,t7=41,t8=55,t9=30,t10=40,y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y,t;
	int n1,n2,n3,n4,n5,n6,n7,n8,n9;
	// ֶ 
	n1=n*0.85,n2=n-1;
	n3=n*0.5,n4=n1-1;
	n5=n*0.15,n6=n3-1;
	n7=n*0.02,n8=n5-1;
	n9=n7-1;
	y1=arr[n1];
	y2=arr[n2];
	y3=arr[n3];
	y4=arr[n4];
	y5=arr[n5];
	y6=arr[n6];
	y7=arr[n7];
	y8=arr[n8];
	y9=arr[n9];
	y10=arr[0];
	
	// ԭʼ֣ж䣬ݻ㹫ʽõת 
	cout<<"Original Grades:";
	cin>>y;
	if(y>=y1 && y<=y2)
		t=(t2*(y-y1)+t1*(y2-y))/(y2-y1);
	else if(y>=y3 && y<=y4)
		t=(t4*(y-y3)+t3*(y4-y))/(y4-y3);
	else if(y>=y5 && y<=y6)
		t=(t6*(y-y5)+t5*(y6-y))/(y6-y5);
	else if(y>=y1 && y<=y2)
		t=(t8*(y-y7)+t7*(y8-y))/(y8-y7);
	else t=(t10*(y-y9)+t9*(y10-y))/(y10-y9);
	printf("%.0f\n",t);
   
    delete[] arr;
    
    return 0;
}
